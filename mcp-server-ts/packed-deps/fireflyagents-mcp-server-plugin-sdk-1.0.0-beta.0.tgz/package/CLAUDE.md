# MCP Server Plugin Development with Claude

This guide demonstrates how Claude Code assists with MCP server plugin development using the Firefly Agents framework.

## Overview

The Firefly Agents MCP server plugin system extends the core framework with modular, reusable functionality. Claude helps streamline plugin development through intelligent code generation, testing, and documentation.

## Plugin Architecture

### Core Components

```typescript
// Plugin Interface Pattern
export interface ServerPlugin {
  // Tool registration - returns array of Tool objects
  getTools?(): Tool[];

  // Optional capabilities
  getResourceRegistrars?(): ResourceRegistrar[];
  getPromptRegistrars?(): PromptRegistrar[];

  // Account configuration for multi-tenant plugins
  getAccountConfig?(): PluginAccountConfig;

  // Health check for plugin monitoring
  healthCheck?(): Promise<{ healthy: boolean; details?: any }>;
}

// Tool Interface
export interface Tool {
  namespace: string;              // Tool namespace (e.g., 'demo')
  name: string;                   // Tool name (e.g., 'hello')
  title: string;                  // Human-readable title
  description?: string;           // Tool description
  paramsSchema: ZodRawShape;      // Input parameter schema
  outputSchema?: ZodRawShape;     // Optional output schema
  handler: ToolHandler;           // Execution handler
  options?: {
    readOnlyHint?: boolean;
    experimental?: boolean;
  };
}

// Handler function signature
export type ToolHandler = (
  params: Record<string, any>,
  extra?: RequestHandlerExtra  // Optional auth/session context
) => Promise<CallToolResult>;
```

### Development Workflow

1. **Plugin Scaffolding**
   - Claude generates boilerplate code following MCP patterns
   - Implements proper TypeScript interfaces
   - Sets up testing infrastructure

2. **Tool Implementation**
   - Claude assists with Zod schema definitions
   - Generates type-safe handlers
   - Implements error handling patterns

3. **Testing & Validation**
   - Unit test generation
   - Integration test scaffolding
   - Schema validation tests

## Example: Demo Plugin Development

### Phase 1: Plugin Structure

**Approach 1: Define Tools as Array**

```typescript
import { z } from '@fireflyagents/mcp-server-types';
import type { Tool, ServerPlugin } from '@fireflyagents/mcp-server-types';

// Define your tools
const helloTool: Tool = {
  namespace: 'demo',
  name: 'hello',
  title: 'Demo Hello Tool',
  description: 'Greets the user by name',
  paramsSchema: z.object({
    name: z.string().describe('Name to greet').optional()
  }).shape,
  options: { readOnlyHint: true },
  handler: async ({ name }) => ({
    content: [{
      type: "text",
      text: `Hello ${name ?? "world"}!`
    }]
  })
};

// Export as array
export const demoTools: Tool[] = [helloTool];

// Implement ServerPlugin interface
class DemoPlugin implements ServerPlugin {
  getTools(): Tool[] {
    return demoTools;
  }

  async healthCheck() {
    return {
      healthy: true,
      details: { plugin: 'demo-plugin', version: '1.0.0' }
    };
  }
}

export async function createPlugin(config: any): Promise<ServerPlugin> {
  return new DemoPlugin();
}
```

**Approach 2: Use Plugin Builder SDK**

```typescript
import { createPluginBuilder } from '@fireflyagents/mcp-server-plugin-sdk';
import { demoTools } from './tools';

export async function createPlugin(config: any): Promise<ServerPlugin> {
  return createPluginBuilder()
    .withTools(demoTools)
    .withHealthCheck(async () => ({
      healthy: true,
      details: { plugin: 'demo-plugin', version: '1.0.0' }
    }))
    .build();
}
```

### Phase 2: Testing Strategy

**Test Tool Logic Directly**

```typescript
import { describe, it, expect } from 'vitest';
import { demoTools } from './tools';

describe('Demo Plugin Tools', () => {
  let helloTool: Tool;

  beforeEach(() => {
    helloTool = demoTools.find(t => t.name === 'hello')!;
  });

  it('should have correct metadata', () => {
    expect(helloTool.namespace).toBe('demo');
    expect(helloTool.name).toBe('hello');
    expect(helloTool.title).toBe('Demo Hello Tool');
  });

  it('should greet with provided name', async () => {
    const result = await helloTool.handler({ name: 'Claude' });

    expect(result.content[0].type).toBe('text');
    expect((result.content[0] as any).text).toBe('Hello Claude!');
  });

  it('should use default greeting', async () => {
    const result = await helloTool.handler({});

    expect((result.content[0] as any).text).toBe('Hello world!');
  });
});
```

**Test Plugin Interface**

```typescript
describe('Demo Plugin', () => {
  let plugin: ServerPlugin;

  beforeEach(async () => {
    plugin = await createPlugin({ accountId: 'test-123' });
  });

  it('should provide tools', () => {
    const tools = plugin.getTools?.();
    expect(tools).toBeDefined();
    expect(Array.isArray(tools)).toBe(true);
    expect(tools?.length).toBeGreaterThan(0);
  });

  it('should pass health check', async () => {
    const health = await plugin.healthCheck?.();
    expect(health?.healthy).toBe(true);
  });
});
```

## Claude Code Integration

### Assisted Development

Claude Code helps with:

1. **Schema Design**
   - Suggests appropriate Zod validators
   - Ensures type safety
   - Documents schema patterns

2. **Error Handling**
   - Implements graceful error recovery
   - Adds proper logging
   - Follows MCP error conventions

3. **Documentation**
   - Generates inline documentation
   - Creates usage examples
   - Maintains consistency

### Best Practices

#### Tool Registration

```typescript
// ✅ Good: Explicit schema with descriptions
const schema = z.object({
  query: z.string().describe('Search query'),
  limit: z.number().optional().describe('Result limit')
});

// ❌ Bad: Missing descriptions
const schema = z.object({
  query: z.string(),
  limit: z.number().optional()
});
```

#### Handler Implementation

```typescript
// ✅ Good: Comprehensive error handling
handler: async (params, extra) => {
  try {
    const result = await processRequest(params);
    return {
      content: [{ type: "text", text: JSON.stringify(result) }]
    };
  } catch (error) {
    logger.error('Handler failed', { error, params });
    throw error;
  }
}

// ❌ Bad: No error handling
handler: async (params) => {
  const result = await processRequest(params);
  return { content: [{ type: "text", text: JSON.stringify(result) }] };
}
```

## Plugin Builder SDK

The Plugin Builder SDK provides a fluent interface for creating plugins with common patterns.

### Basic Usage

```typescript
import { createPluginBuilder } from '@fireflyagents/mcp-server-plugin-sdk';

const plugin = createPluginBuilder()
  .withTools(myTools)
  .withHealthCheck(async () => ({
    healthy: true,
    details: { status: 'ok' }
  }))
  .build();
```

### Account-Aware Plugins

```typescript
const plugin = createPluginBuilder()
  .withTools(myTools)
  .withAccountConfig({
    accountId: 'account-123',
    tenantId: 'tenant-456',
    features: ['feature-a', 'feature-b'],
    metadata: { tier: 'premium' }
  })
  .withHealthCheck(async () => ({
    healthy: true,
    details: { accountId: 'account-123' }
  }))
  .build();
```

### Plugin Templates

The SDK provides pre-built templates for common plugin patterns:

```typescript
import { createPluginTemplate } from '@fireflyagents/mcp-server-plugin-sdk';

// Minimal plugin with just health check
const minimalPlugin = createPluginTemplate('minimal', {
  name: 'my-minimal-plugin',
  version: '1.0.0'
});

// Tools-only plugin
const toolsPlugin = createPluginTemplate('tools-only', {
  name: 'my-tools-plugin',
  version: '1.0.0'
});

// Account-aware plugin
const accountPlugin = createPluginTemplate('account-aware', {
  name: 'my-account-plugin',
  version: '1.0.0',
  accountId: 'account-123',
  tenantId: 'tenant-456'
});

// Full-featured plugin
const fullPlugin = createPluginTemplate('full-featured', {
  name: 'my-full-plugin',
  version: '1.0.0',
  accountId: 'account-123',
  features: ['tools', 'resources', 'prompts']
});
```

## Integration Patterns

### With Core Server

```typescript
import { createMcpServer } from '@fireflyagents/mcp-server-core';
import { demoPlugin } from '@fireflyagents/demo-plugin';

const server = await createMcpServer({
  name: 'my-server',
  version: '1.0.0',
  plugins: [demoPlugin]
});

server.listen(3000);
```

### With Shared Utilities

```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';
import { validateSchema } from '@fireflyagents/mcp-shared-utils';

export const myTool: Tool = {
  namespace: 'demo',
  name: 'my-tool',
  handler: async (params) => {
    logger.debug('Tool called', { params });

    const validated = validateSchema(params, paramsSchema);

    return processRequest(validated);
  }
};
```

## Testing Approach

### Unit Tests

```typescript
describe('Tool Handler', () => {
  it('validates input schema', async () => {
    const invalidParams = { query: 123 }; // Should be string

    await expect(handler(invalidParams)).rejects.toThrow();
  });

  it('returns correct format', async () => {
    const result = await handler({ query: 'test' });

    expect(result).toHaveProperty('content');
    expect(Array.isArray(result.content)).toBe(true);
  });
});
```

### Integration Tests

```typescript
describe('Plugin Integration', () => {
  let server: McpServer;

  beforeAll(async () => {
    server = await createMcpServer({
      plugins: [demoPlugin]
    });
    await server.start();
  });

  afterAll(async () => {
    await server.stop();
  });

  it('registers tools correctly', () => {
    const tools = server.getTools();
    expect(tools).toContain('demo/hello');
  });
});
```

## Distribution

### Package Structure

```
plugins/demo-plugin/
├── src/
│   ├── index.ts           # Main plugin export
│   ├── tools/             # Tool implementations
│   ├── prompts/           # Prompt templates
│   └── resources/         # Resource handlers
├── tests/
│   ├── unit/              # Unit tests
│   └── integration/       # Integration tests
├── package.json
├── tsconfig.json
└── CLAUDE.md              # This file
```

### Publishing

```bash
# Build plugin
npm run build

# Run tests
npm run test:coverage

# Publish to registry
npm publish
```

## Claude Code Workflow

### Development Session

1. **Create Plugin Structure**
   ```
   User: "Create a new MCP plugin for weather data"
   Claude: [Generates plugin scaffold with proper structure]
   ```

2. **Implement Tools**
   ```
   User: "Add a tool to get current weather"
   Claude: [Creates tool with schema and handler]
   ```

3. **Add Tests**
   ```
   User: "Write tests for the weather tool"
   Claude: [Generates comprehensive test suite]
   ```

4. **Documentation**
   ```
   User: "Document the plugin API"
   Claude: [Updates README and inline docs]
   ```

## Common Patterns

### Configuration Schema

```typescript
export const configSchema = z.object({
  apiKey: z.string().describe('API key for service'),
  timeout: z.number().default(5000).describe('Request timeout in ms'),
  cache: z.boolean().default(true).describe('Enable caching')
});

export type PluginConfig = z.infer<typeof configSchema>;
```

### Error Handling

```typescript
export class PluginError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: unknown
  ) {
    super(message);
    this.name = 'PluginError';
  }
}

// Usage
throw new PluginError(
  'Failed to fetch data',
  'FETCH_ERROR',
  { url, status: response.status }
);
```

### Logging

```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';

logger.info('Operation started', { operation: 'fetch', params });
logger.debug('Processing data', { recordCount: data.length });
logger.error('Operation failed', { error, operation: 'fetch' });
```

## Next Steps

1. Review `packages/server/core/CLAUDE.md` for core concepts
2. Explore `packages/shared/utils/CLAUDE.md` for utilities
3. Check example plugins in `plugins/` directory
4. Run `npm run test` to verify setup
5. Start building your plugin!

## Resources

- [MCP Specification](https://modelcontextprotocol.io)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Zod Documentation](https://zod.dev)
- [Vitest Guide](https://vitest.dev/guide/)

---

Generated with Claude Code - Your AI pair programmer for MCP development.
