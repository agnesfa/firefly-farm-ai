import { describe, it, expect } from 'vitest';
import { createPluginBuilder } from './plugin-builder.js';
import { createMockTool } from '../utils/testing.js';

describe('PluginBuilder', () => {
  describe('createPluginBuilder', () => {
    it('should create builder instance', () => {
      const builder = createPluginBuilder();

      expect(builder).toBeDefined();
      expect(typeof builder.build).toBe('function');
    });

    it('should create builder with config', () => {
      const builder = createPluginBuilder({
        accountId: 'test-account',
        tenantId: 'test-tenant',
        features: ['feature1'],
        metadata: { key: 'value' }
      });

      expect(builder).toBeDefined();
    });
  });

  describe('withTools', () => {
    it('should add tools to builder', () => {
      const tool = createMockTool();
      const plugin = createPluginBuilder()
        .withTools([tool])
        .build();

      expect(plugin.getTools).toBeDefined();
      const tools = plugin.getTools!();
      expect(tools).toHaveLength(1);
      expect(tools[0]).toBe(tool);
    });

    it('should accept tool factory function', () => {
      const tool = createMockTool();
      const plugin = createPluginBuilder()
        .withTools(() => [tool])
        .build();

      const tools = plugin.getTools!();
      expect(tools).toHaveLength(1);
      expect(tools[0]).toBe(tool);
    });

    it('should support multiple tool additions', () => {
      const tool1 = createMockTool({ name: 'tool1' });
      const tool2 = createMockTool({ name: 'tool2' });
      const plugin = createPluginBuilder()
        .withTools([tool1])
        .withTools([tool2])
        .build();

      const tools = plugin.getTools!();
      expect(tools).toHaveLength(2);
    });

    it('should not define getTools when no tools added', () => {
      const plugin = createPluginBuilder().build();

      expect(plugin.getTools).toBeUndefined();
    });
  });

  describe('withResources', () => {
    it('should add resources to builder', () => {
      const resource = {
        namespace: 'test',
        name: 'resource',
        title: 'Test Resource',
        uriTemplate: 'test://resource',
        handler: async () => ({ contents: [] })
      };

      const plugin = createPluginBuilder()
        .withResources([resource])
        .build();

      expect(plugin.getResources).toBeDefined();
      const resources = plugin.getResources!();
      expect(resources).toHaveLength(1);
      expect(resources[0]).toBe(resource);
    });

    it('should accept resource factory function', () => {
      const resource = {
        namespace: 'test',
        name: 'resource',
        title: 'Test Resource',
        uriTemplate: 'test://resource',
        handler: async () => ({ contents: [] })
      };

      const plugin = createPluginBuilder()
        .withResources(() => [resource])
        .build();

      const resources = plugin.getResources!();
      expect(resources).toHaveLength(1);
    });

    it('should not define getResources when no resources added', () => {
      const plugin = createPluginBuilder().build();

      expect(plugin.getResources).toBeUndefined();
    });
  });

  describe('withPrompts', () => {
    it('should add prompts to builder', () => {
      const prompt = {
        namespace: 'test',
        name: 'prompt',
        title: 'Test Prompt',
        handler: async () => ({ messages: [] })
      };

      const plugin = createPluginBuilder()
        .withPrompts([prompt])
        .build();

      expect(plugin.getPrompts).toBeDefined();
      const prompts = plugin.getPrompts!();
      expect(prompts).toHaveLength(1);
      expect(prompts[0]).toBe(prompt);
    });

    it('should accept prompt factory function', () => {
      const prompt = {
        namespace: 'test',
        name: 'prompt',
        title: 'Test Prompt',
        handler: async () => ({ messages: [] })
      };

      const plugin = createPluginBuilder()
        .withPrompts(() => [prompt])
        .build();

      const prompts = plugin.getPrompts!();
      expect(prompts).toHaveLength(1);
    });

    it('should not define getPrompts when no prompts added', () => {
      const plugin = createPluginBuilder().build();

      expect(plugin.getPrompts).toBeUndefined();
    });
  });

  describe('withAccountConfig', () => {
    it('should set account configuration', () => {
      const accountConfig = {
        accountId: 'test-account',
        tenantId: 'test-tenant',
        features: ['feature1'],
        metadata: { key: 'value' }
      };

      const plugin = createPluginBuilder()
        .withAccountConfig(accountConfig)
        .build();

      expect(plugin.getAccountConfig).toBeDefined();
      const config = plugin.getAccountConfig!();
      expect(config).toEqual(accountConfig);
    });

    it('should not define getAccountConfig when not set', () => {
      const plugin = createPluginBuilder().build();

      expect(plugin.getAccountConfig).toBeUndefined();
    });
  });

  describe('withHealthCheck', () => {
    it('should use custom health check', async () => {
      const customHealth = { healthy: true, details: { custom: true } };
      const plugin = createPluginBuilder()
        .withHealthCheck(async () => customHealth)
        .build();

      const result = await plugin.healthCheck();
      expect(result).toEqual(customHealth);
    });

    it('should use default health check when not provided', async () => {
      const plugin = createPluginBuilder().build();

      const result = await plugin.healthCheck();
      expect(result.healthy).toBe(true);
      expect(result.details).toBeDefined();
    });

    it('should include capability counts in default health check', async () => {
      const tool = createMockTool();
      const plugin = createPluginBuilder()
        .withTools([tool])
        .build();

      const result = await plugin.healthCheck();
      expect(result.details?.toolCount).toBe(1);
    });
  });

  describe('build', () => {
    it('should build plugin with all features', () => {
      const tool = createMockTool();
      const resource = {
        namespace: 'test',
        name: 'resource',
        title: 'Test Resource',
        uriTemplate: 'test://resource',
        handler: async () => ({ contents: [] })
      };
      const prompt = {
        namespace: 'test',
        name: 'prompt',
        title: 'Test Prompt',
        handler: async () => ({ messages: [] })
      };
      const accountConfig = {
        accountId: 'test-account',
        tenantId: 'test-tenant'
      };

      const plugin = createPluginBuilder()
        .withTools([tool])
        .withResources([resource])
        .withPrompts([prompt])
        .withAccountConfig(accountConfig)
        .withHealthCheck(async () => ({ healthy: true, details: { test: true } }))
        .build();

      expect(plugin.getTools).toBeDefined();
      expect(plugin.getResources).toBeDefined();
      expect(plugin.getPrompts).toBeDefined();
      expect(plugin.getAccountConfig).toBeDefined();
      expect(plugin.healthCheck).toBeDefined();
    });

    it('should build minimal plugin', () => {
      const plugin = createPluginBuilder().build();

      expect(plugin.getTools).toBeUndefined();
      expect(plugin.getResources).toBeUndefined();
      expect(plugin.getPrompts).toBeUndefined();
      expect(plugin.getAccountConfig).toBeUndefined();
      expect(plugin.healthCheck).toBeDefined();
    });
  });
});