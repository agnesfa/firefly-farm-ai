import { describe, it, expect } from 'vitest';
import { PluginHealthChecker } from './health-checker.js';
import { createMockPlugin, createMockTool } from '../utils/testing.js';
import type { ServerPlugin } from '@fireflyagents/mcp-server-types';

describe('PluginHealthChecker', () => {
  describe('check', () => {
    it('should return healthy for basic plugin', async () => {
      const plugin = createMockPlugin();

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      // Details may be undefined for minimal plugins
    });

    it('should include plugin name in details when provided', async () => {
      const plugin = createMockPlugin();

      const result = await PluginHealthChecker.check(plugin, 'test-plugin');

      expect(result.details?.name).toBe('test-plugin');
    });

    it('should return unhealthy when plugin health check fails', async () => {
      const plugin = createMockPlugin({
        healthResult: { healthy: false, details: { error: 'Test failure' } }
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(false);
      expect(result.details?.errors).toContain('Plugin health check failed');
    });

    it('should detect tools capability', async () => {
      const mockTool = createMockTool();
      const plugin = createMockPlugin({
        tools: [mockTool]
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.capabilities).toContain('1 tools');
    });

    it('should detect resources capability', async () => {
      const plugin = createMockPlugin({
        resources: [{
          namespace: 'test',
          name: 'resource',
          title: 'Test Resource',
          uriTemplate: 'test://resource',
          handler: async () => ({ contents: [] })
        }]
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.capabilities).toContain('1 resources');
    });

    it('should detect prompts capability', async () => {
      const plugin = createMockPlugin({
        prompts: [{
          namespace: 'test',
          name: 'prompt',
          title: 'Test Prompt',
          handler: async () => ({ messages: [] })
        }]
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.capabilities).toContain('1 prompts');
    });

    it('should detect account-aware capability', async () => {
      const plugin = createMockPlugin({
        accountConfig: {
          accountId: 'test-account-123',
          tenantId: 'test-tenant-456'
        }
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.capabilities).toContain('account-aware');
    });

    it('should warn when account config missing accountId', async () => {
      const plugin: ServerPlugin = {
        getAccountConfig: () => ({
          accountId: '',
          tenantId: 'test-tenant'
        }),
        healthCheck: async () => ({ healthy: true })
      };

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.warnings).toContain('Account config missing accountId');
    });

    it('should validate tool structure', async () => {
      const invalidTool: any = { name: 'test' }; // Missing required fields
      const plugin = createMockPlugin({
        tools: [invalidTool]
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(false);
      expect(result.details?.errors).toContain('Invalid tool - must have name, namespace, and handler');
    });

    it('should handle plugin health check throwing error', async () => {
      const plugin = createMockPlugin({
        shouldThrow: true
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(false);
      expect(result.details?.errors).toBeDefined();
    });

    it('should handle multiple tools', async () => {
      const tool1 = createMockTool({ name: 'tool1' });
      const tool2 = createMockTool({ name: 'tool2' });
      const plugin = createMockPlugin({
        tools: [tool1, tool2]
      });

      const result = await PluginHealthChecker.check(plugin);

      expect(result.healthy).toBe(true);
      expect(result.details?.capabilities).toContain('2 tools');
    });
  });

  describe('quickCheck', () => {
    it('should return true for healthy plugin', async () => {
      const plugin = createMockPlugin();

      const result = await PluginHealthChecker.quickCheck(plugin);

      expect(result).toBe(true);
    });

    it('should return false for unhealthy plugin', async () => {
      const plugin = createMockPlugin({
        healthResult: { healthy: false }
      });

      const result = await PluginHealthChecker.quickCheck(plugin);

      expect(result).toBe(false);
    });

    it('should return false when health check throws', async () => {
      const plugin = createMockPlugin({
        shouldThrow: true
      });

      const result = await PluginHealthChecker.quickCheck(plugin);

      expect(result).toBe(false);
    });
  });
});