import type {
  ServerPlugin,
  Tool,
  Prompt,
  Resource,
  PluginAccountConfig
} from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:plugin-sdk:plugin-builder' });

/**
 * Plugin Builder Configuration
 */
export interface PluginBuilderConfig {
  accountId?: string;
  tenantId?: string;
  features?: string[];
  metadata?: Record<string, any>;
}

/**
 * Plugin Builder - Helper for creating ServerPlugin instances
 *
 * Provides a builder interface for building plugins with common patterns
 * and best practices built in.
 */
export class PluginBuilder {
  private tools: Tool[] = [];
  private resources: Resource[] = [];
  private prompts: Prompt[] = [];
  private accountConfig?: PluginAccountConfig;
  private healthCheckFn?: () => Promise<{ healthy: boolean; details?: any }>;

  constructor(private config: PluginBuilderConfig = {}) {}

  /**
   * Add tools to the plugin
   */
  withTools(toolsOrFactory: Tool[] | (() => Tool[])): this {
    const tools = typeof toolsOrFactory === 'function' ? toolsOrFactory() : toolsOrFactory;
    this.tools.push(...tools);
    return this;
  }

  /**
   * Add resources to the plugin
   */
  withResources(resourcesOrFactory: Resource[] | (() => Resource[])): this {
    const resources = typeof resourcesOrFactory === 'function' ? resourcesOrFactory() : resourcesOrFactory;
    this.resources.push(...resources);
    return this;
  }

  /**
   * Add prompts to the plugin
   */
  withPrompts(promptsOrFactory: Prompt[] | (() => Prompt[])): this {
    const prompts = typeof promptsOrFactory === 'function' ? promptsOrFactory() : promptsOrFactory;
    this.prompts.push(...prompts);
    return this;
  }

  /**
   * Set account configuration
   */
  withAccountConfig(config: PluginAccountConfig): this {
    this.accountConfig = config;
    return this;
  }

  /**
   * Set custom health check function
   */
  withHealthCheck(fn: () => Promise<{ healthy: boolean; details?: any }>): this {
    this.healthCheckFn = fn;
    return this;
  }

  /**
   * Build the ServerPlugin instance
   */
  build(): ServerPlugin {
    const startTime = Date.now();
    const pluginName = this.config.accountId || this.config.metadata?.name || 'unnamed';

    logger.info('Plugin build started', {
      pluginName,
      hasTools: this.tools.length > 0,
      toolCount: this.tools.length,
      hasResources: this.resources.length > 0,
      resourceCount: this.resources.length,
      hasPrompts: this.prompts.length > 0,
      promptCount: this.prompts.length,
      hasHealthCheck: !!this.healthCheckFn,
      hasAccountConfig: !!this.accountConfig,
      config: this.config
    });

    try {
      const plugin = {
        getTools: this.tools.length > 0
          ? () => this.tools
          : undefined,

        getResources: this.resources.length > 0
          ? () => this.resources
          : undefined,

        getPrompts: this.prompts.length > 0
          ? () => this.prompts
          : undefined,

        getAccountConfig: this.accountConfig
          ? () => this.accountConfig!
          : undefined,

        healthCheck: this.healthCheckFn || this.defaultHealthCheck.bind(this)
      };

      const capabilities = [];
      if (plugin.getTools) capabilities.push('tools');
      if (plugin.getResources) capabilities.push('resources');
      if (plugin.getPrompts) capabilities.push('prompts');
      if (plugin.getAccountConfig) capabilities.push('account-config');
      capabilities.push('health-check');

      logger.info('Plugin build completed', {
        pluginName,
        capabilities,
        duration: Date.now() - startTime,
        success: true
      });

      return plugin;
    } catch (error) {
      logger.error('Plugin build failed', {
        pluginName,
        error: error instanceof Error ? error.message : String(error),
        duration: Date.now() - startTime
      });
      throw error;
    }
  }

  /**
   * Default health check implementation
   */
  private async defaultHealthCheck(): Promise<{ healthy: boolean; details?: any }> {
    return {
      healthy: true,
      details: {
        toolCount: this.tools.length,
        resourceCount: this.resources.length,
        promptCount: this.prompts.length,
        hasAccountConfig: !!this.accountConfig
      }
    };
  }
}

/**
 * Create a new plugin builder instance
 */
export function createPluginBuilder(config?: PluginBuilderConfig): PluginBuilder {
  logger.info('Creating plugin builder instance', { 
    hasConfig: !!config,
    accountId: config?.accountId,
    tenantId: config?.tenantId,
    featuresCount: config?.features?.length || 0,
    hasMetadata: !!config?.metadata
  });
  
  return new PluginBuilder(config);
}