import type { ServerPlugin } from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:plugin-sdk:health-checker' });

/**
 * Health Check Results
 */
export interface PluginHealthResult {
  healthy: boolean;
  details?: {
    name?: string;
    version?: string;
    capabilities?: string[];
    errors?: string[];
    warnings?: string[];
  };
}

/**
 * Plugin Health Checker - Validates plugin functionality and configuration
 */
export class PluginHealthChecker {
  /**
   * Perform comprehensive health check on a plugin
   */
  static async check(plugin: ServerPlugin, pluginName?: string): Promise<PluginHealthResult> {
    const startTime = Date.now();
    const name = pluginName || 'unnamed-plugin';
    
    logger.info('Plugin health check started', {
      pluginName: name,
      hasTools: !!plugin.getTools,
      hasResources: !!plugin.getResources,
      hasPrompts: !!plugin.getPrompts,
      hasAccountConfig: !!plugin.getAccountConfig
    });

    const details: PluginHealthResult['details'] = {
      name: pluginName,
      capabilities: [],
      errors: [],
      warnings: []
    };

    try {
      // Check basic health
      const basicHealth = await plugin.healthCheck();
      if (!basicHealth.healthy) {
        details.errors?.push('Plugin health check failed');
        logger.warn('Plugin basic health check failed', {
          pluginName: name,
          basicHealth,
          duration: Date.now() - startTime
        });
        return { healthy: false, details };
      }

      // Check capabilities
      if (plugin.getTools) {
        const tools = plugin.getTools();
        details.capabilities?.push(`${tools.length} tools`);
        logger.debug('Plugin tools validated', {
          pluginName: name,
          toolCount: tools.length
        });
      }

      if (plugin.getResources) {
        const resources = plugin.getResources();
        details.capabilities?.push(`${resources.length} resources`);
        logger.debug('Plugin resources validated', {
          pluginName: name,
          resourceCount: resources.length
        });
      }

      if (plugin.getPrompts) {
        const prompts = plugin.getPrompts();
        details.capabilities?.push(`${prompts.length} prompts`);
        logger.debug('Plugin prompts validated', {
          pluginName: name,
          promptCount: prompts.length
        });
      }

      if (plugin.getAccountConfig) {
        const accountConfig = plugin.getAccountConfig();
        if (!accountConfig.accountId) {
          details.warnings?.push('Account config missing accountId');
          logger.warn('Plugin account config missing accountId', { 
            pluginName: name 
          });
        }
        details.capabilities?.push('account-aware');
        logger.debug('Plugin account config validated', { 
          pluginName: name, 
          hasAccountId: !!accountConfig.accountId,
          tenantId: accountConfig.tenantId
        });
      }

      // Validate tools
      if (plugin.getTools) {
        const tools = plugin.getTools();
        for (let i = 0; i < tools.length; i++) {
          const tool = tools[i];
          if (typeof tool !== 'object' || !tool.name || !tool.namespace || typeof tool.handler !== 'function') {
            details.errors?.push('Invalid tool - must have name, namespace, and handler');
            logger.error('Invalid tool detected', {
              pluginName: name,
              toolIndex: i,
              toolType: typeof tool,
              hasName: !!tool?.name,
              hasNamespace: !!tool?.namespace,
              hasHandler: typeof tool?.handler === 'function'
            });
          }
        }
      }

      const hasErrors = details.errors && details.errors.length > 0;
      
      // Return details if there's any content or if pluginName was provided
      const hasContent = details.capabilities?.length || details.errors?.length || details.warnings?.length || details.name;
      
      const result = {
        healthy: !hasErrors,
        details: hasContent ? details : undefined
      };

      logger.info('Plugin health check completed', {
        pluginName: name,
        healthy: result.healthy,
        capabilities: details.capabilities || [],
        errorCount: details.errors?.length || 0,
        warningCount: details.warnings?.length || 0,
        duration: Date.now() - startTime,
        success: true
      });

      return result;

    } catch (error) {
      const errorMessage = `Health check failed: ${error instanceof Error ? error.message : String(error)}`;
      details.errors?.push(errorMessage);
      
      logger.error('Plugin health check failed with exception', {
        pluginName: name,
        error: error instanceof Error ? error.message : String(error),
        duration: Date.now() - startTime
      });
      
      return { healthy: false, details };
    }
  }

  /**
   * Quick health check - just calls plugin.healthCheck()
   */
  static async quickCheck(plugin: ServerPlugin): Promise<boolean> {
    const startTime = Date.now();
    
    logger.debug('Plugin quick health check started');
    
    try {
      const result = await plugin.healthCheck();
      const duration = Date.now() - startTime;
      
      logger.debug('Plugin quick health check completed', {
        healthy: result.healthy,
        duration,
        success: true
      });
      
      return result.healthy;
    } catch (error) {
      logger.warn('Plugin quick health check failed', {
        error: error instanceof Error ? error.message : String(error),
        duration: Date.now() - startTime
      });
      return false;
    }
  }
}