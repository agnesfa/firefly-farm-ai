import { describe, it, expect } from 'vitest';
import { createPluginTemplate } from './templates.js';

describe('createPluginTemplate', () => {
  describe('minimal template', () => {
    it('should create minimal plugin', () => {
      const plugin = createPluginTemplate('minimal');

      expect(plugin).toBeDefined();
      expect(plugin.healthCheck).toBeDefined();
      expect(plugin.getTools).toBeUndefined();
      expect(plugin.getResources).toBeUndefined();
      expect(plugin.getPrompts).toBeUndefined();
    });

    it('should include plugin name in health check', async () => {
      const plugin = createPluginTemplate('minimal', {
        name: 'test-plugin',
        version: '1.0.0'
      });

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.name).toBe('test-plugin');
      expect(health.details?.version).toBe('1.0.0');
      expect(health.details?.template).toBe('minimal');
    });

    it('should use defaults when config not provided', async () => {
      const plugin = createPluginTemplate('minimal');

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.name).toBe('minimal-plugin');
    });
  });

  describe('tools-only template', () => {
    it('should create tools-only plugin', () => {
      const plugin = createPluginTemplate('tools-only');

      expect(plugin).toBeDefined();
      expect(plugin.healthCheck).toBeDefined();
    });

    it('should include correct capabilities in health check', async () => {
      const plugin = createPluginTemplate('tools-only', {
        name: 'tools-plugin'
      });

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.template).toBe('tools-only');
      expect(health.details?.capabilities).toContain('tools');
    });
  });

  describe('account-aware template', () => {
    it('should create account-aware plugin', () => {
      const plugin = createPluginTemplate('account-aware', {
        accountId: 'test-account',
        tenantId: 'test-tenant'
      });

      expect(plugin).toBeDefined();
      expect(plugin.getAccountConfig).toBeDefined();
    });

    it('should throw error when accountId missing', () => {
      expect(() => {
        createPluginTemplate('account-aware', {
          name: 'test-plugin'
        });
      }).toThrow('Account-aware plugin requires accountId');
    });

    it('should include account config in plugin', () => {
      const plugin = createPluginTemplate('account-aware', {
        accountId: 'test-account-123',
        tenantId: 'test-tenant-456',
        features: ['feature1', 'feature2'],
        metadata: { custom: 'data' }
      });

      const config = plugin.getAccountConfig!();
      expect(config.accountId).toBe('test-account-123');
      expect(config.tenantId).toBe('test-tenant-456');
      expect(config.features).toEqual(['feature1', 'feature2']);
      expect(config.metadata).toHaveProperty('custom', 'data');
    });

    it('should use default features when not provided', () => {
      const plugin = createPluginTemplate('account-aware', {
        accountId: 'test-account'
      });

      const config = plugin.getAccountConfig!();
      expect(config.features).toEqual([]);
    });

    it('should include account info in health check', async () => {
      const plugin = createPluginTemplate('account-aware', {
        accountId: 'test-account-123',
        name: 'account-plugin'
      });

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.accountId).toBe('test-account-123');
      expect(health.details?.template).toBe('account-aware');
      expect(health.details?.capabilities).toContain('account-aware');
    });
  });

  describe('full-featured template', () => {
    it('should create full-featured plugin', () => {
      const plugin = createPluginTemplate('full-featured', {
        accountId: 'test-account',
        features: ['tools', 'resources', 'prompts']
      });

      expect(plugin).toBeDefined();
      expect(plugin.getAccountConfig).toBeDefined();
    });

    it('should throw error when accountId missing', () => {
      expect(() => {
        createPluginTemplate('full-featured', {
          name: 'test-plugin'
        });
      }).toThrow('Full-featured plugin requires accountId');
    });

    it('should use default features when not provided', () => {
      const plugin = createPluginTemplate('full-featured', {
        accountId: 'test-account'
      });

      const config = plugin.getAccountConfig!();
      expect(config.features).toEqual(['tools', 'resources', 'prompts']);
    });

    it('should include all capabilities in health check', async () => {
      const plugin = createPluginTemplate('full-featured', {
        accountId: 'test-account-123',
        name: 'full-plugin',
        version: '2.0.0'
      });

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.template).toBe('full-featured');
      expect(health.details?.accountId).toBe('test-account-123');
      expect(health.details?.capabilities).toEqual(['tools', 'resources', 'prompts', 'account-aware']);
    });
  });

  describe('error handling', () => {
    it('should throw error for unknown template', () => {
      expect(() => {
        createPluginTemplate('unknown' as any);
      }).toThrow('Unknown plugin template: unknown');
    });
  });

  describe('configuration options', () => {
    it('should support custom description', async () => {
      const plugin = createPluginTemplate('minimal', {
        name: 'custom-plugin',
        description: 'Custom description'
      });

      expect(plugin).toBeDefined();
    });

    it('should support custom metadata', () => {
      const plugin = createPluginTemplate('account-aware', {
        accountId: 'test',
        metadata: {
          custom: 'value',
          nested: { key: 'data' }
        }
      });

      const config = plugin.getAccountConfig!();
      expect(config.metadata).toHaveProperty('custom', 'value');
      expect(config.metadata).toHaveProperty('nested');
    });
  });
});