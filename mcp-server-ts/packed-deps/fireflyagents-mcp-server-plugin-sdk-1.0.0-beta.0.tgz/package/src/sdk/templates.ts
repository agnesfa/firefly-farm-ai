import type { ServerPlugin } from '@fireflyagents/mcp-server-types';
import { createPluginBuilder, PluginBuilder, type PluginBuilderConfig } from './plugin-builder.js';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:plugin-sdk:plugin-template' });

/**
 * Plugin Template Types
 */
export type PluginTemplate = 'minimal' | 'tools-only' | 'account-aware' | 'full-featured';

/**
 * Template Configuration
 */
export interface PluginTemplateConfig extends PluginBuilderConfig {
  name?: string;
  version?: string;
  description?: string;
}

/**
 * Create a plugin from a template
 */
export function createPluginTemplate(
  template: PluginTemplate, 
  config: PluginTemplateConfig = {}
): ServerPlugin {
  const startTime = Date.now();
  const pluginName = config.name || `${template}-plugin`;
  
  logger.info('Creating plugin from template', {
    templateType: template,
    pluginName,
    version: config.version || '1.0.0',
    description: config.description,
    hasConfig: Object.keys(config).length > 0,
    config
  });

  try {
    const builder = createPluginBuilder(config);

    let plugin: ServerPlugin;
    switch (template) {
      case 'minimal':
        plugin = createMinimalPlugin(builder, config);
        break;
      
      case 'tools-only':
        plugin = createToolsOnlyPlugin(builder, config);
        break;
      
      case 'account-aware':
        plugin = createAccountAwarePlugin(builder, config);
        break;
      
      case 'full-featured':
        plugin = createFullFeaturedPlugin(builder, config);
        break;
      
      default:
        logger.error('Unknown plugin template requested', { templateType: template });
        throw new Error(`Unknown plugin template: ${template}`);
    }

    // Determine capabilities from the plugin
    const capabilities = [];
    if (plugin.getTools) capabilities.push('tools');
    if (plugin.getResources) capabilities.push('resources');
    if (plugin.getPrompts) capabilities.push('prompts');
    if (plugin.getAccountConfig) capabilities.push('account-config');
    capabilities.push('health-check');

    logger.info('Plugin template created successfully', {
      templateType: template,
      pluginName,
      capabilities,
      duration: Date.now() - startTime,
      success: true
    });

    return plugin;
  } catch (error) {
    logger.error('Plugin template creation failed', {
      templateType: template,
      pluginName,
      error: error instanceof Error ? error.message : String(error),
      duration: Date.now() - startTime
    });
    throw error;
  }
}

/**
 * Minimal Plugin Template - Basic structure only
 */
function createMinimalPlugin(builder: PluginBuilder, config: PluginTemplateConfig): ServerPlugin {
  return builder
    .withHealthCheck(async () => ({
      healthy: true,
      details: {
        name: config.name || 'minimal-plugin',
        version: config.version || '1.0.0',
        template: 'minimal'
      }
    }))
    .build();
}

/**
 * Tools-Only Plugin Template - For plugins that only provide tools
 */
function createToolsOnlyPlugin(builder: PluginBuilder, config: PluginTemplateConfig): ServerPlugin {
  // Add tools using builder.withTools([...]) in your implementation

  return builder
    .withHealthCheck(async () => ({
      healthy: true,
      details: {
        name: config.name || 'tools-plugin',
        version: config.version || '1.0.0',
        template: 'tools-only',
        capabilities: ['tools']
      }
    }))
    .build();
}

/**
 * Account-Aware Plugin Template - For plugins that need account context
 */
function createAccountAwarePlugin(builder: PluginBuilder, config: PluginTemplateConfig): ServerPlugin {
  if (!config.accountId) {
    throw new Error('Account-aware plugin requires accountId in config');
  }

  return builder
    .withAccountConfig({
      accountId: config.accountId,
      tenantId: config.tenantId,
      features: config.features || [],
      metadata: config.metadata || {}
    })
    .withHealthCheck(async () => ({
      healthy: true,
      details: {
        name: config.name || 'account-aware-plugin',
        version: config.version || '1.0.0',
        template: 'account-aware',
        accountId: config.accountId,
        capabilities: ['account-aware']
      }
    }))
    .build();
}

/**
 * Full-Featured Plugin Template - All capabilities
 */
function createFullFeaturedPlugin(builder: PluginBuilder, config: PluginTemplateConfig): ServerPlugin {
  if (!config.accountId) {
    throw new Error('Full-featured plugin requires accountId in config');
  }

  // Add tools using builder.withTools([...]) in your implementation

  return builder
    .withAccountConfig({
      accountId: config.accountId,
      tenantId: config.tenantId,
      features: config.features || ['tools', 'resources', 'prompts'],
      metadata: config.metadata || {}
    })
    .withHealthCheck(async () => ({
      healthy: true,
      details: {
        name: config.name || 'full-featured-plugin',
        version: config.version || '1.0.0',
        template: 'full-featured',
        accountId: config.accountId,
        capabilities: ['tools', 'resources', 'prompts', 'account-aware']
      }
    }))
    .build();
}