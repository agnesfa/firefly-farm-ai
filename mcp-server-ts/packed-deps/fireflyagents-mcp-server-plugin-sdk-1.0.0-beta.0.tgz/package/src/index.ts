/**
 * MCP Server Plugin SDK
 * 
 * This package provides interfaces, utilities, and development tools for building
 * MCP server plugins. Plugins provide MCP capabilities (tools, resources, prompts)
 * without access to server infrastructure.
 */

// Re-export plugin interfaces from shared types
export type {
  ServerPlugin,
  ServerPluginFactory,
  ServerPluginConfig,
  LoadedServerPlugin,
  PluginAccountConfig
} from '@fireflyagents/mcp-server-types';

// Re-export commonly needed types for plugin development
export type {
  ToolDefinition,
  ToolHandlerContext,
  Tool,
  Prompt,
  Resource,
  PlatformAuthHandler
} from '@fireflyagents/mcp-server-types';

// Essential Zod re-export for plugin development
export { z } from '@fireflyagents/mcp-server-types';

// Export SDK utilities
export { createPluginBuilder } from './sdk/plugin-builder.js';
export { PluginHealthChecker } from './sdk/health-checker.js';
export { createPluginTemplate } from './sdk/templates.js';

// Export plugin development utilities
export { validatePluginConfig } from './utils/validation.js';
export { loadPluginFromConfig } from './utils/loader.js';
export { createMockPluginConfig } from './utils/testing.js';