import { vi } from 'vitest';

// Mock logger to suppress log output in tests
vi.mock('@fireflyagents/mcp-shared-utils', () => {
  const createLoggerMock = () => ({
    debug: vi.fn(),
    info: vi.fn(),
    http: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    child: vi.fn(() => createLoggerMock()),
  });
  
  return {
    logger: createLoggerMock(),
  };
});