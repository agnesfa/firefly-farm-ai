import { describe, it, expect } from 'vitest';
import {
  createMockPluginConfig,
  createMockAccountConfig,
  createMockPlugin,
  createMockTool,
  PluginTestUtils
} from './testing.js';

describe('Testing Utilities', () => {
  describe('createMockPluginConfig', () => {
    it('should create default mock plugin config', () => {
      const config = createMockPluginConfig();

      expect(config.name).toBe('test-plugin');
      expect(config.type).toBe('local');
      expect(config.path).toBe('./test-plugin.js');
      expect(config.enabled).toBe(true);
      expect(config.config).toEqual({});
    });

    it('should create local plugin config with options', () => {
      const config = createMockPluginConfig({
        name: 'custom-plugin',
        path: './custom-path.js',
        enabled: false,
        config: { custom: true }
      });

      expect(config.name).toBe('custom-plugin');
      expect(config.type).toBe('local');
      expect(config.path).toBe('./custom-path.js');
      expect(config.enabled).toBe(false);
      expect(config.config).toEqual({ custom: true });
    });

    it('should create npm plugin config', () => {
      const config = createMockPluginConfig({
        name: 'npm-plugin',
        type: 'npm',
        package: '@test/npm-plugin',
        version: '2.0.0'
      });

      expect(config.name).toBe('npm-plugin');
      expect(config.type).toBe('npm');
      expect(config.package).toBe('@test/npm-plugin');
      expect(config.version).toBe('2.0.0');
      expect(config.path).toBeUndefined();
    });

    it('should generate default npm package name', () => {
      const config = createMockPluginConfig({
        name: 'auto-package',
        type: 'npm'
      });

      expect(config.package).toBe('@test/auto-package');
    });
  });

  describe('createMockAccountConfig', () => {
    it('should create default mock account config', () => {
      const config = createMockAccountConfig();

      expect(config.accountId).toBe('test-account-123');
      expect(config.tenantId).toBe('test-tenant-456');
      expect(config.features).toEqual(['tools', 'testing']);
      expect(config.metadata).toEqual({
        environment: 'test',
        version: '1.0.0'
      });
    });

    it('should create account config with custom options', () => {
      const config = createMockAccountConfig({
        accountId: 'custom-account',
        tenantId: 'custom-tenant',
        features: ['custom-feature'],
        metadata: { custom: true }
      });

      expect(config.accountId).toBe('custom-account');
      expect(config.tenantId).toBe('custom-tenant');
      expect(config.features).toEqual(['custom-feature']);
      expect(config.metadata).toEqual({ custom: true });
    });
  });

  describe('createMockPlugin', () => {
    it('should create default mock plugin', async () => {
      const plugin = createMockPlugin();

      expect(plugin.healthCheck).toBeDefined();

      const health = await plugin.healthCheck();
      expect(health.healthy).toBe(true);
      expect(health.details?.name).toBe('mock-plugin');
      expect(health.details?.mock).toBe(true);
    });

    it('should create plugin with custom health result', async () => {
      const customHealth = {
        healthy: false,
        details: { error: 'Custom error' }
      };

      const plugin = createMockPlugin({
        name: 'unhealthy-plugin',
        healthResult: customHealth
      });

      const health = await plugin.healthCheck();
      expect(health).toEqual(customHealth);
    });

    it('should create plugin with tools', () => {
      const mockTool = createMockTool();
      const plugin = createMockPlugin({
        tools: [mockTool]
      });

      expect(plugin.getTools).toBeDefined();
      const tools = plugin.getTools!();
      expect(tools).toEqual([mockTool]);
    });

    it('should create plugin with account config', () => {
      const accountConfig = {
        accountId: 'test-account',
        tenantId: 'test-tenant'
      };

      const plugin = createMockPlugin({
        accountConfig
      });

      expect(plugin.getAccountConfig).toBeDefined();
      const config = plugin.getAccountConfig!();
      expect(config).toEqual(accountConfig);
    });

    it('should create plugin that throws on health check', async () => {
      const plugin = createMockPlugin({
        name: 'error-plugin',
        shouldThrow: true
      });

      await expect(plugin.healthCheck()).rejects.toThrow('Mock plugin error-plugin health check error');
    });

    it('should not define optional methods when no data provided', () => {
      const plugin = createMockPlugin();

      expect(plugin.getTools).toBeUndefined();
      expect(plugin.getResources).toBeUndefined();
      expect(plugin.getPrompts).toBeUndefined();
      expect(plugin.getAccountConfig).toBeUndefined();
    });
  });

  describe('createMockTool', () => {
    it('should create default mock tool', () => {
      const tool = createMockTool();

      expect(tool.namespace).toBe('test');
      expect(tool.name).toBe('mock-tool');
      expect(tool.title).toBe('Mock Tool');
      expect(tool.description).toBe('A mock tool for testing');
      expect(typeof tool.handler).toBe('function');
    });

    it('should create tool with custom options', () => {
      const tool = createMockTool({
        namespace: 'custom',
        name: 'custom-tool',
        title: 'Custom Tool',
        description: 'Custom description'
      });

      expect(tool.namespace).toBe('custom');
      expect(tool.name).toBe('custom-tool');
      expect(tool.title).toBe('Custom Tool');
      expect(tool.description).toBe('Custom description');
    });

    it('should execute tool handler', async () => {
      const tool = createMockTool();
      const result = await tool.handler({});

      expect(result.content).toBeDefined();
      expect(result.content[0]).toEqual({
        type: "text",
        text: "Mock tool test__mock-tool executed"
      });
    });
  });

  describe('PluginTestUtils', () => {
    describe('assertHealthy', () => {
      it('should pass for healthy plugin', async () => {
        const plugin = createMockPlugin();

        await expect(PluginTestUtils.assertHealthy(plugin)).resolves.toBeUndefined();
      });

      it('should throw for unhealthy plugin', async () => {
        const plugin = createMockPlugin({
          name: 'unhealthy-plugin',
          healthResult: { healthy: false, details: { error: 'Test error' } }
        });

        await expect(PluginTestUtils.assertHealthy(plugin, 'test-plugin'))
          .rejects.toThrow('Plugin test-plugin is not healthy');
      });
    });

    describe('assertCapabilities', () => {
      it('should pass when capabilities match expectations', () => {
        const mockTool = createMockTool();
        const plugin = createMockPlugin({
          tools: [mockTool],
          accountConfig: { accountId: 'test' }
        });

        expect(() => {
          PluginTestUtils.assertCapabilities(plugin, {
            tools: true,
            accountConfig: true,
            prompts: false
          });
        }).not.toThrow();
      });

      it('should throw when tools expectation fails', () => {
        const plugin = createMockPlugin();

        expect(() => {
          PluginTestUtils.assertCapabilities(plugin, { tools: true });
        }).toThrow('Expected plugin to have tools');
      });
    });

    describe('getCapabilitiesSummary', () => {
      it('should return correct summary for plugin with capabilities', () => {
        const mockTool1 = createMockTool({ name: 'tool1' });
        const mockTool2 = createMockTool({ name: 'tool2' });

        const plugin = createMockPlugin({
          tools: [mockTool1, mockTool2],
          accountConfig: { accountId: 'test' }
        });

        const summary = PluginTestUtils.getCapabilitiesSummary(plugin);

        expect(summary).toEqual({
          tools: 2,
          resources: 0,
          prompts: 0,
          hasAccountConfig: true
        });
      });

      it('should return zero counts for plugin without capabilities', () => {
        const plugin = createMockPlugin();

        const summary = PluginTestUtils.getCapabilitiesSummary(plugin);

        expect(summary).toEqual({
          tools: 0,
          resources: 0,
          prompts: 0,
          hasAccountConfig: false
        });
      });
    });
  });
});