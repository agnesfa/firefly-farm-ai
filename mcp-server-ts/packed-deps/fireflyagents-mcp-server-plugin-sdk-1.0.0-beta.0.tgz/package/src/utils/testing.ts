import type {
  ServerPlugin,
  ServerPluginConfig,
  PluginAccountConfig,
  Tool,
  Prompt,
  Resource
} from '@fireflyagents/mcp-server-types';

/**
 * Mock Plugin Configuration Factory
 */
export interface MockPluginConfigOptions {
  name?: string;
  type?: 'local' | 'npm';
  path?: string;
  package?: string;
  version?: string;
  enabled?: boolean;
  config?: Record<string, any>;
}

/**
 * Create a mock plugin configuration for testing
 */
export function createMockPluginConfig(options: MockPluginConfigOptions = {}): ServerPluginConfig {
  const {
    name = 'test-plugin',
    type = 'local',
    path = './test-plugin.js',
    package: packageName,
    version = '1.0.0',
    enabled = true,
    config = {}
  } = options;

  const baseConfig: ServerPluginConfig = {
    name,
    type,
    enabled,
    config
  };

  if (type === 'local') {
    baseConfig.path = path;
  } else if (type === 'npm') {
    baseConfig.package = packageName || `@test/${name}`;
    baseConfig.version = version;
  }

  return baseConfig;
}

/**
 * Mock Account Configuration Factory
 */
export interface MockAccountConfigOptions {
  accountId?: string;
  tenantId?: string;
  features?: string[];
  metadata?: Record<string, any>;
}

/**
 * Create a mock account configuration for testing
 */
export function createMockAccountConfig(options: MockAccountConfigOptions = {}): PluginAccountConfig {
  return {
    accountId: options.accountId || 'test-account-123',
    tenantId: options.tenantId || 'test-tenant-456',
    features: options.features || ['tools', 'testing'],
    metadata: options.metadata || { 
      environment: 'test',
      version: '1.0.0'
    }
  };
}

/**
 * Mock Plugin Factory
 */
export interface MockPluginOptions {
  name?: string;
  healthResult?: { healthy: boolean; details?: any };
  tools?: Tool[];
  resources?: Resource[];
  prompts?: Prompt[];
  accountConfig?: PluginAccountConfig;
  shouldThrow?: boolean;
}

/**
 * Create a mock plugin for testing
 */
export function createMockPlugin(options: MockPluginOptions = {}): ServerPlugin {
  const {
    name = 'mock-plugin',
    healthResult = { healthy: true, details: { name, mock: true } },
    tools = [],
    resources = [],
    prompts = [],
    accountConfig,
    shouldThrow = false
  } = options;

  return {
    getTools: tools.length > 0 ? () => tools : undefined,
    getResources: resources.length > 0 ? () => resources : undefined,
    getPrompts: prompts.length > 0 ? () => prompts : undefined,
    getAccountConfig: accountConfig ? () => accountConfig : undefined,

    healthCheck: async () => {
      if (shouldThrow) {
        throw new Error(`Mock plugin ${name} health check error`);
      }
      return healthResult;
    }
  };
}

/**
 * Mock Tool Factory
 */
export interface MockToolOptions {
  namespace?: string;
  name?: string;
  title?: string;
  description?: string;
}

/**
 * Create a mock tool for testing
 */
export function createMockTool(options: MockToolOptions = {}): Tool {
  const {
    namespace = 'test',
    name = 'mock-tool',
    title = 'Mock Tool',
    description = 'A mock tool for testing'
  } = options;

  return {
    namespace,
    name,
    title,
    description,
    paramsSchema: {},
    handler: async () => ({
      content: [{ type: "text", text: `Mock tool ${namespace}__${name} executed` }]
    })
  };
}

/**
 * Test Utilities for Plugin Development
 */
export class PluginTestUtils {
  /**
   * Assert that a plugin is healthy
   */
  static async assertHealthy(plugin: ServerPlugin, pluginName?: string): Promise<void> {
    const health = await plugin.healthCheck();
    if (!health.healthy) {
      throw new Error(`Plugin ${pluginName || 'unknown'} is not healthy: ${JSON.stringify(health.details)}`);
    }
  }

  /**
   * Assert that a plugin has expected capabilities
   */
  static assertCapabilities(
    plugin: ServerPlugin,
    expected: {
      tools?: boolean;
      resources?: boolean;
      prompts?: boolean;
      accountConfig?: boolean;
    }
  ): void {
    if (expected.tools !== undefined) {
      const hasTools = !!plugin.getTools;
      if (hasTools !== expected.tools) {
        throw new Error(`Expected plugin to ${expected.tools ? 'have' : 'not have'} tools`);
      }
    }

    if (expected.resources !== undefined) {
      const hasResources = !!plugin.getResources;
      if (hasResources !== expected.resources) {
        throw new Error(`Expected plugin to ${expected.resources ? 'have' : 'not have'} resources`);
      }
    }

    if (expected.prompts !== undefined) {
      const hasPrompts = !!plugin.getPrompts;
      if (hasPrompts !== expected.prompts) {
        throw new Error(`Expected plugin to ${expected.prompts ? 'have' : 'not have'} prompts`);
      }
    }

    if (expected.accountConfig !== undefined) {
      const hasAccountConfig = !!plugin.getAccountConfig;
      if (hasAccountConfig !== expected.accountConfig) {
        throw new Error(`Expected plugin to ${expected.accountConfig ? 'have' : 'not have'} account config`);
      }
    }
  }

  /**
   * Get plugin capabilities summary
   */
  static getCapabilitiesSummary(plugin: ServerPlugin): {
    tools: number;
    resources: number;
    prompts: number;
    hasAccountConfig: boolean;
  } {
    return {
      tools: plugin.getTools?.()?.length || 0,
      resources: plugin.getResources?.()?.length || 0,
      prompts: plugin.getPrompts?.()?.length || 0,
      hasAccountConfig: !!plugin.getAccountConfig
    };
  }
}