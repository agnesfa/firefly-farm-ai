import { describe, it, expect } from 'vitest';
import { 
  validatePluginConfig, 
  validateAccountConfig, 
  validatePluginName 
} from './validation.js';
import type { ServerPluginConfig, PluginAccountConfig } from '@fireflyagents/mcp-server-types';

describe('Validation Utilities', () => {
  describe('validatePluginConfig', () => {
    it('should validate valid local plugin config', () => {
      const config: ServerPluginConfig = {
        name: 'test-plugin',
        type: 'local',
        path: './test-plugin.js',
        enabled: true,
        config: { test: true }
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should validate valid npm plugin config', () => {
      const config: ServerPluginConfig = {
        name: 'test-plugin',
        type: 'npm',
        package: '@test/test-plugin',
        version: '1.0.0',
        enabled: true,
        config: { test: true }
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should require plugin name', () => {
      const config = {
        type: 'local',
        path: './test.js',
        enabled: true
      } as ServerPluginConfig;

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name is required');
    });

    it('should require plugin type', () => {
      const config = {
        name: 'test-plugin',
        enabled: true
      } as ServerPluginConfig;

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin type is required');
    });

    it('should require path for local plugins', () => {
      const config: ServerPluginConfig = {
        name: 'test-plugin',
        type: 'local',
        enabled: true
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Local plugins require a path');
    });

    it('should require package for npm plugins', () => {
      const config: ServerPluginConfig = {
        name: 'test-plugin',
        type: 'npm',
        enabled: true
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('NPM plugins require a package name');
    });

    it('should warn about missing version for npm plugins', () => {
      const config: ServerPluginConfig = {
        name: 'test-plugin',
        type: 'npm',
        package: '@test/test-plugin',
        enabled: true
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(true);
      expect(result.warnings).toContain('NPM plugins should specify a version');
    });

    it('should validate plugin name format', () => {
      const config: ServerPluginConfig = {
        name: 'Invalid_Name!',
        type: 'local',
        path: './test.js',
        enabled: true
      };

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name should only contain lowercase letters, numbers, and hyphens');
    });

    it('should validate config object type', () => {
      const config = {
        name: 'test-plugin',
        type: 'local',
        path: './test.js',
        enabled: true,
        config: 'not an object'
      } as any;

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin config must be an object');
    });

    it('should reject array as config', () => {
      const config = {
        name: 'test-plugin',
        type: 'local',
        path: './test.js',
        enabled: true,
        config: []
      } as any;

      const result = validatePluginConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin config must be an object');
    });
  });

  describe('validateAccountConfig', () => {
    it('should validate valid account config', () => {
      const config: PluginAccountConfig = {
        accountId: 'test-account-123',
        tenantId: 'test-tenant-456',
        features: ['feature1', 'feature2'],
        metadata: { key: 'value' }
      };

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should require accountId', () => {
      const config = {
        tenantId: 'test-tenant'
      } as PluginAccountConfig;

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Account ID is required');
    });

    it('should validate accountId format', () => {
      const config: PluginAccountConfig = {
        accountId: 'invalid@account!',
        tenantId: 'test-tenant'
      };

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Account ID should only contain letters, numbers, underscores, and hyphens');
    });

    it('should validate tenantId format', () => {
      const config: PluginAccountConfig = {
        accountId: 'test-account',
        tenantId: 'invalid@tenant!'
      };

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Tenant ID should only contain letters, numbers, underscores, and hyphens');
    });

    it('should validate features array', () => {
      const config = {
        accountId: 'test-account',
        features: 'not an array'
      } as any;

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Features must be an array');
    });

    it('should validate feature items are strings', () => {
      const config = {
        accountId: 'test-account',
        features: ['valid-feature', 123, 'another-valid-feature']
      } as any;

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('All features must be strings');
    });

    it('should validate metadata is object', () => {
      const config = {
        accountId: 'test-account',
        metadata: 'not an object'
      } as any;

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Metadata must be an object');
    });

    it('should reject array as metadata', () => {
      const config = {
        accountId: 'test-account',
        metadata: []
      } as any;

      const result = validateAccountConfig(config);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Metadata must be an object');
    });
  });

  describe('validatePluginName', () => {
    it('should validate valid plugin names', () => {
      const validNames = [
        'test-plugin',
        'my-awesome-plugin',
        'plugin123',
        'abc'
      ];

      validNames.forEach(name => {
        const result = validatePluginName(name);
        expect(result.valid).toBe(true);
        expect(result.errors).toEqual([]);
      });
    });

    it('should reject empty name', () => {
      const result = validatePluginName('');
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name cannot be empty');
    });

    it('should reject invalid characters', () => {
      const invalidNames = [
        'Test-Plugin',  // uppercase
        'test_plugin',  // underscore
        'test plugin',  // space
        'test@plugin',  // special chars
        'test.plugin'   // period
      ];

      invalidNames.forEach(name => {
        const result = validatePluginName(name);
        expect(result.valid).toBe(false);
        expect(result.errors).toContain('Plugin name should only contain lowercase letters, numbers, and hyphens');
      });
    });

    it('should reject names starting with hyphen', () => {
      const result = validatePluginName('-test-plugin');
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name cannot start or end with a hyphen');
    });

    it('should reject names ending with hyphen', () => {
      const result = validatePluginName('test-plugin-');
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name cannot start or end with a hyphen');
    });

    it('should reject consecutive hyphens', () => {
      const result = validatePluginName('test--plugin');
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name cannot contain consecutive hyphens');
    });

    it('should warn about short names', () => {
      const result = validatePluginName('ab');
      
      expect(result.valid).toBe(true);
      expect(result.warnings).toContain('Plugin name should be at least 3 characters long');
    });

    it('should reject overly long names', () => {
      const longName = 'a'.repeat(51);
      const result = validatePluginName(longName);
      
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Plugin name should not exceed 50 characters');
    });

    it('should accept names at the length boundary', () => {
      const fiftyCharName = 'a'.repeat(50);
      const result = validatePluginName(fiftyCharName);
      
      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });
  });
});