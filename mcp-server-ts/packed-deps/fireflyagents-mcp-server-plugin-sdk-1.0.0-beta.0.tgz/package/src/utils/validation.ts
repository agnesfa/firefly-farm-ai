import type { 
  ServerPluginConfig,
  PluginAccountConfig 
} from '@fireflyagents/mcp-server-types';

/**
 * Validation Result
 */
export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validate plugin configuration
 */
export function validatePluginConfig(config: ServerPluginConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required fields
  if (!config.name) {
    errors.push('Plugin name is required');
  }

  if (!config.type) {
    errors.push('Plugin type is required');
  }

  // Type-specific validation
  if (config.type === 'local') {
    if (!config.path) {
      errors.push('Local plugins require a path');
    }
  } else if (config.type === 'npm') {
    if (!config.package) {
      errors.push('NPM plugins require a package name');
    }
    if (!config.version) {
      warnings.push('NPM plugins should specify a version');
    }
  }

  // Name validation
  if (config.name && !/^[a-z0-9-]+$/.test(config.name)) {
    errors.push('Plugin name should only contain lowercase letters, numbers, and hyphens');
  }

  // Config validation
  if (config.config) {
    if (typeof config.config !== 'object' || Array.isArray(config.config)) {
      errors.push('Plugin config must be an object');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

/**
 * Validate account configuration
 */
export function validateAccountConfig(config: PluginAccountConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required fields
  if (!config.accountId) {
    errors.push('Account ID is required');
  }

  // Account ID format validation
  if (config.accountId && !/^[a-zA-Z0-9_-]+$/.test(config.accountId)) {
    errors.push('Account ID should only contain letters, numbers, underscores, and hyphens');
  }

  // Tenant ID validation
  if (config.tenantId && !/^[a-zA-Z0-9_-]+$/.test(config.tenantId)) {
    errors.push('Tenant ID should only contain letters, numbers, underscores, and hyphens');
  }

  // Features validation
  if (config.features) {
    if (!Array.isArray(config.features)) {
      errors.push('Features must be an array');
    } else {
      const invalidFeatures = config.features.filter(feature => typeof feature !== 'string');
      if (invalidFeatures.length > 0) {
        errors.push('All features must be strings');
      }
    }
  }

  // Metadata validation
  if (config.metadata) {
    if (typeof config.metadata !== 'object' || Array.isArray(config.metadata)) {
      errors.push('Metadata must be an object');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

/**
 * Validate plugin name format
 */
export function validatePluginName(name: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!name) {
    errors.push('Plugin name cannot be empty');
    return { valid: false, errors, warnings };
  }

  if (!/^[a-z0-9-]+$/.test(name)) {
    errors.push('Plugin name should only contain lowercase letters, numbers, and hyphens');
  }

  if (name.startsWith('-') || name.endsWith('-')) {
    errors.push('Plugin name cannot start or end with a hyphen');
  }

  if (name.includes('--')) {
    errors.push('Plugin name cannot contain consecutive hyphens');
  }

  if (name.length < 3) {
    warnings.push('Plugin name should be at least 3 characters long');
  }

  if (name.length > 50) {
    errors.push('Plugin name should not exceed 50 characters');
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}