import type { 
  ServerPlugin, 
  ServerPluginFactory,
  ServerPluginConfig,
  LoadedServerPlugin 
} from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:plugin-sdk:plugin-loader' });

/**
 * Load Error
 */
export class PluginLoadError extends Error {
  constructor(
    message: string,
    public readonly pluginName: string,
    public readonly cause?: Error
  ) {
    super(message);
    this.name = 'PluginLoadError';
  }
}

/**
 * Load a plugin from configuration
 * 
 * This is a simplified version for the plugin SDK.
 * The full implementation would be in the core server.
 */
export async function loadPluginFromConfig(
  config: ServerPluginConfig
): Promise<LoadedServerPlugin> {
  const startTime = Date.now();
  const pluginName = config.name || 'unknown';
  
  logger.info('Plugin loading started', {
    pluginName,
    type: config.type,
    enabled: config.enabled,
    hasPath: !!config.path,
    hasPackage: !!config.package,
    hasConfig: !!config.config
  });

  try {
    // Validate config
    if (!config.name) {
      logger.error('Plugin loading failed - name required', { config });
      throw new PluginLoadError('Plugin name is required', config.name || 'unknown');
    }

    if (!config.enabled) {
      logger.warn('Plugin loading skipped - plugin disabled', { pluginName });
      throw new PluginLoadError('Plugin is disabled', config.name);
    }

    let plugin: ServerPlugin;

    if (config.type === 'local') {
      logger.debug('Loading local plugin', { pluginName, path: config.path });
      plugin = await loadLocalPlugin(config);
    } else if (config.type === 'npm') {
      logger.debug('Loading npm plugin', { pluginName, package: config.package });
      plugin = await loadNpmPlugin(config);
    } else {
      logger.error('Unknown plugin type', { pluginName, type: config.type });
      throw new PluginLoadError(`Unknown plugin type: ${config.type}`, config.name);
    }

    // Validate loaded plugin
    logger.debug('Validating loaded plugin', { pluginName });
    await validateLoadedPlugin(plugin, config.name);

    const result: LoadedServerPlugin = {
      name: config.name,
      plugin,
      config
    };

    // Determine capabilities for logging
    const capabilities = [];
    if (plugin.getTools) capabilities.push('tools');
    if (plugin.getResources) capabilities.push('resources');
    if (plugin.getPrompts) capabilities.push('prompts');
    if (plugin.getAccountConfig) capabilities.push('account-config');
    capabilities.push('health-check');

    logger.info('Plugin loading completed', {
      pluginName,
      type: config.type,
      capabilities,
      duration: Date.now() - startTime,
      success: true
    });

    return result;

  } catch (error) {
    logger.error('Plugin loading failed', {
      pluginName,
      type: config.type,
      error: error instanceof Error ? error.message : String(error),
      duration: Date.now() - startTime,
      isPluginLoadError: error instanceof PluginLoadError
    });

    if (error instanceof PluginLoadError) {
      throw error;
    }
    throw new PluginLoadError(
      `Failed to load plugin: ${error instanceof Error ? error.message : String(error)}`,
      config.name || 'unknown',
      error instanceof Error ? error : undefined
    );
  }
}

/**
 * Load a local plugin
 */
async function loadLocalPlugin(config: ServerPluginConfig): Promise<ServerPlugin> {
  if (!config.path) {
    throw new PluginLoadError('Local plugin requires path', config.name);
  }

  try {
    // In a real implementation, this would dynamically import the plugin
    // For now, this is a placeholder that shows the expected interface
    const module = await import(config.path);
    
    if (typeof module.createPlugin === 'function') {
      const factory: ServerPluginFactory = module;
      return await factory.createPlugin(config.config || {});
    } else if (module.default && typeof module.default === 'object') {
      return module.default as ServerPlugin;
    } else {
      throw new PluginLoadError('Plugin module must export createPlugin function or default plugin', config.name);
    }
  } catch (error) {
    throw new PluginLoadError(
      `Failed to import local plugin: ${error instanceof Error ? error.message : String(error)}`,
      config.name,
      error instanceof Error ? error : undefined
    );
  }
}

/**
 * Load an NPM plugin
 */
async function loadNpmPlugin(config: ServerPluginConfig): Promise<ServerPlugin> {
  if (!config.package) {
    throw new PluginLoadError('NPM plugin requires package name', config.name);
  }

  try {
    // In a real implementation, this would handle NPM package loading
    // For now, this is a placeholder
    const module = await import(config.package);
    
    if (typeof module.createPlugin === 'function') {
      const factory: ServerPluginFactory = module;
      return await factory.createPlugin(config.config || {});
    } else if (module.default && typeof module.default === 'object') {
      return module.default as ServerPlugin;
    } else {
      throw new PluginLoadError('Plugin package must export createPlugin function or default plugin', config.name);
    }
  } catch (error) {
    throw new PluginLoadError(
      `Failed to import NPM plugin: ${error instanceof Error ? error.message : String(error)}`,
      config.name,
      error instanceof Error ? error : undefined
    );
  }
}

/**
 * Validate a loaded plugin
 */
async function validateLoadedPlugin(plugin: ServerPlugin, pluginName: string): Promise<void> {
  const startTime = Date.now();
  
  logger.debug('Plugin validation started', {
    pluginName,
    hasHealthCheck: typeof plugin.healthCheck === 'function',
    hasTools: typeof plugin.getTools === 'function',
    hasResources: typeof plugin.getResources === 'function',
    hasPrompts: typeof plugin.getPrompts === 'function',
    hasAccountConfig: typeof plugin.getAccountConfig === 'function'
  });

  // Check required healthCheck method
  if (typeof plugin.healthCheck !== 'function') {
    logger.error('Plugin validation failed - missing healthCheck', { pluginName });
    throw new PluginLoadError('Plugin must implement healthCheck method', pluginName);
  }

  // Test health check
  try {
    logger.debug('Testing plugin health check', { pluginName });
    const health = await plugin.healthCheck();
    
    if (typeof health !== 'object' || typeof health.healthy !== 'boolean') {
      logger.error('Plugin validation failed - invalid health check return', { 
        pluginName, 
        healthType: typeof health,
        healthyType: typeof health?.healthy
      });
      throw new PluginLoadError('Plugin healthCheck must return {healthy: boolean}', pluginName);
    }
    
    if (!health.healthy) {
      logger.warn('Plugin validation failed - health check returned unhealthy', { 
        pluginName, 
        health 
      });
      throw new PluginLoadError('Plugin health check failed', pluginName);
    }

    logger.debug('Plugin health check passed', { pluginName, health });
  } catch (error) {
    if (error instanceof PluginLoadError) {
      throw error;
    }
    logger.error('Plugin health check threw exception', {
      pluginName,
      error: error instanceof Error ? error.message : String(error)
    });
    throw new PluginLoadError(
      `Plugin health check failed: ${error instanceof Error ? error.message : String(error)}`,
      pluginName,
      error instanceof Error ? error : undefined
    );
  }

  // Validate optional methods
  const methodValidations = [
    { name: 'getTools', method: plugin.getTools },
    { name: 'getResources', method: plugin.getResources },
    { name: 'getPrompts', method: plugin.getPrompts },
    { name: 'getAccountConfig', method: plugin.getAccountConfig }
  ];

  for (const validation of methodValidations) {
    if (validation.method && typeof validation.method !== 'function') {
      logger.error('Plugin validation failed - invalid method type', { 
        pluginName, 
        methodName: validation.name,
        actualType: typeof validation.method
      });
      throw new PluginLoadError(`${validation.name} must be a function`, pluginName);
    }
  }

  // Count capabilities for validation logging
  const capabilities = methodValidations
    .filter(v => typeof v.method === 'function')
    .map(v => v.name);

  logger.debug('Plugin validation completed', {
    pluginName,
    capabilities,
    duration: Date.now() - startTime,
    success: true
  });
}