import { describe, it, expect } from 'vitest';
import { loadPluginFromConfig, PluginLoadError } from './loader.js';
import { createMockPluginConfig } from './testing.js';

describe('Plugin Loader', () => {
  describe('PluginLoadError', () => {
    it('should create error with message and plugin name', () => {
      const error = new PluginLoadError('Test error', 'test-plugin');
      
      expect(error.message).toBe('Test error');
      expect(error.pluginName).toBe('test-plugin');
      expect(error.name).toBe('PluginLoadError');
      expect(error.cause).toBeUndefined();
    });

    it('should create error with cause', () => {
      const cause = new Error('Original error');
      const error = new PluginLoadError('Test error', 'test-plugin', cause);
      
      expect(error.cause).toBe(cause);
    });
  });

  describe('loadPluginFromConfig', () => {
    it('should throw error for missing plugin name', async () => {
      const config = createMockPluginConfig({ name: '' });
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(
        expect.objectContaining({
          name: 'PluginLoadError',
          message: 'Plugin name is required'
        })
      );
    });

    it('should throw error for disabled plugin', async () => {
      const config = createMockPluginConfig({ 
        name: 'test-plugin',
        enabled: false 
      });
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(
        expect.objectContaining({
          name: 'PluginLoadError',
          message: 'Plugin is disabled',
          pluginName: 'test-plugin'
        })
      );
    });

    it('should throw error for unknown plugin type', async () => {
      const config = {
        ...createMockPluginConfig(),
        type: 'unknown'
      } as any;
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(
        expect.objectContaining({
          name: 'PluginLoadError',
          message: 'Unknown plugin type: unknown'
        })
      );
    });

    it('should handle local plugin loading (would fail due to missing file)', async () => {
      const config = createMockPluginConfig({
        type: 'local',
        path: './non-existent-plugin.js'
      });
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(PluginLoadError);
    });

    it('should handle npm plugin loading (would fail due to missing package)', async () => {
      const config = createMockPluginConfig({
        type: 'npm',
        package: '@non-existent/plugin'
      });
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(PluginLoadError);
    });

    it('should throw error when local plugin path is missing', async () => {
      const config = {
        ...createMockPluginConfig({ type: 'local' }),
        path: undefined
      } as any;
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(
        expect.objectContaining({
          name: 'PluginLoadError',
          message: 'Local plugin requires path'
        })
      );
    });

    it('should throw error when npm plugin package is missing', async () => {
      const config = {
        ...createMockPluginConfig({ type: 'npm' }),
        package: undefined
      } as any;
      
      await expect(loadPluginFromConfig(config)).rejects.toThrow(
        expect.objectContaining({
          name: 'PluginLoadError',
          message: 'NPM plugin requires package name'
        })
      );
    });

    // Note: Testing dynamic import behavior would require complex mocking
    // These tests focus on the validation and error handling that can be tested
    // without file system access. The actual plugin loading would be integration tested.
  });

  // Note: The actual plugin loading and validation would require more complex
  // mocking of the dynamic import system. These tests focus on the error
  // handling and validation logic that can be tested without file system access.
});