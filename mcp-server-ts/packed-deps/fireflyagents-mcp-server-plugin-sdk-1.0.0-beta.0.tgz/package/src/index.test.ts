import { describe, it, expect } from 'vitest';
import * as PluginSDK from './index.js';

describe('Plugin SDK Index', () => {
  it('should export all expected functions and types', () => {
    // Functions that should be exported
    expect(typeof PluginSDK.createPluginBuilder).toBe('function');
    expect(typeof PluginSDK.createPluginTemplate).toBe('function');
    expect(typeof PluginSDK.validatePluginConfig).toBe('function');
    expect(typeof PluginSDK.loadPluginFromConfig).toBe('function');
    expect(typeof PluginSDK.createMockPluginConfig).toBe('function');
    
    // Classes that should be exported
    expect(PluginSDK.PluginHealthChecker).toBeDefined();
  });

  it('should create plugin builder', () => {
    const builder = PluginSDK.createPluginBuilder();
    expect(builder).toBeDefined();
  });

  it('should create plugin templates', () => {
    const plugin = PluginSDK.createPluginTemplate('minimal');
    expect(plugin).toBeDefined();
    expect(plugin.healthCheck).toBeDefined();
  });

  it('should create mock configs', () => {
    const pluginConfig = PluginSDK.createMockPluginConfig();
    expect(pluginConfig.name).toBe('test-plugin');
    expect(pluginConfig.type).toBe('local');
  });

  it('should validate configs', () => {
    const config = PluginSDK.createMockPluginConfig();
    const result = PluginSDK.validatePluginConfig(config);
    expect(result.valid).toBe(true);
  });
});