# MCP Server Core - Express.js Application

The main Express.js application implementing the Model Context Protocol (MCP) server with comprehensive health monitoring, session management, and containerization support.

## 🏗️ Overview

This server provides production-ready HTTP endpoints and MCP protocol handling:

- **`/mcp`** - Main MCP protocol handler with session management
- **`/health/*`** - Comprehensive health check endpoints for orchestration
- **Session Management** - Redis-ready with in-memory fallback
- **Tool Registration** - Extensible tool system with Zod validation
- **Graceful Shutdown** - Proper cleanup for production deployments

## 🔧 Architecture Patterns

### MCP Transport Pattern - CRITICAL ⚠️

The MCP protocol requires specific transport and server instance management:

**Key Principles:**
1. **Transport instances are persistent** - Stored globally by session ID
2. **Server instances created ONCE per session** - During initialization only  
3. **Subsequent requests reuse existing transport** - Maintains server connection
4. **Session = One transport + One server instance**

**Correct Implementation:**
```typescript
// Initialize request (no session ID):
const server = createMcpServer()              // Create server ONCE
const transport = new StreamableHTTPTransport() // Create transport ONCE  
await server.connect(transport)               // Connect permanently
transports[sessionId] = transport             // Store for reuse

// Subsequent requests (with session ID):
const transport = transports[sessionId]       // Reuse existing transport
await transport.handleRequest(req, res, body) // Handle via connection
```

**Anti-Pattern (WRONG):**
```typescript
// ❌ Every request:
const server = createMcpServer()     // Creates new server every time
const transport = new Transport()    // Creates new transport every time
// Results in: Multiple registrations, protocol errors, session confusion
```

### Health Check Architecture

Comprehensive monitoring for container orchestration:

- **`/health`** - Complete status with detailed metrics
- **`/health/live`** - Liveness probe (app running?)
- **`/health/ready`** - Readiness probe (accepting traffic?)  
- **`/health/startup`** - Startup probe (finished initializing?)

Example response:
```json
{
  "status": "healthy",
  "timestamp": "2025-01-28T10:30:00.000Z",
  "uptime": 3600,
  "version": "0.0.1-beta.1",
  "checks": {
    "mcp_server": "healthy",
    "session_store": "healthy"
  }
}
```

### Session Management

Abstract session store interface supporting multiple backends:

```typescript
// In-memory (default)
const sessionStore = new InMemorySessionStore();

// Redis (production scaling)  
const sessionStore = new RedisSessionStore(redisUrl);
```

## 🐳 Container Deployment

### Production Container
```bash
# Build production image
npm run docker:build

# Run production container
npm run docker:run
```

### Development Container
```bash
# Start development environment
npm run docker:dev

# Start with hot reload
npm run docker:dev:hotreload
```

### Health Check Integration
```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
  CMD curl -f http://localhost:3000/health/live || exit 1
```

## 🛠️ Development

### Local Development
```bash
# From monorepo root
npm run dev:server

# Or from this package
npm run dev --workspace=@fireflyagents/mcp-server-core
```

### Production Build
```bash
# From monorepo root
npm run build
npm run start:server

# Or from this package  
npm run start --workspace=@fireflyagents/mcp-server-core
```

### Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Development server with hot reload |
| `npm run start` | Production server from built output |
| `npm run test` | Run package tests |

## 🔌 MCP Protocol

### Tool Registration
Follow the established pattern for new tools:

```typescript
// 1. Define schema
const inputSchema = z.object({
  name: z.string().describe("Name parameter").optional(),
});

// 2. Register tool
server.tool(
  'namespace/tool-name',
  inputSchema.shape,
  {
    title: 'Tool Description',
    readOnlyHint: true,
  },
  async ({ name }) => ({
    content: [{ type: "text", text: `Result for ${name}` }]
  })
);
```

### Testing MCP Endpoints
```bash
# Test tool list
curl -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}'

# Test tool execution  
curl -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "tools/call", 
    "id": 1,
    "params": {
      "name": "demo/hello",
      "input": {"name": "World"}
    }
  }'
```

## ⚙️ Dependencies & Compatibility

### Zod Version Constraint ⚠️

**Important:** Uses **Zod v3.23.8** (not v4) for MCP SDK compatibility.

**Issue:** MCP SDK expects Zod v3 API internally. Zod v4 causes:
```
MCP error -32603: keyValidator._parse is not a function
```

**Future:** Upgrade to Zod v4 once [typescript-sdk#802](https://github.com/modelcontextprotocol/typescript-sdk/issues/802) is resolved.

### Key Dependencies
- **Express**: `^5.1.0` - HTTP server framework
- **MCP SDK**: `@modelcontextprotocol/sdk@1.17.0` - Protocol implementation
- **Winston**: Structured logging via shared utils
- **CORS**: Cross-origin request handling

## 🚀 Production Features

- ✅ **Health Monitoring** - Container orchestration ready
- ✅ **Session Management** - Redis-ready architecture  
- ✅ **Graceful Shutdown** - Clean termination handling
- ✅ **Error Boundaries** - Robust error handling
- ✅ **Structured Logging** - Production monitoring ready
- ✅ **Type Safety** - Full TypeScript coverage

## 🏢 Scaling Considerations

### Horizontal Scaling
- Configure `REDIS_URL` for shared session storage
- Health checks for load balancer integration
- Stateless application design

### Resource Requirements
- **Memory**: ~50MB base + session storage
- **CPU**: Low usage, I/O bound operations
- **Network**: HTTP/1.1 with keep-alive support

## 🤝 Contributing

When adding features:

1. Follow MCP transport patterns strictly
2. Add comprehensive health checks
3. Ensure container compatibility  
4. Include integration tests
5. Update documentation

## 🔗 Related

- **[Root README](../../../README.md)** - Project overview and Docker commands
- **[DOCKER.md](../../../DOCKER.md)** - Complete containerization guide
- **[Shared Utils](../../shared/utils/README.md)** - Environment and logging utilities

---

Part of the [Firefly Agents MCP](../../../README.md) containerized monorepo.