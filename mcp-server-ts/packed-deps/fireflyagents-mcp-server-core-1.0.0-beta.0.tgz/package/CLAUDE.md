# MCP Server Core Framework

Core framework package providing MCP server primitives, transport handling, authentication, and session management. **Cannot run standalone** - requires an application entry point.

## Package Purpose

**Location:** `packages/server/core/`
**Package:** `@fireflyagents/mcp-server-core`
**Role:** Framework layer providing MCP protocol implementation

### What This Package Provides
- MCP server instance creation and lifecycle management
- Transport handling (StreamableHTTP, SSE)
- Session management and storage
- Authentication infrastructure (API key + OAuth)
- Tool/Prompt/Resource registration utilities
- Health checking and monitoring

### What This Package Does NOT Provide
- Application entry points (see `apps/`)
- Business logic or domain tools (implement in applications)
- Configuration files (managed by applications)
- Standalone executables (framework only)

## Critical MCP Patterns

### Server Instance Pattern

**CRITICAL:** MCP protocol requires specific server instantiation per session:

```typescript
// ✅ CORRECT: Create NEW server instance per initialize request
if (!existingSessionId && isInitializeRequest(req.body)) {
  // Fresh server instance for new session
  const freshServerInstance = await createMcpServer(mcpServerConfig);

  // Create transport for this session
  const transport = new StreamableHTTPServerTransport({
    sessionId: generateSessionId(),
    // ... transport config
  });

  // Connect transport to server instance
  await freshServerInstance.connect(transport);

  // Handle request
  await transport.handleRequest(req, res, req.body);
}

// ✅ CORRECT: Reuse existing transport for established sessions
else if (existingSessionId && await transportStore.hasAsync(existingSessionId)) {
  const transport = await transportStore.getAsync(existingSessionId);
  await transport.handleRequest(req, res, req.body);
}
```

**Why This Matters:**
- Each MCP client session requires its own server instance
- Server instances maintain session-specific state
- Transports are reused across requests within same session
- Violating this pattern causes state corruption and session conflicts

### Transport Reuse Pattern

**CRITICAL:** Transports must be stored and reused per session:

```typescript
// ✅ CORRECT: Global transport store
const transportStore = new Map<string, Transport>();

if (sessionId && transportStore.has(sessionId)) {
  // Reuse existing transport - do not create new one
  const transport = transportStore.get(sessionId);
} else if (isInitializeRequest) {
  // Only create new transport for initialize requests
  const transport = createTransport();
  transportStore.set(sessionId, transport);
}
```

**Why This Matters:**
- MCP SDK expects transport reuse for session continuity
- Creating new transports breaks SSE streaming
- Session state lives in transport instance
- Performance: avoid overhead of recreating connections

### Session ID Propagation

**CRITICAL:** Session IDs must flow from transport to tool handlers:

```typescript
// ✅ CORRECT: Explicit sessionId assignment
transport.sessionId = sessionId;  // Required for MCP SDK

// Tools receive sessionId via RequestHandlerExtra
server.tool('my/tool', schema, async (params, extra) => {
  const sessionId = extra.sessionId; // Now available
  // Use sessionId for session-specific operations
});
```

**Why This Matters:**
- MCP SDK requires `transport.sessionId` to populate `extra.sessionId`
- Tools need session context for session-scoped operations
- Missing session IDs cause client timeouts
- Critical for multi-session production environments

**MCP Specification Compliance:**
- **404** for expired/invalid session IDs (triggers client reconnection)
- **400** for protocol violations (malformed requests)
- **401** for authentication failures

### Auth Context Integration

**Pattern:** OAuth tokens flow from platform handlers to tools via `RequestHandlerExtra.authInfo`:

```typescript
// ✅ Framework injects auth context into req.auth before transport call
const session = sessionManager.getSession(sessionId);
if (session) {
  const platformToken = sessionManager.getPlatformToken(sessionId, 'default');
  if (platformToken) {
    (req as any).auth = {
      token: platformToken.accessToken,
      clientId: session.authContext.clientMetadata?.accountId || 'unknown',
      scopes: ['api'],
      expiresAt: platformToken.expiresAt ? Math.floor(platformToken.expiresAt.getTime() / 1000) : undefined,
      extra: { sessionId, tenantId: session.tenantId, ...metadata }
    };
  }
}
await transport.handleRequest(req, res, req.body);

// ✅ Tools receive auth via RequestHandlerExtra
server.tool('my/tool', schema, async (params, extra) => {
  if (!extra.authInfo) {
    throw new Error('No authentication available');
  }

  const client = createHttpClient({
    headers: { Authorization: `Bearer ${extra.authInfo.token}` }
  });

  return await client.get('/api/data');
});
```

**Request Flow:**
1. API key authentication validates request
2. Session created/retrieved
3. OAuth flow (if needed) obtains platform token
4. Framework injects `req.auth` from session tokens
5. MCP SDK passes `req.auth` to tool as `extra.authInfo`
6. Tool uses token for authenticated API calls

**Architecture Benefits:**
- **Standards Compliant**: Uses MCP SDK's official AuthInfo interface
- **Session-Based**: Tokens cached and reused within session
- **Secure**: No token exposure in logs (preview only)
- **Tool Simplicity**: Tools get clean auth access without complexity

## Key Architecture Components

### Handlers (`src/handlers/`)

**StreamableHTTP Handlers:**
- `streamable-http-handler.ts` - Main unified handler
- `streamable-get-handler.ts` - GET request handling
- `streamable-post-handler.ts` - POST message handling
- `streamable-delete-handler.ts` - DELETE session cleanup

**SSE (Legacy) Handlers:**
- `legacy-sse-handler.ts` - Backward compatibility
- `sse-get-handler.ts` - SSE stream establishment
- `sse-post-handler.ts` - SSE message posting

**Transport Auto-Detection:**
```typescript
// GET requests
Accept: text/event-stream → SSE transport
Accept: application/json → StreamableHTTP transport

// POST requests
Existing SSE session → SSE transport
Otherwise → StreamableHTTP transport
```

### Services (`src/services/`)

**Session Management:**
- `session-manager.ts` - Session lifecycle, tenant isolation
- `in-memory-session-store.ts` - Session storage (default)
- `session-store-factory.ts` - Pluggable session storage

**Transport Management:**
- `transport-store.ts` - Transport instance storage and reuse
- Ensures single transport per session
- Handles transport cleanup on session expiry

**Platform Auth:**
- `platform-auth-service.ts` - OAuth flow orchestration
- Token caching and refresh
- Platform credential management

**Reactive Token Refresh (FAMCP-183)**

The framework refreshes platform OAuth tokens reactively when a tool's API call returns HTTP 401. This handles platforms that rotate tokens on a schedule independent of the stated `expires_in` (e.g. Fluent Commerce rotates at midnight UTC).

Flow:

1. Tool constructs an HTTP/GraphQL client with `onUnauthorized: createAuthRefreshCallback(extra)`.
2. On 401, the shared HTTP client's response interceptor invokes the callback.
3. The callback calls `PlatformAuthService.refreshSessionToken(sessionId)`, which:
   - invokes `handler.invalidateCache?.(authContext)` if the registered handler implements it (flushes handler-internal token caches)
   - calls `handler.authenticate(authContext)` for a fresh token
   - writes the new token into `UnifiedSessionStore.updatePlatformToken`
4. The callback returns refreshed headers; the request is retried exactly once. A second 401 propagates.
5. Subsequent tool calls on the same session pick up the fresh token automatically via `injectAuthContext` reading the store.

Handler registry is encapsulated inside `platform-auth-service.ts` (module-private `handlersRegistry` populated via `PlatformAuthService.registerHandlers(...)` called from the `UnifiedSessionStore` constructor). Handler references are not exposed outside that module — least-privilege.

Tool usage:

```typescript
import { createAuthRefreshCallback } from '@fireflyagents/mcp-server-core';
import { createHttpClient } from '@fireflyagents/mcp-shared-utils';

const client = createHttpClient({
  baseURL,
  headers: { Authorization: `Bearer ${extra.authInfo.token}` },
  onUnauthorized: createAuthRefreshCallback(extra),
});
```

Handlers that cache tokens internally must implement the optional `PlatformAuthHandler.invalidateCache(authContext)` so forced refresh flushes the cache. Without it, a forced refresh may return the stale cached token and the retry will 401 again.

**Health Monitoring:**
- `health-service.ts` - Application health checks
- Dependency status tracking
- Readiness/liveness probes

### Authentication (`src/auth/`)

**API Key Authentication:**
- `extract-auth.ts` - Request authentication (CRITICAL security layer)
- `file-api-key-store.ts` - File-based credential storage with SHA256 hashing
- `dev-key-store.ts` - Simple hardcoded keys for development
- `api-key-store-factory.ts` - Store instantiation

**Admin API (`src/routes/admin.ts`):**
- Role-based access control (FULL/WRITE/READ permissions)
- Self-service credential registration
- Credential export for backup/migration
- Soft-delete (mark as inactive)
- Rate limiting and audit logging

**Security Requirements:**
- All requests must pass API key validation
- 401 response for invalid/missing keys
- Keys hashed with SHA256 before storage
- No raw keys persisted to disk
- Admin operations require separate admin keys with appropriate permissions

### Utilities (`src/utils/`)

**Tool Registration:**
- `tool-registration.ts` - Helper for registering tools with conflict detection
- Namespace management (`namespace__name` pattern)
- Comprehensive logging

**MCP Helpers:**
- `mcp-helpers.ts` - MCP protocol utilities
- Request type detection (initialize, tool call, etc.)
- Session ID extraction

**Structured Responses:**
- `structured-response.ts` - Builder for formatted tool responses
- Privacy-aware data handling
- Consistent response patterns

**Auth Validation:**
- `auth-context-validator.ts` - Validates authentication context structure

## Framework Entry Points

### Primary API

```typescript
import { createServerApp, buildAppConfig } from '@fireflyagents/mcp-server-core';

// Build configuration
const config = buildAppConfig({
  name: 'my-server',
  version: '1.0.0',
  tools: [myTools],
  auth: {
    apiKeyStore: myApiKeyStore,
    platformHandlers: [myOAuthHandler] // Optional
  }
});

// Create server application
const app = await createServerApp(config);

// Start HTTP server
app.listen(3000);
```

### Configuration Builder

**`buildAppConfig()` parameters:**
- `name` - Server name for MCP identification
- `version` - Server version
- `tools` - Array of tool registrar functions
- `prompts` - Array of prompt registrar functions (optional)
- `resources` - Array of resource registrar functions (optional)
- `auth.apiKeyStore` - API key validation implementation (required)
- `auth.platformHandlers` - OAuth handlers for platform integration (optional)
- `serverInfo` - Additional MCP server metadata (optional)

## Logging Standards

All core components use hierarchical context naming:

```typescript
// Format: 'Core:ComponentName' or 'Core:ComponentName:SubComponent'
const logger = baseLogger.child({ context: 'Core:SessionManager' });
const logger = baseLogger.child({ context: 'Core:TransportStore' });
const logger = baseLogger.child({ context: 'Core:Auth:ApiKeyStore' });
```

**Log Levels:**
- `http` - Request/response protocol details
- `info` - Business events (session creation, tool execution)
- `debug` - Implementation details (auth context injection)
- `error` - Failures requiring attention

## Critical Issues & Resolutions

### Multiple Sessions Bug (2025-08-11)
**Issue:** Server created both StreamableHTTP and SSE sessions for single client
**Root Cause:** StreamableHTTP handler wasn't returning `Mcp-Session-Id` header
**Fix:**
- Added `Mcp-Session-Id` header to all StreamableHTTP responses
- Prioritized existing session detection over new session creation
- Improved session ID detection logic (header + query param)

### API Key Auth Bypass (2025-08-14)
**Issue:** Production security vulnerability - auth validation completely bypassed
**Root Cause:** `extract-auth.ts` used mock implementation accepting any key
**Fix:**
- Integrated `ApiKeyStore.validateApiKey()` in authentication flow
- Added proper 401 responses for auth failures
- Updated all handlers to require authentication
- Preserved MCP transport reuse patterns during fix

### Client Timeout Resolution (2025-09-09)
**Issue:** Clients timing out with "No session ID available in MCP context"
**Root Cause:** MCP SDK requires explicit `transport.sessionId` assignment
**Fix:**
- Added `transport.sessionId = sessionId;` in all transport creation paths
- Implemented proper 404 responses for expired sessions (per MCP spec)
- Applied session ID propagation to both StreamableHTTP and SSE transports
**Result:** Eliminated timeouts in multi-session production environments

### Auth Context Integration (2025-08-24)
**Issue:** Tools couldn't access OAuth tokens - `extra.authInfo` was undefined
**Root Cause:** MCP SDK requires `req.auth` property before `transport.handleRequest()`
**Fix:**
- Injected auth context into `req.auth` at session request paths
- Populated from session manager's platform tokens
- Matched exact MCP SDK AuthInfo interface structure
**Result:** Tools can now access OAuth tokens for authenticated API calls

## Testing This Package

Core framework has comprehensive test coverage (>82%):

```bash
# Run core tests (if available)
npm run test --workspace=@fireflyagents/mcp-server-core

# Test from root
npm run test:coverage
```

**Test Focus Areas:**
- Handler routing (16+ scenarios per handler)
- Session lifecycle management
- Transport reuse and cleanup
- Authentication flow (API key + OAuth)
- Error handling and status codes

## Distribution

Core framework can be bundled for distribution:

```bash
# From repository root
npm run pack:dist          # Package for distribution
npm run push:fluent        # Push to consumer project
```

**Bundled Dependencies:**
- `@fireflyagents/mcp-server-types` - Bundled for version consistency
- Other dependencies use standard npm resolution

## Admin API Usage

### Environment Variables

**Role-Based Admin Keys:**
```bash
# Legacy (backward compatible) - Full access
ADMIN_API_KEY=your-super-admin-key

# New role-based keys (recommended)
ADMIN_KEY_FULL_ACCESS=hosting-provider-key    # Export, delete, register, reload
ADMIN_KEY_WRITE_ONLY=customer-self-service-key  # Register credentials only
ADMIN_KEY_READ_ONLY=monitoring-system-key       # Health checks and info only

# Rate limiting (optional)
ADMIN_RATE_LIMIT_WINDOW=60000    # Window in milliseconds (default: 60000 = 1 minute)
ADMIN_RATE_LIMIT_REQUESTS=10     # Max requests per window (default: 10)
```

### Permission Matrix

| Endpoint | Full | Write | Read |
|----------|------|-------|------|
| `POST /admin/credentials/register` | ✅ | ✅ | ❌ |
| `GET /admin/credentials/export` | ✅ | ❌ | ❌ |
| `DELETE /admin/credentials/:hash` | ✅ | ❌ | ❌ |
| `POST /admin/credentials` (upload) | ✅ | ❌ | ❌ |
| `POST /admin/reload` | ✅ | ❌ | ❌ |
| `GET /admin/credentials` (info) | ✅ | ❌ | ✅ |
| `GET /admin/health` | ✅ | ✅ | ✅ |

### Self-Service Registration

**Customer registers new API key:**
```bash
curl -X POST https://your-server.com/admin/credentials/register \
  -H "x-admin-key: write-only-key" \
  -H "Content-Type: application/json" \
  -d '{
    "apiKey": "customer-store-api-key",
    "metadata": {
      "account": "acme",
      "retailer": "store5",
      "environment": "production"
    },
    "platformCredentials": {
      "clientId": "...",
      "clientSecret": "..."
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Credential registered successfully",
  "apiKeyHash": "abc123...***",
  "credentialsCount": 5
}
```

### Backup/Export Credentials

**Export entire credentials file:**
```bash
curl -X GET https://your-server.com/admin/credentials/export \
  -H "x-admin-key: full-access-key"
```

**Response:**
```json
{
  "version": "1.0",
  "environment": "production",
  "credentials": [
    {
      "apiKeyHash": "...",
      "status": "active",
      "createdAt": "2025-01-15T10:30:00.000Z",
      "metadata": { ... },
      "platformCredentials": { ... }
    }
  ]
}
```

### Deactivate Credentials

**Mark credential as inactive (soft delete):**
```bash
curl -X DELETE https://your-server.com/admin/credentials/abc123 \
  -H "x-admin-key: full-access-key"
```

**Response:**
```json
{
  "success": true,
  "message": "Credential marked as inactive",
  "apiKeyHash": "abc123...***"
}
```

## Common Patterns

### Custom API Key Store

```typescript
import { ApiKeyStore, ExtendedAuthContext } from '@fireflyagents/mcp-server-core';

class MyApiKeyStore implements ApiKeyStore {
  async validateApiKey(apiKey: string): Promise<ExtendedAuthContext | null> {
    // Your validation logic
    const valid = await myAuthService.validate(apiKey);

    if (!valid) return null;

    return {
      clientMetadata: { accountId: 'acct-123' },
      platformCredentials: { /* OAuth config */ }
    };
  }
}
```

### Custom Platform Auth Handler

```typescript
import { PlatformAuthHandler, PlatformCredentials } from '@fireflyagents/mcp-server-core';

class MyOAuthHandler implements PlatformAuthHandler {
  async authenticate(
    credentials: PlatformCredentials,
    metadata?: Record<string, unknown>
  ): Promise<{ accessToken: string; expiresAt?: Date }> {
    // Your OAuth flow
    return { accessToken: 'token', expiresAt: new Date() };
  }

  async refreshToken(refreshToken: string): Promise<{ accessToken: string; expiresAt?: Date }> {
    // Your refresh logic
  }
}
```

## Integration with Other Packages

**Depends On:**
- `@fireflyagents/mcp-server-types` - Type definitions (bundled)
- `@fireflyagents/mcp-shared-utils` - Logger, HTTP client
- `@modelcontextprotocol/sdk` - Official MCP SDK

**Used By:**
- Applications in `apps/` (demo-server, minimal-server)
- Plugins in `plugins/` (via plugin SDK)

---

**For application development patterns, see `apps/demo-server/CLAUDE.md` or `apps/minimal-server/CLAUDE.md`**
**For plugin development, see `packages/server/plugin/CLAUDE.md`**