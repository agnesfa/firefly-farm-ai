import { describe, expect, it } from 'vitest';
import {
  validateAuthContext,
  validateBasicAuthContext,
  validateSessionContext,
  type AuthContextValidationConfig,
} from './auth-context-validator.js';

describe('Auth Context Validator', () => {
  describe('validateAuthContext', () => {
    describe('basic validation', () => {
      it('should pass with valid auth context using defaults', () => {
        const validExtra = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {},
          },
        };

        expect(() => validateAuthContext(validExtra)).not.toThrow();
      });

      it('should throw error when sessionId is missing by default', () => {
        const extraWithoutSession = {
          authInfo: {
            token: 'oauth-token',
            metadata: {},
          },
        };

        expect(() => validateAuthContext(extraWithoutSession)).toThrow(
          'No session ID available in MCP context'
        );
      });

      it('should throw error when authInfo is missing by default', () => {
        const extraWithoutAuth = {
          sessionId: 'session-123',
        };

        expect(() => validateAuthContext(extraWithoutAuth)).toThrow(
          'No authentication information available in MCP context'
        );
      });

      it('should allow disabling sessionId requirement', () => {
        const extraWithoutSession = {
          authInfo: {
            token: 'oauth-token',
            metadata: {},
          },
        };

        expect(() =>
          validateAuthContext(extraWithoutSession, { requireSessionId: false })
        ).not.toThrow();
      });

      it('should allow disabling authInfo requirement', () => {
        const extraWithoutAuth = {
          sessionId: 'session-123',
        };

        expect(() =>
          validateAuthContext(extraWithoutAuth, { requireAuthInfo: false })
        ).not.toThrow();
      });

      it('should allow disabling both requirements', () => {
        const minimalExtra = {};

        expect(() =>
          validateAuthContext(minimalExtra, {
            requireSessionId: false,
            requireAuthInfo: false,
          })
        ).not.toThrow();
      });
    });

    describe('metadata field validation', () => {
      it('should pass when required metadata fields are present', () => {
        const validExtra = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              accountId: 'account-123',
              tenantId: 'tenant-456',
              customField: 'custom-value',
            },
          },
        };

        expect(() =>
          validateAuthContext(validExtra, {
            requiredMetadataFields: ['accountId', 'tenantId', 'customField'],
          })
        ).not.toThrow();
      });

      it('should throw error when required metadata field is missing', () => {
        const extraMissingField = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              accountId: 'account-123',
              // Missing tenantId
            },
          },
        };

        expect(() =>
          validateAuthContext(extraMissingField, {
            requiredMetadataFields: ['accountId', 'tenantId'],
          })
        ).toThrow('Missing required auth metadata field: tenantId');
      });

      it('should throw error when metadata object is missing', () => {
        const extraWithoutMetadata = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            // No metadata property
          },
        };

        expect(() =>
          validateAuthContext(extraWithoutMetadata, {
            requiredMetadataFields: ['accountId'],
          })
        ).toThrow('Missing required auth metadata field: accountId');
      });

      it('should throw error when metadata field value is falsy', () => {
        const extraWithFalsyField = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              accountId: '', // Empty string
              tenantId: null, // Null value
              userId: undefined, // Undefined value
            },
          },
        };

        expect(() =>
          validateAuthContext(extraWithFalsyField, {
            requiredMetadataFields: ['accountId'],
          })
        ).toThrow('Missing required auth metadata field: accountId');

        expect(() =>
          validateAuthContext(extraWithFalsyField, {
            requiredMetadataFields: ['tenantId'],
          })
        ).toThrow('Missing required auth metadata field: tenantId');

        expect(() =>
          validateAuthContext(extraWithFalsyField, {
            requiredMetadataFields: ['userId'],
          })
        ).toThrow('Missing required auth metadata field: userId');
      });

      it('should handle multiple missing metadata fields', () => {
        const extraMissingMultiple = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              // Missing both accountId and tenantId
            },
          },
        };

        // Should throw on first missing field
        expect(() =>
          validateAuthContext(extraMissingMultiple, {
            requiredMetadataFields: ['accountId', 'tenantId'],
          })
        ).toThrow('Missing required auth metadata field: accountId');
      });
    });

    describe('custom error messages', () => {
      it('should use custom error message for missing session ID', () => {
        const extraWithoutSession = {
          authInfo: { token: 'oauth-token' },
        };

        const customConfig: AuthContextValidationConfig = {
          errorMessages: {
            missingSessionId: 'Custom session error message',
          },
        };

        expect(() => validateAuthContext(extraWithoutSession, customConfig)).toThrow(
          'Custom session error message'
        );
      });

      it('should use custom error message for missing auth info', () => {
        const extraWithoutAuth = {
          sessionId: 'session-123',
        };

        const customConfig: AuthContextValidationConfig = {
          errorMessages: {
            missingAuthInfo: 'Custom auth info error message',
          },
        };

        expect(() => validateAuthContext(extraWithoutAuth, customConfig)).toThrow(
          'Custom auth info error message'
        );
      });

      it('should use custom error message function for missing metadata fields', () => {
        const extraMissingField = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {},
          },
        };

        const customConfig: AuthContextValidationConfig = {
          requiredMetadataFields: ['apiKey'],
          errorMessages: {
            missingMetadataField: (field) => `Custom metadata error for ${field}`,
          },
        };

        expect(() => validateAuthContext(extraMissingField, customConfig)).toThrow(
          'Custom metadata error for apiKey'
        );
      });

      it('should merge custom error messages with defaults', () => {
        const extraWithoutSession = {
          authInfo: { token: 'oauth-token' },
        };

        const partialConfig: AuthContextValidationConfig = {
          errorMessages: {
            missingSessionId: 'Custom session message',
            // missingAuthInfo not specified - should use default
          },
        };

        expect(() => validateAuthContext(extraWithoutSession, partialConfig)).toThrow(
          'Custom session message'
        );
      });
    });

    describe('complex scenarios', () => {
      it('should handle deeply nested metadata structures', () => {
        const complexExtra = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            scopes: ['read', 'write'],
            metadata: {
              platform: {
                accountId: 'account-123',
                environment: 'production',
              },
              user: {
                id: 'user-456',
                roles: ['admin'],
              },
              nested: {
                deep: {
                  value: 'deep-nested-value',
                },
              },
            },
          },
        };

        // Flat field access (won't work with current implementation)
        expect(() =>
          validateAuthContext(complexExtra, {
            requiredMetadataFields: ['platform'], // This will work (object exists)
          })
        ).not.toThrow();

        // Missing field
        expect(() =>
          validateAuthContext(complexExtra, {
            requiredMetadataFields: ['nonExistentField'],
          })
        ).toThrow('Missing required auth metadata field: nonExistentField');
      });

      it('should handle edge case values in metadata', () => {
        const edgeCaseExtra = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              zeroValue: 0,
              falseValue: false,
              emptyArray: [],
              emptyObject: {},
            },
          },
        };

        // These should be considered "present" even though they're falsy
        expect(() =>
          validateAuthContext(edgeCaseExtra, {
            requiredMetadataFields: ['zeroValue'],
          })
        ).not.toThrow();

        expect(() =>
          validateAuthContext(edgeCaseExtra, {
            requiredMetadataFields: ['falseValue'],
          })
        ).not.toThrow();

        expect(() =>
          validateAuthContext(edgeCaseExtra, {
            requiredMetadataFields: ['emptyArray'],
          })
        ).not.toThrow();

        expect(() =>
          validateAuthContext(edgeCaseExtra, {
            requiredMetadataFields: ['emptyObject'],
          })
        ).not.toThrow();
      });

      it('should validate multiple fields with mixed presence', () => {
        const mixedExtra = {
          sessionId: 'session-123',
          authInfo: {
            token: 'oauth-token',
            metadata: {
              accountId: 'account-123',
              tenantId: 'tenant-456',
              // Missing userId and orgId
            },
          },
        };

        // Should pass for present fields
        expect(() =>
          validateAuthContext(mixedExtra, {
            requiredMetadataFields: ['accountId', 'tenantId'],
          })
        ).not.toThrow();

        // Should fail for missing field
        expect(() =>
          validateAuthContext(mixedExtra, {
            requiredMetadataFields: ['accountId', 'userId'],
          })
        ).toThrow('Missing required auth metadata field: userId');
      });
    });

    describe('configuration merging', () => {
      it('should merge partial config with defaults correctly', () => {
        const extraWithoutAuth = {
          sessionId: 'session-123',
        };

        const partialConfig: AuthContextValidationConfig = {
          requireAuthInfo: false, // Override default
          // Other fields should use defaults
        };

        // Should not throw because we disabled authInfo requirement
        expect(() => validateAuthContext(extraWithoutAuth, partialConfig)).not.toThrow();
      });

      it('should handle empty config (use all defaults)', () => {
        const validExtra = {
          sessionId: 'session-123',
          authInfo: { token: 'oauth-token', metadata: {} },
        };

        expect(() => validateAuthContext(validExtra, {})).not.toThrow();
      });

      it('should handle config with only error message overrides', () => {
        const extraWithoutSession = {
          authInfo: { token: 'oauth-token' },
        };

        const messageOnlyConfig: AuthContextValidationConfig = {
          errorMessages: {
            missingSessionId: 'Please provide session identifier',
          },
        };

        expect(() => validateAuthContext(extraWithoutSession, messageOnlyConfig)).toThrow(
          'Please provide session identifier'
        );
      });
    });
  });

  describe('validateBasicAuthContext', () => {
    it('should require both sessionId and authInfo', () => {
      const validExtra = {
        sessionId: 'session-123',
        authInfo: { token: 'oauth-token', metadata: {} },
      };

      const extraWithoutSession = {
        authInfo: { token: 'oauth-token' },
      };

      const extraWithoutAuth = {
        sessionId: 'session-123',
      };

      expect(() => validateBasicAuthContext(validExtra)).not.toThrow();
      expect(() => validateBasicAuthContext(extraWithoutSession)).toThrow(
        'No session ID available in MCP context'
      );
      expect(() => validateBasicAuthContext(extraWithoutAuth)).toThrow(
        'No authentication information available in MCP context'
      );
    });

    it('should not require metadata fields by default', () => {
      const validExtra = {
        sessionId: 'session-123',
        authInfo: {
          token: 'oauth-token',
          metadata: {}, // Empty metadata is OK
        },
      };

      expect(() => validateBasicAuthContext(validExtra)).not.toThrow();
    });
  });

  describe('validateSessionContext', () => {
    it('should require only sessionId', () => {
      const validExtraWithSession = {
        sessionId: 'session-123',
        // No authInfo required
      };

      const validExtraWithBoth = {
        sessionId: 'session-123',
        authInfo: { token: 'oauth-token' }, // AuthInfo can be present but not required
      };

      const extraWithoutSession = {
        authInfo: { token: 'oauth-token' },
        // Missing sessionId
      };

      expect(() => validateSessionContext(validExtraWithSession)).not.toThrow();
      expect(() => validateSessionContext(validExtraWithBoth)).not.toThrow();
      expect(() => validateSessionContext(extraWithoutSession)).toThrow(
        'No session ID available in MCP context'
      );
    });

    it('should not require authInfo', () => {
      const sessionOnlyExtra = {
        sessionId: 'session-123',
        // Explicitly no authInfo
      };

      expect(() => validateSessionContext(sessionOnlyExtra)).not.toThrow();
    });
  });

  describe('real-world usage scenarios', () => {
    it('should validate Fluent Commerce auth requirements', () => {
      const fluentExtra = {
        sessionId: 'session-123',
        authInfo: {
          token: 'oauth-token',
          metadata: {
            accountId: 'AGNESAPAC',
            retailerId: 'agnes-retailer',
          },
        },
      };

      const fluentConfig: AuthContextValidationConfig = {
        requiredMetadataFields: ['accountId', 'retailerId'],
      };

      expect(() => validateAuthContext(fluentExtra, fluentConfig)).not.toThrow();

      // Test missing Fluent field
      const fluentExtraMissingRetailer = {
        sessionId: 'session-123',
        authInfo: {
          token: 'oauth-token',
          metadata: {
            accountId: 'AGNESAPAC',
            // Missing retailerId
          },
        },
      };

      expect(() => validateAuthContext(fluentExtraMissingRetailer, fluentConfig)).toThrow(
        'Missing required auth metadata field: retailerId'
      );
    });

    it('should validate Shopify-style auth requirements', () => {
      const shopifyExtra = {
        sessionId: 'session-123',
        authInfo: {
          token: 'shopify-access-token',
          metadata: {
            shopDomain: 'test-shop.myshopify.com',
            apiVersion: '2023-10',
          },
        },
      };

      const shopifyConfig: AuthContextValidationConfig = {
        requiredMetadataFields: ['shopDomain', 'apiVersion'],
        errorMessages: {
          missingMetadataField: (field) => `Shopify ${field} is required`,
        },
      };

      expect(() => validateAuthContext(shopifyExtra, shopifyConfig)).not.toThrow();

      // Test custom error message
      const shopifyExtraMissingDomain = {
        sessionId: 'session-123',
        authInfo: {
          token: 'shopify-access-token',
          metadata: {
            apiVersion: '2023-10',
            // Missing shopDomain
          },
        },
      };

      expect(() => validateAuthContext(shopifyExtraMissingDomain, shopifyConfig)).toThrow(
        'Shopify shopDomain is required'
      );
    });

    it('should validate minimal API key auth requirements', () => {
      const apiKeyExtra = {
        sessionId: 'session-123',
        authInfo: {
          token: 'api-key-12345',
          metadata: {
            keyId: 'key-abc123',
          },
        },
      };

      const apiKeyConfig: AuthContextValidationConfig = {
        requiredMetadataFields: ['keyId'],
        errorMessages: {
          missingAuthInfo: 'API key authentication required',
          missingMetadataField: (field) => `API key ${field} not found`,
        },
      };

      expect(() => validateAuthContext(apiKeyExtra, apiKeyConfig)).not.toThrow();

      // Test custom auth info error
      const extraWithoutAuth = {
        sessionId: 'session-123',
      };

      expect(() => validateAuthContext(extraWithoutAuth, apiKeyConfig)).toThrow(
        'API key authentication required'
      );
    });

    it('should validate session-only tools (no auth required)', () => {
      const sessionOnlyExtra = {
        sessionId: 'session-123',
        // Tools that don't need OAuth can work with session only
      };

      const sessionOnlyConfig: AuthContextValidationConfig = {
        requireAuthInfo: false,
        errorMessages: {
          missingSessionId: 'Session required for tool execution',
        },
      };

      expect(() => validateAuthContext(sessionOnlyExtra, sessionOnlyConfig)).not.toThrow();

      // Test custom session error
      const extraWithoutSession = {};

      expect(() => validateAuthContext(extraWithoutSession, sessionOnlyConfig)).toThrow(
        'Session required for tool execution'
      );
    });
  });

  describe('edge cases', () => {
    it('should handle null and undefined values in extra', () => {
      const extraWithNulls = {
        sessionId: null,
        authInfo: undefined,
      };

      expect(() => validateAuthContext(extraWithNulls)).toThrow(
        'No session ID available in MCP context'
      );
    });

    it('should handle non-object authInfo', () => {
      const extraWithPrimitiveAuth = {
        sessionId: 'session-123',
        authInfo: 'not-an-object',
      };

      expect(() =>
        validateAuthContext(extraWithPrimitiveAuth, {
          requiredMetadataFields: ['accountId'],
        })
      ).toThrow('Missing required auth metadata field: accountId');
    });

    it('should handle non-object metadata', () => {
      const extraWithPrimitiveMetadata = {
        sessionId: 'session-123',
        authInfo: {
          token: 'oauth-token',
          metadata: 'not-an-object',
        },
      };

      expect(() =>
        validateAuthContext(extraWithPrimitiveMetadata, {
          requiredMetadataFields: ['accountId'],
        })
      ).toThrow('Missing required auth metadata field: accountId');
    });

    it('should handle empty extra object', () => {
      const emptyExtra = {};

      expect(() => validateAuthContext(emptyExtra)).toThrow(
        'No session ID available in MCP context'
      );
    });
  });
});