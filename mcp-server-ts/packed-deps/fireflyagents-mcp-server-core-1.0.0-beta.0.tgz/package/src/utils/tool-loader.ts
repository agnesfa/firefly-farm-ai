// mcp-server/tool-loader.ts
import type { ToolDefinition, McpServerInstance } from "@fireflyagents/mcp-server-types"
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:core:tool-loader' });

/**
 * @deprecated Use tool-registration instead
 * Registers an array of tools on the given MCP server.
 * Skips disabled tools automatically.
 */
export function registerTools(
  server: McpServerInstance,
  ...tools: ToolDefinition[]
): void {
  for (const tool of tools) {
    if (tool.enabled === false) continue;

    const fullName = tool.namespace
      ? `${tool.namespace}__${tool.name}`
      : tool.name;

    const handler = tool.handler as any; // TS workaround

    if (tool.inputSchema) {
      const schema = tool.inputSchema;

      if (tool.description) {
        server.tool(fullName, tool.description, schema, handler);
      } else {
        server.tool(fullName, schema, handler);
      }
    } else {
      if (tool.description) {
        server.tool(fullName, tool.description, handler);
      } else {
        server.tool(fullName, handler);
      }
    }
    logger.info(`✅ Registered tool: ${fullName} (${tool.version ?? "v1"})`);
  }
}