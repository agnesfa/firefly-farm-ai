import { describe, it, expect, vi, beforeEach } from 'vitest';
import { registerPrompt, registerPrompts } from './prompt-registration.js';
import { type Prompt, z } from '@fireflyagents/mcp-server-types';

// Mock logger
vi.mock('@fireflyagents/mcp-shared-utils', () => ({
  logger: {
    child: () => ({
      warn: vi.fn(),
      debug: vi.fn(),
    }),
  },
}));

describe('prompt-registration', () => {
  const mockServer = {
    prompt: vi.fn(),
  };

  const mockPromptWithParams: Prompt = {
    namespace: 'test',
    name: 'test_prompt',
    title: 'Test Prompt',
    description: 'A test prompt',
    paramsSchema: {
      input: z.string().optional().describe('Test input parameter'),
    },
    handler: vi.fn().mockResolvedValue({
      messages: [{ role: 'user', content: { type: 'text', text: 'test' } }]
    }),
  };

  const mockPromptWithoutParams: Prompt = {
    namespace: 'test',
    name: 'simple_prompt',
    title: 'Simple Prompt',
    description: 'A simple prompt',
    handler: vi.fn().mockResolvedValue({
      messages: [{ role: 'user', content: { type: 'text', text: 'test' } }]
    }),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('registerPrompt', () => {
    it('should register prompt with parameters', () => {
      registerPrompt(mockServer as any, mockPromptWithParams);

      expect(mockServer.prompt).toHaveBeenCalledWith(
        'test__test_prompt',
        'A test prompt',
        mockPromptWithParams.paramsSchema,
        mockPromptWithParams.handler
      );
    });

    it('should register prompt without parameters', () => {
      registerPrompt(mockServer as any, mockPromptWithoutParams);

      expect(mockServer.prompt).toHaveBeenCalledWith(
        'test__simple_prompt',
        'A simple prompt',
        {},
        expect.any(Function)
      );
    });

    it('should use title as fallback when description is not provided', () => {
      const promptWithoutDescription: Prompt = {
        ...mockPromptWithParams,
        description: undefined,
      };

      registerPrompt(mockServer as any, promptWithoutDescription);

      expect(mockServer.prompt).toHaveBeenCalledWith(
        'test__test_prompt',
        'Test Prompt',
        mockPromptWithParams.paramsSchema,
        mockPromptWithParams.handler
      );
    });

    it('should allow registering duplicate prompt names', () => {
      // Register same prompt twice - should successfully register both
      registerPrompt(mockServer as any, mockPromptWithParams);
      registerPrompt(mockServer as any, mockPromptWithParams);

      // Both registrations should have happened
      expect(mockServer.prompt).toHaveBeenCalledTimes(2);
      expect(mockServer.prompt).toHaveBeenNthCalledWith(
        1,
        'test__test_prompt',
        'A test prompt',
        mockPromptWithParams.paramsSchema,
        mockPromptWithParams.handler
      );
      expect(mockServer.prompt).toHaveBeenNthCalledWith(
        2,
        'test__test_prompt',
        'A test prompt',
        mockPromptWithParams.paramsSchema,
        mockPromptWithParams.handler
      );
    });
  });

  describe('registerPrompts', () => {
    it('should register multiple prompts', () => {
      const prompts = [mockPromptWithParams, mockPromptWithoutParams];

      registerPrompts(mockServer as any, prompts);

      expect(mockServer.prompt).toHaveBeenCalledTimes(2);
    });
  });
});