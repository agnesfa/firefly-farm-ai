import { Request, Response } from 'express';
import {RequestContext} from "@fireflyagents/mcp-server-types";
import {randomUUID} from "crypto";
import {requestLoggerFactory} from "@fireflyagents/mcp-shared-utils/dist/logger/request-logger-factory.js";
import {getUnifiedSessionStore} from "../services/unified-session-store.js";

export function createRequestContext(req: Request, logger: any): RequestContext {
    const requestId = randomUUID();
    const startTime = Date.now();
    const sessionId = req.headers['mcp-session-id'] as string || req.query.sessionId as string;
    const acceptHeader = req.headers.accept || '';
    const originHeader = req.headers.origin || '';
    const refererHeader = req.headers.referer || '';
    const mcpProtocolVersionHeader = req.headers['mcp-protocol-version'] || '';
    const mcpMethod = req.body?.method || '';

    const requestLogger = requestLoggerFactory(logger, req, requestId, sessionId);
    requestLogger.http('Request received', {
        contentType: req.headers['content-type'],
        contentLength: req.headers['content-length'],
        mcpProtocolVersion: mcpProtocolVersionHeader,
        mcpMethod: mcpMethod,
    });

    requestLogger.debug('Request received', {
        contentType: req.headers['content-type'],
        contentLength: req.headers['content-length'],
        accept: acceptHeader,
        clientIp: req.ip,
        origin: originHeader,
        referer: refererHeader,
        mcpProtocolVersion: mcpProtocolVersionHeader,
        mcpMethod: mcpMethod,
    });

    return { requestId, startTime, sessionId, requestLogger };
}

export function injectAuthContext(sessionId: string, req: Request, authContext: any, sessionLogger: any) {
    // Add auth context directly to original request for MCP SDK
    const unifiedStore = getUnifiedSessionStore();
    const sessionData = unifiedStore['sessions'].get(sessionId); // Direct access to map for synchronous operation

    const platformToken = unifiedStore.getPlatformToken(sessionId, 'default');
    sessionLogger.debug('Auth context injection attempt for existing session', {
        sessionId: sessionId,
        hasSession: !!sessionData,
        hasPlatformToken: !!platformToken,
        tokenPreview: platformToken ? platformToken.accessToken.substring(0, 10) + '...' : 'none'
    });

    if (platformToken) {
        (req as any).auth = {
            sessionId: sessionId,
            tenantId: sessionData?.tenantId,
            token: platformToken.accessToken,
            expiresAt: platformToken.expiresAt ? Math.floor(platformToken.expiresAt.getTime() / 1000) : undefined,
            metadata: sessionData?.authContext.clientMetadata
        };
        sessionLogger.debug('Auth context added to existing session request', {
            sessionId: sessionId,
            tokenPreview: platformToken.accessToken.substring(0, 20) + '...',
            originalRequest: true
        });
    } else {
        sessionLogger.warn('No platform token found for existing session', {
            sessionId: sessionId,
            tenantId: sessionData?.tenantId
        });
    }
}

export function isAuthenticationError(errorMessage: string): boolean {
    return errorMessage.includes('Invalid API key') || errorMessage.includes('API key is required');
}

export function handleAuthenticationError(req: Request, res: Response, context: RequestContext, errorMessage: string) {
    context.requestLogger.warn('Authentication failed', {
        error: errorMessage,
        sessionId: context.sessionId,
        clientIp: req.ip,
        userAgent: req.headers['user-agent'],
        duration: Date.now() - context.startTime
    });

    if (!res.headersSent) {
        res.status(401).json({
            error: {
                code: -32001,
                message: 'Authentication failed',
                data: {reason: errorMessage}
            }
        });
    }
}