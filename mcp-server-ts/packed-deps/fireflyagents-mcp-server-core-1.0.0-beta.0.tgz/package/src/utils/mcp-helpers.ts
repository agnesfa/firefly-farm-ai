/**
 * Check if a request body represents an MCP initialization request
 */
export function isInitializeRequest(body: any): boolean {
  return !!(
    body &&
    body.jsonrpc === '2.0' &&
    body.method === 'initialize' &&
    body.params &&
    typeof body.params.protocolVersion === 'string'
  );
}

/**
 * Extract MCP method from request body if available
 */
export function getMcpMethod(body: any): string | undefined {
  return body?.method;
}