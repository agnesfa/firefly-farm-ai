import { describe, it, expect } from 'vitest';
import { isInitializeRequest, getMcpMethod } from './mcp-helpers.js';

describe('MCP Helpers', () => {
  describe('isInitializeRequest', () => {
    it('should return true for valid initialize request', () => {
      const validRequest = {
        jsonrpc: '2.0',
        method: 'initialize',
        params: {
          protocolVersion: '2024-11-05',
          clientInfo: { name: 'test-client', version: '1.0.0' },
        },
        id: 1,
      };

      expect(isInitializeRequest(validRequest)).toBe(true);
    });

    it('should return false for missing jsonrpc', () => {
      const request = {
        method: 'initialize',
        params: { protocolVersion: '2024-11-05' },
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for wrong jsonrpc version', () => {
      const request = {
        jsonrpc: '1.0',
        method: 'initialize',
        params: { protocolVersion: '2024-11-05' },
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for wrong method', () => {
      const request = {
        jsonrpc: '2.0',
        method: 'tools/list',
        params: { protocolVersion: '2024-11-05' },
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for missing params', () => {
      const request = {
        jsonrpc: '2.0',
        method: 'initialize',
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for missing protocolVersion', () => {
      const request = {
        jsonrpc: '2.0',
        method: 'initialize',
        params: { clientInfo: { name: 'test' } },
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for non-string protocolVersion', () => {
      const request = {
        jsonrpc: '2.0',
        method: 'initialize',
        params: { protocolVersion: 123 },
      };

      expect(isInitializeRequest(request)).toBe(false);
    });

    it('should return false for null/undefined input', () => {
      expect(isInitializeRequest(null)).toBe(false);
      expect(isInitializeRequest(undefined)).toBe(false);
    });

    it('should return false for non-object input', () => {
      expect(isInitializeRequest('string')).toBe(false);
      expect(isInitializeRequest(123)).toBe(false);
      expect(isInitializeRequest(true)).toBe(false);
    });
  });

  describe('getMcpMethod', () => {
    it('should return method from valid request body', () => {
      const body = {
        jsonrpc: '2.0',
        method: 'tools/list',
        id: 1,
      };

      expect(getMcpMethod(body)).toBe('tools/list');
    });

    it('should return initialize method', () => {
      const body = {
        jsonrpc: '2.0',
        method: 'initialize',
        params: { protocolVersion: '2024-11-05' },
      };

      expect(getMcpMethod(body)).toBe('initialize');
    });

    it('should return tools/call method', () => {
      const body = {
        jsonrpc: '2.0',
        method: 'tools/call',
        params: { name: 'demo/hello' },
      };

      expect(getMcpMethod(body)).toBe('tools/call');
    });

    it('should return undefined for missing method', () => {
      const body = {
        jsonrpc: '2.0',
        id: 1,
      };

      expect(getMcpMethod(body)).toBeUndefined();
    });

    it('should return undefined for null/undefined input', () => {
      expect(getMcpMethod(null)).toBeUndefined();
      expect(getMcpMethod(undefined)).toBeUndefined();
    });

    it('should return undefined for non-object input', () => {
      expect(getMcpMethod('string')).toBeUndefined();
      expect(getMcpMethod(123)).toBeUndefined();
      expect(getMcpMethod(true)).toBeUndefined();
    });

    it('should handle nested method access safely', () => {
      const body = { nested: { method: 'should-not-access' } };
      expect(getMcpMethod(body)).toBeUndefined();
    });
  });
});