import { describe, it, expect, vi, beforeEach } from 'vitest';
import { registerResource, registerResources } from './resource-registration.js';
import type { Resource } from '@fireflyagents/mcp-server-types';

// Mock logger
vi.mock('@fireflyagents/mcp-shared-utils', () => ({
  logger: {
    child: () => ({
      warn: vi.fn(),
      debug: vi.fn(),
    }),
  },
}));

describe('resource-registration', () => {
  const mockServer = {
    resource: vi.fn(),
  };

  const mockResourceWithOptions: Resource = {
    namespace: 'test',
    name: 'config_file',
    title: 'Config File',
    description: 'A configuration file resource',
    uriTemplate: 'config://test.json',
    handler: vi.fn().mockResolvedValue({
      contents: [{ uri: 'config://test.json', mimeType: 'application/json', text: '{}' }]
    }),
    options: {
      mimeType: 'application/json'
    }
  };

  const mockResourceWithoutOptions: Resource = {
    namespace: 'test',
    name: 'simple_resource',
    title: 'Simple Resource',
    description: 'A simple resource',
    uriTemplate: 'simple://resource',
    handler: vi.fn().mockResolvedValue({
      contents: [{ uri: 'simple://resource', mimeType: 'text/plain', text: 'content' }]
    }),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('registerResource', () => {
    it('should register resource with options', () => {
      registerResource(mockServer as any, mockResourceWithOptions);

      expect(mockServer.resource).toHaveBeenCalledWith(
        'Config File',
        'config://test.json',
        {
          description: 'A configuration file resource',
          mimeType: 'application/json'
        },
        mockResourceWithOptions.handler
      );
    });

    it('should register resource without options', () => {
      registerResource(mockServer as any, mockResourceWithoutOptions);

      expect(mockServer.resource).toHaveBeenCalledWith(
        'Simple Resource',
        'simple://resource',
        {
          description: 'A simple resource',
          mimeType: undefined
        },
        mockResourceWithoutOptions.handler
      );
    });

    it('should register resource without description', () => {
      const resourceWithoutDescription: Resource = {
        ...mockResourceWithOptions,
        description: undefined,
      };

      registerResource(mockServer as any, resourceWithoutDescription);

      expect(mockServer.resource).toHaveBeenCalledWith(
        'Config File',
        'config://test.json',
        {
          description: undefined,
          mimeType: 'application/json'
        },
        resourceWithoutDescription.handler
      );
    });

    it('should allow registering duplicate resource names', () => {
      // Register same resource twice - should successfully register both
      registerResource(mockServer as any, mockResourceWithOptions);
      registerResource(mockServer as any, mockResourceWithOptions);

      // Both registrations should have happened
      expect(mockServer.resource).toHaveBeenCalledTimes(2);
      expect(mockServer.resource).toHaveBeenNthCalledWith(
        1,
        'Config File',
        'config://test.json',
        {
          description: 'A configuration file resource',
          mimeType: 'application/json'
        },
        mockResourceWithOptions.handler
      );
      expect(mockServer.resource).toHaveBeenNthCalledWith(
        2,
        'Config File',
        'config://test.json',
        {
          description: 'A configuration file resource',
          mimeType: 'application/json'
        },
        mockResourceWithOptions.handler
      );
    });
  });

  describe('registerResources', () => {
    it('should register multiple resources', () => {
      const resources = [mockResourceWithOptions, mockResourceWithoutOptions];

      registerResources(mockServer as any, resources);

      expect(mockServer.resource).toHaveBeenCalledTimes(2);
    });

    it('should register empty array without error', () => {
      registerResources(mockServer as any, []);

      expect(mockServer.resource).not.toHaveBeenCalled();
    });
  });

  describe('handler integration', () => {
    it('should preserve original handler functionality', async () => {
      const mockHandler = vi.fn().mockResolvedValue({
        contents: [{ uri: 'test://uri', mimeType: 'text/plain', text: 'test content' }]
      });

      const resource: Resource = {
        namespace: 'test',
        name: 'handler_test',
        title: 'Handler Test',
        uriTemplate: 'test://uri',
        handler: mockHandler
      };

      registerResource(mockServer as any, resource);

      // Verify the handler was passed through correctly
      expect(mockServer.resource).toHaveBeenCalledWith(
        'Handler Test',
        'test://uri',
        expect.any(Object),
        mockHandler
      );

      // Verify handler can still be called
      const result = await mockHandler(new URL('test://uri'));
      expect(result).toEqual({
        contents: [{ uri: 'test://uri', mimeType: 'text/plain', text: 'test content' }]
      });
    });
  });
});