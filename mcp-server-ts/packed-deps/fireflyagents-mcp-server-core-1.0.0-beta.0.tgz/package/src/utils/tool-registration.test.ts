import { describe, it, expect, beforeEach, vi } from 'vitest';
import { z, type Tool } from '@fireflyagents/mcp-server-types';
import {
  registerTool,
  registerTools
} from './tool-registration.js';

// Mock MCP Server
const createMockServer = () => ({
  tool: vi.fn(),
  registerTool: vi.fn(),
});

// Mock logger to avoid console output in tests
vi.mock('@fireflyagents/mcp-shared-utils', () => ({
  logger: {
    child: () => ({
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      debug: vi.fn(),
    }),
  },
}));

describe('Tool Registration System', () => {
  let mockServer: ReturnType<typeof createMockServer>;

  beforeEach(() => {
    mockServer = createMockServer();
  });

  describe('registerTool', () => {
    it('should register a tool with correct namespace and name', () => {
      const tool: Tool = {
        namespace: 'test',
        name: 'hello',
        title: 'Test Hello Tool',
        description: 'A test tool for greeting',
        paramsSchema: z.object({ name: z.string().optional() }).shape,
        options: { readOnlyHint: true },
        handler: async ({ name }) => ({
          content: [{ type: 'text' as const, text: `Hello ${name || 'world'}!` }]
        })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'test__hello',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: tool.paramsSchema,
          annotations: { readOnlyHint: true }
        },
        tool.handler
      );
    });

    it('should register tool with minimal required fields', () => {
      const tool: Tool = {
        namespace: 'minimal',
        name: 'test',
        title: 'Minimal Test Tool',
        paramsSchema: z.object({}).shape,
        handler: async () => ({
          content: [{ type: 'text' as const, text: 'minimal test' }]
        })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'minimal__test',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: tool.paramsSchema
        },
        tool.handler
      );
    });

    it('should handle complex parameter schemas correctly', () => {
      const complexSchema = z.object({
        id: z.string().describe('Resource ID'),
        filters: z.object({
          status: z.enum(['active', 'inactive']).optional(),
          limit: z.number().min(1).max(100).optional()
        }).optional(),
        includeMetadata: z.boolean().default(false)
      });

      const tool: Tool = {
        namespace: 'complex',
        name: 'query',
        title: 'Complex Query Tool',
        paramsSchema: complexSchema.shape,
        handler: async (params) => ({
          content: [{ type: 'text' as const, text: `Query result for ${params.id}` }]
        })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'complex__query',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: complexSchema.shape
        },
        tool.handler
      );
    });

    it('should allow registering duplicate tool names', () => {
      const tool1: Tool = {
        namespace: 'duplicate',
        name: 'test',
        title: 'First Tool',
        paramsSchema: z.object({}).shape,
        handler: async () => ({ content: [{ type: 'text' as const, text: 'first' }] })
      };

      const tool2: Tool = {
        namespace: 'duplicate',
        name: 'test',
        title: 'Second Tool',
        paramsSchema: z.object({}).shape,
        handler: async () => ({ content: [{ type: 'text' as const, text: 'second' }] })
      };

      // Register first tool
      registerTool(mockServer as any, tool1);
      expect(mockServer.registerTool).toHaveBeenCalledTimes(1);

      // Register duplicate - should successfully register both
      registerTool(mockServer as any, tool2);
      expect(mockServer.registerTool).toHaveBeenCalledTimes(2);

      // Both registrations should have happened
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        1, 'duplicate__test', {
          title: tool1.title,
          description: tool1.description,
          inputSchema: tool1.paramsSchema
        }, tool1.handler
      );
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        2, 'duplicate__test', {
          title: tool2.title,
          description: tool2.description,
          inputSchema: tool2.paramsSchema
        }, tool2.handler
      );
    });

    it('should handle different namespace separators correctly', () => {
      // The implementation uses __ separator, so verify this behavior
      const tool: Tool = {
        namespace: 'name_space',
        name: 'tool_name',
        title: 'Underscore Test',
        paramsSchema: z.object({}).shape,
        handler: async () => ({ content: [{ type: 'text' as const, text: 'test' }] })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'name_space__tool_name',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: tool.paramsSchema
        },
        tool.handler
      );
    });

    it('should preserve tool options when provided', () => {
      const tool: Tool = {
        namespace: 'options',
        name: 'test',
        title: 'Options Test',
        paramsSchema: z.object({}).shape,
        options: {
          readOnlyHint: true,
          experimental: true
        },
        handler: async () => ({ content: [{ type: 'text' as const, text: 'test' }] })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'options__test',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: tool.paramsSchema,
          annotations: { readOnlyHint: true }
        },
        tool.handler
      );
    });

    it('should register output schema when provided', () => {
      const tool: Tool = {
        namespace: 'structured',
        name: 'output',
        title: 'Structured Output Tool',
        description: 'A tool with structured output',
        paramsSchema: z.object({ query: z.string() }).shape,
        outputSchema: z.object({
          results: z.array(z.string()),
          count: z.number()
        }).shape,
        handler: async ({ query }) => ({
          content: [{
            type: 'text' as const,
            text: `Structured results for: ${query}`
          }]
        })
      };

      registerTool(mockServer as any, tool);

      expect(mockServer.registerTool).toHaveBeenCalledWith(
        'structured__output',
        {
          title: tool.title,
          description: tool.description,
          inputSchema: tool.paramsSchema,
          outputSchema: tool.outputSchema
        },
        tool.handler
      );
    });
  });

  describe('registerTools', () => {
    it('should register multiple tools at once', () => {
      const tools: Tool[] = [
        {
          namespace: 'batch',
          name: 'first',
          title: 'First Tool',
          paramsSchema: z.object({}).shape,
          handler: async () => ({ content: [{ type: 'text' as const, text: 'first' }] })
        },
        {
          namespace: 'batch',
          name: 'second',
          title: 'Second Tool',
          paramsSchema: z.object({ id: z.string() }).shape,
          handler: async ({ id }) => ({ content: [{ type: 'text' as const, text: `second: ${id}` }] })
        },
        {
          namespace: 'other',
          name: 'third',
          title: 'Third Tool',
          paramsSchema: z.object({ count: z.number() }).shape,
          handler: async ({ count }) => ({ content: [{ type: 'text' as const, text: `count: ${count}` }] })
        }
      ];

      registerTools(mockServer as any, tools);

      expect(mockServer.registerTool).toHaveBeenCalledTimes(3);
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        1, 'batch__first', {
          title: tools[0].title,
          description: tools[0].description,
          inputSchema: tools[0].paramsSchema
        }, tools[0].handler
      );
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        2, 'batch__second', {
          title: tools[1].title,
          description: tools[1].description,
          inputSchema: tools[1].paramsSchema
        }, tools[1].handler
      );
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        3, 'other__third', {
          title: tools[2].title,
          description: tools[2].description,
          inputSchema: tools[2].paramsSchema
        }, tools[2].handler
      );
    });

    it('should handle empty tools array', () => {
      registerTools(mockServer as any, []);

      expect(mockServer.registerTool).not.toHaveBeenCalled();
    });

    it('should handle mixed tool configurations', () => {
      const tools: Tool[] = [
        {
          namespace: 'mixed',
          name: 'minimal',
          title: 'Minimal Tool',
          paramsSchema: z.object({}).shape,
          handler: async () => ({ content: [{ type: 'text' as const, text: 'minimal' }] })
        },
        {
          namespace: 'mixed',
          name: 'complex',
          title: 'Complex Tool',
          description: 'A more complex tool',
          paramsSchema: z.object({
            data: z.string(),
            options: z.object({ format: z.enum(['json', 'text']) }).optional()
          }).shape,
          options: {
            readOnlyHint: false,
            experimental: true
          },
          handler: async ({ data, options }) => ({
            content: [{ type: 'text' as const, text: `Processing ${data} as ${options?.format || 'json'}` }]
          })
        }
      ];

      registerTools(mockServer as any, tools);

      expect(mockServer.registerTool).toHaveBeenCalledTimes(2);
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        1, 'mixed__minimal', {
          title: tools[0].title,
          description: tools[0].description,
          inputSchema: tools[0].paramsSchema
        }, tools[0].handler
      );
      expect(mockServer.registerTool).toHaveBeenNthCalledWith(
        2, 'mixed__complex', {
          title: tools[1].title,
          description: tools[1].description,
          inputSchema: tools[1].paramsSchema,
          annotations: { readOnlyHint: false }
        }, tools[1].handler
      );
    });
  });

  describe('namespace and naming conventions', () => {
    it('should handle various namespace formats', () => {
      const namespaceTests = [
        { namespace: 'simple', name: 'tool', expected: 'simple__tool' },
        { namespace: 'with-dash', name: 'test', expected: 'with-dash__test' },
        { namespace: 'with_underscore', name: 'test', expected: 'with_underscore__test' },
        { namespace: 'CamelCase', name: 'tool', expected: 'CamelCase__tool' },
        { namespace: 'with.dot', name: 'test', expected: 'with.dot__test' },
        { namespace: 'number123', name: 'tool', expected: 'number123__tool' },
      ];

      namespaceTests.forEach(({ namespace, name, expected }) => {
        const tool: Tool = {
          namespace,
          name,
          title: `${namespace} ${name}`,
          paramsSchema: z.object({}).shape,
          handler: async () => ({ content: [{ type: 'text' as const, text: 'test' }] })
        };

        registerTool(mockServer as any, tool);

        expect(mockServer.registerTool).toHaveBeenCalledWith(
          expected,
          {
            title: tool.title,
            description: tool.description,
            inputSchema: tool.paramsSchema
          },
          tool.handler
        );
      });
    });

    it('should handle various tool name formats', () => {
      const nameTests = [
        { namespace: 'test', name: 'simple', expected: 'test__simple' },
        { namespace: 'test', name: 'with-dash', expected: 'test__with-dash' },
        { namespace: 'test', name: 'with_underscore', expected: 'test__with_underscore' },
        { namespace: 'test', name: 'CamelCase', expected: 'test__CamelCase' },
        { namespace: 'test', name: 'with.extension', expected: 'test__with.extension' },
        { namespace: 'test', name: 'number123', expected: 'test__number123' },
      ];

      nameTests.forEach(({ namespace, name, expected }) => {
        const tool: Tool = {
          namespace,
          name,
          title: `${namespace} ${name}`,
          paramsSchema: z.object({}).shape,
          handler: async () => ({ content: [{ type: 'text' as const, text: 'test' }] })
        };

        registerTool(mockServer as any, tool);

        expect(mockServer.registerTool).toHaveBeenCalledWith(
          expected,
          {
            title: tool.title,
            description: tool.description,
            inputSchema: tool.paramsSchema
          },
          tool.handler
        );
      });
    });
  });
});