// Prompt registration utilities for session-based MCP server architecture
import type { Prompt } from '@fireflyagents/mcp-server-types';
import type { McpServer } from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:core:prompt-registration' });

/**
 * Register a prompt with the server using the Prompt interface
 * Handles namespace logic automatically
 *
 * Note: With per-session server instances, each server maintains its own
 * prompt registry. No global state or conflict detection needed.
 */
export function registerPrompt(server: McpServer, prompt: Prompt): void {
  const finalName = `${prompt.namespace}__${prompt.name}`;

  // Register with the server using MCP SDK signature
  if (prompt.paramsSchema) {
    // With parameters schema - use the same pattern as hello-world-prompt
    server.prompt(finalName, prompt.description || prompt.title, prompt.paramsSchema, prompt.handler);
  } else {
    // Without parameters schema - create a handler that ignores the unused params
    const simpleHandler = (_params: any, extra: any) => prompt.handler({} as any, extra);
    server.prompt(finalName, prompt.description || prompt.title, {}, simpleHandler);
  }

  logger.debug('Prompt registered successfully', {
    finalName,
    namespace: prompt.namespace,
    name: prompt.name,
    title: prompt.title,
    hasParams: !!prompt.paramsSchema
  });
}

/**
 * Register multiple prompts at once
 */
export function registerPrompts(server: McpServer, prompts: Prompt[]): void {
  for (const prompt of prompts) {
    registerPrompt(server, prompt);
  }
}