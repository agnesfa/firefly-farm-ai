import { describe, it, expect, vi, beforeEach } from 'vitest';
import { registerTools } from './tool-loader.js';
import { z } from '@fireflyagents/mcp-server-types';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

// Mock the logger to prevent console output during tests
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
  const actual = await importOriginal() as typeof SharedUtils;
  return {
    ...actual,
    logger: {
      ...actual.logger,
      child: vi.fn().mockReturnValue({
        info: vi.fn(),
      }),
    },
  };
});

// Mock server for testing
const mockServer = {
  tool: vi.fn(),
};

describe('Tool Loader', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('registerTools', () => {
    it('should register a simple tool without schema', () => {
      const mockHandler = vi.fn();
      const tool = {
        name: 'simple-tool',
        description: 'A simple tool',
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'simple-tool',
        'A simple tool',
        mockHandler
      );
    });

    it('should register tool with namespace', () => {
      const mockHandler = vi.fn();
      const tool = {
        name: 'hello',
        namespace: 'demo',
        description: 'Demo hello tool',
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'demo__hello',
        'Demo hello tool',
        mockHandler
      );
    });

    it('should register tool with input schema', () => {
      const mockHandler = vi.fn();
      const inputSchema = {
        message: z.string(),
      };

      const tool = {
        name: 'schema-tool',
        description: 'Tool with schema',
        inputSchema,
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'schema-tool',
        'Tool with schema',
        inputSchema,
        mockHandler
      );
    });

    it('should register tool with schema but no description', () => {
      const mockHandler = vi.fn();
      const inputSchema = {
        data: z.string(),
      };

      const tool = {
        name: 'no-desc-tool',
        inputSchema,
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'no-desc-tool',
        inputSchema,
        mockHandler
      );
    });

    it('should register tool without description or schema', () => {
      const mockHandler = vi.fn();
      const tool = {
        name: 'minimal-tool',
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'minimal-tool',
        mockHandler
      );
    });

    it('should skip disabled tools', () => {
      const mockHandler = vi.fn();
      const enabledTool = {
        name: 'enabled-tool',
        handler: mockHandler,
      };
      const disabledTool = {
        name: 'disabled-tool',
        enabled: false,
        handler: mockHandler,
      };

      registerTools(mockServer as any, enabledTool, disabledTool);

      expect(mockServer.tool).toHaveBeenCalledTimes(1);
      expect(mockServer.tool).toHaveBeenCalledWith('enabled-tool', mockHandler);
    });

    it('should register multiple tools', () => {
      const handler1 = vi.fn();
      const handler2 = vi.fn();
      
      const tool1 = {
        name: 'tool1',
        description: 'First tool',
        handler: handler1,
      };
      
      const tool2 = {
        name: 'tool2',
        description: 'Second tool',
        handler: handler2,
      };

      registerTools(mockServer as any, tool1, tool2);

      expect(mockServer.tool).toHaveBeenCalledTimes(2);
      expect(mockServer.tool).toHaveBeenNthCalledWith(1, 'tool1', 'First tool', handler1);
      expect(mockServer.tool).toHaveBeenNthCalledWith(2, 'tool2', 'Second tool', handler2);
    });

    it('should handle tools with version information', () => {
      const mockHandler = vi.fn();
      const tool = {
        name: 'versioned-tool',
        version: '2.0.0',
        handler: mockHandler,
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith('versioned-tool', mockHandler);
    });

    it('should handle empty tools array', () => {
      registerTools(mockServer as any);

      expect(mockServer.tool).not.toHaveBeenCalled();
    });

    it('should register tools with complex schema', () => {
      const mockHandler = vi.fn();
      const complexSchema = {
        name: z.string().describe('User name'),
        age: z.number().optional(),
        preferences: z.object({
          theme: z.enum(['light', 'dark']),
          notifications: z.boolean(),
        }),
      };

      const tool = {
        name: 'complex-tool',
        namespace: 'advanced',
        description: 'Tool with complex schema',
        inputSchema: complexSchema,
        handler: mockHandler,
        version: '1.5.0',
      };

      registerTools(mockServer as any, tool);

      expect(mockServer.tool).toHaveBeenCalledWith(
        'advanced__complex-tool',
        'Tool with complex schema',
        complexSchema,
        mockHandler
      );
    });

    it('should handle mixed enabled and disabled tools', () => {
      const handler1 = vi.fn();
      const handler2 = vi.fn();
      const handler3 = vi.fn();

      const tools = [
        { name: 'tool1', handler: handler1 },
        { name: 'tool2', enabled: false, handler: handler2 },
        { name: 'tool3', enabled: true, handler: handler3 },
      ];

      registerTools(mockServer as any, ...tools);

      expect(mockServer.tool).toHaveBeenCalledTimes(2);
      expect(mockServer.tool).toHaveBeenCalledWith('tool1', handler1);
      expect(mockServer.tool).toHaveBeenCalledWith('tool3', handler3);
    });
  });
});