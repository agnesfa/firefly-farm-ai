// Resource registration utilities for session-based MCP server architecture
import type { Resource } from '@fireflyagents/mcp-server-types';
import type { McpServer } from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:core:resource-registration' });

/**
 * Register a resource with the server using the Resource interface
 * Handles namespace logic automatically
 *
 * Note: With per-session server instances, each server maintains its own
 * resource registry. No global state or conflict detection needed.
 */
export function registerResource(server: McpServer, resource: Resource): void {
  const finalName = `${resource.namespace}__${resource.name}`;

  // Register with the server using MCP SDK signature
  server.resource(
    resource.title, // name parameter
    resource.uriTemplate, // uri/template parameter
    {
      description: resource.description,
      mimeType: resource.options?.mimeType
    },
    resource.handler // readCallback
  );

  logger.debug('Resource registered successfully', {
    finalName,
    namespace: resource.namespace,
    name: resource.name,
    title: resource.title,
    uriTemplate: resource.uriTemplate
  });
}

/**
 * Register multiple resources at once
 */
export function registerResources(server: McpServer, resources: Resource[]): void {
  for (const resource of resources) {
    registerResource(server, resource);
  }
}