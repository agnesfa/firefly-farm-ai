/**
 * Configuration for auth context validation
 */
export interface AuthContextValidationConfig {
  /** Whether to require sessionId (default: true) */
  requireSessionId?: boolean;
  /** Whether to require authInfo (default: true) */
  requireAuthInfo?: boolean;
  /** Required fields in authInfo.metadata (default: []) */
  requiredMetadataFields?: string[];
  /** Custom error messages */
  errorMessages?: {
    missingSessionId?: string;
    missingAuthInfo?: string;
    missingMetadataField?: (field: string) => string;
  };
}

/**
 * Default configuration for auth context validation
 */
const DEFAULT_CONFIG: Required<AuthContextValidationConfig> = {
  requireSessionId: true,
  requireAuthInfo: true,
  requiredMetadataFields: [],
  errorMessages: {
    missingSessionId: 'No session ID available in MCP context',
    missingAuthInfo: 'No authentication information available in MCP context',
    missingMetadataField: (field: string) => `Missing required auth metadata field: ${field}`,
  },
};

/**
 * Generic MCP auth context validator.
 * Validates the presence of session ID, auth info, and optionally specific metadata fields.
 *
 * @param extra - MCP RequestHandlerExtra object containing auth context
 * @param config - Validation configuration options
 * @throws Error with specific message if validation fails
 *
 * @example
 * ```typescript
 * // Basic validation (session + auth info only)
 * validateAuthContext(extra);
 *
 * // Custom metadata requirements
 * validateAuthContext(extra, {
 *   requiredMetadataFields: ['accountId', 'tenantId']
 * });
 *
 * // Custom error messages
 * validateAuthContext(extra, {
 *   requiredMetadataFields: ['apiKey'],
 *   errorMessages: {
 *     missingMetadataField: (field) => `API key missing: ${field}`
 *   }
 * });
 * ```
 */
export function validateAuthContext(
  extra: Record<string, unknown>,
  config: AuthContextValidationConfig = {}
): void {
  const resolvedConfig = { ...DEFAULT_CONFIG, ...config };

  // Validate session ID
  if (resolvedConfig.requireSessionId && !extra.sessionId) {
    throw new Error(resolvedConfig.errorMessages.missingSessionId);
  }

  // Validate auth info presence
  if (resolvedConfig.requireAuthInfo && !extra.authInfo) {
    throw new Error(resolvedConfig.errorMessages.missingAuthInfo);
  }

  // Validate required metadata fields
  if (resolvedConfig.requiredMetadataFields.length > 0 && extra.authInfo) {
    const authInfo = extra.authInfo as Record<string, unknown>;
    const metadata = authInfo.metadata;

    for (const field of resolvedConfig.requiredMetadataFields) {
      const errorMessage = resolvedConfig.errorMessages.missingMetadataField?.(field) ??
                         `Missing required auth metadata field: ${field}`;

      // Check if metadata is not an object
      if (!metadata || typeof metadata !== 'object') {
        throw new Error(errorMessage);
      }

      const metadataObj = metadata as Record<string, unknown>;

      // Field must exist and not be null/undefined (but 0, false, "" are OK)
      if (!(field in metadataObj) || metadataObj[field] == null) {
        throw new Error(errorMessage);
      }

      // Empty string should be considered invalid for most auth scenarios
      if (metadataObj[field] === '') {
        throw new Error(errorMessage);
      }
    }
  }
}

/**
 * Convenience function for validating basic MCP auth context.
 * Requires sessionId and authInfo to be present.
 *
 * @param extra - MCP RequestHandlerExtra object
 * @throws Error if session ID or auth info is missing
 */
export function validateBasicAuthContext(extra: Record<string, unknown>): void {
  validateAuthContext(extra, {
    requireSessionId: true,
    requireAuthInfo: true,
  });
}

/**
 * Convenience function for validating session-only context.
 * Only requires sessionId to be present (useful for tools that don't need OAuth).
 *
 * @param extra - MCP RequestHandlerExtra object
 * @throws Error if session ID is missing
 */
export function validateSessionContext(extra: Record<string, unknown>): void {
  validateAuthContext(extra, {
    requireSessionId: true,
    requireAuthInfo: false,
  });
}