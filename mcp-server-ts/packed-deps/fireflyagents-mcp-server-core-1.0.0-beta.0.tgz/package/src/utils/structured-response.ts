import type { ZodTypeAny } from 'zod';
import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';

/**
 * Simple utility for creating structured MCP tool responses
 * Validates data against schema and provides both text and structured content
 */
export class StructuredResponseBuilder {

    static buildResponse<T>(data: T, schema: ZodTypeAny): CallToolResult {
        const parsedData = schema.safeParse(data);
        if (parsedData.success) {
            return {
                content: [{ type: 'text', text: `${JSON.stringify(parsedData.data, null, 2)}` }],
                structuredContent: parsedData.data
            };
        } else {
            const errorMessages = parsedData.error.issues.map(issue => {
                const path = issue.path.length > 0 ? ` at "${issue.path.join('.')}"` : '';
                return `${issue.message}${path}`;
            });
            return this.buildErrorResponse(errorMessages);
        }
    }

    static buildErrorResponse(error: unknown): CallToolResult {
        const errorMessage = (error instanceof Error) ? error.message : (typeof error === "string") ? error : `Unknown Error: ${JSON.stringify(error, null, 2)}`;
        const textSummary = `Error occurred: ${errorMessage}`;
        return {
            content: [{ type: 'text', text: textSummary }],
            isError: true
        }
    }
}