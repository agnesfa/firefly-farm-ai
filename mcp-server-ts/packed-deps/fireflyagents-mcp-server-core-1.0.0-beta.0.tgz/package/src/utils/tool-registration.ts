// Tool registration utilities for session-based MCP server architecture
import type { Tool } from '@fireflyagents/mcp-server-types';
import type { McpServer } from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:core:tool-registration' });

/**
 * Register a tool with the server using the Tool interface
 * Handles namespace logic automatically
 *
 * Note: With per-session server instances, each server maintains its own
 * tool registry. No global state or conflict detection needed.
 */
export function registerTool(server: McpServer, tool: Tool): void {
  const finalName = `${tool.namespace}__${tool.name}`;

  // Register with the server using registerTool method (supports output schema)
  server.registerTool(
    finalName,
    {
      title: tool.title,
      description: tool.description,
      inputSchema: tool.paramsSchema,
      ...(tool.outputSchema && { outputSchema: tool.outputSchema }),
      ...(tool.options?.readOnlyHint !== undefined && { annotations: { readOnlyHint: tool.options.readOnlyHint } })
    },
    tool.handler
  );

  logger.debug('Tool registered successfully', {
    finalName,
    namespace: tool.namespace,
    name: tool.name,
    title: tool.title,
    hasOutputSchema: !!tool.outputSchema
  });
}

/**
 * Register multiple tools at once
 */
export function registerTools(server: McpServer, tools: Tool[]): void {
  for (const tool of tools) {
    registerTool(server, tool);
  }
}