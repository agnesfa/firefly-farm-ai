import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { Server } from 'http';
import { getUnifiedSessionStore } from '../services/unified-session-store.js';
import { healthService } from '../services/health-service.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:shutdown' });

type ShutdownOptions = {
  server: Server;
  timeout?: number;
};

/**
 * Sets up graceful shutdown handlers for the application
 * Handles SIGINT and SIGTERM signals
 */
export function setupGracefulShutdown({ server, timeout = 10000 }: ShutdownOptions): void {
  let shuttingDown = false;

  const shutdown = async (signal: string): Promise<void> => {
    if (shuttingDown) {
      logger.info('Shutdown already in progress, ignoring duplicate signal');
      return;
    }

    shuttingDown = true;
    logger.info(`Received ${signal} signal, starting graceful shutdown...`);

    // Create a timeout to force exit if graceful shutdown takes too long
    const forceExit = setTimeout(() => {
      logger.error(`Graceful shutdown timed out after ${timeout}ms, forcing exit`);
      process.exit(1);
    }, timeout);

    try {
      // Mark application as not ready to stop accepting new traffic
      healthService.markNotReady();
      logger.info('Application marked as not ready');

      // Clear all active sessions and transports
      const unifiedStore = getUnifiedSessionStore();
      const sessionCount = unifiedStore.getSessionCount();

      if (sessionCount > 0) {
        logger.info(`Clearing ${sessionCount} sessions...`);
        await unifiedStore.clearAllSessions();
      } else {
        logger.info('No active sessions to clear');
      }

      // Then close the HTTP server to stop accepting new connections
      logger.info('Stopping HTTP server...');
      await new Promise<void>((resolve) => {
        server.close((err) => {
          if (err) {
            logger.warn('Error closing HTTP server, continuing shutdown', { error: err });
          } else {
            logger.info('HTTP server closed successfully');
          }
          // Always resolve, even if there's an error
          resolve();
        });
      });

      logger.info('Graceful shutdown completed successfully');
      clearTimeout(forceExit);
      process.exit(0);
    } catch (error) {
      logger.error('Error during graceful shutdown', { error });
      clearTimeout(forceExit);
      process.exit(1);
    }
  };

  // Register signal handlers
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  logger.info('Graceful shutdown handlers registered');
}
