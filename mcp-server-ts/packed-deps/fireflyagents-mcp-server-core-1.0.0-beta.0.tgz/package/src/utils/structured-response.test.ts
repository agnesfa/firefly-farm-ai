import { describe, it, expect, vi, beforeEach } from 'vitest';
import { z } from 'zod';
import { StructuredResponseBuilder } from './structured-response.js';

// Helper type for text content assertions
type TextContent = { type: 'text'; text: string };

describe('StructuredResponseBuilder', () => {
  const testSchema = z.object({
    name: z.string(),
    count: z.number(),
    active: z.boolean(),
  });

  const validData = {
    name: 'Test Item',
    count: 42,
    active: true,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('buildResponse', () => {
    it('should build response with valid data', () => {
      const result = StructuredResponseBuilder.buildResponse(validData, testSchema);

      expect(result).toEqual({
        content: [{ type: 'text', text: JSON.stringify(validData, null, 2) }],
        structuredContent: validData,
      });
    });

    it('should validate data against schema', () => {
      const result = StructuredResponseBuilder.buildResponse(validData, testSchema);

      expect(result.content).toHaveLength(1);
      expect(result.content[0].type).toBe('text');
      expect((result.content[0] as TextContent).text).toBe(JSON.stringify(validData, null, 2));
      expect(result.structuredContent).toEqual(validData);
    });

    it('should handle complex nested data', () => {
      const complexSchema = z.object({
        user: z.object({
          id: z.string(),
          profile: z.object({
            name: z.string(),
            settings: z.array(z.string()),
          }),
        }),
        metadata: z.record(z.unknown()),
      });

      const complexData = {
        user: {
          id: '123',
          profile: {
            name: 'John Doe',
            settings: ['dark-mode', 'notifications'],
          },
        },
        metadata: {
          createdAt: '2025-01-01',
          version: 1,
        },
      };

      const result = StructuredResponseBuilder.buildResponse(complexData, complexSchema);

      expect(result.structuredContent).toEqual(complexData);
      expect((result.content[0] as TextContent).text).toBe(JSON.stringify(complexData, null, 2));
    });

    it('should handle array data', () => {
      const arraySchema = z.array(z.object({
        id: z.string(),
        name: z.string(),
      }));

      const arrayData = [
        { id: '1', name: 'Item 1' },
        { id: '2', name: 'Item 2' },
      ];

      const result = StructuredResponseBuilder.buildResponse(arrayData, arraySchema);

      expect(result.structuredContent).toEqual(arrayData);
      expect((result.content[0] as TextContent).text).toBe(JSON.stringify(arrayData, null, 2));
    });

    it('should handle primitive data types', () => {
      const stringSchema = z.string();
      const stringData = 'Hello, World!';

      const result = StructuredResponseBuilder.buildResponse(stringData, stringSchema);

      expect(result.structuredContent).toBe(stringData);
      expect((result.content[0] as TextContent).text).toBe(JSON.stringify(stringData, null, 2));
    });

    it('should return error response for invalid data', () => {
      const invalidData = {
        name: 123, // Should be string
        count: 'not-a-number', // Should be number
        active: 'not-a-boolean', // Should be boolean
      };

      const result = StructuredResponseBuilder.buildResponse(invalidData, testSchema);

      expect(result.isError).toBe(true);
      expect(result.content).toHaveLength(1);
      expect(result.content[0].type).toBe('text');
      expect((result.content[0] as TextContent).text).toContain('Error occurred:');
      expect(result.structuredContent).toBeUndefined();
    });

    it('should include detailed error messages for validation failures', () => {
      const invalidData = {
        name: 123, // Should be string
        count: 'abc', // Should be number
        active: 'yes', // Should be boolean
      };

      const result = StructuredResponseBuilder.buildResponse(invalidData, testSchema);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain('Expected string, received number at \\"name\\"');
      expect((result.content[0] as TextContent).text).toContain('Expected number, received string at \\"count\\"');
      expect((result.content[0] as TextContent).text).toContain('Expected boolean, received string at \\"active\\"');
    });

    it('should handle missing required fields', () => {
      const incompleteData = {
        name: 'Test',
        // missing count and active
      };

      const result = StructuredResponseBuilder.buildResponse(incompleteData, testSchema);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Error occurred:');
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain('Required at \\"count\\"');
      expect((result.content[0] as TextContent).text).toContain('Required at \\"active\\"');
    });

    it('should handle nested validation errors', () => {
      const nestedSchema = z.object({
        user: z.object({
          id: z.string(),
          age: z.number(),
        }),
      });

      const invalidNestedData = {
        user: {
          id: 123, // Should be string
          age: 'twenty', // Should be number
        },
      };

      const result = StructuredResponseBuilder.buildResponse(invalidNestedData, nestedSchema);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain('Expected string, received number at \\"user.id\\"');
      expect((result.content[0] as TextContent).text).toContain('Expected number, received string at \\"user.age\\"');
    });

    it('should handle root-level validation errors without path', () => {
      const stringSchema = z.string();
      const invalidData = 123; // Should be string

      const result = StructuredResponseBuilder.buildResponse(invalidData, stringSchema);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Expected string, received number');
      expect((result.content[0] as TextContent).text).not.toContain(' at ');
    });
  });

  describe('buildErrorResponse', () => {
    it('should handle Error object', () => {
      const error = new Error('Something went wrong');
      const result = StructuredResponseBuilder.buildErrorResponse(error);

      expect(result).toEqual({
        content: [{ type: 'text', text: 'Error occurred: Something went wrong' }],
        isError: true,
      });
    });

    it('should handle string errors', () => {
      const errorString = 'Simple error message';
      const result = StructuredResponseBuilder.buildErrorResponse(errorString);

      expect(result).toEqual({
        content: [{ type: 'text', text: 'Error occurred: Simple error message' }],
        isError: true,
      });
    });

    it('should handle array of error messages', () => {
      const errorMessages = [
        'First error message',
        'Second error message',
        'Third error message',
      ];
      const result = StructuredResponseBuilder.buildErrorResponse(errorMessages);

      expect(result.isError).toBe(true);
      expect(result.content).toHaveLength(1);
      expect(result.content[0].type).toBe('text');
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain('First error message');
      expect((result.content[0] as TextContent).text).toContain('Second error message');
      expect((result.content[0] as TextContent).text).toContain('Third error message');
    });

    it('should handle unknown error types', () => {
      const unknownError = { code: 500, details: 'Server error' };
      const result = StructuredResponseBuilder.buildErrorResponse(unknownError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain(JSON.stringify(unknownError, null, 2));
    });

    it('should handle null error', () => {
      const result = StructuredResponseBuilder.buildErrorResponse(null);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error: null');
    });

    it('should handle undefined error', () => {
      const result = StructuredResponseBuilder.buildErrorResponse(undefined);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error: undefined');
    });

    it('should handle number error', () => {
      const numberError = 404;
      const result = StructuredResponseBuilder.buildErrorResponse(numberError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error: 404');
    });

    it('should handle boolean error', () => {
      const booleanError = false;
      const result = StructuredResponseBuilder.buildErrorResponse(booleanError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error: false');
    });

    it('should handle Error with custom properties', () => {
      class CustomError extends Error {
        public code: number;

        constructor(message: string, code: number) {
          super(message);
          this.name = 'CustomError';
          this.code = code;
        }
      }

      const customError = new CustomError('Custom error occurred', 500);
      const result = StructuredResponseBuilder.buildErrorResponse(customError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toBe('Error occurred: Custom error occurred');
    });

    it('should handle Error with empty message', () => {
      const error = new Error('');
      const result = StructuredResponseBuilder.buildErrorResponse(error);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toBe('Error occurred: ');
    });

    it('should handle complex object error', () => {
      const complexError = {
        message: 'Complex error',
        stack: 'Error\n  at line 1',
        nested: {
          field: 'value',
          array: [1, 2, 3],
        },
      };

      const result = StructuredResponseBuilder.buildErrorResponse(complexError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain(JSON.stringify(complexError, null, 2));
    });

    it('should handle array with mixed types', () => {
      const mixedArray = ['string error', 123, { key: 'value' }];
      const result = StructuredResponseBuilder.buildErrorResponse(mixedArray);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toContain('Unknown Error:');
      expect((result.content[0] as TextContent).text).toContain(JSON.stringify(mixedArray, null, 2));
    });

    it('should handle TypeError specifically', () => {
      const typeError = new TypeError('Type error occurred');
      const result = StructuredResponseBuilder.buildErrorResponse(typeError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toBe('Error occurred: Type error occurred');
    });

    it('should handle ReferenceError specifically', () => {
      const refError = new ReferenceError('Reference error occurred');
      const result = StructuredResponseBuilder.buildErrorResponse(refError);

      expect(result.isError).toBe(true);
      expect((result.content[0] as TextContent).text).toBe('Error occurred: Reference error occurred');
    });

    it('should not include structuredContent in error response', () => {
      const error = new Error('Test error');
      const result = StructuredResponseBuilder.buildErrorResponse(error);

      expect(result.structuredContent).toBeUndefined();
      expect(result.isError).toBe(true);
    });
  });
});