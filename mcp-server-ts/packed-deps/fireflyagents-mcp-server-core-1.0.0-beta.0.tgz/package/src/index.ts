import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';

const logger = baseLogger.child({ context: 'fa-mcp:core:index' });

logger.debug('Running core framework index...');

// ===== PUBLIC TYPE EXPORTS =====

// Essential Zod re-export
export { z } from '@fireflyagents/mcp-server-types';

// MCP SDK Types - Re-exported through our types package for bundled compatibility
export type { CallToolResult, ReadResourceResult, GetPromptResult } from '@fireflyagents/mcp-server-types';
export { McpServer } from '@fireflyagents/mcp-server-types';
export type { Transport, StreamableHTTPServerTransport, SSEServerTransport } from '@fireflyagents/mcp-server-types';

// Application Development
export type {
  AppConfig,
  AppHealth,
  McpServerApp,
  Server
} from '@fireflyagents/mcp-server-types';

// MCP Capabilities (Primary Use Case)
export type {
  Tool,
  ToolHandler
} from '@fireflyagents/mcp-server-types';

export type {
  Prompt,
  PromptHandler
} from '@fireflyagents/mcp-server-types';

export type {
  Resource,
  ResourceHandler
} from '@fireflyagents/mcp-server-types';

// TODO: Should core do this, or just the sdk?
// Plugin Development
export type {
  ServerPlugin,
  PluginAccountConfig
} from '@fireflyagents/mcp-server-types';

// Authentication (for custom implementations)
export type {
  AuthContext,
  ExtendedAuthContext,
  ApiKeyStore,
  PlatformAuthHandler,
  PlatformCredentials
} from '@fireflyagents/mcp-server-types';

// ===== FRAMEWORK API =====

// Primary API - 3-line pattern for any MCP server
export { createServerApp } from './default-server.js'; // TODO: Do we need this too: createAppWithAsyncConfig
export { buildAppConfig, type AppExtensions } from './config/app-config.js';

// Phase 2: Capability Filtering
export { RoleBasedToolFilter, NamespaceToolFilter, TenantWhitelistToolFilter, type ToolFilter, type ToolFilterContext } from './filtering/tool-filter.js';
export { RoleBasedPromptFilter, NamespacePromptFilter, type PromptFilter, type PromptFilterContext } from './filtering/prompt-filter.js';
export { RoleBasedResourceFilter, NamespaceResourceFilter, type ResourceFilter, type ResourceFilterContext } from './filtering/resource-filter.js';
export { SessionCapabilityResolver, type SessionCapabilityConfig } from './services/session-capability-resolver.js';

// Authentication components
export * from './auth/index.js';

export { StructuredResponseBuilder } from './utils/structured-response.js';

// MCP-specific utilities
export * from './utils/auth-context-validator.js';
