/**
 * App factory and runtime implementation for lean framework pattern
 */
import express from 'express';
import type {McpServerApp, AppConfig, Server, AppHealth} from '@fireflyagents/mcp-server-types';
import type { McpServerConfig } from '@fireflyagents/mcp-server-types';
import {logger as baseLogger, type Env, env} from '@fireflyagents/mcp-shared-utils';
import {createMcpRouter} from "./routes/mcp-router.js";
import cors from "cors";
import {createServer} from "http";
import {DefaultMcpServerApp} from "./app/default-mcp-server-app.js";
import {healthRouter} from "./routes/health.js";
import {healthService} from "./services/health-service.js";
import {createAdminRouter} from "./routes/admin.js";
import {setupGracefulShutdown} from "./utils/shutdown.js";
import {initializeUnifiedSessionStore} from "./services/unified-session-store.js";
import {SessionCapabilityResolver} from "./services/session-capability-resolver.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:server' });

/**
 * App runtime implementation
 */
class DefaultServer implements Server {
  private httpServer: any;
  private ready: boolean = false;

  constructor(
    private application: McpServerApp,
    private config: AppConfig
  ) {}

  async start(): Promise<void> {
    logger.info('Starting MCP Server Application', {
      name: this.config.server.name,
      version: this.config.server.version,
      port: this.config.server.port,
      host: this.config.server.host,
      environment: this.config.environment
    });

    // Verify application health before starting
    const healthCheck = await this.application.healthCheck();
    if (!healthCheck.healthy) {
      throw new Error(`Application health check failed: ${JSON.stringify(healthCheck.details)}`);
    }

    logger.debug('Application health check passed', healthCheck.details);

    // Create MCP server configuration from application
    // Application layer (DefaultMcpServerApp) handles merging config + plugin capabilities
    const mcpServerConfig: McpServerConfig = {
      name: this.config.server.name,
      version: this.config.server.version,
      // Get capabilities from application (already merged with plugins)
      tools: this.application.getTools?.() || [],
      prompts: this.application.getPrompts?.() || [],
      resources: this.application.getResources?.() || [],
      plugins: this.application.getPlugins?.() || [],
      // Auth: use config override, then application defaults
      apiKeyStore: this.config.auth.apiKeyStore || this.application.getApiKeyStore(),
      authHandlers: this.application.getAuthHandlers?.() || []
    };

    // Create capability resolver with configured filters
    const hasFilters =
      (this.config.toolFilters && this.config.toolFilters.length > 0) ||
      (this.config.promptFilters && this.config.promptFilters.length > 0) ||
      (this.config.resourceFilters && this.config.resourceFilters.length > 0);

    const capabilityResolver = hasFilters
      ? new SessionCapabilityResolver(
          this.config.toolFilters || [],
          this.config.promptFilters || [],
          this.config.resourceFilters || []
        )
      : new SessionCapabilityResolver([], [], []); // No filters = no filtering

    // Initialize unified session store with base config and capability resolver
    initializeUnifiedSessionStore(mcpServerConfig, {
      ttl: 3600, // 1 hour session TTL
      capabilityResolver
    });

    const filterNames = capabilityResolver.getFilterNames();
    logger.info('Unified session store initialized with capability filtering', {
      sessionTTL: 3600,
      toolFilters: filterNames.tools,
      promptFilters: filterNames.prompts,
      resourceFilters: filterNames.resources
    });

    // Create Express app (framework owns Express)
    const expressApp = express();

      expressApp.use(express.json());
      expressApp.use(cors({
          origin: '*',
          exposedHeaders: ["Mcp-Session-Id"]
      }));

    // Framework registers core MCP endpoints
      expressApp.use('/mcp', createMcpRouter(mcpServerConfig));

      // Register Health Routes
      healthService.initialize(mcpServerConfig);
      expressApp.use('/', healthRouter);

      // Register Admin Routes
      // TODO: Move this out and only create this router if using the framework's file key store
      if (mcpServerConfig.apiKeyStore && process.env.ADMIN_API_KEY) {
          expressApp.use('/admin', createAdminRouter(mcpServerConfig.apiKeyStore));
          logger.info('Admin API endpoints enabled', {
              adminKeySet: !!process.env.ADMIN_API_KEY,
              storeType: mcpServerConfig.apiKeyStore.constructor.name
          });
      } else if (process.env.ADMIN_API_KEY) {
          logger.warn('Admin API key configured but no API key store provided');
      } else if (mcpServerConfig.apiKeyStore) {
          logger.info('API key store available but admin API not enabled (set ADMIN_API_KEY)');
      }

    // Register custom routes from config and application
    const routeRegistrars = [
      ...(this.config.routeRegistrars || []),
      ...(this.application.getRouteRegistrars?.() || [])
    ];
    for (const registrar of routeRegistrars) {
      try {
          // TODO: Figure out best implementation approach
          // logger.debug('Custom Route Registrar: ', {registrar: registrar});
          // expressApp.use(registrar.name, registrar.handler());
        // const routeRegistrar = await registrar(expressApp, this.config, this.application);
        // routeRegistrar.
      } catch (error) {
        logger.error('Failed to register application routes', {
          error: error instanceof Error ? error.message : String(error),
          registrar: registrar.name || 'anonymous'
        });
        throw error;
      }
    }

    // Start HTTP server and wait for it to be listening
    await new Promise<void>((resolve, reject) => {
        this.httpServer = createServer(expressApp);
        this.httpServer.listen(this.config.server.port, this.config.server.host, (error?: Error) => {
            if (error) {
                reject(error);
            } else {
                this.ready = true;
                logger.debug('Default MCP Application Server ready to accept connections', {
                    readyState: this.ready
                });
                resolve();
            }
        })
    });

      // Set up graceful shutdown handlers
      setupGracefulShutdown({
          server: this.httpServer,
          timeout: 15000 // 15 seconds timeout for graceful shutdown
      });

      // Mark application as ready to accept traffic
      healthService.markReady();

      logger.info('Default MCP Application Server started successfully', {
      url: `http://${this.config.server.host}:${this.config.server.port}`,
      mcpEndpoint: '/mcp',
      sseEndpoint: '/mcp/sse',
      healthEndpoints: {
        comprehensive: `http://${env.HOST}:${env.PORT}/health`,
        liveness: `http://${env.HOST}:${env.PORT}/health/live`,
        readiness: `http://${env.HOST}:${env.PORT}/health/ready`,
        startup: `http://${env.HOST}:${env.PORT}/health/startup`
      },
      customRoutes: routeRegistrars.length,
      capabilities: {
        tools: (mcpServerConfig.tools?.length || 0),
        prompts: (mcpServerConfig.prompts?.length || 0),
        resources: (mcpServerConfig.resources?.length || 0),
        plugins: mcpServerConfig.plugins?.length || 0
      }
    });
  }

  async stop(): Promise<void> {
    if (this.httpServer) {
      this.ready = false;
      return new Promise((resolve, reject) => {
        this.httpServer.close((error: any) => {
          if (error) {
            logger.error('Error stopping HTTP server', { error: error.message });
            reject(error);
          } else {
            logger.info('Default MCP Application Server stopped');
            resolve();
          }
        });
      });
    }
  }

  isReady(): boolean {
    return this.ready;
  }

  async healthCheck(): Promise<AppHealth> {
    try {
      const applicationHealth = await this.application.healthCheck();

      return {
        healthy: applicationHealth.healthy && this.ready,
        details: {
          application: applicationHealth,
          server: {
            ready: this.ready,
            running: !!this.httpServer,
            config: {
              name: this.config.server.name,
              version: this.config.server.version,
              environment: this.config.environment,
              host: this.config.server.host,
              port: this.config.server.port
            }
          }
        }
      };
    } catch (error) {
      return {
        healthy: false,
        details: {
          error: error instanceof Error ? error.message : 'Unknown error during health check',
          ready: this.ready,
          running: !!this.httpServer
        }
      };
    }
  }
}

/**
 * Create an App instance with the provided configuration and mcpServerApp
 *
 * @param config - Application configuration (use buildAppConfig() to create)
 * @param mcpServerApp - Optional custom mcpServerApp (uses DefaultApplication if not provided)
 * @returns App instance ready to start
 */
export function createServerApp(config: AppConfig, mcpServerApp?: McpServerApp): Server {
  // const app = mcpServerApp || new DefaultApplication(config);
    const app = mcpServerApp || new DefaultMcpServerApp(config);
  return new DefaultServer(app, config);
}

/**
 * Create an App instance with async configuration building
 *
 * @param env
 * @param mcpServerApp - Optional custom mcpServerApp
 * @returns App instance ready to start
 */
export async function createAppWithAsyncConfig(
  env: Env,
  mcpServerApp?: McpServerApp
): Promise<Server> {
  // Import the async config builder
  const { buildAppConfig } = await import('./config/app-config.js');
  const config = await buildAppConfig(env);

  // const app = mcpServerApp || new DefaultApplication(config);
    const app = mcpServerApp || new DefaultMcpServerApp(config);
  return new DefaultServer(app, config);
}