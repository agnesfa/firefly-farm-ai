import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type {
  ExtendedAuthContext,
  SupportedTransport,
  McpServer,
  McpServerConfig
} from '@fireflyagents/mcp-server-types';
import { createMcpServer } from '../factory/mcp-server-factory.js';
import {
  SessionCapabilityResolver
} from './session-capability-resolver.js';
import { PlatformAuthService } from './platform-auth-service.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:unified-session-store' });

/**
 * Platform token information for session-level token management
 */
interface PlatformTokenInfo {
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
}

/**
 * Complete session data structure - consolidates all session-related information
 */
export interface UnifiedSessionData {
  // Identity
  sessionId: string;
  tenantId: string;

  // Authentication context (from API key validation + OAuth)
  authContext: ExtendedAuthContext;

  // MCP infrastructure
  transport: SupportedTransport;
  serverInstance: McpServer;  // ⭐ NEW: Track server per session

  // Lifecycle tracking
  createdAt: Date;
  lastAccessed: Date;

  // Platform authentication state
  platformTokens?: Record<string, PlatformTokenInfo>;

  // Capability metadata (Phase 2 preparation)
  enabledToolNames?: string[];  // Tools available in this session
}

/**
 * Unified session store - single source of truth for session lifecycle
 *
 * Consolidates previous SessionManager + TransportStore into one service.
 * Tracks complete session state including server instances.
 */
export class UnifiedSessionStore {
  private sessions: Map<string, UnifiedSessionData> = new Map();
  private baseConfig: McpServerConfig;
  private capabilityResolver: SessionCapabilityResolver;
  private readonly defaultTtl: number;
  private readonly ttlTimers: Map<string, NodeJS.Timeout> = new Map();

  constructor(
    baseConfig: McpServerConfig,
    options: {
      ttl?: number;
      capabilityResolver?: SessionCapabilityResolver;
    } = {}
  ) {
    this.baseConfig = baseConfig;
    this.defaultTtl = options.ttl || 3600; // 1 hour default
    this.capabilityResolver = options.capabilityResolver || new SessionCapabilityResolver([], [], []);

    // Register platform auth handlers with PlatformAuthService so it can
    // perform reactive token refresh without reaching back into this store.
    // Handlers stay encapsulated inside PlatformAuthService — not exposed here.
    PlatformAuthService.registerHandlers(baseConfig.authHandlers ?? []);

    const filterNames = this.capabilityResolver.getFilterNames();
    logger.info('UnifiedSessionStore initialized', {
      defaultTtl: this.defaultTtl,
      toolFilters: filterNames.tools,
      promptFilters: filterNames.prompts,
      resourceFilters: filterNames.resources
    });
  }

  /**
   * Create a new session with server instance
   *
   * This is the primary session creation method that creates an MCP server
   * instance for the session and stores all related data together.
   */
  async createSession(
    sessionId: string,
    transport: SupportedTransport,
    authContext: ExtendedAuthContext,
    ttl?: number
  ): Promise<McpServer> {
    const tenantId = authContext.tenantId || 'default';

    const filterNames = this.capabilityResolver.getFilterNames();
    logger.debug('Creating session with capability resolution', {
      sessionId,
      tenantId,
      apiKeyPrefix: authContext.apiKey?.substring(0, 8) + '***',
      toolFilters: filterNames.tools,
      promptFilters: filterNames.prompts,
      resourceFilters: filterNames.resources
    });

    // Resolve session-specific capabilities
    const sessionConfig = await this.capabilityResolver.resolveForSession({
      tenantId,
      authContext,
      baseConfig: this.baseConfig
    });

    // Create MCP server with filtered capabilities
    const server = await createMcpServer(sessionConfig);

    // Extract existing platform tokens from auth context if present
    const platformTokens: Record<string, PlatformTokenInfo> = {};
    if (authContext.platformCredentials?.tokens) {
      const { accessToken, refreshToken, expiresAt } = authContext.platformCredentials.tokens;
      if (accessToken) {
        platformTokens['default'] = {
          accessToken,
          refreshToken,
          expiresAt
        };
      }
    }

    // Store complete session data
    const now = new Date();
    this.sessions.set(sessionId, {
      sessionId,
      tenantId,
      authContext,
      transport,
      serverInstance: server,
      createdAt: now,
      lastAccessed: now,
      platformTokens: Object.keys(platformTokens).length > 0 ? platformTokens : undefined,
      // Store enabled tool names for introspection
      enabledToolNames: sessionConfig.tools?.map(t => `${t.namespace}__${t.name}`)
    });

    // Set up TTL cleanup
    this.setupTtlCleanup(sessionId, ttl || this.defaultTtl);

    logger.info('Session created successfully with filtered capabilities', {
      sessionId,
      tenantId,
      enabledToolCount: sessionConfig.tools?.length || 0,
      enabledPromptCount: sessionConfig.prompts?.length || 0,
      enabledResourceCount: sessionConfig.resources?.length || 0,
      hasPlatformTokens: !!platformTokens['default'],
      totalSessions: this.sessions.size
    });

    return server;
  }

  /**
   * Get session data by session ID
   */
  async getSession(sessionId: string): Promise<UnifiedSessionData | null> {
    const session = this.sessions.get(sessionId);
    if (session) {
      // Update last accessed time
      session.lastAccessed = new Date();
      logger.debug('Retrieved session', { sessionId });
    }
    return session || null;
  }

  /**
   * Get transport for a session (backward compatible accessor)
   */
  async getTransport(sessionId: string): Promise<SupportedTransport | null> {
    const session = await this.getSession(sessionId);
    return session?.transport || null;
  }

  /**
   * Get server instance for a session
   */
  async getServerInstance(sessionId: string): Promise<McpServer | null> {
    const session = await this.getSession(sessionId);
    return session?.serverInstance || null;
  }

  /**
   * Check if session exists and belongs to tenant
   */
  isValidSession(sessionId: string, tenantId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    // Update last accessed
    session.lastAccessed = new Date();

    // Validate tenant ownership
    return session.tenantId === tenantId;
  }

  /**
   * Check if session exists
   */
  async hasSession(sessionId: string): Promise<boolean> {
    return this.sessions.has(sessionId);
  }

  /**
   * Remove a session and cleanup all resources
   */
  async removeSession(sessionId: string): Promise<boolean> {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    this.clearTtlTimer(sessionId);

    // Delete from Map FIRST to prevent re-entrant calls.
    // server.close() → transport.close() → onclose callback → removeSession() again.
    // With the session already gone from the Map, the recursive call returns false immediately.
    this.sessions.delete(sessionId);

    // Close server instance (which closes transport via Protocol.close()).
    // Safe to call even if transport is already closed — the MCP SDK's close()
    // operates on cleared Maps and is effectively idempotent.
    try {
      await session.serverInstance.close();
    } catch (error) {
      logger.debug('Error closing server during session removal (may already be closed)', {
        sessionId,
        error: error instanceof Error ? error.message : String(error)
      });
    }

    logger.info('Session removed', {
      sessionId,
      tenantId: session.tenantId,
      remainingSessions: this.sessions.size
    });

    return true;
  }

  /**
   * Get all session IDs
   */
  getSessionIds(): string[] {
    return Array.from(this.sessions.keys());
  }

  /**
   * Get session count
   */
  getSessionCount(): number {
    return this.sessions.size;
  }

  /**
   * Clear all sessions
   */
  async clearAllSessions(): Promise<void> {
    const count = this.sessions.size;

    for (const timer of this.ttlTimers.values()) {
      clearTimeout(timer);
    }
    this.ttlTimers.clear();

    // Snapshot sessions before clearing — close all server instances.
    // Clear Map FIRST to prevent re-entrant removeSession() calls from onclose callbacks.
    const sessions = Array.from(this.sessions.values());
    this.sessions.clear();

    await Promise.all(
      sessions.map(session =>
        session.serverInstance.close().catch(err =>
          logger.debug('Error closing server during clearAll', {
            sessionId: session.sessionId,
            error: err instanceof Error ? err.message : String(err)
          })
        )
      )
    );

    logger.info('Cleared all sessions', { count });
  }

  /**
   * Get platform token for a session
   */
  getPlatformToken(sessionId: string, platform: string = 'default'): PlatformTokenInfo | null {
    const session = this.sessions.get(sessionId);
    return session?.platformTokens?.[platform] || null;
  }

  /**
   * Update platform token for a session
   */
  updatePlatformToken(
    sessionId: string,
    platform: string,
    tokenInfo: PlatformTokenInfo
  ): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    if (!session.platformTokens) {
      session.platformTokens = {};
    }

    session.platformTokens[platform] = tokenInfo;

    // Also update the auth context if it has platform credentials
    if (session.authContext.platformCredentials && platform === 'default') {
      session.authContext.platformCredentials.tokens = tokenInfo;
    }

    logger.debug('Updated platform token', { sessionId, platform });
    return true;
  }

  /**
   * Check if any platform tokens are expired
   */
  getExpiredTokens(sessionId: string, bufferMs: number = 5 * 60 * 1000): string[] {
    const session = this.sessions.get(sessionId);
    if (!session?.platformTokens) return [];

    const now = new Date();
    const expiredPlatforms: string[] = [];

    for (const [platform, tokenInfo] of Object.entries(session.platformTokens)) {
      if (tokenInfo.expiresAt) {
        const timeToExpiry = tokenInfo.expiresAt.getTime() - now.getTime();
        if (timeToExpiry <= bufferMs) {
          expiredPlatforms.push(platform);
        }
      }
    }

    return expiredPlatforms;
  }

  /**
   * Cleanup expired sessions
   */
  cleanupExpiredSessions(maxAgeMs: number = 24 * 60 * 60 * 1000): number {
    const now = new Date();
    let cleanedCount = 0;

    for (const [sessionId, session] of this.sessions.entries()) {
      const age = now.getTime() - session.lastAccessed.getTime();
      if (age > maxAgeMs) {
        this.removeSession(sessionId);
        cleanedCount++;
      }
    }

    if (cleanedCount > 0) {
      logger.info('Cleaned up expired sessions', { cleanedCount });
    }

    return cleanedCount;
  }

  /**
   * Set up TTL cleanup for a session
   */
  private setupTtlCleanup(sessionId: string, ttl: number): void {
    this.clearTtlTimer(sessionId);

    if (ttl > 0) {
      const timer = setTimeout(() => {
        logger.debug('Session TTL expired', { sessionId });
        this.removeSession(sessionId);
      }, ttl * 1000);

      this.ttlTimers.set(sessionId, timer);
    }
  }

  /**
   * Clear TTL timer for a session
   */
  private clearTtlTimer(sessionId: string): void {
    const existingTimer = this.ttlTimers.get(sessionId);
    if (existingTimer) {
      clearTimeout(existingTimer);
      this.ttlTimers.delete(sessionId);
    }
  }
}

// Singleton instance (will be initialized in default-server.ts)
let storeInstance: UnifiedSessionStore | null = null;

export function getUnifiedSessionStore(): UnifiedSessionStore {
  if (!storeInstance) {
    throw new Error('UnifiedSessionStore not initialized. Call initializeUnifiedSessionStore() first.');
  }
  return storeInstance;
}

export function initializeUnifiedSessionStore(
  baseConfig: McpServerConfig,
  options?: {
    ttl?: number;
    capabilityResolver?: SessionCapabilityResolver;
  }
): UnifiedSessionStore {
  storeInstance = new UnifiedSessionStore(baseConfig, options);
  return storeInstance;
}

/**
 * Reset singleton instance for testing purposes
 * @internal
 */
export function resetUnifiedSessionStore(): void {
  storeInstance = null;
}

// Export for use in handlers
export { storeInstance as unifiedSessionStore };