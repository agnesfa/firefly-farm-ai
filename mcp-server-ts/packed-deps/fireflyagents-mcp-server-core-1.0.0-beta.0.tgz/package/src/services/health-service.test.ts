import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import {HealthService, healthService} from './health-service.js';
import {HealthStatus} from '@fireflyagents/mcp-server-types';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';
import {McpServerConfig} from "@fireflyagents/mcp-server-types";
import {createMcpServer} from "../factory/mcp-server-factory.js";

// Mock the logger to prevent console output during tests
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
    const actual = await importOriginal() as typeof SharedUtils;
    return {
        ...actual,
        logger: {
            ...actual.logger,
            child: vi.fn().mockReturnValue({
                info: vi.fn(),
                debug: vi.fn(),
                error: vi.fn(),
                warn: vi.fn(),
            }),
        },
    };
});

// Mock unified session store
const mockGetSessionCount = vi.fn().mockReturnValue(0);

vi.mock('./unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn(() => ({
        getSessionCount: mockGetSessionCount,
    })),
}));

vi.mock('../factory/mcp-server-factory.js', () => ({
    createMcpServer: vi.fn().mockResolvedValue({
        server: {
            status: 'ok',
            health: vi.fn().mockResolvedValue({status: 'healthy'})
        }
    })
}));

const mockMcpServerConfig: McpServerConfig = {
    name: 'test-server',
    version: '1.0.0',
}

describe('HealthService', () => {
    let service: HealthService;

    beforeEach(async () => {
        vi.clearAllMocks();

        mockGetSessionCount.mockReturnValue(0);

        // Get fresh instance (will create new one since we reset in afterEach)
        service = HealthService.getInstance();
    });

    afterEach(async () => {
        // Clean up any spies
        vi.clearAllMocks();

        mockGetSessionCount.mockReturnValue(0);

        // Reset singleton instance completely
        HealthService.resetInstance();

    });

    describe('singleton pattern', () => {
        it('should return the same instance', () => {
            const instance1 = HealthService.getInstance();
            const instance2 = HealthService.getInstance();
            expect(instance1).toBe(instance2);
        });

        it('should use the exported singleton', () => {
            expect(healthService).toBeInstanceOf(HealthService);
            // Note: In tests, exported instance may differ from current instance due to resets
            // This is expected behavior for test isolation
        });
    });

    describe('initialization', () => {
        it('should initialize with MCP server config', () => {
            service.initialize(mockMcpServerConfig);
            expect(service['isApplicationStarted']).toBe(true);
            expect(service['mcpServerConfig']).toBe(mockMcpServerConfig);
        });

        it('should initialize without MCP server config', () => {
            service.initialize();
            expect(service['isApplicationStarted']).toBe(true);
            expect(service['mcpServerConfig']).toBe(undefined);
        });
    });

    describe('ready state management', () => {
        it('should mark application as ready', () => {
            expect(service['isApplicationReady']).toBe(false);
            service.markReady();
            expect(service['isApplicationReady']).toBe(true);
        });

        it('should mark application as not ready', () => {
            service.markReady();
            expect(service['isApplicationReady']).toBe(true);
            service.markNotReady();
            expect(service['isApplicationReady']).toBe(false);
        });
    });

    describe('liveness probe', () => {
        beforeEach(() => {
            service.initialize(mockMcpServerConfig);
        });

        it('should return healthy when all checks pass', async () => {
            const result = await service.livenessProbe();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Application is alive');
        });

        it('should return unhealthy when RSS usage is critical', async () => {
            // Mock process.memoryUsage to return high RSS usage (> 85% of 8GB = 6.97GB)
            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: 7500000000, // 7.5GB RSS - above 85% of 8GB container limit
                heapTotal: 100000000, // 95MB heap
                heapUsed: 50000000,   // 50MB used - only 50% heap usage
                external: 50000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await service.livenessProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Critical memory usage detected');

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should handle errors gracefully', async () => {
            // Mock checkMemory to throw an error
            const memorySpy = vi.spyOn(service as any, 'checkMemory').mockRejectedValue(new Error('Memory check failed'));

            const result = await service.livenessProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Liveness probe failure');

            // Clean up spy
            memorySpy.mockRestore();
        });
    });

    describe('readiness probe', () => {
        beforeEach(() => {
            service.initialize(mockMcpServerConfig);
        });

        it('should return unhealthy when application is not ready', async () => {
            const result = await service.readinessProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Application not ready to accept traffic');
        });

        it('should return healthy when application is ready and dependencies are healthy', async () => {
            service.markReady();

            const result = await service.readinessProbe();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Application ready to accept traffic');
        });

        it('should return unhealthy when session store is unhealthy', async () => {
            service.markReady();

            // Mock checkSessionStore to return unhealthy status
            vi.spyOn(service as any, 'checkSessionStore').mockResolvedValue({
                status: HealthStatus.UNHEALTHY,
                message: 'Store not available'
            });

            const result = await service.readinessProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Session store unavailable');
        });

        it('should handle errors gracefully', async () => {
            service.markReady();

            // Mock checkSessionStore to throw an error
            vi.spyOn(service as any, 'checkSessionStore').mockRejectedValue(new Error('Session store check failed'));

            const result = await service.readinessProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Readiness probe failure');
        });
    });

    describe('startup probe', () => {
        it('should return unhealthy when application has not started', async () => {
            const result = await service.startupProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Application still starting');
        });

        it('should return healthy when application has started and session store is healthy', async () => {
            service.initialize(mockMcpServerConfig);

            const result = await service.startupProbe();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Application startup complete');
        });

        it('should return unhealthy when session store is not initialized', async () => {
            service.initialize(mockMcpServerConfig);
            // Mock checkSessionStore to return unhealthy status
            vi.spyOn(service as any, 'checkSessionStore').mockResolvedValue({
                status: HealthStatus.UNHEALTHY,
                message: 'Store not initialized'
            });

            const result = await service.startupProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Session store not initialized');
        });

        it('should handle errors gracefully', async () => {
            service.initialize(mockMcpServerConfig);

            // Mock checkSessionStore to throw an error
            vi.spyOn(service as any, 'checkSessionStore').mockRejectedValue(new Error('Session store check failed'));

            const result = await service.startupProbe();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Startup probe failure');
        });
    });

    describe('comprehensive health check', () => {
        beforeEach(() => {
            service.initialize(mockMcpServerConfig);
            service.markReady();
        });

        it('should return healthy status when all checks pass', async () => {
            const result = await service.checkHealth();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.timestamp).toBeDefined();
            expect(result.uptime).toBeGreaterThanOrEqual(0);
            expect(result.version).toBeDefined();
            expect(result.checks).toBeDefined();
            expect(result.summary).toBeDefined();

            expect(result.checks.sessionStore.status).toBe(HealthStatus.HEALTHY);
            expect(result.checks.mcpServer.status).toBe(HealthStatus.HEALTHY);
            expect(result.checks.memory?.status).toBe(HealthStatus.HEALTHY);
        });

        it('should return degraded status when some checks are degraded', async () => {
            // First get the container limit that will be detected
            const testResult = await (service as any).checkMemory();
            const containerLimitMB = testResult.details.containerLimitMB;
            const warningThresholdBytes = Math.floor(containerLimitMB * 1024 * 1024 * 0.75); // 75% to ensure warning

            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: warningThresholdBytes, // RSS at 75% of detected container limit
                heapTotal: 100000000, // 95MB heap
                heapUsed: 50000000,   // 50MB used - only 50% heap usage
                external: 50000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await service.checkHealth();

            expect(result.status).toBe(HealthStatus.DEGRADED);
            expect(result.checks.memory?.status).toBe(HealthStatus.DEGRADED);
            expect(result.summary.degraded).toBe(1);

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should return unhealthy status when any check is unhealthy', async () => {
            // Mock checkSessionStore to throw (simulates unhealthy state)
            vi.spyOn(service as any, 'checkSessionStore').mockRejectedValue(new Error('Connection failed'));

            const result = await service.checkHealth();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.checks.sessionStore.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.summary.unhealthy).toBeGreaterThan(0);
        });

        it('should include startup check when application is not ready', async () => {
            service.markNotReady();

            // Mock uptime to be > 1 second to satisfy startup check condition
            const uptimeSpy = vi.spyOn(service as any, 'getUptimeSeconds').mockReturnValue(2);

            const result = await service.checkHealth();

            expect(result.checks.startup).toBeDefined();
            expect(result.checks.startup?.status).toBe(HealthStatus.HEALTHY); // Since app is started and uptime > 1s

            // Clean up spy
            uptimeSpy.mockRestore();
        });

        it('should handle system failures gracefully', async () => {
            // Mock all checks to fail within this test scope
            const sessionStoreSpy = vi.spyOn(service as any, 'checkSessionStore').mockRejectedValue(new Error('System failure'));
            const mcpServerSpy = vi.spyOn(service as any, 'checkMcpServer').mockRejectedValue(new Error('System failure'));
            const memorySpy = vi.spyOn(service as any, 'checkMemory').mockRejectedValue(new Error('System failure'));

            const result = await service.checkHealth();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.checks.sessionStore.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.checks.mcpServer.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.checks.memory?.status).toBe(HealthStatus.UNHEALTHY);

            // Clean up spies immediately after test
            sessionStoreSpy.mockRestore();
            mcpServerSpy.mockRestore();
            memorySpy.mockRestore();
        });
    });

    describe('memory health check', () => {
        it('should return healthy status for normal memory usage', async () => {
            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: 500000000,   // 500MB RSS - well below container limit
                heapTotal: 100000000,  // 95MB heap
                heapUsed: 50000000,    // 50MB used - 50% heap usage (normal)
                external: 20000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await (service as any).checkMemory();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Memory usage normal');
            expect(result.details.heapUsagePercent).toBe(50);
            expect(result.details.rss).toBe(477); // ~477MB
            expect(result.details.containerLimitMB).toBeGreaterThan(0); // Any valid limit
            expect(result.details.rssUsagePercent).toBeGreaterThanOrEqual(0); // Valid percentage

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should return degraded status for high RSS usage', async () => {
            // First get the container limit that will be detected
            const testResult = await (service as any).checkMemory();
            const containerLimitMB = testResult.details.containerLimitMB;
            const warningThresholdBytes = Math.floor(containerLimitMB * 1024 * 1024 * 0.75); // 75% to ensure warning

            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: warningThresholdBytes, // RSS at 75% of detected container limit
                heapTotal: 100000000,  // 95MB heap
                heapUsed: 50000000,    // 50MB used - only 50% heap usage
                external: 30000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await (service as any).checkMemory();

            expect(result.status).toBe(HealthStatus.DEGRADED);
            expect(result.message).toContain('High RSS usage');
            expect(result.details.heapUsagePercent).toBe(50); // Heap usage still normal
            expect(result.details.rssUsagePercent).toBeGreaterThan(70); // RSS usage at warning level
            expect(result.details.containerLimitMB).toBeGreaterThan(0);

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should return unhealthy status for critical RSS usage', async () => {
            // First get the container limit that will be detected
            const testResult = await (service as any).checkMemory();
            const containerLimitMB = testResult.details.containerLimitMB;
            const criticalThresholdBytes = Math.floor(containerLimitMB * 1024 * 1024 * 0.90); // 90% to ensure critical

            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: criticalThresholdBytes, // RSS at 90% of detected container limit
                heapTotal: 100000000,  // 95MB heap
                heapUsed: 50000000,    // 50MB used - only 50% heap usage
                external: 40000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await (service as any).checkMemory();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toContain('Critical RSS usage');
            expect(result.details.heapUsagePercent).toBe(50); // Heap usage still normal
            expect(result.details.rssUsagePercent).toBeGreaterThan(85); // RSS usage at critical level
            expect(result.details.containerLimitMB).toBeGreaterThan(0);

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should return unhealthy status for extreme heap usage (fallback check)', async () => {
            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: 500000000,    // 500MB RSS - low RSS usage
                heapTotal: 100000000,  // 95MB heap
                heapUsed: 99000000,    // 99MB used - 99% heap usage (extreme)
                external: 20000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await (service as any).checkMemory();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toContain('Critical heap usage');
            expect(result.details.heapUsagePercent).toBe(99);
            expect(result.details.rssUsagePercent).toBeLessThan(70); // RSS usage still low

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should return degraded status for high heap usage (fallback check)', async () => {
            const originalMemoryUsage = process.memoryUsage;
            process.memoryUsage = vi.fn().mockReturnValue({
                rss: 500000000,    // 500MB RSS - low RSS usage
                heapTotal: 100000000,  // 95MB heap
                heapUsed: 98000000,    // 98MB used - 98% heap usage (high)
                external: 20000000,
                arrayBuffers: 10000000
            }) as unknown as typeof process.memoryUsage;

            const result = await (service as any).checkMemory();

            expect(result.status).toBe(HealthStatus.DEGRADED);
            expect(result.message).toContain('High heap usage');
            expect(result.details.heapUsagePercent).toBe(98);
            expect(result.details.rssUsagePercent).toBeLessThan(70); // RSS usage still low

            // Restore original
            process.memoryUsage = originalMemoryUsage;
        });

        it('should include container limit detection in details', async () => {
            const result = await (service as any).checkMemory();

            expect(result.details).toHaveProperty('containerLimitMB');
            expect(result.details).toHaveProperty('rssUsagePercent');
            expect(result.details.containerLimitMB).toBeGreaterThan(0);
            expect(result.details.rssUsagePercent).toBeGreaterThanOrEqual(0);
        });
    });

    describe('event loop health check', () => {
        it('should return healthy status for responsive event loop', async () => {
            const result = await (service as any).checkEventLoop();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Event loop responsive');
            expect(result.details.lagMs).toBeGreaterThanOrEqual(0);
        }, 10000); // 10 second timeout

        it('should detect event loop lag structure', async () => {
            // This test is tricky to implement reliably, but we can at least test the structure
            const result = await (service as any).checkEventLoop();

            expect(result).toHaveProperty('status');
            expect(result).toHaveProperty('message');
            expect(result.details).toHaveProperty('lagMs');
            expect(typeof result.details.lagMs).toBe('number');
            expect(result.details.lagMs).toBeGreaterThanOrEqual(0);
        }, 10000); // 10 second timeout
    });

    describe('MCP server health check', () => {
        beforeEach(() => {
            service.initialize(mockMcpServerConfig);
        });

        it('should return healthy when MCP server config works', async () => {
            const result = await (service as any).checkMcpServer();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('MCP server factory operational');
            expect(createMcpServer).toHaveBeenCalledWith(mockMcpServerConfig);
        });

        it('should return healthy when no config but transport system works', async () => {
            service['mcpServerConfig'] = undefined;

            const result = await (service as any).checkMcpServer();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('MCP transport system operational');
            expect(result.details.activeSessions).toBe(0);
        });

        it('should return unhealthy when MCP server factory fails', async () => {
            vi.mocked(createMcpServer).mockRejectedValue(new Error('Factory failed'));

            const result = await (service as any).checkMcpServer();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('MCP server health check failed');
            expect(result.details.error).toBe('Factory failed');
        });
    });

    describe('session store health check', () => {
        it('should return healthy when session store is operational', async () => {
            mockGetSessionCount.mockReturnValue(5);
            const result = await (service as any).checkSessionStore();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Unified session store operational');
            expect(result.details.activeSessions).toBe(5);
        });

        it('should return unhealthy when getUnifiedSessionStore throws', async () => {
            // Mock getUnifiedSessionStore to throw (simulates uninitialized store)
            const {getUnifiedSessionStore} = await import('./unified-session-store.js');
            const originalMock = vi.mocked(getUnifiedSessionStore).getMockImplementation();

            vi.mocked(getUnifiedSessionStore).mockImplementation(() => {
                throw new Error('Store not initialized');
            });

            const result = await (service as any).checkSessionStore();

            expect(result.status).toBe(HealthStatus.UNHEALTHY);
            expect(result.message).toBe('Session store health check failed');
            expect(result.details.error).toBe('Store not initialized');

            // Restore original mock
            if (originalMock) {
                vi.mocked(getUnifiedSessionStore).mockImplementation(originalMock);
            }
        });

        it('should return healthy when session count is 0', async () => {
            mockGetSessionCount.mockReturnValue(0);
            const result = await (service as any).checkSessionStore();

            expect(result.status).toBe(HealthStatus.HEALTHY);
            expect(result.message).toBe('Unified session store operational');
            expect(result.details.activeSessions).toBe(0);
        });
    });

    describe('container memory limit detection', () => {
        it('should use environment variable when available', async () => {
            const originalEnv = process.env.MEMORY_LIMIT_BYTES;
            process.env.MEMORY_LIMIT_BYTES = '4294967296'; // 4GB in bytes

            // Reset instance to clear cached limit
            HealthService.resetInstance();
            const testService = HealthService.getInstance();

            const result = await (testService as any).checkMemory();

            expect(result.details.containerLimitMB).toBe(4096); // 4GB

            // Restore environment
            if (originalEnv) {
                process.env.MEMORY_LIMIT_BYTES = originalEnv;
            } else {
                delete process.env.MEMORY_LIMIT_BYTES;
            }
        });

        it('should cache container memory limit after first detection', async () => {
            const testService = HealthService.getInstance();

            // Call checkMemory twice
            const result1 = await (testService as any).checkMemory();
            const result2 = await (testService as any).checkMemory();

            // Should return same limit both times (cached)
            expect(result1.details.containerLimitMB).toBe(result2.details.containerLimitMB);
            expect(result1.details.containerLimitMB).toBeGreaterThan(0);
        });

        it('should use default 8GB limit when no container limit detected', async () => {
            // Ensure no memory limit environment variables are set
            const originalEnvVars = {
                MEMORY_LIMIT_BYTES: process.env.MEMORY_LIMIT_BYTES,
                CONTAINER_MEMORY_LIMIT: process.env.CONTAINER_MEMORY_LIMIT,
                RAILWAY_MEMORY_LIMIT: process.env.RAILWAY_MEMORY_LIMIT,
                KUBERNETES_MEMORY_LIMIT: process.env.KUBERNETES_MEMORY_LIMIT,
                DOCKER_MEMORY_LIMIT: process.env.DOCKER_MEMORY_LIMIT,
            };

            // Clear all memory limit env vars
            delete process.env.MEMORY_LIMIT_BYTES;
            delete process.env.CONTAINER_MEMORY_LIMIT;
            delete process.env.RAILWAY_MEMORY_LIMIT;
            delete process.env.KUBERNETES_MEMORY_LIMIT;
            delete process.env.DOCKER_MEMORY_LIMIT;

            // Reset instance to clear cached limit
            HealthService.resetInstance();
            const testService = HealthService.getInstance();

            const result = await (testService as any).checkMemory();

            expect(result.details.containerLimitMB).toBeGreaterThanOrEqual(4096); // At least 4GB default

            // Restore environment variables
            Object.entries(originalEnvVars).forEach(([key, value]) => {
                if (value) {
                    process.env[key] = value;
                }
            });
        });
    });
});