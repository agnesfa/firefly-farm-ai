import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { SessionStore, SessionMetadata, SupportedTransport } from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:in-memory-session-store' });

/**
 * In-memory implementation of SessionStore.
 * Suitable for single-node deployments or sticky session architectures.
 * All data is lost when the process restarts.
 */
export class InMemorySessionStore implements SessionStore {
  private transports: Map<string, SupportedTransport> = new Map();
  private metadata: Map<string, SessionMetadata> = new Map();
  private readonly defaultTtl: number;
  private readonly nodeId: string;
  private readonly ttlTimers: Map<string, NodeJS.Timeout> = new Map();

  constructor(options: { ttl?: number; nodeId?: string } = {}) {
    this.defaultTtl = options.ttl || 3600; // 1 hour default
    this.nodeId = options.nodeId || `node-${process.pid}`;
    logger.info('InMemorySessionStore initialized', { 
      defaultTtl: this.defaultTtl, 
      nodeId: this.nodeId 
    });
  }

  async get(sessionId: string): Promise<SupportedTransport | null> {
    const transport = this.transports.get(sessionId);
    if (transport) {
      // Update last accessed time
      const meta = this.metadata.get(sessionId);
      if (meta) {
        meta.lastAccessed = new Date();
        this.metadata.set(sessionId, meta);
      }
      logger.debug('Retrieved transport for session', { sessionId });
      return transport;
    }
    return null;
  }

  async set(sessionId: string, transport: SupportedTransport, ttl?: number): Promise<void> {
    const effectiveTtl = ttl || this.defaultTtl;
    
    // Store transport
    this.transports.set(sessionId, transport);
    
    // Create or update metadata
    const now = new Date();
    const existingMeta = this.metadata.get(sessionId);
    const metadata: SessionMetadata = {
      sessionId,
      nodeId: this.nodeId,
      createdAt: existingMeta?.createdAt || now,
      lastAccessed: now,
      clientInfo: existingMeta?.clientInfo
    };
    this.metadata.set(sessionId, metadata);

    // Set up TTL cleanup
    this.clearTtlTimer(sessionId);
    if (effectiveTtl > 0) {
      const timer = setTimeout(() => {
        this.cleanupSession(sessionId);
      }, effectiveTtl * 1000);
      this.ttlTimers.set(sessionId, timer);
    }

    logger.debug('Stored transport for session', { 
      sessionId, 
      ttl: effectiveTtl,
      nodeId: this.nodeId 
    });
  }

  async has(sessionId: string): Promise<boolean> {
    return this.transports.has(sessionId);
  }

  async delete(sessionId: string): Promise<boolean> {
    const existed = this.transports.has(sessionId);
    if (existed) {
      this.cleanupSession(sessionId);
      logger.debug('Removed transport for session', { sessionId });
    }
    return existed;
  }

  async getSessionIds(): Promise<string[]> {
    return Array.from(this.transports.keys());
  }

  async size(): Promise<number> {
    return this.transports.size;
  }

  async clear(): Promise<void> {
    const count = this.transports.size;
    
    // Clear all TTL timers
    for (const timer of this.ttlTimers.values()) {
      clearTimeout(timer);
    }
    this.ttlTimers.clear();
    
    // Clear storage
    this.transports.clear();
    this.metadata.clear();
    
    logger.info('Cleared all sessions', { count });
  }

  async getMetadata(sessionId: string): Promise<SessionMetadata | null> {
    return this.metadata.get(sessionId) || null;
  }

  async setMetadata(sessionId: string, metadata: SessionMetadata): Promise<void> {
    // Ensure nodeId is set to current node
    metadata.nodeId = this.nodeId;
    this.metadata.set(sessionId, metadata);
    logger.debug('Updated metadata for session', { sessionId });
  }

  async healthCheck(): Promise<{ healthy: boolean; details?: any }> {
    return {
      healthy: true,
      details: {
        type: 'memory',
        nodeId: this.nodeId,
        sessionCount: this.transports.size,
        uptimeMs: process.uptime() * 1000
      }
    };
  }

  private clearTtlTimer(sessionId: string): void {
    const existingTimer = this.ttlTimers.get(sessionId);
    if (existingTimer) {
      clearTimeout(existingTimer);
      this.ttlTimers.delete(sessionId);
    }
  }

  private cleanupSession(sessionId: string): void {
    this.transports.delete(sessionId);
    this.metadata.delete(sessionId);
    this.clearTtlTimer(sessionId);
    logger.debug('Session expired and cleaned up', { sessionId });
  }
}