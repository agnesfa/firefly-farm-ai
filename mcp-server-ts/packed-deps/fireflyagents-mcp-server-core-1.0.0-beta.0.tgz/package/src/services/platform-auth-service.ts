import type {
    ExtendedAuthContext,
    McpServerConfig,
    PlatformAuthHandler
} from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { getUnifiedSessionStore } from './unified-session-store.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:platform-auth-service' });

/**
 * Module-private registry of platform auth handlers.
 *
 * Populated once at bootstrap via `PlatformAuthService.registerHandlers()`
 * (called from UnifiedSessionStore's constructor). Keeping handlers here —
 * rather than exposing them on the session store — prevents code outside this
 * module from obtaining handler references, which would violate least-privilege
 * (a handler can `authenticate()` for arbitrary auth contexts, clear caches,
 * etc.).
 */
let handlersRegistry: PlatformAuthHandler[] = [];

/**
 * Service responsible for platform OAuth authentication during session lifecycle
 */
export class PlatformAuthService {
  /**
   * Register the platform auth handlers available in this process. Called
   * once at bootstrap by UnifiedSessionStore; overwrites any previous
   * registration. Tests may call this directly to install mocks.
   */
  static registerHandlers(handlers: PlatformAuthHandler[]): void {
    handlersRegistry = handlers;
    logger.debug('Auth handlers registered', { count: handlers.length });
  }

  /**
   * @internal — for tests only
   */
  static _getHandlersForTest(): PlatformAuthHandler[] {
    return handlersRegistry;
  }
  /**
   * Perform OAuth authentication on session creation if platform credentials exist
   */
  static async authenticateOnSessionCreation(
    sessionId: string, 
    authContext: ExtendedAuthContext, 
    mcpServerConfig: McpServerConfig
  ): Promise<void> {
    logger.debug('PlatformAuthService.authenticateOnSessionCreation called', {
      sessionId,
      tenantId: authContext.tenantId,
      clientType: authContext.clientType,
      hasPlatformCredentials: !!authContext.platformCredentials
    });

    try {
      // Check if we have platform credentials that require OAuth
      if (!authContext.platformCredentials) {
        logger.warn('No platform credentials found, skipping OAuth authentication', {
          sessionId,
          tenantId: authContext.tenantId,
          clientType: authContext.clientType
        });
        return;
      }

      logger.debug('Platform credentials found, checking for auth handlers', {
        sessionId,
        hasCredentials: !!authContext.platformCredentials.credentials
      });

      const authHandlers = mcpServerConfig.authHandlers ?? [];

      logger.debug('Checking for platform auth handlers', {
        sessionId,
        authHandlersCount: authHandlers.length
      });

      if (authHandlers.length === 0) {
        logger.warn(
          'Platform credentials are configured for this session but no PlatformAuthHandler is registered — the framework cannot perform OAuth. Register a handler via buildAppConfig({ capabilities: { authHandlers: [...] } }), or remove platformCredentials from the API key store entry if the plugin handles auth directly.',
          {
            sessionId,
            tenantId: authContext.tenantId
          }
        );
        return;
      }

      const platformAuthHandler = authHandlers[0];
      
      logger.debug('Performing OAuth authentication on session creation', {
        sessionId,
        tenantId: authContext.tenantId,
        clientMetadata: authContext.clientMetadata
      });

      // ✅ Call the platform auth handler to get OAuth token
      const accessToken = await platformAuthHandler.authenticate(authContext);
      
      logger.info('OAuth authentication successful - token obtained', {
        sessionId,
        tenantId: authContext.tenantId,
        // tokenPreview: accessToken.substring(0, 20) + '...'
      });

      // ✅ Store the OAuth token in the session
      // Always store the token that was returned by the auth handler
      // The auth handler may return cached tokens without updating authContext.platformCredentials.tokens
      const unifiedStore = getUnifiedSessionStore();
      const tokenInfo = authContext.platformCredentials.tokens;
      if (tokenInfo && tokenInfo.accessToken) {
        // Use token info from authContext if it was updated by handler
        unifiedStore.updatePlatformToken(sessionId, 'default', {
          accessToken: tokenInfo.accessToken,
          refreshToken: tokenInfo.refreshToken,
          expiresAt: tokenInfo.expiresAt
        });

        logger.debug('OAuth token stored in session from authContext', {
          sessionId,
          expiresAt: tokenInfo.expiresAt
        });
      } else {
        // Fallback: create token info from the returned accessToken
        // This handles cases where auth handler returns cached token without updating authContext
        const expiresAt = new Date(Date.now() + 3600000); // Default 1 hour expiration
        unifiedStore.updatePlatformToken(sessionId, 'default', {
          accessToken: accessToken,
          refreshToken: undefined,
          expiresAt: expiresAt
        });

        logger.debug('OAuth token stored in session from returned accessToken', {
          sessionId,
          accessToken: accessToken.substring(0, 20) + '...',
          expiresAt: expiresAt
        });
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown OAuth error';
      logger.error('OAuth authentication failed on session creation', {
        sessionId,
        error: errorMessage
      });
      
      // Don't throw - allow session creation to continue even if OAuth fails
      // Tools can handle authentication errors gracefully
    }
  }

  /**
   * Get OAuth token for a session and platform (for use by tools)
   */
  static getSessionToken(sessionId: string, platform: string): string | null {
    const unifiedStore = getUnifiedSessionStore();
    const tokenInfo = unifiedStore.getPlatformToken(sessionId, platform);
    return tokenInfo?.accessToken || null;
  }

  /**
   * Check if OAuth token is expired and needs refresh
   */
  static isTokenExpired(sessionId: string, platform: string, bufferMs: number = 5 * 60 * 1000): boolean {
    const unifiedStore = getUnifiedSessionStore();
    const tokenInfo = unifiedStore.getPlatformToken(sessionId, platform);
    if (!tokenInfo?.expiresAt) {
      return false; // No expiration info, assume valid
    }

    const now = new Date();
    const timeToExpiry = tokenInfo.expiresAt.getTime() - now.getTime();
    return timeToExpiry <= bufferMs;
  }

  /**
   * Forcibly re-authenticate a session: invalidate any handler-internal cache,
   * re-OAuth via the registered handler, and update the session's stored token.
   *
   * Returns the fresh access token on success, or `null` if the session is
   * unknown, no auth handler is registered, or the handler refuses.
   *
   * Used by `createAuthRefreshCallback` when a tool's API call returns 401 —
   * typically because a platform rotated tokens outside of the stated
   * `expires_in` (e.g. Fluent Commerce's midnight-UTC rotation).
   */
  static async refreshSessionToken(
    sessionId: string,
    platform: string = 'default'
  ): Promise<string | null> {
    if (!sessionId) {
      logger.debug('refreshSessionToken called without sessionId');
      return null;
    }

    const unifiedStore = getUnifiedSessionStore();
    const session = await unifiedStore.getSession(sessionId);
    if (!session) {
      logger.warn('refreshSessionToken: session not found', { sessionId });
      return null;
    }

    const handler = handlersRegistry[0];
    if (!handler) {
      logger.warn('refreshSessionToken: no auth handler registered', { sessionId });
      return null;
    }

    try {
      if (handler.invalidateCache) {
        await handler.invalidateCache(session.authContext);
        logger.debug('Handler cache invalidated for forced refresh', {
          sessionId,
          tenantId: session.tenantId
        });
      } else {
        logger.debug('Handler does not implement invalidateCache — relying on authenticate() to return fresh token', {
          sessionId,
          platform: handler.platform
        });
      }

      const accessToken = await handler.authenticate(session.authContext);

      // Prefer the fully-populated tokenInfo that the handler writes onto
      // authContext (includes expiresAt + refreshToken); fall back to the
      // returned accessToken with a conservative 1h expiry if the handler
      // doesn't update authContext.
      const tokenInfo = session.authContext.platformCredentials?.tokens;
      if (tokenInfo && tokenInfo.accessToken) {
        unifiedStore.updatePlatformToken(sessionId, platform, {
          accessToken: tokenInfo.accessToken,
          refreshToken: tokenInfo.refreshToken,
          expiresAt: tokenInfo.expiresAt
        });
      } else {
        unifiedStore.updatePlatformToken(sessionId, platform, {
          accessToken,
          refreshToken: undefined,
          expiresAt: new Date(Date.now() + 3600000)
        });
      }

      logger.info('Session token refreshed', {
        sessionId,
        tenantId: session.tenantId,
        platform
      });

      return accessToken;
    } catch (error) {
      logger.error('refreshSessionToken failed', {
        sessionId,
        platform,
        error: error instanceof Error ? error.message : String(error)
      });
      return null;
    }
  }
}