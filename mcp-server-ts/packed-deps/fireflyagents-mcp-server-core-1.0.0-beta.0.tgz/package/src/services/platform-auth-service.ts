import type {
    ExtendedAuthContext,
    PlatformAuthHandler,
    McpServerConfig
} from '@fireflyagents/mcp-server-types';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { getUnifiedSessionStore } from './unified-session-store.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:platform-auth-service' });

/**
 * Service responsible for platform OAuth authentication during session lifecycle
 */
export class PlatformAuthService {
  /**
   * Perform OAuth authentication on session creation if platform credentials exist
   */
  static async authenticateOnSessionCreation(
    sessionId: string, 
    authContext: ExtendedAuthContext, 
    mcpServerConfig: McpServerConfig
  ): Promise<void> {
    logger.debug('PlatformAuthService.authenticateOnSessionCreation called', {
      sessionId,
      tenantId: authContext.tenantId,
      clientType: authContext.clientType,
      hasPlatformCredentials: !!authContext.platformCredentials
    });

    try {
      // Check if we have platform credentials that require OAuth
      if (!authContext.platformCredentials) {
        logger.warn('No platform credentials found, skipping OAuth authentication', {
          sessionId,
          tenantId: authContext.tenantId,
          clientType: authContext.clientType
        });
        return;
      }

      logger.debug('Platform credentials found, checking for auth handlers', {
        sessionId,
        hasCredentials: !!authContext.platformCredentials.credentials
      });

      // Get the platform auth handlers from the server instance
      const authHandlers = mcpServerConfig.authHandlers as Map<string, PlatformAuthHandler> | undefined;
      
      logger.debug('Checking for platform auth handlers on server instance', {
        sessionId,
        hasAuthHandlers: !!authHandlers,
        authHandlersSize: authHandlers?.size || 0
      });

      if (!authHandlers || authHandlers.size === 0) {
        logger.warn('No platform auth handlers configured on server instance, skipping OAuth authentication', { 
          sessionId
        });
        return;
      }

      // Use the first available auth handler (lean approach - no platform matching needed)
      const platformAuthHandler = Array.from(authHandlers.values())[0];
      
      logger.debug('Performing OAuth authentication on session creation', {
        sessionId,
        tenantId: authContext.tenantId,
        clientMetadata: authContext.clientMetadata
      });

      // ✅ Call the platform auth handler to get OAuth token
      const accessToken = await platformAuthHandler.authenticate(authContext);
      
      logger.info('OAuth authentication successful - token obtained', {
        sessionId,
        tenantId: authContext.tenantId,
        // tokenPreview: accessToken.substring(0, 20) + '...'
      });

      // ✅ Store the OAuth token in the session
      // Always store the token that was returned by the auth handler
      // The auth handler may return cached tokens without updating authContext.platformCredentials.tokens
      const unifiedStore = getUnifiedSessionStore();
      const tokenInfo = authContext.platformCredentials.tokens;
      if (tokenInfo && tokenInfo.accessToken) {
        // Use token info from authContext if it was updated by handler
        unifiedStore.updatePlatformToken(sessionId, 'default', {
          accessToken: tokenInfo.accessToken,
          refreshToken: tokenInfo.refreshToken,
          expiresAt: tokenInfo.expiresAt
        });

        logger.debug('OAuth token stored in session from authContext', {
          sessionId,
          expiresAt: tokenInfo.expiresAt
        });
      } else {
        // Fallback: create token info from the returned accessToken
        // This handles cases where auth handler returns cached token without updating authContext
        const expiresAt = new Date(Date.now() + 3600000); // Default 1 hour expiration
        unifiedStore.updatePlatformToken(sessionId, 'default', {
          accessToken: accessToken,
          refreshToken: undefined,
          expiresAt: expiresAt
        });

        logger.debug('OAuth token stored in session from returned accessToken', {
          sessionId,
          accessToken: accessToken.substring(0, 20) + '...',
          expiresAt: expiresAt
        });
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown OAuth error';
      logger.error('OAuth authentication failed on session creation', {
        sessionId,
        error: errorMessage
      });
      
      // Don't throw - allow session creation to continue even if OAuth fails
      // Tools can handle authentication errors gracefully
    }
  }

  /**
   * Get OAuth token for a session and platform (for use by tools)
   */
  static getSessionToken(sessionId: string, platform: string): string | null {
    const unifiedStore = getUnifiedSessionStore();
    const tokenInfo = unifiedStore.getPlatformToken(sessionId, platform);
    return tokenInfo?.accessToken || null;
  }

  /**
   * Check if OAuth token is expired and needs refresh
   */
  static isTokenExpired(sessionId: string, platform: string, bufferMs: number = 5 * 60 * 1000): boolean {
    const unifiedStore = getUnifiedSessionStore();
    const tokenInfo = unifiedStore.getPlatformToken(sessionId, platform);
    if (!tokenInfo?.expiresAt) {
      return false; // No expiration info, assume valid
    }

    const now = new Date();
    const timeToExpiry = tokenInfo.expiresAt.getTime() - now.getTime();
    return timeToExpiry <= bufferMs;
  }
}