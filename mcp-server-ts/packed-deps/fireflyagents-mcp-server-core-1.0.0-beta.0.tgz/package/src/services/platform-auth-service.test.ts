import { describe, it, expect, vi, beforeEach } from 'vitest';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';
import type {
    ExtendedAuthContext,
    McpServerConfig,
    PlatformAuthHandler
} from '@fireflyagents/mcp-server-types';

const mockLogger = {
    info: vi.fn(),
    debug: vi.fn(),
    error: vi.fn(),
    warn: vi.fn()
};

vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
    const actual = await importOriginal() as typeof SharedUtils;
    return {
        ...actual,
        logger: {
            ...actual.logger,
            child: vi.fn().mockReturnValue(mockLogger)
        }
    };
});

const mockUpdatePlatformToken = vi.fn();
const mockGetPlatformToken = vi.fn();
const mockGetSession = vi.fn();

vi.mock('./unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn(() => ({
        updatePlatformToken: mockUpdatePlatformToken,
        getPlatformToken: mockGetPlatformToken,
        getSession: mockGetSession
    }))
}));

// Import after mocks so module-level logger child() is wired to our mock
const { PlatformAuthService } = await import('./platform-auth-service.js');

const SESSION_ID = 'sess-123';
const TENANT_ID = 'tenant-abc';

function makeAuthContext(overrides: Partial<ExtendedAuthContext> = {}): ExtendedAuthContext {
    return {
        apiKey: 'test-api-key',
        tenantId: TENANT_ID,
        platformCredentials: {
            credentials: {
                clientId: 'client',
                clientSecret: 'secret',
                username: 'user',
                password: 'pass'
            }
        },
        ...overrides
    };
}

function makeHandler(
    authenticateImpl: (ctx: ExtendedAuthContext) => Promise<string>
): PlatformAuthHandler {
    return {
        platform: 'test-platform',
        authenticate: vi.fn(authenticateImpl),
        refreshToken: vi.fn().mockResolvedValue({ accessToken: 'refreshed', expiresAt: new Date() }),
        validateToken: vi.fn().mockResolvedValue(true),
        healthCheck: vi.fn().mockResolvedValue({ healthy: true })
    };
}

describe('PlatformAuthService.authenticateOnSessionCreation', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('returns early and warns when platformCredentials are absent', async () => {
        const authContext = makeAuthContext({ platformCredentials: undefined });
        const config: McpServerConfig = { authHandlers: [] };

        await PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config);

        expect(mockLogger.warn).toHaveBeenCalledWith(
            'No platform credentials found, skipping OAuth authentication',
            expect.objectContaining({ sessionId: SESSION_ID })
        );
        expect(mockUpdatePlatformToken).not.toHaveBeenCalled();
    });

    it('warns clearly (without crashing) when platformCredentials present but authHandlers is empty', async () => {
        // This is the FAMCP-136 regression test. Previously this path crashed
        // with "Cannot read properties of undefined (reading 'authenticate')"
        // because the service treated authHandlers (an array) as a Map.
        const authContext = makeAuthContext();
        const config: McpServerConfig = { authHandlers: [] };

        await expect(
            PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config)
        ).resolves.toBeUndefined();

        expect(mockLogger.warn).toHaveBeenCalledWith(
            expect.stringContaining('no PlatformAuthHandler is registered'),
            expect.objectContaining({ sessionId: SESSION_ID, tenantId: TENANT_ID })
        );
        expect(mockLogger.error).not.toHaveBeenCalled();
        expect(mockUpdatePlatformToken).not.toHaveBeenCalled();
    });

    it('warns clearly when authHandlers is undefined (not set on config)', async () => {
        const authContext = makeAuthContext();
        const config: McpServerConfig = {};

        await expect(
            PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config)
        ).resolves.toBeUndefined();

        expect(mockLogger.warn).toHaveBeenCalledWith(
            expect.stringContaining('no PlatformAuthHandler is registered'),
            expect.objectContaining({ sessionId: SESSION_ID })
        );
        expect(mockLogger.error).not.toHaveBeenCalled();
    });

    it('invokes the first registered handler and stores the returned token', async () => {
        const handler = makeHandler(async () => 'access-token-xyz');
        const authContext = makeAuthContext();
        const config: McpServerConfig = { authHandlers: [handler] };

        await PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config);

        expect(handler.authenticate).toHaveBeenCalledWith(authContext);
        expect(mockUpdatePlatformToken).toHaveBeenCalledWith(
            SESSION_ID,
            'default',
            expect.objectContaining({ accessToken: 'access-token-xyz' })
        );
    });

    it('prefers token info from authContext when handler populates it', async () => {
        const expiresAt = new Date(Date.now() + 60_000);
        const handler = makeHandler(async (ctx) => {
            ctx.platformCredentials!.tokens = {
                accessToken: 'from-context',
                refreshToken: 'refresh-abc',
                expiresAt
            };
            return 'from-return-value';
        });
        const authContext = makeAuthContext();
        const config: McpServerConfig = { authHandlers: [handler] };

        await PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config);

        expect(mockUpdatePlatformToken).toHaveBeenCalledWith(SESSION_ID, 'default', {
            accessToken: 'from-context',
            refreshToken: 'refresh-abc',
            expiresAt
        });
    });

    it('swallows handler errors and logs at error level without throwing', async () => {
        const handler = makeHandler(async () => {
            throw new Error('OAuth provider unreachable');
        });
        const authContext = makeAuthContext();
        const config: McpServerConfig = { authHandlers: [handler] };

        await expect(
            PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config)
        ).resolves.toBeUndefined();

        expect(mockLogger.error).toHaveBeenCalledWith(
            'OAuth authentication failed on session creation',
            expect.objectContaining({
                sessionId: SESSION_ID,
                error: 'OAuth provider unreachable'
            })
        );
        expect(mockUpdatePlatformToken).not.toHaveBeenCalled();
    });

    it('uses the first handler when multiple are registered', async () => {
        const first = makeHandler(async () => 'first-token');
        const second = makeHandler(async () => 'second-token');
        const authContext = makeAuthContext();
        const config: McpServerConfig = { authHandlers: [first, second] };

        await PlatformAuthService.authenticateOnSessionCreation(SESSION_ID, authContext, config);

        expect(first.authenticate).toHaveBeenCalledTimes(1);
        expect(second.authenticate).not.toHaveBeenCalled();
    });
});

describe('PlatformAuthService.getSessionToken', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('returns the stored access token', () => {
        mockGetPlatformToken.mockReturnValueOnce({ accessToken: 'abc' });
        expect(PlatformAuthService.getSessionToken(SESSION_ID, 'default')).toBe('abc');
    });

    it('returns null when no token is stored', () => {
        mockGetPlatformToken.mockReturnValueOnce(undefined);
        expect(PlatformAuthService.getSessionToken(SESSION_ID, 'default')).toBeNull();
    });
});

describe('PlatformAuthService.isTokenExpired', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('returns false when no expiresAt is stored', () => {
        mockGetPlatformToken.mockReturnValueOnce({ accessToken: 'abc' });
        expect(PlatformAuthService.isTokenExpired(SESSION_ID, 'default')).toBe(false);
    });

    it('returns true when token is within the expiry buffer', () => {
        mockGetPlatformToken.mockReturnValueOnce({
            accessToken: 'abc',
            expiresAt: new Date(Date.now() + 60_000) // 1 minute from now
        });
        // default buffer is 5 minutes, so 1 minute is within buffer
        expect(PlatformAuthService.isTokenExpired(SESSION_ID, 'default')).toBe(true);
    });

    it('returns false when token is well outside the expiry buffer', () => {
        mockGetPlatformToken.mockReturnValueOnce({
            accessToken: 'abc',
            expiresAt: new Date(Date.now() + 60 * 60_000) // 1 hour from now
        });
        expect(PlatformAuthService.isTokenExpired(SESSION_ID, 'default')).toBe(false);
    });
});

describe('PlatformAuthService.registerHandlers + refreshSessionToken', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        // Reset the module-private registry between tests.
        PlatformAuthService.registerHandlers([]);
    });

    it('returns null when called with no sessionId', async () => {
        const result = await PlatformAuthService.refreshSessionToken('');
        expect(result).toBeNull();
        expect(mockGetSession).not.toHaveBeenCalled();
    });

    it('returns null when the session is not found', async () => {
        mockGetSession.mockResolvedValueOnce(null);
        PlatformAuthService.registerHandlers([makeHandler(async () => 'new-token')]);

        const result = await PlatformAuthService.refreshSessionToken(SESSION_ID);
        expect(result).toBeNull();
    });

    it('returns null when no auth handler is registered', async () => {
        mockGetSession.mockResolvedValueOnce({
            authContext: makeAuthContext(),
            tenantId: TENANT_ID
        });
        PlatformAuthService.registerHandlers([]);

        const result = await PlatformAuthService.refreshSessionToken(SESSION_ID);
        expect(result).toBeNull();
    });

    it('invalidates handler cache when implemented, re-authenticates, and updates store', async () => {
        const authContext = makeAuthContext();
        mockGetSession.mockResolvedValueOnce({ authContext, tenantId: TENANT_ID });

        const invalidateCache = vi.fn();
        const handler: PlatformAuthHandler = {
            ...makeHandler(async () => 'refreshed-token'),
            invalidateCache
        };
        PlatformAuthService.registerHandlers([handler]);

        const result = await PlatformAuthService.refreshSessionToken(SESSION_ID);

        expect(invalidateCache).toHaveBeenCalledWith(authContext);
        expect(handler.authenticate).toHaveBeenCalledWith(authContext);
        expect(mockUpdatePlatformToken).toHaveBeenCalledTimes(1);
        expect(result).toBe('refreshed-token');
    });

    it('works with handlers that do not implement invalidateCache', async () => {
        const authContext = makeAuthContext();
        mockGetSession.mockResolvedValueOnce({ authContext, tenantId: TENANT_ID });

        const handler = makeHandler(async () => 'refreshed-token');
        // deliberately no invalidateCache
        PlatformAuthService.registerHandlers([handler]);

        const result = await PlatformAuthService.refreshSessionToken(SESSION_ID);

        expect(handler.authenticate).toHaveBeenCalledWith(authContext);
        expect(result).toBe('refreshed-token');
    });

    it('returns null and logs error when handler.authenticate throws', async () => {
        const authContext = makeAuthContext();
        mockGetSession.mockResolvedValueOnce({ authContext, tenantId: TENANT_ID });

        const handler = makeHandler(async () => {
            throw new Error('OAuth endpoint unreachable');
        });
        PlatformAuthService.registerHandlers([handler]);

        const result = await PlatformAuthService.refreshSessionToken(SESSION_ID);
        expect(result).toBeNull();
        expect(mockLogger.error).toHaveBeenCalledWith(
            'refreshSessionToken failed',
            expect.objectContaining({ sessionId: SESSION_ID })
        );
    });

    it('prefers authContext.platformCredentials.tokens (populated by handler) over fallback', async () => {
        const futureDate = new Date(Date.now() + 7200_000);
        const authContext = makeAuthContext();
        mockGetSession.mockResolvedValueOnce({ authContext, tenantId: TENANT_ID });

        const handler = makeHandler(async (ctx) => {
            ctx.platformCredentials!.tokens = {
                accessToken: 'handler-populated',
                expiresAt: futureDate,
                refreshToken: 'rt-xyz'
            };
            return 'handler-populated';
        });
        PlatformAuthService.registerHandlers([handler]);

        await PlatformAuthService.refreshSessionToken(SESSION_ID);

        expect(mockUpdatePlatformToken).toHaveBeenCalledWith(SESSION_ID, 'default', {
            accessToken: 'handler-populated',
            refreshToken: 'rt-xyz',
            expiresAt: futureDate
        });
    });
});
