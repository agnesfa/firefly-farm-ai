import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { UnifiedSessionStore, initializeUnifiedSessionStore, getUnifiedSessionStore, resetUnifiedSessionStore } from './unified-session-store.js';
import type { McpServerConfig, ExtendedAuthContext, SupportedTransport, McpServer } from '@fireflyagents/mcp-server-types';

// Mock the factory — each call returns a fresh mock with close() tracking
const mockClose = vi.fn().mockResolvedValue(undefined);
vi.mock('../factory/mcp-server-factory.js', () => ({
  createMcpServer: vi.fn(async () => ({
    name: 'test-server',
    version: '1.0.0',
    connect: vi.fn(),
    close: mockClose
  } as unknown as McpServer))
}));

describe('UnifiedSessionStore', () => {
  let store: UnifiedSessionStore;
  let mockConfig: McpServerConfig;
  let mockTransport: SupportedTransport;
  let mockAuthContext: ExtendedAuthContext;

  beforeEach(() => {
    vi.clearAllMocks();

    mockConfig = {
      name: 'test-server',
      version: '1.0.0',
      tools: []
    };

    mockTransport = {
      sessionId: 'test-session-id'
    } as SupportedTransport;

    mockAuthContext = {
      apiKey: 'test-api-key',
      tenantId: 'tenant-123',
      clientMetadata: {}
    };

    store = new UnifiedSessionStore(mockConfig, { ttl: 60 });
  });

  afterEach(() => {
    vi.clearAllTimers();
  });

  describe('Session Creation', () => {
    it('should create session with server instance', async () => {
      const server = await store.createSession(
        'session-1',
        mockTransport,
        mockAuthContext
      );

      expect(server).toBeDefined();
      expect(await store.hasSession('session-1')).toBe(true);
      expect(store.getSessionCount()).toBe(1);
    });

    it('should store complete session data', async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);

      const session = await store.getSession('session-1');
      expect(session).toBeDefined();
      expect(session?.sessionId).toBe('session-1');
      expect(session?.tenantId).toBe('tenant-123');
      expect(session?.transport).toBe(mockTransport);
      expect(session?.serverInstance).toBeDefined();
      expect(session?.createdAt).toBeInstanceOf(Date);
      expect(session?.lastAccessed).toBeInstanceOf(Date);
    });

    it('should use default tenant if not provided', async () => {
      const authWithoutTenant: ExtendedAuthContext = {
        apiKey: 'test-api-key',
        clientMetadata: {}
      };

      await store.createSession('session-1', mockTransport, authWithoutTenant);

      const session = await store.getSession('session-1');
      expect(session?.tenantId).toBe('default');
    });

    it('should extract platform tokens from auth context', async () => {
      const authWithTokens: ExtendedAuthContext = {
        apiKey: 'test-api-key',
        tenantId: 'tenant-123',
        clientMetadata: {},
        platformCredentials: {
          credentials: {},
          tokens: {
            accessToken: 'test-token',
            refreshToken: 'refresh-token',
            expiresAt: new Date('2025-12-31')
          }
        }
      };

      await store.createSession('session-1', mockTransport, authWithTokens);

      const session = await store.getSession('session-1');
      expect(session?.platformTokens).toBeDefined();
      expect(session?.platformTokens?.['default']?.accessToken).toBe('test-token');
    });

    it('should setup TTL cleanup timer', async () => {
      vi.useFakeTimers();

      const customStore = new UnifiedSessionStore(mockConfig, { ttl: 5 }); // 5 seconds
      await customStore.createSession('session-1', mockTransport, mockAuthContext, 5);

      expect(await customStore.hasSession('session-1')).toBe(true);

      // Fast-forward 5 seconds
      vi.advanceTimersByTime(5000);

      expect(await customStore.hasSession('session-1')).toBe(false);

      vi.useRealTimers();
    });
  });

  describe('Session Retrieval', () => {
    beforeEach(async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
    });

    it('should get session by ID', async () => {
      const session = await store.getSession('session-1');
      expect(session).toBeDefined();
      expect(session?.sessionId).toBe('session-1');
    });

    it('should return null for non-existent session', async () => {
      const session = await store.getSession('non-existent');
      expect(session).toBeNull();
    });

    it('should update lastAccessed on retrieval', async () => {
      const session1 = await store.getSession('session-1');
      const firstAccess = session1?.lastAccessed;

      // Wait a bit
      await new Promise(resolve => setTimeout(resolve, 10));

      const session2 = await store.getSession('session-1');
      const secondAccess = session2?.lastAccessed;

      expect(secondAccess).toBeDefined();
      expect(firstAccess).toBeDefined();
      expect(secondAccess!.getTime()).toBeGreaterThan(firstAccess!.getTime());
    });

    it('should get transport for session', async () => {
      const transport = await store.getTransport('session-1');
      expect(transport).toBe(mockTransport);
    });

    it('should get server instance for session', async () => {
      const server = await store.getServerInstance('session-1');
      expect(server).toBeDefined();
      // Server instance exists (name not tested as it's implementation detail)
    });

    it('should return null for transport of non-existent session', async () => {
      const transport = await store.getTransport('non-existent');
      expect(transport).toBeNull();
    });
  });

  describe('Session Validation', () => {
    beforeEach(async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
    });

    it('should validate session exists and belongs to tenant', () => {
      expect(store.isValidSession('session-1', 'tenant-123')).toBe(true);
    });

    it('should reject session with wrong tenant', () => {
      expect(store.isValidSession('session-1', 'wrong-tenant')).toBe(false);
    });

    it('should reject non-existent session', () => {
      expect(store.isValidSession('non-existent', 'tenant-123')).toBe(false);
    });

    it('should update lastAccessed on validation', async () => {
      const session1 = await store.getSession('session-1');
      const firstAccess = session1?.lastAccessed;

      await new Promise(resolve => setTimeout(resolve, 10)); // Wait a bit

      store.isValidSession('session-1', 'tenant-123');

      const session2 = await store.getSession('session-1');
      const secondAccess = session2?.lastAccessed;

      expect(secondAccess!.getTime()).toBeGreaterThanOrEqual(firstAccess!.getTime());
    });
  });

  describe('Session Removal', () => {
    beforeEach(async () => {
      mockClose.mockClear();
      await store.createSession('session-1', mockTransport, mockAuthContext);
    });

    it('should remove session', async () => {
      expect(await store.hasSession('session-1')).toBe(true);

      const removed = await store.removeSession('session-1');

      expect(removed).toBe(true);
      expect(await store.hasSession('session-1')).toBe(false);
      expect(store.getSessionCount()).toBe(0);
    });

    it('should return false when removing non-existent session', async () => {
      const removed = await store.removeSession('non-existent');
      expect(removed).toBe(false);
    });

    it('should close server instance on removal', async () => {
      await store.removeSession('session-1');
      expect(mockClose).toHaveBeenCalledTimes(1);
    });

    it('should handle server.close() errors gracefully', async () => {
      mockClose.mockRejectedValueOnce(new Error('transport already closed'));

      const removed = await store.removeSession('session-1');

      expect(removed).toBe(true);
      expect(await store.hasSession('session-1')).toBe(false);
    });

    it('should be safe to call removeSession twice (re-entrant safe)', async () => {
      const removed1 = await store.removeSession('session-1');
      const removed2 = await store.removeSession('session-1');

      expect(removed1).toBe(true);
      expect(removed2).toBe(false);
      // close() should only be called once — second call bails before reaching it
      expect(mockClose).toHaveBeenCalledTimes(1);
    });

    it('should cleanup TTL timer on removal', async () => {
      vi.useFakeTimers();

      const customStore = new UnifiedSessionStore(mockConfig, { ttl: 10 });
      await customStore.createSession('session-1', mockTransport, mockAuthContext);

      expect(await customStore.hasSession('session-1')).toBe(true);

      // Remove before TTL expires
      const removed = await customStore.removeSession('session-1');
      expect(removed).toBe(true);

      // Advance timers - should not throw or cause issues
      vi.advanceTimersByTime(15000);

      // Session should still be gone (no re-creation from timer)
      expect(await customStore.hasSession('session-1')).toBe(false);

      vi.useRealTimers();
    });

    it('should close server instance on TTL expiry', async () => {
      vi.useFakeTimers();
      mockClose.mockClear();

      const customStore = new UnifiedSessionStore(mockConfig, { ttl: 5 });
      await customStore.createSession('session-ttl', mockTransport, mockAuthContext);

      expect(await customStore.hasSession('session-ttl')).toBe(true);

      // Fast-forward past TTL
      await vi.advanceTimersByTimeAsync(5000);

      expect(await customStore.hasSession('session-ttl')).toBe(false);
      expect(mockClose).toHaveBeenCalled();

      vi.useRealTimers();
    });
  });

  describe('Session Management', () => {
    it('should get all session IDs', async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);
      await store.createSession('session-3', mockTransport, mockAuthContext);

      const ids = store.getSessionIds();
      expect(ids).toHaveLength(3);
      expect(ids).toContain('session-1');
      expect(ids).toContain('session-2');
      expect(ids).toContain('session-3');
    });

    it('should get session count', async () => {
      expect(store.getSessionCount()).toBe(0);

      await store.createSession('session-1', mockTransport, mockAuthContext);
      expect(store.getSessionCount()).toBe(1);

      await store.createSession('session-2', mockTransport, mockAuthContext);
      expect(store.getSessionCount()).toBe(2);

      await store.removeSession('session-1');
      expect(store.getSessionCount()).toBe(1);
    });

    it('should clear all sessions', async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);
      await store.createSession('session-3', mockTransport, mockAuthContext);

      expect(store.getSessionCount()).toBe(3);

      await store.clearAllSessions();

      expect(store.getSessionCount()).toBe(0);
      expect(await store.hasSession('session-1')).toBe(false);
      expect(await store.hasSession('session-2')).toBe(false);
      expect(await store.hasSession('session-3')).toBe(false);
    });

    it('should close all server instances when clearing all sessions', async () => {
      mockClose.mockClear();

      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);
      await store.createSession('session-3', mockTransport, mockAuthContext);

      await store.clearAllSessions();

      // All three server instances should have been closed
      expect(mockClose).toHaveBeenCalledTimes(3);
    });

    it('should handle close errors during clearAll gracefully', async () => {
      mockClose.mockClear();
      mockClose.mockRejectedValue(new Error('close failed'));

      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);

      // Should not throw despite close errors
      await expect(store.clearAllSessions()).resolves.toBeUndefined();
      expect(store.getSessionCount()).toBe(0);
    });
  });

  describe('Platform Token Management', () => {
    beforeEach(async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
    });

    it('should get platform token', () => {
      store.updatePlatformToken('session-1', 'default', {
        accessToken: 'test-token',
        expiresAt: new Date('2025-12-31')
      });

      const token = store.getPlatformToken('session-1', 'default');
      expect(token).toBeDefined();
      expect(token?.accessToken).toBe('test-token');
    });

    it('should return null for non-existent platform', () => {
      const token = store.getPlatformToken('session-1', 'non-existent');
      expect(token).toBeNull();
    });

    it('should update platform token', () => {
      const updated = store.updatePlatformToken('session-1', 'test-platform', {
        accessToken: 'new-token',
        refreshToken: 'refresh-token',
        expiresAt: new Date('2025-12-31')
      });

      expect(updated).toBe(true);

      const token = store.getPlatformToken('session-1', 'test-platform');
      expect(token?.accessToken).toBe('new-token');
      expect(token?.refreshToken).toBe('refresh-token');
    });

    it('should return false when updating token for non-existent session', () => {
      const updated = store.updatePlatformToken('non-existent', 'default', {
        accessToken: 'token'
      });

      expect(updated).toBe(false);
    });

    it('should detect expired tokens', () => {
      const pastDate = new Date(Date.now() - 10000); // 10 seconds ago
      store.updatePlatformToken('session-1', 'expired-platform', {
        accessToken: 'token',
        expiresAt: pastDate
      });

      const expiredPlatforms = store.getExpiredTokens('session-1', 0);
      expect(expiredPlatforms).toContain('expired-platform');
    });

    it('should not detect non-expired tokens', () => {
      const futureDate = new Date(Date.now() + 10000); // 10 seconds from now
      store.updatePlatformToken('session-1', 'valid-platform', {
        accessToken: 'token',
        expiresAt: futureDate
      });

      const expiredPlatforms = store.getExpiredTokens('session-1', 0);
      expect(expiredPlatforms).not.toContain('valid-platform');
    });
  });

  describe('Session Cleanup', () => {
    it('should cleanup expired sessions', async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);

      // Manually set old lastAccessed time
      const session1 = store['sessions'].get('session-1');
      if (session1) {
        session1.lastAccessed = new Date(Date.now() - 25 * 60 * 60 * 1000); // 25 hours ago
      }

      const cleaned = store.cleanupExpiredSessions(24 * 60 * 60 * 1000); // 24 hours

      expect(cleaned).toBe(1);
      expect(await store.hasSession('session-1')).toBe(false);
      expect(await store.hasSession('session-2')).toBe(true);
    });

    it('should not cleanup recent sessions', async () => {
      await store.createSession('session-1', mockTransport, mockAuthContext);
      await store.createSession('session-2', mockTransport, mockAuthContext);

      const cleaned = store.cleanupExpiredSessions(24 * 60 * 60 * 1000);

      expect(cleaned).toBe(0);
      expect(await store.hasSession('session-1')).toBe(true);
      expect(await store.hasSession('session-2')).toBe(true);
    });
  });

  describe('Singleton Pattern', () => {
    beforeEach(() => {
      // Reset singleton before each test using proper reset function
      resetUnifiedSessionStore();
    });

    afterEach(() => {
      // Reset singleton for other tests
      resetUnifiedSessionStore();
    });

    it('should initialize singleton instance', () => {
      const instance = initializeUnifiedSessionStore(mockConfig, { ttl: 60 });
      expect(instance).toBeDefined();
      expect(instance).toBeInstanceOf(UnifiedSessionStore);
    });

    it('should get initialized singleton', () => {
      initializeUnifiedSessionStore(mockConfig, { ttl: 60 });
      const instance = getUnifiedSessionStore();
      expect(instance).toBeDefined();
      expect(instance).toBeInstanceOf(UnifiedSessionStore);
    });

    it('should throw error when getting uninitialized singleton', () => {
      // Explicitly reset to ensure clean state
      resetUnifiedSessionStore();
      expect(() => getUnifiedSessionStore()).toThrow('UnifiedSessionStore not initialized');
    });

    it('should return same instance on multiple gets', () => {
      initializeUnifiedSessionStore(mockConfig, { ttl: 60 });
      const instance1 = getUnifiedSessionStore();
      const instance2 = getUnifiedSessionStore();
      expect(instance1).toBe(instance2);
    });
  });
});