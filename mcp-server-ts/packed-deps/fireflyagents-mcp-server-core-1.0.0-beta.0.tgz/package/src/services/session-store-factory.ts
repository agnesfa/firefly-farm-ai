import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { SessionStore, SessionStoreConfig } from '@fireflyagents/mcp-server-types';
import { InMemorySessionStore } from './in-memory-session-store.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:session-store-factory' });

/**
 * Factory function to create SessionStore implementations based on configuration
 */
export function createSessionStore(config: SessionStoreConfig): SessionStore {
  logger.debug('Creating session store', { type: config.type, nodeId: config.nodeId, hasTtl: !!config.ttl, hasRedisConfig: !!config.redis });

  switch (config.type) {
    case 'memory':
      return new InMemorySessionStore({
        ttl: config.ttl,
        nodeId: config.nodeId
      });

    case 'redis':
      // TODO: Implement RedisSessionStore when needed
      throw new Error('Redis session store not yet implemented. Use type: "memory" for now.');

    default:
      throw new Error(`Unsupported session store type: ${(config as any).type}`);
  }
}

/**
 * Create a session store from environment variables and defaults
 */
export function createSessionStoreFromEnv(): SessionStore {
  const config: SessionStoreConfig = {
    type: (process.env.SESSION_STORE_TYPE as 'memory' | 'redis') || 'memory',
    ttl: process.env.SESSION_TTL ? parseInt(process.env.SESSION_TTL, 10) : undefined,
    nodeId: process.env.NODE_ID || `node-${process.pid}`,
    redis: process.env.REDIS_URL ? {
      connectionString: process.env.REDIS_URL,
      keyPrefix: process.env.REDIS_KEY_PREFIX || 'mcp:session:'
    } : undefined
  };

  logger.debug('Creating session store from environment', {
    type: config.type, 
    nodeId: config.nodeId,
    hasTtl: !!config.ttl,
    hasRedisConfig: !!config.redis
  });

  return createSessionStore(config);
}