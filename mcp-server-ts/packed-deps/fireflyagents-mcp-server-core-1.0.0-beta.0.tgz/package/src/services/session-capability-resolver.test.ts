import { describe, it, expect } from 'vitest';
import { SessionCapabilityResolver } from './session-capability-resolver.js';
import { RoleBasedToolFilter } from '../filtering/tool-filter.js';
import { RoleBasedPromptFilter } from '../filtering/prompt-filter.js';
import { RoleBasedResourceFilter } from '../filtering/resource-filter.js';
import type { McpServerConfig, ExtendedAuthContext, Tool, Prompt, Resource } from '@fireflyagents/mcp-server-types';

describe('SessionCapabilityResolver', () => {
  const createMockTool = (namespace: string, name: string, options?: any): Tool => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    paramsSchema: {},
    handler: async () => ({ content: [] }),
    options
  });

  const createMockPrompt = (namespace: string, name: string, options?: any): Prompt => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    handler: async () => ({ messages: [] }),
    options
  });

  const createMockResource = (namespace: string, name: string, options?: any): Resource => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    uriTemplate: `${namespace}://${name}`,
    handler: async () => ({ contents: [] }),
    options
  });

  const createMockConfig = (): McpServerConfig => ({
    name: 'test-server',
    version: '1.0.0',
    tools: [],
    prompts: [],
    resources: []
  });

  const createMockAuthContext = (roles: string[] = []): ExtendedAuthContext => ({
    apiKey: 'test-key',
    tenantId: 'test-tenant',
    clientMetadata: { roles }
  });

  describe('Constructor', () => {
    it('should initialize with no filters', () => {
      const resolver = new SessionCapabilityResolver();
      const filterNames = resolver.getFilterNames();

      expect(filterNames.tools).toEqual([]);
      expect(filterNames.prompts).toEqual([]);
      expect(filterNames.resources).toEqual([]);
    });

    it('should initialize with all filter types', () => {
      const resolver = new SessionCapabilityResolver(
        [new RoleBasedToolFilter()],
        [new RoleBasedPromptFilter()],
        [new RoleBasedResourceFilter()]
      );

      const filterNames = resolver.getFilterNames();
      expect(filterNames.tools).toEqual(['role-based']);
      expect(filterNames.prompts).toEqual(['role-based-prompts']);
      expect(filterNames.resources).toEqual(['role-based-resources']);
    });
  });

  describe('resolveForSession - No Filters', () => {
    it('should return all capabilities when no filters configured', async () => {
      const resolver = new SessionCapabilityResolver();
      const baseConfig = createMockConfig();
      baseConfig.tools = [
        createMockTool('demo', 'tool1'),
        createMockTool('demo', 'tool2')
      ];
      baseConfig.prompts = [
        createMockPrompt('demo', 'prompt1')
      ];
      baseConfig.resources = [
        createMockResource('demo', 'resource1')
      ];

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(),
        baseConfig
      });

      expect(result.tools).toHaveLength(2);
      expect(result.prompts).toHaveLength(1);
      expect(result.resources).toHaveLength(1);
    });
  });

  describe('resolveForSession - Tool Filtering', () => {
    it('should filter tools by roles', async () => {
      const resolver = new SessionCapabilityResolver([new RoleBasedToolFilter()]);
      const baseConfig = createMockConfig();
      baseConfig.tools = [
        createMockTool('demo', 'public_tool'),
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] }),
        createMockTool('demo', 'manager_tool', { requiredRoles: ['manager'] })
      ];

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['manager']),
        baseConfig
      });

      expect(result.tools).toHaveLength(2);
      expect(result.tools?.map(t => t.name).sort()).toEqual(['manager_tool', 'public_tool']);
    });

    it('should preserve prompts and resources when only tool filters configured', async () => {
      const resolver = new SessionCapabilityResolver([new RoleBasedToolFilter()]);
      const baseConfig = createMockConfig();
      baseConfig.tools = [createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] })];
      baseConfig.prompts = [createMockPrompt('demo', 'prompt1')];
      baseConfig.resources = [createMockResource('demo', 'resource1')];

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['user']), // No admin role
        baseConfig
      });

      expect(result.tools).toHaveLength(0); // Filtered out
      expect(result.prompts).toHaveLength(1); // Not filtered
      expect(result.resources).toHaveLength(1); // Not filtered
    });
  });

  describe('resolveForSession - All Capability Types', () => {
    it('should filter all capability types independently', async () => {
      const resolver = new SessionCapabilityResolver(
        [new RoleBasedToolFilter()],
        [new RoleBasedPromptFilter()],
        [new RoleBasedResourceFilter()]
      );

      const baseConfig = createMockConfig();
      baseConfig.tools = [
        createMockTool('demo', 'public_tool'),
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] })
      ];
      baseConfig.prompts = [
        createMockPrompt('demo', 'public_prompt'),
        createMockPrompt('demo', 'admin_prompt', { requiredRoles: ['admin'] })
      ];
      baseConfig.resources = [
        createMockResource('demo', 'public_resource'),
        createMockResource('demo', 'admin_resource', { requiredRoles: ['admin'] })
      ];

      const managerResult = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['manager']),
        baseConfig
      });

      // Only public capabilities (manager doesn't have admin role)
      expect(managerResult.tools).toHaveLength(1);
      expect(managerResult.prompts).toHaveLength(1);
      expect(managerResult.resources).toHaveLength(1);

      const adminResult = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['admin']),
        baseConfig
      });

      // All capabilities (admin has admin role)
      expect(adminResult.tools).toHaveLength(2);
      expect(adminResult.prompts).toHaveLength(2);
      expect(adminResult.resources).toHaveLength(2);
    });

    it('should handle empty capabilities gracefully', async () => {
      const resolver = new SessionCapabilityResolver(
        [new RoleBasedToolFilter()],
        [new RoleBasedPromptFilter()],
        [new RoleBasedResourceFilter()]
      );

      const baseConfig = createMockConfig();
      // No capabilities provided

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['admin']),
        baseConfig
      });

      expect(result.tools).toEqual([]);
      expect(result.prompts).toEqual([]);
      expect(result.resources).toEqual([]);
    });
  });

  describe('getFilterNames', () => {
    it('should return filter names for all types', () => {
      const resolver = new SessionCapabilityResolver(
        [new RoleBasedToolFilter()],
        [new RoleBasedPromptFilter()],
        [new RoleBasedResourceFilter()]
      );

      const names = resolver.getFilterNames();
      expect(names).toEqual({
        tools: ['role-based'],
        prompts: ['role-based-prompts'],
        resources: ['role-based-resources']
      });
    });

    it('should return empty arrays when no filters configured', () => {
      const resolver = new SessionCapabilityResolver();
      const names = resolver.getFilterNames();

      expect(names).toEqual({
        tools: [],
        prompts: [],
        resources: []
      });
    });
  });

  describe('Complex Filtering Scenarios', () => {
    it('should handle multiple roles with complex role requirements', async () => {
      const resolver = new SessionCapabilityResolver([new RoleBasedToolFilter()]);
      const baseConfig = createMockConfig();
      baseConfig.tools = [
        createMockTool('demo', 'tool1', { requiredRoles: ['role1', 'role2'] }), // OR logic
        createMockTool('demo', 'tool2', { requiredRoles: ['role3'] }),
        createMockTool('demo', 'tool3', { requiredRoles: ['role1'] })
      ];

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(['role1', 'role4']),
        baseConfig
      });

      // User has role1, so can access tool1 and tool3
      expect(result.tools).toHaveLength(2);
      expect(result.tools?.map(t => t.name).sort()).toEqual(['tool1', 'tool3']);
    });

    it('should preserve config metadata through filtering', async () => {
      const resolver = new SessionCapabilityResolver([new RoleBasedToolFilter()]);
      const baseConfig = createMockConfig();
      baseConfig.tools = [createMockTool('demo', 'tool1')];
      baseConfig.name = 'custom-server';
      baseConfig.version = '2.0.0';

      const result = await resolver.resolveForSession({
        tenantId: 'test-tenant',
        authContext: createMockAuthContext(),
        baseConfig
      });

      expect(result.name).toBe('custom-server');
      expect(result.version).toBe('2.0.0');
    });
  });
});