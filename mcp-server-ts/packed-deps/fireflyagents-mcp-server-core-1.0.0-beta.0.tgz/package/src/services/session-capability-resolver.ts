import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type {
  McpServerConfig,
  ExtendedAuthContext,
  Tool,
  Prompt,
  Resource
} from '@fireflyagents/mcp-server-types';
import type { ToolFilter, ToolFilterContext } from '../filtering/tool-filter.js';
import type { PromptFilter, PromptFilterContext } from '../filtering/prompt-filter.js';
import type { ResourceFilter, ResourceFilterContext } from '../filtering/resource-filter.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:session-capability-resolver' });

/**
 * Configuration for session capability resolution
 */
export interface SessionCapabilityConfig {
  tenantId: string;
  authContext: ExtendedAuthContext;
  baseConfig: McpServerConfig;
}

/**
 * Session Capability Resolver
 *
 * Responsible for resolving session-specific capabilities (tools, prompts, resources)
 * by applying configured filters. This keeps filtering logic out of handlers and
 * provides a clean abstraction for capability management.
 *
 * Usage:
 *   const resolver = new SessionCapabilityResolver(
 *     [new RoleBasedToolFilter()],
 *     [new RoleBasedPromptFilter()],
 *     [new RoleBasedResourceFilter()]
 *   );
 *   const sessionConfig = await resolver.resolveForSession({
 *     tenantId: 'tenant-123',
 *     authContext: {...},
 *     baseConfig: mcpServerConfig
 *   });
 *   // sessionConfig now has filtered capabilities for this specific session
 */
export class SessionCapabilityResolver {
  constructor(
    private toolFilters: ToolFilter[] = [],
    private promptFilters: PromptFilter[] = [],
    private resourceFilters: ResourceFilter[] = []
  ) {
    logger.info('SessionCapabilityResolver created', {
      toolFilterCount: toolFilters.length,
      promptFilterCount: promptFilters.length,
      resourceFilterCount: resourceFilters.length,
      toolFilters: toolFilters.map(f => f.name),
      promptFilters: promptFilters.map(f => f.name),
      resourceFilters: resourceFilters.map(f => f.name)
    });
  }

  /**
   * Resolve capabilities for a specific session
   *
   * Applies all configured filters to create a session-specific
   * McpServerConfig with filtered capabilities.
   *
   * @param config - Session context and base configuration
   * @returns Session-specific McpServerConfig with filtered tools, prompts, and resources
   */
  async resolveForSession(config: SessionCapabilityConfig): Promise<McpServerConfig> {
    const { tenantId, authContext, baseConfig } = config;

    logger.debug('Resolving session capabilities', {
      tenantId,
      baseToolCount: baseConfig.tools?.length || 0,
      basePromptCount: baseConfig.prompts?.length || 0,
      baseResourceCount: baseConfig.resources?.length || 0,
      toolFilterCount: this.toolFilters.length,
      promptFilterCount: this.promptFilters.length,
      resourceFilterCount: this.resourceFilters.length
    });

    // Apply tool filters
    const filteredTools = this.applyToolFilters({
      tenantId,
      authContext,
      availableTools: baseConfig.tools || []
    });

    // Apply prompt filters
    const filteredPrompts = this.applyPromptFilters({
      tenantId,
      authContext,
      availablePrompts: baseConfig.prompts || []
    });

    // Apply resource filters
    const filteredResources = this.applyResourceFilters({
      tenantId,
      authContext,
      availableResources: baseConfig.resources || []
    });

    // Create session-specific config
    const sessionConfig: McpServerConfig = {
      ...baseConfig,
      tools: filteredTools,
      prompts: filteredPrompts,
      resources: filteredResources
    };

    logger.info('Session capabilities resolved', {
      tenantId,
      tools: {
        original: baseConfig.tools?.length || 0,
        filtered: filteredTools.length,
        removed: (baseConfig.tools?.length || 0) - filteredTools.length
      },
      prompts: {
        original: baseConfig.prompts?.length || 0,
        filtered: filteredPrompts.length,
        removed: (baseConfig.prompts?.length || 0) - filteredPrompts.length
      },
      resources: {
        original: baseConfig.resources?.length || 0,
        filtered: filteredResources.length,
        removed: (baseConfig.resources?.length || 0) - filteredResources.length
      }
    });

    logger.debug('Filtered tools list', {
      tenantId,
      filteredToolNames: filteredTools.map(t => `${t.namespace}__${t.name}`)
    });

    return sessionConfig;
  }

  /**
   * Apply tool filters sequentially
   *
   * Each filter receives the output of the previous filter,
   * creating a pipeline of filtering operations.
   */
  private applyToolFilters(context: ToolFilterContext): Tool[] {
    // If no filters configured, return all tools
    if (this.toolFilters.length === 0) {
      logger.debug('No tool filters configured, returning all tools');
      return context.availableTools;
    }

    let tools = context.availableTools;

    // Apply each filter in sequence
    for (const filter of this.toolFilters) {
      const beforeCount = tools.length;

      tools = filter.filterTools({
        ...context,
        availableTools: tools
      });

      const afterCount = tools.length;
      const removed = beforeCount - afterCount;

      if (removed > 0) {
        logger.debug('Tool filter applied', {
          filter: filter.name,
          beforeCount,
          afterCount,
          removed
        });
      }
    }

    return tools;
  }

  /**
   * Apply prompt filters sequentially
   */
  private applyPromptFilters(context: PromptFilterContext): Prompt[] {
    if (this.promptFilters.length === 0) {
      logger.debug('No prompt filters configured, returning all prompts');
      return context.availablePrompts;
    }

    let prompts = context.availablePrompts;

    for (const filter of this.promptFilters) {
      const beforeCount = prompts.length;

      prompts = filter.filterPrompts({
        ...context,
        availablePrompts: prompts
      });

      const afterCount = prompts.length;
      const removed = beforeCount - afterCount;

      if (removed > 0) {
        logger.debug('Prompt filter applied', {
          filter: filter.name,
          beforeCount,
          afterCount,
          removed
        });
      }
    }

    return prompts;
  }

  /**
   * Apply resource filters sequentially
   */
  private applyResourceFilters(context: ResourceFilterContext): Resource[] {
    if (this.resourceFilters.length === 0) {
      logger.debug('No resource filters configured, returning all resources');
      return context.availableResources;
    }

    let resources = context.availableResources;

    for (const filter of this.resourceFilters) {
      const beforeCount = resources.length;

      resources = filter.filterResources({
        ...context,
        availableResources: resources
      });

      const afterCount = resources.length;
      const removed = beforeCount - afterCount;

      if (removed > 0) {
        logger.debug('Resource filter applied', {
          filter: filter.name,
          beforeCount,
          afterCount,
          removed
        });
      }
    }

    return resources;
  }

  /**
   * Get list of configured filter names
   */
  getFilterNames(): { tools: string[]; prompts: string[]; resources: string[] } {
    return {
      tools: this.toolFilters.map(f => f.name),
      prompts: this.promptFilters.map(f => f.name),
      resources: this.resourceFilters.map(f => f.name)
    };
  }
}