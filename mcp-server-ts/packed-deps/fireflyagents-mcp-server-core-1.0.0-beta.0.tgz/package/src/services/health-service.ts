import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { HealthStatus } from '@fireflyagents/mcp-server-types';
import type {
  SystemHealth,
  HealthCheckResult,
  HealthConfig
} from '@fireflyagents/mcp-server-types';
import { getUnifiedSessionStore } from './unified-session-store.js';
import {McpServerConfig} from "@fireflyagents/mcp-server-types";
import {createMcpServer} from "../factory/mcp-server-factory.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:health-service' });

logger.debug('Inside health-service...')

/**
 * Health service for comprehensive application health monitoring
 * Supports Kubernetes-style liveness, readiness, and startup probes
 */
export class HealthService {
  private static instance: HealthService;
  private isApplicationReady = false;
  private isApplicationStarted = false;
  private startupTime: Date;
  private mcpServerConfig?: McpServerConfig;
  
  private readonly config: HealthConfig = {
    timeout: 5000, // 5 seconds
    enablePerformanceMetrics: true,
    memoryThreshold: {
      warning: 70,  // 70% of container limit (RSS-based)
      critical: 85  // 85% of container limit (RSS-based)
    }
  };

  // Container memory limit in MB (cached after first detection)
  private containerMemoryLimitMB?: number;

  private constructor() {
    this.startupTime = new Date();
  }

  public static getInstance(): HealthService {
    if (!HealthService.instance) {
      HealthService.instance = new HealthService();
    }
    return HealthService.instance;
  }

  /**
   * Reset singleton instance for testing purposes
   * @internal
   */
  public static resetInstance(): void {
    HealthService.instance = undefined as any;
  }

  // TODO: Change this to accept the AppImpl, so that we can call the app's healthCheck()
  /**
   * Initialize the health service with application components
   */
  public initialize(mcpServerConfig?: McpServerConfig): void {
    this.mcpServerConfig = mcpServerConfig;
    this.isApplicationStarted = true;
    logger.info('Health service initialized');
  }

  /**
   * Mark the application as ready to accept traffic
   */
  public markReady(): void {
    this.isApplicationReady = true;
    logger.info('Application marked as ready');
  }

  /**
   * Mark the application as not ready (e.g., during shutdown)
   */
  public markNotReady(): void {
    this.isApplicationReady = false;
    logger.info('Application marked as not ready');
  }

  /**
   * Perform comprehensive health check
   */
  public async checkHealth(): Promise<SystemHealth> {
    const startTime = Date.now();
    
    try {
      // Run all health checks concurrently
      const [sessionStoreHealth, mcpServerHealth, memoryHealth] = await Promise.allSettled([
        this.checkSessionStore(),
        this.checkMcpServer(),
        this.checkMemory()
      ]);

      // Process results
      const checks: SystemHealth['checks'] = {
        sessionStore: this.getResultFromSettled(sessionStoreHealth, 'Session store check failed'),
        mcpServer: this.getResultFromSettled(mcpServerHealth, 'MCP server check failed'),
        memory: this.getResultFromSettled(memoryHealth, 'Memory check failed')
      };

      // Add startup check if still in startup phase
      if (!this.isApplicationReady) {
        checks.startup = await this.checkStartup();
      }

      // Calculate overall status
      const summary = this.calculateSummary(checks);
      const overallStatus = this.determineOverallStatus(summary);

      const health: SystemHealth = {
        status: overallStatus,
        timestamp: new Date().toISOString(),
        uptime: this.getUptimeSeconds(),
        version: process.env.npm_package_version || '0.0.1-beta.1',
        checks,
        summary
      };

      const responseTime = Date.now() - startTime;
      logger.debug('Health check completed', { 
        status: overallStatus, 
        responseTime,
        summary
      });

      return health;
    } catch (error) {
      logger.error('Health check failed', { error });
      return this.createUnhealthyResponse('Health check system failure', error);
    }
  }

  /**
   * Liveness probe - Is the application running?
   */
  public async livenessProbe(): Promise<{ status: HealthStatus; message?: string }> {
    try {
      // Basic checks: process is running, no critical failures
      const memoryCheck = await this.checkMemory();
      
      if (memoryCheck.status === HealthStatus.UNHEALTHY) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Critical memory usage detected'
        };
      }

      // Check if the event loop is not blocked
      const eventLoopCheck = await this.checkEventLoop();
      if (eventLoopCheck.status === HealthStatus.UNHEALTHY) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Event loop blocked'
        };
      }

      return {
        status: HealthStatus.HEALTHY,
        message: 'Application is alive'
      };
    } catch (error) {
      logger.error('Liveness probe failed', { error });
      return {
        status: HealthStatus.UNHEALTHY,
        message: 'Liveness probe failure'
      };
    }
  }

  /**
   * Readiness probe - Can the application accept traffic?
   */
  public async readinessProbe(): Promise<{ status: HealthStatus; message?: string }> {
    try {
      if (!this.isApplicationReady) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Application not ready to accept traffic'
        };
      }

      // Check critical dependencies
      const sessionStoreCheck = await this.checkSessionStore();
      if (sessionStoreCheck.status === HealthStatus.UNHEALTHY) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Session store unavailable'
        };
      }

      return {
        status: HealthStatus.HEALTHY,
        message: 'Application ready to accept traffic'
      };
    } catch (error) {
      logger.error('Readiness probe failed', { error });
      return {
        status: HealthStatus.UNHEALTHY,
        message: 'Readiness probe failure'
      };
    }
  }

  /**
   * Startup probe - Has the application finished starting?
   */
  public async startupProbe(): Promise<{ status: HealthStatus; message?: string }> {
    try {
      if (!this.isApplicationStarted) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Application still starting'
        };
      }

      // Check if all components are initialized
      const sessionStoreCheck = await this.checkSessionStore();
      if (sessionStoreCheck.status === HealthStatus.UNHEALTHY) {
        return {
          status: HealthStatus.UNHEALTHY,
          message: 'Session store not initialized'
        };
      }

      return {
        status: HealthStatus.HEALTHY,
        message: 'Application startup complete'
      };
    } catch (error) {
      logger.error('Startup probe failed', { error });
      return {
        status: HealthStatus.UNHEALTHY,
        message: 'Startup probe failure'
      };
    }
  }

  /**
   * Check session store health
   */
  private async checkSessionStore(): Promise<HealthCheckResult> {
    const startTime = Date.now();

    try {
      logger.debug('Checking unified session store health...');
      const unifiedStore = getUnifiedSessionStore();
      const sessionCount = unifiedStore.getSessionCount();

      const responseTime = Date.now() - startTime;

      return {
        status: HealthStatus.HEALTHY,
        message: 'Unified session store operational',
        details: { activeSessions: sessionCount },
        responseTime
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      logger.error('Session store health check failed', { error, responseTime });

      return {
        status: HealthStatus.UNHEALTHY,
        message: 'Session store health check failed',
        details: { error: (error as Error).message },
        responseTime
      };
    }
  }

  /**
   * Check MCP server health
   */
  private async checkMcpServer(): Promise<HealthCheckResult> {
    const startTime = Date.now();

    try {
      // Basic check: can we create a server instance?
      if (this.mcpServerConfig) {
        const server = await createMcpServer(this.mcpServerConfig);
        if (server) {
          const responseTime = Date.now() - startTime;
          return {
            status: HealthStatus.HEALTHY,
            message: 'MCP server factory operational',
            responseTime
          };
        }
      }

      // Check active sessions as a proxy for MCP health
      logger.debug('Checking MCP server health...');
      const unifiedStore = getUnifiedSessionStore();
      const sessionCount = unifiedStore.getSessionCount();
      const responseTime = Date.now() - startTime;

      return {
        status: HealthStatus.HEALTHY,
        message: 'MCP transport system operational',
        details: { activeSessions: sessionCount },
        responseTime
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      logger.error('MCP server health check failed', { error, responseTime });

      return {
        status: HealthStatus.UNHEALTHY,
        message: 'MCP server health check failed',
        details: { error: (error as Error).message },
        responseTime
      };
    }
  }

  /**
   * Check memory usage using RSS against container limits
   * Falls back to heap thresholds only at extreme levels (98%+ heap usage)
   */
  private async checkMemory(): Promise<HealthCheckResult> {
    const startTime = Date.now();

    try {
      const memoryUsage = process.memoryUsage();
      const rssMB = Math.round(memoryUsage.rss / 1024 / 1024);
      const heapUsedMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
      const heapTotalMB = Math.round(memoryUsage.heapTotal / 1024 / 1024);
      const externalMB = Math.round(memoryUsage.external / 1024 / 1024);

      const heapUsagePercent = Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100);

      // Get or detect container memory limit
      const containerLimitMB = this.getContainerMemoryLimitMB();
      const rssUsagePercent = Math.round((rssMB / containerLimitMB) * 100);

      let status = HealthStatus.HEALTHY;
      let message = 'Memory usage normal';

      // Primary check: RSS against container limit
      if (rssUsagePercent > this.config.memoryThreshold.critical) {
        status = HealthStatus.UNHEALTHY;
        message = `Critical RSS usage: ${rssMB}MB (${rssUsagePercent}% of ${containerLimitMB}MB limit)`;
      } else if (rssUsagePercent > this.config.memoryThreshold.warning) {
        status = HealthStatus.DEGRADED;
        message = `High RSS usage: ${rssMB}MB (${rssUsagePercent}% of ${containerLimitMB}MB limit)`;
      }
      // Fallback check: Only flag heap usage at extreme levels (98%+ heap usage)
      else if (heapUsagePercent >= 99) {
        status = HealthStatus.UNHEALTHY;
        message = `Critical heap usage: ${heapUsedMB}MB (${heapUsagePercent}% of ${heapTotalMB}MB heap)`;
      } else if (heapUsagePercent >= 98) {
        status = HealthStatus.DEGRADED;
        message = `High heap usage: ${heapUsedMB}MB (${heapUsagePercent}% of ${heapTotalMB}MB heap)`;
      }

      const responseTime = Date.now() - startTime;

      return {
        status,
        message,
        details: {
          heapUsed: heapUsedMB,
          heapTotal: heapTotalMB,
          heapUsagePercent,
          rss: rssMB,
          rssUsagePercent,
          external: externalMB,
          containerLimitMB
        },
        responseTime
      };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      logger.error('Memory health check failed', { error, responseTime });

      return {
        status: HealthStatus.UNHEALTHY,
        message: 'Memory health check failed',
        details: { error: (error as Error).message },
        responseTime
      };
    }
  }

  /**
   * Check for startup completion
   */
  private async checkStartup(): Promise<HealthCheckResult> {
    const uptimeSeconds = this.getUptimeSeconds();
    const isReady = this.isApplicationReady;
    
    // Consider startup complete after basic initialization
    const startupComplete = this.isApplicationStarted && uptimeSeconds > 1;
    
    return {
      status: startupComplete ? HealthStatus.HEALTHY : HealthStatus.UNHEALTHY,
      message: startupComplete ? 'Startup complete' : 'Still starting up',
      details: {
        uptime: uptimeSeconds,
        applicationStarted: this.isApplicationStarted,
        applicationReady: isReady
      }
    };
  }

  /**
   * Check event loop lag
   */
  private async checkEventLoop(): Promise<HealthCheckResult> {
    return new Promise((resolve) => {
      const start = process.hrtime.bigint();
      
      setImmediate(() => {
        const lag = Number(process.hrtime.bigint() - start) / 1000000; // Convert to ms
        
        let status = HealthStatus.HEALTHY;
        let message = 'Event loop responsive';
        
        if (lag > 100) { // More than 100ms lag is concerning
          status = HealthStatus.UNHEALTHY;
          message = 'Event loop blocked';
        } else if (lag > 50) { // More than 50ms lag is degraded
          status = HealthStatus.DEGRADED;
          message = 'Event loop slow';
        }
        
        resolve({
          status,
          message,
          details: { lagMs: Math.round(lag) }
        });
      });
    });
  }

  private getUptimeSeconds(): number {
    return Math.floor((Date.now() - this.startupTime.getTime()) / 1000);
  }

  private getResultFromSettled(
    result: PromiseSettledResult<HealthCheckResult>, 
    failureMessage: string
  ): HealthCheckResult {
    if (result.status === 'fulfilled') {
      return result.value;
    } else {
      return {
        status: HealthStatus.UNHEALTHY,
        message: failureMessage,
        details: { error: result.reason?.message || 'Unknown error' }
      };
    }
  }

  private calculateSummary(checks: SystemHealth['checks']) {
    let total = 0;
    let healthy = 0;
    let unhealthy = 0;
    let degraded = 0;

    Object.values(checks).forEach(check => {
      if (!check) return;
      total++;
      switch (check.status) {
        case HealthStatus.HEALTHY:
          healthy++;
          break;
        case HealthStatus.UNHEALTHY:
          unhealthy++;
          break;
        case HealthStatus.DEGRADED:
          degraded++;
          break;
      }
    });

    return { total, healthy, unhealthy, degraded };
  }

  private determineOverallStatus(summary: { unhealthy: number; degraded: number }): HealthStatus {
    if (summary.unhealthy > 0) {
      return HealthStatus.UNHEALTHY;
    }
    if (summary.degraded > 0) {
      return HealthStatus.DEGRADED;
    }
    return HealthStatus.HEALTHY;
  }

  /**
   * Detect container memory limit from environment or system
   * Caches result after first detection
   */
  private getContainerMemoryLimitMB(): number {
    if (this.containerMemoryLimitMB) {
      return this.containerMemoryLimitMB;
    }

    // Check common container memory limit environment variables
    const memoryLimitBytes =
      process.env.MEMORY_LIMIT_BYTES ||           // Custom env var
      process.env.CONTAINER_MEMORY_LIMIT ||      // Generic container limit
      process.env.RAILWAY_MEMORY_LIMIT ||        // Railway-specific
      process.env.KUBERNETES_MEMORY_LIMIT ||     // Kubernetes limit
      process.env.DOCKER_MEMORY_LIMIT;           // Docker limit

    if (memoryLimitBytes) {
      const limitMB = Math.round(parseInt(memoryLimitBytes) / 1024 / 1024);
      logger.info('Using container memory limit from environment', {
        limitMB,
        source: 'environment variable'
      });
      this.containerMemoryLimitMB = limitMB;
      return limitMB;
    }

    // Try to read from cgroup (Linux containers)
    try {
      const fs = require('fs');
      const cgroupMemory = fs.readFileSync('/sys/fs/cgroup/memory/memory.limit_in_bytes', 'utf8');
      const limitBytes = parseInt(cgroupMemory.trim());

      // Ignore if it's the theoretical maximum (no real limit set)
      if (limitBytes < Number.MAX_SAFE_INTEGER) {
        const limitMB = Math.round(limitBytes / 1024 / 1024);
        logger.info('Using container memory limit from cgroup', {
          limitMB,
          source: '/sys/fs/cgroup/memory/memory.limit_in_bytes'
        });
        this.containerMemoryLimitMB = limitMB;
        return limitMB;
      }
    } catch (error) {
        logger.warn('Failed to read cgroup memory limit', { error });
      // Ignore - not in a Linux container or cgroup not accessible
    }

    // Try cgroups v2 (newer container systems)
    try {
      const fs = require('fs');
      const cgroupMemory = fs.readFileSync('/sys/fs/cgroup/memory.max', 'utf8');
      const limitStr = cgroupMemory.trim();

      if (limitStr !== 'max') {
        const limitBytes = parseInt(limitStr);
        const limitMB = Math.round(limitBytes / 1024 / 1024);
        logger.info('Using container memory limit from cgroup v2', {
          limitMB,
          source: '/sys/fs/cgroup/memory.max'
        });
        this.containerMemoryLimitMB = limitMB;
        return limitMB;
      }
    } catch (error) {
        logger.warn('Failed to read cgroup v2 memory limit', { error });
      // Ignore - not in a cgroups v2 container
    }

    // Default to 8GB (8192MB) - common container default
    const defaultLimitMB = 8192;
    logger.info('Using default container memory limit', {
      limitMB: defaultLimitMB,
      source: 'default assumption (8GB)'
    });
    this.containerMemoryLimitMB = defaultLimitMB;
    return defaultLimitMB;
  }

  private createUnhealthyResponse(_message: string, _error?: any): SystemHealth {
    return {
      status: HealthStatus.UNHEALTHY,
      timestamp: new Date().toISOString(),
      uptime: this.getUptimeSeconds(),
      version: process.env.npm_package_version || '0.0.1-beta.1',
      checks: {
        sessionStore: {
          status: HealthStatus.UNHEALTHY,
          message: 'Not checked due to system failure'
        },
        mcpServer: {
          status: HealthStatus.UNHEALTHY,
          message: 'Not checked due to system failure'
        }
      },
      summary: {
        total: 2,
        healthy: 0,
        unhealthy: 2,
        degraded: 0
      }
    };
  }
}

// Export singleton instance
// Export a getter to always return current singleton instance
export const getHealthService = () => HealthService.getInstance();

// Export singleton instance for backward compatibility
export const healthService = HealthService.getInstance();