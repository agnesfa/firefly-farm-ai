// mcp-server/factory.ts

import { McpServer, type McpServerConfig } from "@fireflyagents/mcp-server-types";
import { logger as baseLogger, readNameAndVersionFromPackageJson } from "@fireflyagents/mcp-shared-utils";
import { registerTool, registerPrompt, registerResource } from "../utils/index.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:server-factory' });
/**
 * Create a new McpServer, capabilities, authentication plugins, and context provider.
 */
export async function createMcpServer({
  name,
  version,
  packageJsonPath,
  tools = [],
  prompts = [],
  resources = [],
  // plugins = [],
  apiKeyStore,
}: McpServerConfig = {}): Promise<McpServer> {
  logger.info('Creating MCP server instance', { name, version, packageJsonPath });
  if (!name || !version) {
    const { pkgName, pkgVersion } = await readNameAndVersionFromPackageJson(
      packageJsonPath
    );
    name ??= pkgName;
    version ??= pkgVersion;
  }

  const server = new McpServer({ name, version });

  // Store authentication plugins on the server instance for later use
  // This allows request handlers to access them
  if (apiKeyStore) {
    (server as any)._apiKeyStore = apiKeyStore;
  }

  // Plugin capabilities are extracted by the Application layer (DefaultMcpServerApp)
  // and passed in via the tools/prompts/resources arrays.
  // The factory just registers what it receives - no duplicate extraction.
  const allTools = tools;
  const allPrompts = prompts;
  const allResources = resources;

  // Register tools directly on server
  for (const tool of allTools) {
    registerTool(server, tool);
    logger.debug('Registered tool', { namespace: tool.namespace, name: tool.name });
  }

  // Register prompts directly on server
  for (const prompt of allPrompts) {
    registerPrompt(server, prompt);
    logger.debug('Registered prompt', { namespace: prompt.namespace, name: prompt.name });
  }

  // Register resources directly on server
  for (const resource of allResources) {
    registerResource(server, resource);
    logger.debug('Registered resource', { namespace: resource.namespace, name: resource.name });
  }

  return server;
}