import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createMcpServer } from './mcp-server-factory.js';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';
import type * as SharedTypes from '@fireflyagents/mcp-server-types';
import {Tool} from "@fireflyagents/mcp-server-types";
import {CallToolResult} from "@modelcontextprotocol/sdk/types.js";
import {helloWorldTool} from "../capabilities/tools/hello-world.js";
import {registerPrompt, registerResource, registerTool} from "../utils/index.js";

// Mock the shared utils
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
  const actual = await importOriginal() as typeof SharedUtils;
  return {
    ...actual,
    readNameAndVersionFromPackageJson: vi.fn(),
  };
});

// Mock the McpServer
vi.mock('@fireflyagents/mcp-server-types', async (importOriginal) => {
  const actual = await importOriginal() as typeof SharedTypes;
  return {
    ...actual,
    McpServer: vi.fn().mockImplementation((options) => ({
      name: options.name,
      version: options.version,
      tools: [],
        registerTool: vi.fn()
    })),
  };
});

vi.mock('../utils/index.js', async () => ({
    registerTool: vi.fn(),
    registerPrompt: vi.fn(),
    registerResource: vi.fn()
}));

const { readNameAndVersionFromPackageJson } = await import('@fireflyagents/mcp-shared-utils');
const { McpServer } = await import('@fireflyagents/mcp-server-types');

describe('MCP Server Factory', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('createMcpServer', () => {
    it('should create server with provided name and version', async () => {
      const options = {
        name: 'test-server',
        version: '1.0.0',
      };

      await createMcpServer(options);

      expect(McpServer).toHaveBeenCalledWith({
        name: 'test-server',
        version: '1.0.0',
      });
      expect(readNameAndVersionFromPackageJson).not.toHaveBeenCalled();
    });

    it('should use package.json fallback when name/version not provided', async () => {
      vi.mocked(readNameAndVersionFromPackageJson).mockResolvedValue({
        pkgName: 'pkg-name',
        pkgVersion: '2.0.0',
      });

      await createMcpServer();

      expect(readNameAndVersionFromPackageJson).toHaveBeenCalledWith(undefined);
      expect(McpServer).toHaveBeenCalledWith({
        name: 'pkg-name',
        version: '2.0.0',
      });
    });

    it('should use package.json fallback with custom path', async () => {
      vi.mocked(readNameAndVersionFromPackageJson).mockResolvedValue({
        pkgName: 'custom-pkg',
        pkgVersion: '3.0.0',
      });

      const options = {
        packageJsonPath: '/custom/path/package.json',
      };

      await createMcpServer(options);

      expect(readNameAndVersionFromPackageJson).toHaveBeenCalledWith('/custom/path/package.json');
      expect(McpServer).toHaveBeenCalledWith({
        name: 'custom-pkg',
        version: '3.0.0',
      });
    });

    it('should use provided name but fallback version from package.json', async () => {
      vi.mocked(readNameAndVersionFromPackageJson).mockResolvedValue({
        pkgName: 'pkg-name',
        pkgVersion: '4.0.0',
      });

      const options = {
        name: 'override-name',
      };

      await createMcpServer(options);

      expect(readNameAndVersionFromPackageJson).toHaveBeenCalledWith(undefined);
      expect(McpServer).toHaveBeenCalledWith({
        name: 'override-name',
        version: '4.0.0',
      });
    });

    it('should use provided version but fallback name from package.json', async () => {
      vi.mocked(readNameAndVersionFromPackageJson).mockResolvedValue({
        pkgName: 'pkg-name',
        pkgVersion: '5.0.0',
      });

      const options = {
        version: 'override-version',
      };

      await createMcpServer(options);

      expect(readNameAndVersionFromPackageJson).toHaveBeenCalledWith(undefined);
      expect(McpServer).toHaveBeenCalledWith({
        name: 'pkg-name',
        version: 'override-version',
      });
    });

    it('should register all provided Tools', async () => {
      let helloWorldTool2: Tool = {
          handler(_params: Record<string, any>, _extra: any): Promise<CallToolResult> {
              return Promise.resolve(undefined as any);
          }, name: "helloWorld2", namespace: "fa", paramsSchema: undefined as any, title: ""

      }

      const mockServer = {
        name: 'test-server',
        version: '1.0.0',
          registerTool: vi.fn()
      };

      vi.mocked(McpServer).mockReturnValue(mockServer as any);

      vi.mocked(registerTool);

      const options = {
        name: 'test-server',
        version: '1.0.0',
        tools: [helloWorldTool, helloWorldTool2],
      };

      await createMcpServer(options);

      expect(registerTool).toHaveBeenCalledTimes(2);
      expect(registerTool).toHaveBeenNthCalledWith(1, mockServer, helloWorldTool);
      expect(registerTool).toHaveBeenNthCalledWith(2, mockServer, helloWorldTool2);
    });

    it('should work with empty Tools array', async () => {
      const options = {
        name: 'test-server',
        version: '1.0.0',
        tools: [],
      };

      await createMcpServer(options);

      expect(McpServer).toHaveBeenCalledWith({
        name: 'test-server',
        version: '1.0.0',
      });
    });

    it('should work with no Tools provided', async () => {
      const options = {
        name: 'test-server',
        version: '1.0.0',
      };

      await createMcpServer(options);

      expect(McpServer).toHaveBeenCalledWith({
        name: 'test-server',
        version: '1.0.0',
      });
    });

    it('should register all provided Prompts', async () => {
      const mockPrompt1 = {
        namespace: 'test',
        name: 'mock_prompt_1',
        title: 'Mock Prompt 1',
        description: 'A mock prompt for testing',
        paramsSchema: {},
        handler: vi.fn()
      };

      const mockPrompt2 = {
        namespace: 'test',
        name: 'mock_prompt_2',
        title: 'Mock Prompt 2',
        description: 'Another mock prompt for testing',
        paramsSchema: {},
        handler: vi.fn()
      };

      const mockServer = {
        name: 'test-server',
        version: '1.0.0',
      };

      vi.mocked(McpServer).mockReturnValue(mockServer as any);

      const options = {
        name: 'test-server',
        version: '1.0.0',
        prompts: [mockPrompt1, mockPrompt2],
      };

      await createMcpServer(options);

      expect(registerPrompt).toHaveBeenCalledTimes(2);
      expect(registerPrompt).toHaveBeenNthCalledWith(1, mockServer, mockPrompt1);
      expect(registerPrompt).toHaveBeenNthCalledWith(2, mockServer, mockPrompt2);
    });

    it('should register all provided Resources', async () => {
      const mockResource1 = {
        namespace: 'test',
        name: 'mock_resource_1',
        title: 'Mock Resource 1',
        description: 'A mock resource for testing',
        uriTemplate: 'test://resource1',
        handler: vi.fn()
      };

      const mockResource2 = {
        namespace: 'test',
        name: 'mock_resource_2',
        title: 'Mock Resource 2',
        description: 'Another mock resource for testing',
        uriTemplate: 'test://resource2',
        handler: vi.fn()
      };

      const mockServer = {
        name: 'test-server',
        version: '1.0.0',
      };

      vi.mocked(McpServer).mockReturnValue(mockServer as any);

      const options = {
        name: 'test-server',
        version: '1.0.0',
        resources: [mockResource1, mockResource2],
      };

      await createMcpServer(options);

      expect(registerResource).toHaveBeenCalledTimes(2);
      expect(registerResource).toHaveBeenNthCalledWith(1, mockServer, mockResource1);
      expect(registerResource).toHaveBeenNthCalledWith(2, mockServer, mockResource2);
    });

    it('should register mixed capabilities when all are provided', async () => {
      const mockTool = {
        namespace: 'test',
        name: 'mock_tool',
        title: 'Mock Tool',
        paramsSchema: {},
        handler: vi.fn()
      };

      const mockPrompt = {
        namespace: 'test',
        name: 'mock_prompt',
        title: 'Mock Prompt',
        paramsSchema: {},
        handler: vi.fn()
      };

      const mockResource = {
        namespace: 'test',
        name: 'mock_resource',
        title: 'Mock Resource',
        uriTemplate: 'test://resource',
        handler: vi.fn()
      };

      const mockServer = {
        name: 'test-server',
        version: '1.0.0',
      };

      vi.mocked(McpServer).mockReturnValue(mockServer as any);

      const options = {
        name: 'test-server',
        version: '1.0.0',
        tools: [mockTool],
        prompts: [mockPrompt],
        resources: [mockResource],
      };

      await createMcpServer(options);

      expect(registerTool).toHaveBeenCalledTimes(1);
      expect(registerTool).toHaveBeenCalledWith(mockServer, mockTool);

      expect(registerPrompt).toHaveBeenCalledTimes(1);
      expect(registerPrompt).toHaveBeenCalledWith(mockServer, mockPrompt);

      expect(registerResource).toHaveBeenCalledTimes(1);
      expect(registerResource).toHaveBeenCalledWith(mockServer, mockResource);
    });
  });
});