// Integration tests for lean framework API
import { describe, it, expect, vi } from 'vitest';
import type { Env } from '@fireflyagents/mcp-shared-utils';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

// Mock utilities to avoid complex dependencies
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
    const actual = await importOriginal() as typeof SharedUtils;
    return {
        ...actual,
        readNameAndVersionFromPackageJson: vi.fn().mockResolvedValue({
            pkgName: 'test-app',
            pkgVersion: '1.0.0'
        }),
    }
});

const mockEnv: Env = {
  NODE_ENV: 'development',
  PORT: 3000,
  HOST: 'localhost',
  LOG_LEVEL: 'info',
  MCP_SERVER_PORT: '8080',
  MCP_SERVER_HOST: 'localhost',
  CREDENTIALS_PATH: undefined
};

describe('Lean Framework API Integration', () => {
  it('should export primary lean framework functions', async () => {
    const { buildAppConfig, createServerApp } = await import('./index.js');

    expect(typeof buildAppConfig).toBe('function');
    expect(typeof createServerApp).toBe('function');
  });

  it('should support zero-config pattern', async () => {
    const { buildAppConfig } = await import('./config/app-config.js');

    const config = await buildAppConfig(mockEnv);

    expect(config.environment).toBe('development');
    expect(config.server.name).toBe('test-app');
    expect(config.auth.type).toBe('dev');
    expect(config.tools).toBeDefined();
    expect(config.prompts).toBeDefined();
    expect(config.resources).toBeDefined();
  });

  it('should support extensions pattern', async () => {
    const { buildAppConfig } = await import('./config/app-config.js');
    const mockTool = {
      namespace: 'test',
      name: 'mock_tool',
      title: 'Mock Tool',
      paramsSchema: {},
      handler: vi.fn()
    };

    const config = await buildAppConfig(mockEnv, {
      capabilities: { tools: [mockTool] }
    });

    expect(config.tools).toContain(mockTool);
    expect((config.tools?.length || 0)).toBeGreaterThan(1); // Demo + custom
  });

  it('should support disabling defaults', async () => {
    const { buildAppConfig } = await import('./config/app-config.js');
    const mockTool = {
      namespace: 'test',
      name: 'mock_tool_2',
      title: 'Mock Tool 2',
      paramsSchema: {},
      handler: vi.fn()
    };

    const config = await buildAppConfig(mockEnv, {
      includeDefaults: false,
      capabilities: { tools: [mockTool] }
    });

    expect(config.tools).toEqual([mockTool]); // Only custom
  });

  it('should create app instances', async () => {
    const { buildAppConfig, createServerApp } = await import('./index.js');

    const config = await buildAppConfig(mockEnv);
    const app = createServerApp(config);

    expect(app).toBeDefined();
    expect(typeof app.start).toBe('function');
    expect(typeof app.stop).toBe('function');
    expect(typeof app.isReady).toBe('function');
    expect(typeof app.healthCheck).toBe('function');
  });
});