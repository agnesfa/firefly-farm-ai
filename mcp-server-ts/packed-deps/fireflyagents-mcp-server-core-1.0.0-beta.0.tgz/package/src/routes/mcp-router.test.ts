import { describe, it, expect } from 'vitest';
import request from 'supertest';
import express from 'express';
import { createMcpRouter } from './mcp-router.js';

// Mock server factory for testing
// const mockServerFactory = () => {
//   return new McpServer({ name: 'test-server', version: '1.0.0' });
// };

const mockMcpServerConfig = {
  name: 'test-server',
  version: '1.0.0',
  capabilities: {
    tools: {},
  },
};

// Create a minimal express app to test the router
const app = express();
app.use(express.json());
app.use(createMcpRouter(mockMcpServerConfig));

describe('MCP Router', () => {
  describe('GET /', () => {
    it.skip('SSE endpoint functional but hangs in tests', () => {
      // SSE connection stays open, skip for now
    });
  });

  describe('POST /', () => {
    it('should return 401 for request without API key', async () => {
      const response = await request(app).post('/').send({});
      // Authentication happens first, so should return 401
      expect(response.status).toBe(401);
      expect(response.body.error.message).toBe('Authentication failed');
    }, 10000);
  });

  describe('DELETE /', () => {
    it('should return 401 when API key is missing', async () => {
      const response = await request(app).delete('/');
      expect(response.status).toBe(401);
    });
  });
});
