import { Router } from 'express';
import type {McpServerConfig} from '@fireflyagents/mcp-server-types';
import {handleLegacySse} from "../handlers/legacy-sse-handler.js";
import {handleStreamableHttp} from "../handlers/streamable-http-handler.js";
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";

const logger = baseLogger.child({ context: 'fa-mcp:core:mcp-router' });
logger.debug('Inside MCP Router...')
export function createMcpRouter(mcpServerConfig: McpServerConfig): Router {
  const router = Router();

  logger.debug('Creating MCP router with config:', {mcpServerConfig});

    // Streamable HTTP endpoints
    router.get('/', handleStreamableHttp(mcpServerConfig));
    router.post('/', handleStreamableHttp(mcpServerConfig));
    router.delete('/', handleStreamableHttp(mcpServerConfig));

    // Legacy endpoints for backward compatibility (if needed)
    router.get('/sse', handleLegacySse(mcpServerConfig));
    router.post('/messages', handleLegacySse(mcpServerConfig));

  return router;
}


