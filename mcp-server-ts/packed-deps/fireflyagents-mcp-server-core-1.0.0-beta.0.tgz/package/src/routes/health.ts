import { Router } from 'express';
import type { Request, Response } from 'express';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { healthService } from '../services/health-service.js';
import { HealthStatus } from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:health-routes' });
const router = Router();

logger.debug('Inside Health Router...');
/**
 * Comprehensive health check endpoint
 * Returns detailed health information for monitoring systems
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
      logger.debug('Inside /health GET handler...');
    const healthData = await healthService.checkHealth();
    
    // Set appropriate HTTP status based on health
    const httpStatus = healthData.status === HealthStatus.HEALTHY ? 200 :
                      healthData.status === HealthStatus.DEGRADED ? 200 : 503;
    
    res.status(httpStatus).json(healthData);
  } catch (error) {
    logger.error('Health check endpoint failed', { error });
    res.status(503).json({
      status: HealthStatus.UNHEALTHY,
      timestamp: new Date().toISOString(),
      message: 'Health check system failure',
      error: (error as Error).message
    });
  }
});

/**
 * Kubernetes/Docker liveness probe endpoint
 * Simple endpoint to check if the application is alive
 */
router.get('/health/live', async (req: Request, res: Response) => {
  try {
    const result = await healthService.livenessProbe();
    
    const httpStatus = result.status === HealthStatus.HEALTHY ? 200 : 503;
    
    res.status(httpStatus).json({
      status: result.status,
      message: result.message,
      timestamp: new Date().toISOString(),
      probe: 'liveness'
    });
  } catch (error) {
    logger.error('Liveness probe failed', { error });
    res.status(503).json({
      status: HealthStatus.UNHEALTHY,
      message: 'Liveness probe failure',
      timestamp: new Date().toISOString(),
      probe: 'liveness'
    });
  }
});

/**
 * Kubernetes/Docker readiness probe endpoint
 * Checks if the application is ready to accept traffic
 */
router.get('/health/ready', async (req: Request, res: Response) => {
  try {
    const result = await healthService.readinessProbe();
    
    const httpStatus = result.status === HealthStatus.HEALTHY ? 200 : 503;
    
    res.status(httpStatus).json({
      status: result.status,
      message: result.message,
      timestamp: new Date().toISOString(),
      probe: 'readiness'
    });
  } catch (error) {
    logger.error('Readiness probe failed', { error });
    res.status(503).json({
      status: HealthStatus.UNHEALTHY,
      message: 'Readiness probe failure',
      timestamp: new Date().toISOString(),
      probe: 'readiness'
    });
  }
});

/**
 * Kubernetes/Docker startup probe endpoint
 * Checks if the application has finished starting up
 */
router.get('/health/startup', async (req: Request, res: Response) => {
  try {
    const result = await healthService.startupProbe();
    
    const httpStatus = result.status === HealthStatus.HEALTHY ? 200 : 503;
    
    res.status(httpStatus).json({
      status: result.status,
      message: result.message,
      timestamp: new Date().toISOString(),
      probe: 'startup'
    });
  } catch (error) {
    logger.error('Startup probe failed', { error });
    res.status(503).json({
      status: HealthStatus.UNHEALTHY,
      message: 'Startup probe failure',
      timestamp: new Date().toISOString(),
      probe: 'startup'
    });
  }
});

/**
 * Legacy health endpoint for backward compatibility
 * Returns simple OK status
 */
router.get('/health/simple', (req: Request, res: Response) => {
  res.status(200).json({ status: 'ok' });
});

export { router as healthRouter };