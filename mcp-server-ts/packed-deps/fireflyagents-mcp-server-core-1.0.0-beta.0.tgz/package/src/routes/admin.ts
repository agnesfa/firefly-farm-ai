import express, { Request, Response, NextFunction } from 'express';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { ApiKeyStore } from '@fireflyagents/mcp-server-types';
import { FileApiKeyStore } from '../auth/file-api-key-store.js';
import { createHash } from 'crypto';

const logger = baseLogger.child({ context: 'fa-mcp:core:admin-routes' });

/**
 * Admin permission levels for role-based access control
 */
enum AdminPermission {
  FULL = 'full',    // All operations (export, delete, register, reload, upload)
  WRITE = 'write',  // Register credentials only
  READ = 'read'     // Health checks and info only
}

/**
 * Determine admin permission level from provided API key
 * Supports both legacy ADMIN_API_KEY and new role-based keys
 */
function determinePermission(adminKey: string): AdminPermission | null {
  // Check full access keys (priority order)
  const fullAccessKeys = [
    process.env.ADMIN_KEY_FULL_ACCESS,
    process.env.ADMIN_API_KEY  // Backward compatibility
  ].filter(Boolean);

  if (fullAccessKeys.includes(adminKey)) {
    return AdminPermission.FULL;
  }

  // Check write-only key
  if (process.env.ADMIN_KEY_WRITE_ONLY && adminKey === process.env.ADMIN_KEY_WRITE_ONLY) {
    return AdminPermission.WRITE;
  }

  // Check read-only key
  if (process.env.ADMIN_KEY_READ_ONLY && adminKey === process.env.ADMIN_KEY_READ_ONLY) {
    return AdminPermission.READ;
  }

  return null;
}

/**
 * Check if a permission level satisfies the required level
 */
function hasPermission(actual: AdminPermission, required: AdminPermission): boolean {
  const hierarchy = {
    [AdminPermission.FULL]: 3,
    [AdminPermission.WRITE]: 2,
    [AdminPermission.READ]: 1
  };

  return hierarchy[actual] >= hierarchy[required];
}

/**
 * Admin authentication middleware with role-based access control
 * Validates x-admin-key header and determines permission level
 */
const authenticateAdmin = (requiredPermission: AdminPermission = AdminPermission.READ) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const adminKey = req.headers['x-admin-key'] as string;

    // Check if any admin key is configured
    const hasAnyAdminKey = !!(
      process.env.ADMIN_API_KEY ||
      process.env.ADMIN_KEY_FULL_ACCESS ||
      process.env.ADMIN_KEY_WRITE_ONLY ||
      process.env.ADMIN_KEY_READ_ONLY
    );

    if (!hasAnyAdminKey) {
      logger.warn('Admin API accessed but no admin keys configured');
      return res.status(500).json({
        error: 'Admin API not configured',
        message: 'No admin keys configured'
      });
    }

    if (!adminKey) {
      logger.warn('Admin authentication failed: no key provided', {
        requiredPermission,
        userAgent: req.headers['user-agent'],
        ip: req.ip
      });
      return res.status(401).json({ error: 'Admin authentication required' });
    }

    const permission = determinePermission(adminKey);

    if (!permission) {
      logger.warn('Invalid admin authentication attempt', {
        keyPrefix: adminKey.substring(0, 8) + '***',
        requiredPermission,
        userAgent: req.headers['user-agent'],
        ip: req.ip
      });
      return res.status(401).json({ error: 'Invalid admin authentication' });
    }

    if (!hasPermission(permission, requiredPermission)) {
      logger.warn('Insufficient admin permissions', {
        keyPrefix: adminKey.substring(0, 8) + '***',
        actualPermission: permission,
        requiredPermission,
        userAgent: req.headers['user-agent'],
        ip: req.ip
      });
      return res.status(403).json({
        error: 'Insufficient permissions',
        message: `This operation requires ${requiredPermission} permission`
      });
    }

    logger.debug('Admin authentication successful', {
      permission,
      requiredPermission
    });

    // Store permission in request for logging
    (req as any).adminPermission = permission;

    next();
  };
};

/**
 * Rate limiting middleware (simple implementation)
 * Creates a fresh rate limiter per router instance to avoid test interference
 */
function createAdminRateLimit() {
  const requests = new Map<string, number[]>();
  // Read env vars when middleware is created, not when module loads
  const windowMs = parseInt(process.env.ADMIN_RATE_LIMIT_WINDOW || '60000'); // 1 minute
  const maxRequests = parseInt(process.env.ADMIN_RATE_LIMIT_REQUESTS || '10');

  return (req: Request, res: Response, next: NextFunction) => {
    const clientId = req.ip || 'unknown';
    const now = Date.now();

    if (!requests.has(clientId)) {
      requests.set(clientId, []);
    }

    const clientRequests = requests.get(clientId)!;

    // Remove old requests outside the window
    const validRequests = clientRequests.filter(timestamp => now - timestamp < windowMs);
    requests.set(clientId, validRequests);

    if (validRequests.length >= maxRequests) {
      logger.warn('Admin API rate limit exceeded', {
        clientId,
        requestCount: validRequests.length,
        maxRequests,
        windowMs
      });
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message: `Maximum ${maxRequests} requests per ${windowMs}ms`
      });
    }

    validRequests.push(now);
    next();
  };
}

/**
 * Create admin router with credential management endpoints
 */
export function createAdminRouter(apiKeyStore?: ApiKeyStore) {
  const router = express.Router();

  // Apply rate limiting to all admin routes
  // Create fresh rate limiter for each router instance (prevents test interference)
  router.use(createAdminRateLimit());

  /**
   * GET /admin/credentials
   * Returns sanitized information about current credentials
   * Permission: READ or higher
   */
  router.get('/credentials', authenticateAdmin(AdminPermission.READ), async (req: Request, res: Response) => {
    try {
      logger.info('Admin credentials info requested');

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      // Get health check info (contains sanitized credential info)
      const healthCheck = await apiKeyStore.healthCheck();
      
      // If it's a FileApiKeyStore, get additional store info
      let storeInfo = null;
      if (apiKeyStore instanceof FileApiKeyStore) {
        storeInfo = apiKeyStore.getStoreInfo();
      }

      const response = {
        healthy: healthCheck.healthy,
        details: healthCheck.details,
        ...(storeInfo && { storeInfo })
      };

      logger.info('Admin credentials info retrieved', {
        healthy: healthCheck.healthy,
        hasStoreInfo: !!storeInfo
      });

      res.json(response);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to retrieve credentials info', { error: errorMessage });
      
      res.status(500).json({
        error: 'Failed to retrieve credentials information',
        message: errorMessage
      });
    }
  });

  /**
   * POST /admin/credentials
   * Upload/update credentials file (replaces entire file)
   * Permission: FULL only
   */
  router.post('/credentials', authenticateAdmin(AdminPermission.FULL), async (req: Request, res: Response) => {
    try {
      logger.info('Admin credentials upload requested');

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      if (!(apiKeyStore instanceof FileApiKeyStore)) {
        return res.status(400).json({
          error: 'Unsupported credential store',
          message: 'Credential upload only supported for file-based stores'
        });
      }

      const credentialsData = req.body;

      // Basic validation
      if (!credentialsData || typeof credentialsData !== 'object') {
        return res.status(400).json({
          error: 'Invalid credentials data',
          message: 'Request body must contain valid JSON credentials'
        });
      }

      // Validate basic structure
      if (!credentialsData.version || !credentialsData.credentials || !Array.isArray(credentialsData.credentials)) {
        return res.status(400).json({
          error: 'Invalid credentials structure',
          message: 'Credentials must have version and credentials array'
        });
      }

      // Write credentials to file and reload store
      const fs = await import('fs');
      const storeInfo = apiKeyStore.getStoreInfo();
      const credentialsPath = storeInfo.credentialsPath;
      
      fs.writeFileSync(credentialsPath, JSON.stringify(credentialsData, null, 2), 'utf8');
      
      // Reload the credential store
      await apiKeyStore.reload();

      // Verify the upload worked
      const healthCheck = await apiKeyStore.healthCheck();
      
      logger.info('Admin credentials uploaded successfully', {
        credentialsPath,
        credentialsCount: credentialsData.credentials.length,
        storeHealthy: healthCheck.healthy
      });

      res.json({
        success: true,
        message: 'Credentials uploaded and reloaded successfully',
        credentialsCount: credentialsData.credentials.length,
        credentialsPath,
        storeHealthy: healthCheck.healthy
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to upload credentials', { error: errorMessage });
      
      res.status(500).json({
        error: 'Failed to upload credentials',
        message: errorMessage
      });
    }
  });

  /**
   * POST /admin/reload
   * Force reload of credential store from file
   * Permission: FULL only
   */
  router.post('/reload', authenticateAdmin(AdminPermission.FULL), async (req: Request, res: Response) => {
    try {
      logger.info('Admin credentials reload requested');

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      if (!(apiKeyStore instanceof FileApiKeyStore)) {
        return res.status(400).json({
          error: 'Unsupported credential store',
          message: 'Reload only supported for file-based stores'
        });
      }

      // Reload the credential store
      await apiKeyStore.reload();

      // Verify the reload worked
      const healthCheck = await apiKeyStore.healthCheck();
      
      logger.info('Admin credentials reloaded successfully', {
        storeHealthy: healthCheck.healthy
      });

      res.json({
        success: true,
        message: 'Credentials reloaded successfully',
        storeHealthy: healthCheck.healthy,
        details: healthCheck.details
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to reload credentials', { error: errorMessage });
      
      res.status(500).json({
        error: 'Failed to reload credentials',
        message: errorMessage
      });
    }
  });

  /**
   * POST /admin/credentials/register
   * Register a new API key credential
   * Permission: WRITE or higher
   */
  router.post('/credentials/register', authenticateAdmin(AdminPermission.WRITE), async (req: Request, res: Response) => {
    try {
      logger.info('Admin credential registration requested', {
        permission: (req as any).adminPermission
      });

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      if (!(apiKeyStore instanceof FileApiKeyStore)) {
        return res.status(400).json({
          error: 'Unsupported credential store',
          message: 'Credential registration only supported for file-based stores'
        });
      }

      const { apiKey, metadata, platformCredentials } = req.body;

      // Validate required fields
      if (!apiKey || typeof apiKey !== 'string') {
        return res.status(400).json({
          error: 'Invalid request',
          message: 'apiKey is required and must be a string'
        });
      }

      // Hash the API key
      const apiKeyHash = createHash('sha256').update(apiKey).digest('hex');

      // Load current credentials
      const fs = await import('fs');
      const storeInfo = apiKeyStore.getStoreInfo();
      const credentialsPath = storeInfo.credentialsPath;

      let credentialsData;
      try {
        const fileContent = fs.readFileSync(credentialsPath, 'utf8');
        credentialsData = JSON.parse(fileContent);
      } catch (error) {
        return res.status(500).json({
          error: 'Failed to read credentials file',
          message: error instanceof Error ? error.message : 'Unknown error'
        });
      }

      // Check if key already exists
      const existingEntry = credentialsData.credentials.find(
        (c: any) => c.apiKeyHash === apiKeyHash
      );

      if (existingEntry) {
        return res.status(409).json({
          error: 'Credential already exists',
          message: 'An API key with this hash already exists',
          apiKeyHash: apiKeyHash.substring(0, 16) + '***'
        });
      }

      // Create new credential entry
      const newEntry = {
        apiKeyHash,
        status: 'active',
        createdAt: new Date().toISOString(),
        ...(metadata && { metadata }),
        ...(platformCredentials && { platformCredentials })
      };

      // Append to credentials array
      credentialsData.credentials.push(newEntry);

      // Write updated credentials to file
      fs.writeFileSync(credentialsPath, JSON.stringify(credentialsData, null, 2), 'utf8');

      // Reload the credential store
      await apiKeyStore.reload();

      logger.info('Admin credential registered successfully', {
        apiKeyHash: apiKeyHash.substring(0, 16) + '***',
        credentialsCount: credentialsData.credentials.length,
        permission: (req as any).adminPermission
      });

      res.status(201).json({
        success: true,
        message: 'Credential registered successfully',
        apiKeyHash: apiKeyHash.substring(0, 16) + '***',
        credentialsCount: credentialsData.credentials.length
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to register credential', { error: errorMessage });

      res.status(500).json({
        error: 'Failed to register credential',
        message: errorMessage
      });
    }
  });

  /**
   * GET /admin/credentials/export
   * Export entire credentials file (for backup/migration)
   * Permission: FULL only
   */
  router.get('/credentials/export', authenticateAdmin(AdminPermission.FULL), async (req: Request, res: Response) => {
    try {
      logger.info('Admin credentials export requested', {
        permission: (req as any).adminPermission
      });

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      if (!(apiKeyStore instanceof FileApiKeyStore)) {
        return res.status(400).json({
          error: 'Unsupported credential store',
          message: 'Credential export only supported for file-based stores'
        });
      }

      // Read credentials file
      const fs = await import('fs');
      const storeInfo = apiKeyStore.getStoreInfo();
      const credentialsPath = storeInfo.credentialsPath;

      let credentialsData;
      try {
        const fileContent = fs.readFileSync(credentialsPath, 'utf8');
        credentialsData = JSON.parse(fileContent);
      } catch (error) {
        return res.status(500).json({
          error: 'Failed to read credentials file',
          message: error instanceof Error ? error.message : 'Unknown error'
        });
      }

      logger.info('Admin credentials exported successfully', {
        credentialsCount: credentialsData.credentials.length,
        permission: (req as any).adminPermission
      });

      res.json(credentialsData);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to export credentials', { error: errorMessage });

      res.status(500).json({
        error: 'Failed to export credentials',
        message: errorMessage
      });
    }
  });

  /**
   * DELETE /admin/credentials/:hash
   * Mark a credential as inactive (soft delete)
   * Permission: FULL only
   */
  router.delete('/credentials/:hash', authenticateAdmin(AdminPermission.FULL), async (req: Request, res: Response) => {
    try {
      const { hash } = req.params;

      logger.info('Admin credential deletion requested', {
        hashPrefix: hash.substring(0, 16) + '***',
        permission: (req as any).adminPermission
      });

      if (!apiKeyStore) {
        return res.status(500).json({
          error: 'No API key store configured',
          message: 'Server does not have credential management capabilities'
        });
      }

      if (!(apiKeyStore instanceof FileApiKeyStore)) {
        return res.status(400).json({
          error: 'Unsupported credential store',
          message: 'Credential deletion only supported for file-based stores'
        });
      }

      // Load current credentials
      const fs = await import('fs');
      const storeInfo = apiKeyStore.getStoreInfo();
      const credentialsPath = storeInfo.credentialsPath;

      let credentialsData;
      try {
        const fileContent = fs.readFileSync(credentialsPath, 'utf8');
        credentialsData = JSON.parse(fileContent);
      } catch (error) {
        return res.status(500).json({
          error: 'Failed to read credentials file',
          message: error instanceof Error ? error.message : 'Unknown error'
        });
      }

      // Find credential by hash (support partial hash matching)
      const entry = credentialsData.credentials.find(
        (c: any) => c.apiKeyHash.startsWith(hash) || c.apiKeyHash === hash
      );

      if (!entry) {
        return res.status(404).json({
          error: 'Credential not found',
          message: 'No credential found with provided hash'
        });
      }

      // Mark as inactive (soft delete - preserves audit trail)
      entry.status = 'inactive';
      entry.deactivatedAt = new Date().toISOString();

      // Write updated credentials to file
      fs.writeFileSync(credentialsPath, JSON.stringify(credentialsData, null, 2), 'utf8');

      // Reload the credential store
      await apiKeyStore.reload();

      logger.info('Admin credential marked as inactive', {
        apiKeyHash: entry.apiKeyHash.substring(0, 16) + '***',
        permission: (req as any).adminPermission
      });

      res.json({
        success: true,
        message: 'Credential marked as inactive',
        apiKeyHash: entry.apiKeyHash.substring(0, 16) + '***'
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to delete credential', { error: errorMessage });

      res.status(500).json({
        error: 'Failed to delete credential',
        message: errorMessage
      });
    }
  });

  /**
   * GET /admin/health
   * Admin-specific health check with more detailed information
   * Permission: READ or higher (accessible to all admin keys)
   */
  router.get('/health', authenticateAdmin(AdminPermission.READ), async (req: Request, res: Response) => {
    try {
      const adminHealth = {
        adminApiEnabled: !!process.env.ADMIN_API_KEY,
        rateLimiting: {
          enabled: true,
          windowMs: parseInt(process.env.ADMIN_RATE_LIMIT_WINDOW || '60000'),
          maxRequests: parseInt(process.env.ADMIN_RATE_LIMIT_REQUESTS || '10')
        },
        apiKeyStore: {
          configured: !!apiKeyStore,
          type: apiKeyStore?.constructor.name || 'none',
          supportsUpload: apiKeyStore instanceof FileApiKeyStore
        },
        environment: {
          nodeEnv: process.env.NODE_ENV || 'development',
          credentialsPath: apiKeyStore instanceof FileApiKeyStore ? apiKeyStore.getStoreInfo().credentialsPath : 'not-configured'
        }
      };

      // If API key store exists, include its health info
      if (apiKeyStore) {
        const storeHealth = await apiKeyStore.healthCheck();
        (adminHealth.apiKeyStore as any) = {
          ...adminHealth.apiKeyStore,
          healthy: storeHealth.healthy,
          details: storeHealth.details
        };
      }

      logger.debug('Admin health check requested', adminHealth);
      res.json(adminHealth);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Admin health check failed', { error: errorMessage });
      
      res.status(500).json({
        error: 'Admin health check failed',
        message: errorMessage
      });
    }
  });

  return router;
}