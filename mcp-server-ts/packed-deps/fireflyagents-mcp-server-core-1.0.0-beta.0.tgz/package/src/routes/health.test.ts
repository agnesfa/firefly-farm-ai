import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { healthRouter } from './health.js';
import { HealthStatus } from '@fireflyagents/mcp-server-types';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

// Mock the logger to prevent console output during tests
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
  const actual = await importOriginal() as typeof SharedUtils;
  return {
    ...actual,
    logger: {
      ...actual.logger,
      child: vi.fn().mockReturnValue({
        info: vi.fn(),
        debug: vi.fn(),
        error: vi.fn(),
        warn: vi.fn(),
      }),
    },
  };
});

// Mock health service
vi.mock('../services/health-service.js', () => ({
  healthService: {
    checkHealth: vi.fn(),
    livenessProbe: vi.fn(),
    readinessProbe: vi.fn(),
    startupProbe: vi.fn(),
  },
}));

describe('Health Routes', () => {
  let app: express.Application;
  let mockHealthService: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    app = express();
    app.use(express.json());
    app.use('/', healthRouter);
    
    // Get the mocked health service
    const { healthService } = await import('../services/health-service.js');
    mockHealthService = healthService;
  });

  describe('GET /health', () => {
    it('should return 200 for healthy system', async () => {
      const mockHealthData = {
        status: HealthStatus.HEALTHY,
        timestamp: '2024-01-01T00:00:00.000Z',
        uptime: 3600,
        version: '1.0.0',
        checks: {
          sessionStore: { status: HealthStatus.HEALTHY, message: 'OK' },
          mcpServer: { status: HealthStatus.HEALTHY, message: 'OK' },
          memory: { status: HealthStatus.HEALTHY, message: 'OK' }
        },
        summary: { total: 3, healthy: 3, unhealthy: 0, degraded: 0 }
      };

      mockHealthService.checkHealth.mockResolvedValue(mockHealthData);

      const response = await request(app).get('/health');

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockHealthData);
      expect(mockHealthService.checkHealth).toHaveBeenCalledOnce();
    });

    it('should return 200 for degraded system', async () => {
      const mockHealthData = {
        status: HealthStatus.DEGRADED,
        timestamp: '2024-01-01T00:00:00.000Z',
        uptime: 3600,
        version: '1.0.0',
        checks: {
          sessionStore: { status: HealthStatus.HEALTHY, message: 'OK' },
          mcpServer: { status: HealthStatus.DEGRADED, message: 'Slow response' },
          memory: { status: HealthStatus.HEALTHY, message: 'OK' }
        },
        summary: { total: 3, healthy: 2, unhealthy: 0, degraded: 1 }
      };

      mockHealthService.checkHealth.mockResolvedValue(mockHealthData);

      const response = await request(app).get('/health');

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockHealthData);
    });

    it('should return 503 for unhealthy system', async () => {
      const mockHealthData = {
        status: HealthStatus.UNHEALTHY,
        timestamp: '2024-01-01T00:00:00.000Z',
        uptime: 3600,
        version: '1.0.0',
        checks: {
          sessionStore: { status: HealthStatus.UNHEALTHY, message: 'Connection failed' },
          mcpServer: { status: HealthStatus.HEALTHY, message: 'OK' },
          memory: { status: HealthStatus.HEALTHY, message: 'OK' }
        },
        summary: { total: 3, healthy: 2, unhealthy: 1, degraded: 0 }
      };

      mockHealthService.checkHealth.mockResolvedValue(mockHealthData);

      const response = await request(app).get('/health');

      expect(response.status).toBe(503);
      expect(response.body).toEqual(mockHealthData);
    });

    it('should return 503 when health check throws an error', async () => {
      const error = new Error('Health check system failure');
      mockHealthService.checkHealth.mockRejectedValue(error);

      const response = await request(app).get('/health');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Health check system failure',
        error: 'Health check system failure'
      });
      expect(response.body.timestamp).toBeDefined();
    });
  });

  describe('GET /health/live', () => {
    it('should return 200 for healthy liveness probe', async () => {
      const mockResult = {
        status: HealthStatus.HEALTHY,
        message: 'Application is alive'
      };

      mockHealthService.livenessProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/live');

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        status: HealthStatus.HEALTHY,
        message: 'Application is alive',
        probe: 'liveness'
      });
      expect(response.body.timestamp).toBeDefined();
      expect(mockHealthService.livenessProbe).toHaveBeenCalledOnce();
    });

    it('should return 503 for unhealthy liveness probe', async () => {
      const mockResult = {
        status: HealthStatus.UNHEALTHY,
        message: 'Critical memory usage detected'
      };

      mockHealthService.livenessProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/live');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Critical memory usage detected',
        probe: 'liveness'
      });
    });

    it('should return 503 when liveness probe throws an error', async () => {
      const error = new Error('Liveness probe failed');
      mockHealthService.livenessProbe.mockRejectedValue(error);

      const response = await request(app).get('/health/live');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Liveness probe failure',
        probe: 'liveness'
      });
    });
  });

  describe('GET /health/ready', () => {
    it('should return 200 for healthy readiness probe', async () => {
      const mockResult = {
        status: HealthStatus.HEALTHY,
        message: 'Application ready to accept traffic'
      };

      mockHealthService.readinessProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/ready');

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        status: HealthStatus.HEALTHY,
        message: 'Application ready to accept traffic',
        probe: 'readiness'
      });
      expect(response.body.timestamp).toBeDefined();
      expect(mockHealthService.readinessProbe).toHaveBeenCalledOnce();
    });

    it('should return 503 for unhealthy readiness probe', async () => {
      const mockResult = {
        status: HealthStatus.UNHEALTHY,
        message: 'Application not ready to accept traffic'
      };

      mockHealthService.readinessProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/ready');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Application not ready to accept traffic',
        probe: 'readiness'
      });
    });

    it('should return 503 when readiness probe throws an error', async () => {
      const error = new Error('Readiness probe failed');
      mockHealthService.readinessProbe.mockRejectedValue(error);

      const response = await request(app).get('/health/ready');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Readiness probe failure',
        probe: 'readiness'
      });
    });
  });

  describe('GET /health/startup', () => {
    it('should return 200 for healthy startup probe', async () => {
      const mockResult = {
        status: HealthStatus.HEALTHY,
        message: 'Application startup complete'
      };

      mockHealthService.startupProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/startup');

      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        status: HealthStatus.HEALTHY,
        message: 'Application startup complete',
        probe: 'startup'
      });
      expect(response.body.timestamp).toBeDefined();
      expect(mockHealthService.startupProbe).toHaveBeenCalledOnce();
    });

    it('should return 503 for unhealthy startup probe', async () => {
      const mockResult = {
        status: HealthStatus.UNHEALTHY,
        message: 'Application still starting'
      };

      mockHealthService.startupProbe.mockResolvedValue(mockResult);

      const response = await request(app).get('/health/startup');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Application still starting',
        probe: 'startup'
      });
    });

    it('should return 503 when startup probe throws an error', async () => {
      const error = new Error('Startup probe failed');
      mockHealthService.startupProbe.mockRejectedValue(error);

      const response = await request(app).get('/health/startup');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Startup probe failure',
        probe: 'startup'
      });
    });
  });

  describe('GET /health/simple', () => {
    it('should return simple OK status', async () => {
      const response = await request(app).get('/health/simple');

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ status: 'ok' });
    });

    it('should not call health service for simple endpoint', async () => {
      await request(app).get('/health/simple');

      expect(mockHealthService.checkHealth).not.toHaveBeenCalled();
      expect(mockHealthService.livenessProbe).not.toHaveBeenCalled();
      expect(mockHealthService.readinessProbe).not.toHaveBeenCalled();
      expect(mockHealthService.startupProbe).not.toHaveBeenCalled();
    });
  });

  describe('error handling', () => {
    it('should handle JSON parsing errors gracefully', async () => {
      // Mock health service to return valid data (Express handles JSON serialization)
      const mockHealthData = {
        status: HealthStatus.HEALTHY,
        timestamp: '2024-01-01T00:00:00.000Z',
        uptime: 3600,
        version: '1.0.0',
        checks: {
          sessionStore: { status: HealthStatus.HEALTHY, message: 'OK' },
          mcpServer: { status: HealthStatus.HEALTHY, message: 'OK' },
          memory: { status: HealthStatus.HEALTHY, message: 'OK' }
        },
        summary: { total: 3, healthy: 3, unhealthy: 0, degraded: 0 }
      };

      mockHealthService.checkHealth.mockResolvedValue(mockHealthData);

      const response = await request(app).get('/health');

      // Should handle normally since Express handles JSON serialization
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockHealthData);
    });

    it('should handle undefined probe results', async () => {
      mockHealthService.livenessProbe.mockResolvedValue(undefined);

      const response = await request(app).get('/health/live');

      expect(response.status).toBe(503);
      expect(response.body).toMatchObject({
        status: HealthStatus.UNHEALTHY,
        message: 'Liveness probe failure',
        probe: 'liveness'
      });
    });
  });

  describe('response format validation', () => {
    it('should include timestamp in all probe responses', async () => {
      const mockResult = { status: HealthStatus.HEALTHY, message: 'OK' };
      
      mockHealthService.livenessProbe.mockResolvedValue(mockResult);
      mockHealthService.readinessProbe.mockResolvedValue(mockResult);
      mockHealthService.startupProbe.mockResolvedValue(mockResult);

      const livenessResponse = await request(app).get('/health/live');
      const readinessResponse = await request(app).get('/health/ready');
      const startupResponse = await request(app).get('/health/startup');

      expect(livenessResponse.body.timestamp).toBeDefined();
      expect(readinessResponse.body.timestamp).toBeDefined();
      expect(startupResponse.body.timestamp).toBeDefined();

      // Timestamps should be valid ISO strings
      expect(new Date(livenessResponse.body.timestamp).toISOString()).toBe(livenessResponse.body.timestamp);
      expect(new Date(readinessResponse.body.timestamp).toISOString()).toBe(readinessResponse.body.timestamp);
      expect(new Date(startupResponse.body.timestamp).toISOString()).toBe(startupResponse.body.timestamp);
    });

    it('should include probe type in all probe responses', async () => {
      const mockResult = { status: HealthStatus.HEALTHY, message: 'OK' };
      
      mockHealthService.livenessProbe.mockResolvedValue(mockResult);
      mockHealthService.readinessProbe.mockResolvedValue(mockResult);
      mockHealthService.startupProbe.mockResolvedValue(mockResult);

      const livenessResponse = await request(app).get('/health/live');
      const readinessResponse = await request(app).get('/health/ready');
      const startupResponse = await request(app).get('/health/startup');

      expect(livenessResponse.body.probe).toBe('liveness');
      expect(readinessResponse.body.probe).toBe('readiness');
      expect(startupResponse.body.probe).toBe('startup');
    });
  });
});