import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs';
import { resolve } from 'path';
import { createAdminRouter } from './admin.js';
import { FileApiKeyStore } from '../auth/file-api-key-store.js';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

// Mock the logger to prevent console output during tests
vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
  const actual = await importOriginal() as typeof SharedUtils;
  return {
    ...actual,
    logger: {
      ...actual.logger,
      child: vi.fn().mockReturnValue({
        info: vi.fn(),
        debug: vi.fn(),
        error: vi.fn(),
        warn: vi.fn(),
      }),
    },
  };
});

// Note: We use the real admin router implementation without mocking
// This ensures authentication middleware changes are properly tested

describe('Admin Routes', () => {
  let app: express.Application;
  let testCredentialsPath: string;
  let testCredentialsDir: string;
  let originalEnv: NodeJS.ProcessEnv;
  let mockApiKeyStore: FileApiKeyStore;
  let mockGenericApiKeyStore: any;

  const testCredentials = {
    version: '1.0',
    environment: 'test',
    credentials: [{
      apiKeyHash: 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',
      status: 'active',
      createdAt: '2025-01-01T00:00:00.000Z',
      metadata: { accountId: 'TEST', retailerId: '12345' },
      platformCredentials: {
        clientId: 'test-client',
        clientSecret: 'test-secret'
      }
    }]
  };

  beforeEach(() => {
    vi.clearAllMocks();

    // Save original environment
    originalEnv = { ...process.env };

    // Set high rate limit for tests to avoid 429 errors
    // Specific rate limit tests will override this
    process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
    process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';

    // Setup test directory and file
    testCredentialsDir = resolve('./test-admin-data');
    testCredentialsPath = resolve(testCredentialsDir, 'credentials.json');

    if (!existsSync(testCredentialsDir)) {
      mkdirSync(testCredentialsDir, { recursive: true });
    }

    // Create test credentials file
    writeFileSync(testCredentialsPath, JSON.stringify(testCredentials, null, 2));

    // Setup express app
    app = express();
    app.use(express.json());

    // Create mock API key store
    mockApiKeyStore = new FileApiKeyStore({
      credentialsPath: testCredentialsPath,
      watchForChanges: false,
      validateOnLoad: true
    });

    // Create mock generic API key store (non-FileApiKeyStore)
    mockGenericApiKeyStore = {
      healthCheck: vi.fn().mockResolvedValue({
        healthy: true,
        details: { type: 'generic-store', configured: true }
      })
    };
  });

  afterEach(() => {
    // Restore environment
    process.env = originalEnv;
    
    // Cleanup test files
    if (existsSync(testCredentialsPath)) {
      unlinkSync(testCredentialsPath);
    }
    if (existsSync(testCredentialsDir)) {
      try {
        unlinkSync(testCredentialsDir);
      } catch {
        // Directory might not be empty, ignore
      }
    }
  });

  describe('Authentication Middleware', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      app.use('/admin', createAdminRouter(mockApiKeyStore));
    });

    it('should reject requests without admin key', async () => {
      const response = await request(app).get('/admin/health');

      expect(response.status).toBe(401);
      expect(response.body).toEqual({
        error: 'Admin authentication required'
      });
    });

    it('should reject requests with wrong admin key', async () => {
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'wrong-key');
      
      expect(response.status).toBe(401);
      expect(response.body).toEqual({
        error: 'Invalid admin authentication'
      });
    });

    it('should accept requests with correct admin key', async () => {
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('adminApiEnabled', true);
    });

    it('should return 500 when no admin keys are configured', async () => {
      delete process.env.ADMIN_API_KEY;
      delete process.env.ADMIN_KEY_FULL_ACCESS;
      delete process.env.ADMIN_KEY_WRITE_ONLY;
      delete process.env.ADMIN_KEY_READ_ONLY;

      // Create new app without admin key
      const newApp = express();
      newApp.use(express.json());
      newApp.use('/admin', createAdminRouter(mockApiKeyStore));

      const response = await request(newApp).get('/admin/health');

      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'Admin API not configured',
        message: 'No admin keys configured'
      });
    });
  });

  describe('Rate Limiting Middleware', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '2';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '1000'; // 1 second
      process.env.TEST_ENABLE_RATE_LIMITING = 'true'; // Enable rate limiting for these tests
      app.use('/admin', createAdminRouter(mockApiKeyStore));
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
      delete process.env.TEST_ENABLE_RATE_LIMITING;
    });

    it('should allow requests within rate limit', async () => {
      const response1 = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      const response2 = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response1.status).toBe(200);
      expect(response2.status).toBe(200);
    });

    it.skip('should reject requests exceeding rate limit', async () => {
      // Make 2 requests (at the limit)
      await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      // Third request should be rate limited
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(429);
      expect(response.body).toEqual({
        error: 'Rate limit exceeded',
        message: 'Maximum 2 requests per 1000ms'
      });
    });

    it('should reset rate limit after window expires', async () => {
      // Make requests at limit
      await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      // Wait for window to expire
      await new Promise(resolve => setTimeout(resolve, 1100));
      
      // Should be allowed again
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
    });
  });

  describe('GET /admin/credentials', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      // Use different rate limit settings to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '100'; 
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should return credential status with FileApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        healthy: true,
        details: expect.objectContaining({
          type: 'file-api-key-store',
          credentialsPath: testCredentialsPath,
          fileExists: true,
          credentialsCount: 1
        }),
        storeInfo: expect.objectContaining({
          credentialsPath: testCredentialsPath,
          credentialsCount: 1,
          entries: [{
            status: 'active',
            hasMetadata: true,
            hasPlatformCredentials: true
          }]
        })
      });
    });

    it('should return credential status with generic ApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockGenericApiKeyStore));
      
      const response = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        healthy: true,
        details: expect.objectContaining({
          type: 'generic-store',
          configured: true
        })
      });
      expect(response.body.storeInfo).toBeUndefined();
    });

    it('should return 500 when no API key store is configured', async () => {
      app.use('/admin', createAdminRouter());
      
      const response = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'No API key store configured',
        message: 'Server does not have credential management capabilities'
      });
    });

    it('should handle API key store errors', async () => {
      const failingStore = {
        validateApiKey: vi.fn(),
        getCredentials: vi.fn(),
        refreshToken: vi.fn(),
        storeCredentials: vi.fn(),
        healthCheck: vi.fn().mockRejectedValue(new Error('Store connection failed'))
      };
      app.use('/admin', createAdminRouter(failingStore as any));
      
      const response = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'Failed to retrieve credentials information',
        message: 'Store connection failed'
      });
    });
  });

  describe('POST /admin/credentials', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      // Use high rate limits to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should successfully upload credentials', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const newCredentials = {
        version: '1.0',
        environment: 'production',
        credentials: [{
          apiKeyHash: 'b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb9',
          status: 'active',
          createdAt: '2025-01-02T00:00:00.000Z',
          metadata: { accountId: 'PROD', retailerId: '67890' }
        }]
      };
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(newCredentials);
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Credentials uploaded and reloaded successfully',
        credentialsCount: 1,
        credentialsPath: testCredentialsPath,
        storeHealthy: true
      });
    });

    it('should reject invalid JSON data', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send('invalid json');
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials data',
        message: 'Request body must contain valid JSON credentials'
      });
    });

    it('should reject credentials without version', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const invalidCredentials = {
        environment: 'test',
        credentials: []
      };
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(invalidCredentials);
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials structure',
        message: 'Credentials must have version and credentials array'
      });
    });

    it('should reject credentials without credentials array', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const invalidCredentials = {
        version: '1.0',
        environment: 'test'
      };
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(invalidCredentials);
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials structure',
        message: 'Credentials must have version and credentials array'
      });
    });

    it('should reject credentials with invalid credentials array', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const invalidCredentials = {
        version: '1.0',
        environment: 'test',
        credentials: 'not-an-array'
      };
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(invalidCredentials);
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials structure',
        message: 'Credentials must have version and credentials array'
      });
    });

    it('should return 500 when no API key store is configured', async () => {
      app.use('/admin', createAdminRouter());
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(testCredentials);
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'No API key store configured',
        message: 'Server does not have credential management capabilities'
      });
    });

    it('should return 400 for non-FileApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockGenericApiKeyStore));
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(testCredentials);
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Unsupported credential store',
        message: 'Credential upload only supported for file-based stores'
      });
    });

    it('should handle file write errors', async () => {
      // Create a valid store, then spy on getStoreInfo to return an invalid path
      // so the admin router's fs.writeFileSync fails
      const storeForWriteError = new FileApiKeyStore({
        credentialsPath: testCredentialsPath,
        watchForChanges: false,
        validateOnLoad: true
      });

      vi.spyOn(storeForWriteError, 'getStoreInfo').mockReturnValue({
        credentialsPath: '/nonexistent/dir/credentials.json',
        credentialsCount: 0,
        entries: []
      });

      app.use('/admin', createAdminRouter(storeForWriteError));

      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send(testCredentials);

      expect(response.status).toBe(500);
      expect(response.body).toMatchObject({
        error: 'Failed to upload credentials',
        message: expect.stringContaining('ENOENT')
      });
    });
  });

  describe('POST /admin/reload', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      // Use high rate limits to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should successfully reload credentials', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .post('/admin/reload')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        success: true,
        message: 'Credentials reloaded successfully',
        storeHealthy: true,
        details: expect.objectContaining({
          type: 'file-api-key-store'
        })
      });
    });

    it('should return 500 when no API key store is configured', async () => {
      app.use('/admin', createAdminRouter());
      
      const response = await request(app)
        .post('/admin/reload')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'No API key store configured',
        message: 'Server does not have credential management capabilities'
      });
    });

    it('should return 400 for non-FileApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockGenericApiKeyStore));
      
      const response = await request(app)
        .post('/admin/reload')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Unsupported credential store',
        message: 'Reload only supported for file-based stores'
      });
    });

    it('should handle reload errors', async () => {
      // Create a spy on the reload method to make it fail
      const reloadSpy = vi.spyOn(mockApiKeyStore, 'reload')
        .mockRejectedValue(new Error('Reload failed'));
      
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .post('/admin/reload')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'Failed to reload credentials',
        message: 'Reload failed'
      });
      
      reloadSpy.mockRestore();
    });
  });

  describe('GET /admin/health', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      process.env.NODE_ENV = 'test';
      // Use high rate limits to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
    });

    afterEach(() => {
      delete process.env.NODE_ENV;
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should return admin health status with FileApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        adminApiEnabled: true,
        rateLimiting: {
          enabled: true,
          windowMs: 60000,
          maxRequests: 1000  // Environment variable override
        },
        apiKeyStore: {
          configured: true,
          type: 'FileApiKeyStore',
          supportsUpload: true,
          healthy: true,
          details: expect.objectContaining({
            type: 'file-api-key-store'
          })
        },
        environment: {
          nodeEnv: 'test',
          credentialsPath: testCredentialsPath
        }
      });
    });

    it('should return admin health status with generic ApiKeyStore', async () => {
      app.use('/admin', createAdminRouter(mockGenericApiKeyStore));
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        adminApiEnabled: true,
        rateLimiting: {
          enabled: true,
          windowMs: 60000,
          maxRequests: 1000  // Environment variable override
        },
        apiKeyStore: {
          configured: true,
          type: 'Object',
          supportsUpload: false,
          healthy: true,
          details: expect.objectContaining({
            type: 'generic-store'
          })
        },
        environment: {
          nodeEnv: 'test',
          credentialsPath: 'not-configured'
        }
      });
    });

    it('should return admin health status without API key store', async () => {
      app.use('/admin', createAdminRouter());
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body).toMatchObject({
        adminApiEnabled: true,
        rateLimiting: {
          enabled: true,
          windowMs: 60000,
          maxRequests: 1000  // Environment variable override
        },
        apiKeyStore: {
          configured: false,
          type: 'none',
          supportsUpload: false
        },
        environment: {
          nodeEnv: 'test',
          credentialsPath: 'not-configured'
        }
      });
    });

    it('should use custom rate limiting configuration', async () => {
      process.env.ADMIN_RATE_LIMIT_WINDOW = '30000';
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '5';
      
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(200);
      expect(response.body.rateLimiting).toEqual({
        enabled: true,
        windowMs: 30000,
        maxRequests: 5
      });
      
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
    });

    it('should handle API key store health check errors', async () => {
      const failingStore = {
        constructor: { name: 'FailingStore' },
        validateApiKey: vi.fn(),
        getCredentials: vi.fn(),
        refreshToken: vi.fn(),
        storeCredentials: vi.fn(),
        healthCheck: vi.fn().mockRejectedValue(new Error('Health check failed'))
      };
      
      app.use('/admin', createAdminRouter(failingStore as any));
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'Admin health check failed',
        message: 'Health check failed'
      });
    });

    it('should show adminApiEnabled as false when ADMIN_API_KEY not set', async () => {
      delete process.env.ADMIN_API_KEY;
      
      // This won't actually work due to auth middleware, but test the logic
      process.env.ADMIN_API_KEY = 'test-key';
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      delete process.env.ADMIN_API_KEY;
      
      const response = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'test-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toMatchObject({
        error: 'Admin API not configured'
      });
    });
  });

  describe('Integration Tests', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'integration-test-key';
      // Use high rate limits to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
      app.use('/admin', createAdminRouter(mockApiKeyStore));
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should complete full credential management workflow', async () => {
      // 1. Check initial health
      const healthResponse = await request(app)
        .get('/admin/health')
        .set('x-admin-key', 'integration-test-key');
      
      expect(healthResponse.status).toBe(200);
      expect(healthResponse.body.adminApiEnabled).toBe(true);
      
      // 2. Check initial credentials
      const initialCredsResponse = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'integration-test-key');
      
      expect(initialCredsResponse.status).toBe(200);
      expect(initialCredsResponse.body.storeInfo.credentialsCount).toBe(1);
      
      // 3. Upload new credentials
      const newCredentials = {
        version: '1.0',
        environment: 'integration-test',
        credentials: [
          {
            apiKeyHash: 'c32dc65e4c7f3b2e5bb1c7e3b2f4a5d1a8e3c6f4b9c2a5d8e1f3b7c2a5d8e1f3',
            status: 'active',
            createdAt: '2025-01-03T00:00:00.000Z',
            metadata: { accountId: 'INTEGRATION', retailerId: '99999' }
          },
          {
            apiKeyHash: 'd4f6e8a2c5b3f1d8e4a7c3f6b9d2e5a8c1f4b7d0a3f6b9c2e5a8d1f4b7c0a3f6',
            status: 'inactive',
            createdAt: '2025-01-03T01:00:00.000Z',
            metadata: { accountId: 'INTEGRATION2', retailerId: '88888' }
          }
        ]
      };
      
      const uploadResponse = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'integration-test-key')
        .send(newCredentials);
      
      expect(uploadResponse.status).toBe(200);
      expect(uploadResponse.body.credentialsCount).toBe(2);
      
      // 4. Verify updated credentials
      const updatedCredsResponse = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'integration-test-key');
      
      expect(updatedCredsResponse.status).toBe(200);
      expect(updatedCredsResponse.body.storeInfo.credentialsCount).toBe(2);
      expect(updatedCredsResponse.body.storeInfo.entries).toHaveLength(2);
      
      // 5. Test reload
      const reloadResponse = await request(app)
        .post('/admin/reload')
        .set('x-admin-key', 'integration-test-key');
      
      expect(reloadResponse.status).toBe(200);
      expect(reloadResponse.body.success).toBe(true);
    });

    it('should handle concurrent requests properly', async () => {
      const requests = Array.from({ length: 5 }, (_, _i) =>
        request(app)
          .get('/admin/health')
          .set('x-admin-key', 'integration-test-key')
      );
      
      const responses = await Promise.all(requests);
      
      // All should succeed (within rate limit)
      responses.forEach((response, _index) => {
        expect(response.status).toBe(200);
        expect(response.body.adminApiEnabled).toBe(true);
      });
    });
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      process.env.ADMIN_API_KEY = 'test-admin-key';
      // Use high rate limits to avoid interference
      process.env.ADMIN_RATE_LIMIT_REQUESTS = '1000';
      process.env.ADMIN_RATE_LIMIT_WINDOW = '60000';
    });

    afterEach(() => {
      delete process.env.ADMIN_RATE_LIMIT_REQUESTS;
      delete process.env.ADMIN_RATE_LIMIT_WINDOW;
    });

    it('should handle non-Error exceptions gracefully', async () => {
      const failingStore = {
        validateApiKey: vi.fn(),
        getCredentials: vi.fn(),
        refreshToken: vi.fn(),
        storeCredentials: vi.fn(),
        healthCheck: vi.fn().mockRejectedValue('String error')
      };
      
      app.use('/admin', createAdminRouter(failingStore as any));
      
      const response = await request(app)
        .get('/admin/credentials')
        .set('x-admin-key', 'test-admin-key');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({
        error: 'Failed to retrieve credentials information',
        message: 'Unknown error'
      });
    });

    it('should handle missing request body gracefully', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .set('Content-Type', 'application/json');
        // No body sent
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials structure',
        message: 'Credentials must have version and credentials array'
      });
    });

    it('should handle empty request body', async () => {
      app.use('/admin', createAdminRouter(mockApiKeyStore));
      
      const response = await request(app)
        .post('/admin/credentials')
        .set('x-admin-key', 'test-admin-key')
        .send({});
      
      expect(response.status).toBe(400);
      expect(response.body).toEqual({
        error: 'Invalid credentials structure',
        message: 'Credentials must have version and credentials array'
      });
    });
  });

  describe('Role-Based Admin Authentication', () => {
    describe('Permission Levels', () => {
      it('should accept legacy ADMIN_API_KEY as full access', async () => {
        process.env.ADMIN_API_KEY = 'legacy-admin-key';
        delete process.env.ADMIN_KEY_FULL_ACCESS;
        delete process.env.ADMIN_KEY_WRITE_ONLY;
        delete process.env.ADMIN_KEY_READ_ONLY;

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'legacy-admin-key');

        expect(response.status).toBe(200);
      });

      it('should support ADMIN_KEY_FULL_ACCESS for all operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_FULL_ACCESS = 'full-access-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'full-access-key');

        expect(response.status).toBe(200);
      });

      it('should allow ADMIN_KEY_WRITE_ONLY for write operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-only-key')
          .send({
            apiKey: 'test-new-key',
            metadata: { account: 'test' }
          });

        expect(response.status).toBe(201);
        expect(response.body.success).toBe(true);
      });

      it('should allow ADMIN_KEY_READ_ONLY for read operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_READ_ONLY = 'read-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'read-only-key');

        expect(response.status).toBe(200);
      });

      it('should reject WRITE key for FULL-only operations (export)', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'write-only-key');

        expect(response.status).toBe(403);
        expect(response.body).toEqual({
          error: 'Insufficient permissions',
          message: 'This operation requires full permission'
        });
      });

      it('should reject WRITE key for DELETE operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .delete('/admin/credentials/a665a45920422f9d')
          .set('x-admin-key', 'write-only-key');

        expect(response.status).toBe(403);
        expect(response.body.error).toBe('Insufficient permissions');
      });

      it('should reject READ key for WRITE operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_READ_ONLY = 'read-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'read-only-key')
          .send({
            apiKey: 'test-key',
            metadata: {}
          });

        expect(response.status).toBe(403);
        expect(response.body).toEqual({
          error: 'Insufficient permissions',
          message: 'This operation requires write permission'
        });
      });

      it('should reject READ key for FULL operations', async () => {
        delete process.env.ADMIN_API_KEY;
        process.env.ADMIN_KEY_READ_ONLY = 'read-only-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        const response = await request(app)
          .post('/admin/reload')
          .set('x-admin-key', 'read-only-key');

        expect(response.status).toBe(403);
        expect(response.body.error).toBe('Insufficient permissions');
      });
    });

    describe('POST /admin/credentials/register', () => {
      beforeEach(() => {
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-key';
        app.use('/admin', createAdminRouter(mockApiKeyStore));
      });

      it('should register a new credential successfully', async () => {
        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({
            apiKey: 'new-api-key-123',
            metadata: {
              account: 'acme',
              retailer: 'store5'
            },
            platformCredentials: {
              clientId: 'client-123',
              clientSecret: 'secret-456'
            }
          });

        expect(response.status).toBe(201);
        expect(response.body).toMatchObject({
          success: true,
          message: 'Credential registered successfully',
          credentialsCount: 2  // Original 1 + new 1
        });
        expect(response.body.apiKeyHash).toMatch(/^[a-f0-9]{16}\*\*\*$/);
      });

      it('should reject registration with missing apiKey', async () => {
        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({
            metadata: { account: 'test' }
          });

        expect(response.status).toBe(400);
        expect(response.body).toEqual({
          error: 'Invalid request',
          message: 'apiKey is required and must be a string'
        });
      });

      it('should reject registration with non-string apiKey', async () => {
        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({
            apiKey: 12345,
            metadata: {}
          });

        expect(response.status).toBe(400);
        expect(response.body.error).toBe('Invalid request');
      });

      it('should detect duplicate API keys', async () => {
        const apiKey = 'duplicate-key';

        // Register first time
        await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({ apiKey, metadata: {} });

        // Try to register same key again
        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({ apiKey, metadata: {} });

        expect(response.status).toBe(409);
        expect(response.body).toMatchObject({
          error: 'Credential already exists',
          message: 'An API key with this hash already exists'
        });
      });

      it('should handle missing metadata gracefully', async () => {
        const response = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({
            apiKey: 'minimal-key'
          });

        expect(response.status).toBe(201);
        expect(response.body.success).toBe(true);
      });

      it('should fail for non-FileApiKeyStore', async () => {
        const appWithGeneric = express();
        appWithGeneric.use(express.json());
        appWithGeneric.use('/admin', createAdminRouter(mockGenericApiKeyStore as any));

        const response = await request(appWithGeneric)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'write-key')
          .send({
            apiKey: 'test-key',
            metadata: {}
          });

        expect(response.status).toBe(400);
        expect(response.body).toEqual({
          error: 'Unsupported credential store',
          message: 'Credential registration only supported for file-based stores'
        });
      });
    });

    describe('GET /admin/credentials/export', () => {
      beforeEach(() => {
        process.env.ADMIN_KEY_FULL_ACCESS = 'full-key';
        app.use('/admin', createAdminRouter(mockApiKeyStore));
      });

      it('should export credentials successfully with full access', async () => {
        const response = await request(app)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'full-key');

        expect(response.status).toBe(200);
        expect(response.body).toMatchObject({
          version: '1.0',
          environment: 'test',
          credentials: expect.arrayContaining([
            expect.objectContaining({
              apiKeyHash: expect.any(String),
              status: 'active'
            })
          ])
        });
      });

      it('should fail without full access permission', async () => {
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-key';

        const response = await request(app)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'write-key');

        expect(response.status).toBe(403);
      });

      it('should fail for non-FileApiKeyStore', async () => {
        const appWithGeneric = express();
        appWithGeneric.use(express.json());
        appWithGeneric.use('/admin', createAdminRouter(mockGenericApiKeyStore as any));

        const response = await request(appWithGeneric)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'full-key');

        expect(response.status).toBe(400);
        expect(response.body.error).toBe('Unsupported credential store');
      });
    });

    describe('DELETE /admin/credentials/:hash', () => {
      beforeEach(() => {
        process.env.ADMIN_KEY_FULL_ACCESS = 'full-key';
        app.use('/admin', createAdminRouter(mockApiKeyStore));
      });

      it('should mark credential as inactive', async () => {
        const hash = 'a665a45920422f9d';  // First 16 chars of test hash

        const response = await request(app)
          .delete(`/admin/credentials/${hash}`)
          .set('x-admin-key', 'full-key');

        expect(response.status).toBe(200);
        expect(response.body).toMatchObject({
          success: true,
          message: 'Credential marked as inactive'
        });

        // Verify credential was marked inactive
        const exportResponse = await request(app)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'full-key');

        const inactiveCredential = exportResponse.body.credentials.find(
          (c: any) => c.apiKeyHash.startsWith(hash)
        );
        expect(inactiveCredential.status).toBe('inactive');
        expect(inactiveCredential.deactivatedAt).toBeDefined();
      });

      it('should accept full hash', async () => {
        const fullHash = 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3';

        const response = await request(app)
          .delete(`/admin/credentials/${fullHash}`)
          .set('x-admin-key', 'full-key');

        expect(response.status).toBe(200);
      });

      it('should return 404 for non-existent hash', async () => {
        const response = await request(app)
          .delete('/admin/credentials/nonexistenthash')
          .set('x-admin-key', 'full-key');

        expect(response.status).toBe(404);
        expect(response.body).toEqual({
          error: 'Credential not found',
          message: 'No credential found with provided hash'
        });
      });

      it('should fail without full access permission', async () => {
        process.env.ADMIN_KEY_WRITE_ONLY = 'write-key';

        const response = await request(app)
          .delete('/admin/credentials/a665a45920422f9d')
          .set('x-admin-key', 'write-key');

        expect(response.status).toBe(403);
      });
    });

    describe('Backward Compatibility', () => {
      it('should work with only ADMIN_API_KEY set (legacy mode)', async () => {
        process.env.ADMIN_API_KEY = 'legacy-key';
        delete process.env.ADMIN_KEY_FULL_ACCESS;
        delete process.env.ADMIN_KEY_WRITE_ONLY;
        delete process.env.ADMIN_KEY_READ_ONLY;

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        // Should have full access with legacy key
        const healthResponse = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'legacy-key');
        expect(healthResponse.status).toBe(200);

        const exportResponse = await request(app)
          .get('/admin/credentials/export')
          .set('x-admin-key', 'legacy-key');
        expect(exportResponse.status).toBe(200);

        const registerResponse = await request(app)
          .post('/admin/credentials/register')
          .set('x-admin-key', 'legacy-key')
          .send({ apiKey: 'new-key', metadata: {} });
        expect(registerResponse.status).toBe(201);
      });

      it('should prioritize ADMIN_KEY_FULL_ACCESS over ADMIN_API_KEY', async () => {
        process.env.ADMIN_API_KEY = 'old-key';
        process.env.ADMIN_KEY_FULL_ACCESS = 'new-key';

        app.use('/admin', createAdminRouter(mockApiKeyStore));

        // Old key should still work
        const oldKeyResponse = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'old-key');
        expect(oldKeyResponse.status).toBe(200);

        // New key should also work
        const newKeyResponse = await request(app)
          .get('/admin/health')
          .set('x-admin-key', 'new-key');
        expect(newKeyResponse.status).toBe(200);
      });
    });
  });
});