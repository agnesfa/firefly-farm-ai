import type {
    ApiKeyStore,
    AppConfig,
    McpServerApp,
    PlatformAuthHandler, Prompt, Resource, RouteRegistrar,
    ServerPlugin, SessionStore, Tool
} from "@fireflyagents/mcp-server-types";
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import {FileApiKeyStore} from "../auth/index.js";
import {createSessionStoreFromEnv} from "../services/session-store-factory.js";
import {DevApiKeyStore} from "../auth/dev-key-store.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:default-app' });

export class DefaultMcpServerApp implements McpServerApp {
    private appConfig: AppConfig;
    private apiKeyStoreInstance?: ApiKeyStore;
    private pluginTools: Tool[] = [];
    private pluginPrompts: Prompt[] = [];
    private pluginResources: Resource[] = [];

    constructor(private config: AppConfig) {
        this.appConfig = config;

        // Load capabilities from plugins
        if (config.plugins?.length) {
            config.plugins.forEach((plugin: ServerPlugin) => {
                if (plugin) {
                    const tools = plugin.getTools?.();
                    if (tools && tools.length > 0) {
                        this.pluginTools.push(...tools);
                    }

                    const prompts = plugin.getPrompts?.();
                    if (prompts && prompts.length > 0) {
                        this.pluginPrompts.push(...prompts);
                    }

                    const resources = plugin.getResources?.();
                    if (resources && resources.length > 0) {
                        this.pluginResources.push(...resources);
                    }
                }
            });
        }
        logger.info('Using DefaultMcpServerApp', {
            name: config.server.name,
            version: config.server.version,
            environment: config.environment,
            authType: config.auth.type,
            port: config.server.port,
            hasCustomApiKeyStore: !!config.auth.apiKeyStore,
            hasCustomPlatformAuth: !!config.authHandlers?.length,
            hasCustomSessionStore: !!config.sessionStore
        });
    }

    getApiKeyStore(): ApiKeyStore {
        if (!this.apiKeyStoreInstance) {
            if (this.config.auth.type === 'dev') {
                this.apiKeyStoreInstance = new DevApiKeyStore();
            } else {
                this.apiKeyStoreInstance = new FileApiKeyStore({
                    credentialsPath: this.appConfig.auth.credentialsPath || '.secrets/api-keys.json',
                    watchForChanges: this.config.environment === 'development',
                    validateOnLoad: true
                });
            }
        }
        return this.apiKeyStoreInstance;
    }

    getAuthHandlers(): PlatformAuthHandler[] {
        return this.config.authHandlers || [];
    }

    getPlugins(): ServerPlugin[] {
        return this.config.plugins || [];
    }

    getPrompts(): Prompt[] {
        // Merge config prompts with plugin prompts
        return [...(this.config.prompts || []), ...this.pluginPrompts];
    }

    getResources(): Resource[] {
        // Merge config resources with plugin resources
        return [...(this.config.resources || []), ...this.pluginResources];
    }

    getRouteRegistrars(): RouteRegistrar[] {
        return this.config.routeRegistrars || [];
    }

    getSessionStore(): SessionStore {
        logger.debug('Creating session store here...')
        return createSessionStoreFromEnv();
    }

    getTools(): Tool[] {
        // Merge config tools with plugin tools
        const merged = [...(this.config.tools || []), ...this.pluginTools];
        logger.debug('getTools() called', {
            configToolCount: this.config.tools?.length || 0,
            pluginToolCount: this.pluginTools.length,
            mergedCount: merged.length,
            configToolNames: (this.config.tools || []).map(t => `${t.namespace}__${t.name}`),
            pluginToolNames: this.pluginTools.map(t => `${t.namespace}__${t.name}`)
        });
        return merged;
    }

    async healthCheck(): Promise<{ healthy: boolean; details?: any }> {
        try {
            const apiKeyHealthCheck = await this.getApiKeyStore().healthCheck();
            const sessionStore = this.getSessionStore();
            const sessionStoreHealthCheck = sessionStore?.healthCheck ?
                await sessionStore.healthCheck() :
                { healthy: true, details: 'no-health-check-available' };

            const healthy = apiKeyHealthCheck.healthy && sessionStoreHealthCheck.healthy;

            return {
                healthy,
                details: {
                    application: 'DefaultApp',
                    environment: this.config.environment,
                    server: this.config.server,
                    capabilities: {
                        tools: this.getTools().length,
                        prompts: this.getPrompts().length,
                        resources: this.getResources().length,
                        plugins: this.getPlugins().length,
                        routes: this.getRouteRegistrars().length
                    },
                    apiKeyStore: apiKeyHealthCheck.details,
                    sessionStore: sessionStoreHealthCheck.details
                }
            };
        } catch (error) {
            return {
                healthy: false,
                details: {
                    application: 'DefaultApp',
                    environment: this.config.environment,
                    error: error instanceof Error ? error.message : 'Unknown error',
                    server: this.config.server
                }
            };
        }
    }
}