import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { UnauthorizedRetryResult } from '@fireflyagents/mcp-shared-utils';
import { PlatformAuthService } from '../services/platform-auth-service.js';

const logger = baseLogger.child({ context: 'fa-mcp:core:auth-refresh-callback' });

/**
 * Minimal shape the refresh callback needs from a tool's RequestHandlerExtra.
 *
 * We deliberately don't import the MCP SDK's RequestHandlerExtra type here —
 * the callback works from any object that exposes `sessionId` (and optionally
 * a mutable `authInfo.token` so in-flight tool handlers can see the fresh
 * token). `authInfo` is typed as `unknown` to accept richer shapes (MCP
 * SDK's `AuthInfo`, our internal augmentation with `metadata`, or plain
 * objects) without forcing a tight coupling here.
 */
export interface AuthRefreshContext {
  sessionId?: string;
  authInfo?: unknown;
}

/**
 * Build an `onUnauthorized` callback for the shared HTTP client that
 * re-authenticates the current session and returns a refreshed Authorization
 * header.
 *
 * The returned function:
 * 1. Calls `PlatformAuthService.refreshSessionToken(sessionId, platform)` to
 *    invalidate any handler-internal cache, re-OAuth, and update the session
 *    store's stored token.
 * 2. Mutates `extra.authInfo.token` in place so the in-flight tool handler
 *    that holds a reference to `extra` sees the fresh token for any
 *    subsequent calls on clients it has already constructed.
 * 3. Returns `{ headers: { Authorization: "Bearer …" } }` for the axios
 *    interceptor to merge into the retried request.
 *
 * Returns `null` when refresh is not possible (no sessionId, no handler, or
 * the handler refused) — the axios client then propagates the original 401.
 *
 * Typical tool usage:
 * ```ts
 * const client = createHttpClient({
 *   baseURL,
 *   headers: { Authorization: `Bearer ${extra.authInfo.token}` },
 *   onUnauthorized: createAuthRefreshCallback(extra)
 * });
 * ```
 */
export function createAuthRefreshCallback(
  extra: AuthRefreshContext,
  platform: string = 'default'
): () => Promise<UnauthorizedRetryResult | null> {
  return async () => {
    const sessionId = extra.sessionId;
    if (!sessionId) {
      logger.debug('createAuthRefreshCallback: extra has no sessionId; cannot refresh');
      return null;
    }

    const newToken = await PlatformAuthService.refreshSessionToken(sessionId, platform);
    if (!newToken) return null;

    // Best-effort mutation of extra.authInfo.token so the in-flight handler
    // sees the fresh token if it references `extra.authInfo.token` directly
    // after this point. Typed as unknown so we widen here.
    if (extra.authInfo && typeof extra.authInfo === 'object') {
      (extra.authInfo as { token?: string }).token = newToken;
    }

    return { headers: { Authorization: `Bearer ${newToken}` } };
  };
}
