import {ApiKeyStore, ExtendedAuthContext, PlatformCredentials} from "@fireflyagents/mcp-server-types";
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";

const logger = baseLogger.child({context: 'fa-mcp:core:dev-key-store'});

// TODO: Determine if this is safe and needed or whether there is a better way to handle this

/**
 * Simple development API key store with hardcoded key
 */
export class DevApiKeyStore implements ApiKeyStore {
    async validateApiKey(apiKey: string): Promise<ExtendedAuthContext> {
        // Simple hardcoded development key
        if (apiKey === 'dev-key-12345') {
            return {
                apiKey,
                tenantId: 'dev-tenant',
                clientType: 'development',
                clientMetadata: {
                    environment: 'development',
                    keyType: 'hardcoded'
                }
            };
        }
        // Return invalid auth context for unknown keys
        throw new Error(`Invalid API key: ${apiKey}`);
    }

    async getCredentials(apiKey: string): Promise<PlatformCredentials | null> {
        if (apiKey === 'dev-key-12345') {
            return {
                credentials: {
                    type: 'development',
                    environment: 'dev'
                }
            };
        }
        return null;
    }

    async refreshToken(apiKey: string): Promise<string> {
        if (apiKey === 'dev-key-12345') {
            return 'dev-refresh-token-12345';
        }
        throw new Error(`Cannot refresh token for invalid API key: ${apiKey}`);
    }

    async storeCredentials(apiKey: string, credentials: PlatformCredentials): Promise<void> {
        // Development store doesn't persist credentials
        logger.debug('DevApiKeyStore: storeCredentials called (no-op in development)', {
            apiKey: apiKey.substring(0, 8) + '***',
            credentials: Object.keys(credentials.credentials || {})
        });
    }

    async healthCheck(): Promise<{ healthy: boolean; details?: any }> {
        return {
            healthy: true,
            details: {
                type: 'development',
                validKeys: ['dev-key-12345'],
                usage: 'Include x-api-key: dev-key-12345 in requests'
            }
        };
    }
}