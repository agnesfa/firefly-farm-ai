import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
    const actual = await importOriginal() as typeof SharedUtils;
    return {
        ...actual,
        logger: {
            ...actual.logger,
            child: vi.fn().mockReturnValue({
                info: vi.fn(),
                debug: vi.fn(),
                error: vi.fn(),
                warn: vi.fn()
            })
        }
    };
});

describe('DevApiKeyStore', () => {
    let originalNodeEnv: string | undefined;

    beforeEach(() => {
        originalNodeEnv = process.env.NODE_ENV;
        vi.resetModules();
    });

    afterEach(() => {
        if (originalNodeEnv === undefined) {
            delete process.env.NODE_ENV;
        } else {
            process.env.NODE_ENV = originalNodeEnv;
        }
    });

    describe('production gate', () => {
        it('throws when NODE_ENV is production', async () => {
            process.env.NODE_ENV = 'production';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            expect(() => new DevApiKeyStore()).toThrow('DevApiKeyStore cannot be used in production');
        });

        it('throws when NODE_ENV is staging', async () => {
            process.env.NODE_ENV = 'staging';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            expect(() => new DevApiKeyStore()).toThrow('DevApiKeyStore cannot be used in staging');
        });

        it('allows instantiation when NODE_ENV is development', async () => {
            process.env.NODE_ENV = 'development';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            expect(() => new DevApiKeyStore()).not.toThrow();
        });

        it('allows instantiation when NODE_ENV is test', async () => {
            process.env.NODE_ENV = 'test';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            expect(() => new DevApiKeyStore()).not.toThrow();
        });

        it('allows instantiation when NODE_ENV is undefined', async () => {
            delete process.env.NODE_ENV;
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            expect(() => new DevApiKeyStore()).not.toThrow();
        });
    });

    describe('validateApiKey', () => {
        it('returns auth context for valid dev key', async () => {
            process.env.NODE_ENV = 'test';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            const store = new DevApiKeyStore();
            const context = await store.validateApiKey('dev-key-12345');
            expect(context.tenantId).toBe('dev-tenant');
            expect(context.clientType).toBe('development');
        });

        it('throws for invalid key', async () => {
            process.env.NODE_ENV = 'test';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            const store = new DevApiKeyStore();
            await expect(store.validateApiKey('wrong-key')).rejects.toThrow('Invalid API key');
        });
    });

    describe('healthCheck', () => {
        it('returns healthy', async () => {
            process.env.NODE_ENV = 'test';
            const { DevApiKeyStore } = await import('./dev-key-store.js');
            const store = new DevApiKeyStore();
            const health = await store.healthCheck();
            expect(health.healthy).toBe(true);
            expect(health.details.type).toBe('development');
        });
    });
});
