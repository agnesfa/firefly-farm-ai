import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type {ExtendedAuthContext, McpServerConfig} from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:auth-extractor' });

/**
 * Extract authentication context from request headers using configured ApiKeyStore
 * Validates API key against the configured store and returns authenticated context
 */
export async function extractAuthContext(
  headers: Record<string, string | string[] | undefined>, 
  serverConfig: McpServerConfig
): Promise<ExtendedAuthContext> {
  const apiKey = headers['x-api-key'] || headers['X-API-KEY'];

  // Convert to string if it's an array
  const apiKeyStr = Array.isArray(apiKey) ? apiKey[0] : apiKey;

  if (!apiKeyStr) {
    logger.warn('No API key provided in request headers');
    throw new Error('API key is required - provide x-api-key header');
  }

  // Get the configured ApiKeyStore from the server instance
  const apiKeyStore = serverConfig.apiKeyStore
  
  if (!apiKeyStore) {
    logger.error('No ApiKeyStore configured on server - authentication cannot be validated');
    throw new Error('API key validation not configured');
  }

  try {
    logger.debug('Validating API key against configured store', { 
      apiKeyPrefix: apiKeyStr.substring(0, 8) + '***' 
    });
    
    // Use the configured ApiKeyStore to validate and get full auth context
    const authContext = await apiKeyStore.validateApiKey(apiKeyStr);
    
    logger.debug('API key validation successful', {
      apiKeyPrefix: apiKeyStr.substring(0, 8) + '***',
      tenantId: authContext.tenantId,
      clientType: authContext.clientType 
    });
    
    return authContext;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown validation error';
    logger.warn('API key validation failed', { 
      apiKeyPrefix: apiKeyStr.substring(0, 8) + '***',
      error: errorMessage 
    });
    
    // Re-throw with consistent error format
    throw new Error(`Invalid API key: ${errorMessage}`);
  }
}
