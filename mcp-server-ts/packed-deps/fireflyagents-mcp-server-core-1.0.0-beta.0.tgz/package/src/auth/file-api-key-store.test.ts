import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { resolve } from 'path';
import { FileApiKeyStore, type FileCredentialsSchema } from './file-api-key-store.js';

// Mock logger from shared-utils
vi.mock('@fireflyagents/mcp-shared-utils', async () => {
  const actual = await vi.importActual('@fireflyagents/mcp-shared-utils');
  return {
    ...actual,
    logger: {
      child: vi.fn(() => ({
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn()
      })),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn()
    }
  };
});

describe('FileApiKeyStore', () => {
  const testFilePath = resolve('./test-credentials.json');
  const validSchema: FileCredentialsSchema = {
    version: '1.0',
    environment: 'development',
    credentials: [
      {
        apiKeyHash: '4f1012550f833d619871c3adee7ab41d8e50794560c0ce872fe29110802919b2',
        status: 'active',
        createdAt: '2025-01-15T10:30:00.000Z',
        lastUsedAt: '2025-08-17T05:45:00.000Z',
        metadata: {
          platform: 'acme-inc',
          account: 'acme',
          retailer: 'store1',
          region: 'us-east-1',
          features: ['orders', 'inventory'],
          displayName: 'ACME Store 1'
        },
        platformCredentials: {
          clientId: 'client-123',
          clientSecret: 'secret-456'
        }
      },
      {
        apiKeyHash: '75a1873f8f655765c8466a3f95cdfcd769e129d272f599e876e0eed39743528d',
        status: 'active',
        createdAt: '2025-01-20T14:15:00.000Z',
        metadata: {
          platform: 'acme-inc',
          account: 'acme',
          retailer: 'store2'
        },
        platformCredentials: {
          clientId: 'client-789',
          clientSecret: 'secret-012'
        }
      }
    ]
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    if (existsSync(testFilePath)) {
      unlinkSync(testFilePath);
    }
  });

  describe('constructor', () => {
    it('creates store with valid credentials file', () => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
      
      const store = new FileApiKeyStore({
        credentialsPath: testFilePath
      });
      
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });

    it('handles missing credentials file gracefully', () => {
      const store = new FileApiKeyStore({
        credentialsPath: testFilePath
      });
      
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });

    it('throws error for invalid JSON', () => {
      writeFileSync(testFilePath, '{ invalid json }');
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('Invalid JSON in file');
    });

    it('throws error for invalid schema version', () => {
      const invalidSchema = { ...validSchema, version: '2.0' };
      writeFileSync(testFilePath, JSON.stringify(invalidSchema));
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('Invalid credentials file format');
    });
  });

  describe('validateApiKey', () => {
    beforeEach(() => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
    });

    it('validates existing API key successfully', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = await store.validateApiKey('acme-store1-dev-abc123');
      
      expect(result).toEqual({
        apiKey: 'acme-store1-dev-abc123',
        tenantId: '4f101255', // Hash-based tenantId (first 8 chars of SHA256)
        clientType: 'file-based',
        clientMetadata: {
          status: 'active',
          createdAt: '2025-01-15T10:30:00.000Z',
          lastUsedAt: expect.any(String), // Updated in-memory
          platform: 'acme-inc', // Raw metadata passed through
          account: 'acme',
          retailer: 'store1',
          region: 'us-east-1',
          features: ['orders', 'inventory'],
          displayName: 'ACME Store 1'
        },
        platformCredentials: {
          credentials: {
            clientId: 'client-123',
            clientSecret: 'secret-456'
          }
          // No platform field needed - lean and agnostic
        }
      });

      // API key validation should succeed
    });

    it('handles entries without optional metadata fields', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = await store.validateApiKey('acme-store2-dev-def456');
      
      expect(result.clientMetadata?.region).toBeUndefined(); // Not set in second entry
      expect(result.clientMetadata?.features).toBeUndefined(); // Not set in second entry
      expect(result.clientMetadata?.account).toBe('acme'); // From metadata
      expect(result.clientMetadata?.retailer).toBe('store2'); // From metadata
    });

    it('throws error for invalid API key', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      await expect(store.validateApiKey('invalid-key')).rejects.toThrow(
        'Invalid API key. Check your credentials file'
      );
    });

    it('throws error for inactive API key', async () => {
      const inactiveSchema = {
        ...validSchema,
        credentials: [{
          apiKeyHash: '5d061fea11ae0fa1feff13abe568a60bd99c61f50e6f6d8169dbe7a33336e658',
          status: 'inactive' as const,
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'acme-inc',
            account: 'test',
            retailer: 'test'
          }
        }]
      };
      writeFileSync(testFilePath, JSON.stringify(inactiveSchema));
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      await expect(store.validateApiKey('inactive-key-123')).rejects.toThrow(
        'API key is inactive. Only active keys are accepted.'
      );
    });
  });

  describe('getCredentials', () => {
    beforeEach(() => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
    });

    it('returns credentials for valid API key', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = await store.getCredentials('acme-store1-dev-abc123');
      
      expect(result).toEqual({
        credentials: {
          clientId: 'client-123',
          clientSecret: 'secret-456'
        }
        // No platform field - lean and agnostic
      });
    });

    it('returns null for invalid API key', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = await store.getCredentials('invalid-key');
      
      expect(result).toBeNull();
    });
  });

  describe('refreshToken', () => {
    it('throws not supported error', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      await expect(store.refreshToken('any-key')).rejects.toThrow(
        'Token refresh not supported by FileApiKeyStore'
      );
    });
  });

  describe('storeCredentials', () => {
    it('throws not supported error', async () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      await expect(store.storeCredentials('key', { 
        credentials: {} as any 
      })).rejects.toThrow(
        'Storing credentials not supported by FileApiKeyStore'
      );
    });
  });

  describe('healthCheck', () => {
    it('returns healthy status for valid store', async () => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = await store.healthCheck();
      
      expect(result.healthy).toBe(true);
      expect(result.details).toMatchObject({
        type: 'file-api-key-store',
        credentialsPath: testFilePath,
        fileExists: true,
        credentialsCount: 2
        // No longer provides accounts/tenants arrays - framework is metadata agnostic
      });
    });

    it('returns healthy status with auto-created empty file for missing path', async () => {
      // When file doesn't exist, constructor auto-creates an empty credentials file
      // for admin API bootstrap, so healthCheck should report healthy with 0 credentials
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });

      const result = await store.healthCheck();

      expect(result.healthy).toBe(true);
      expect(result.details).toMatchObject({
        type: 'file-api-key-store',
        fileExists: true,
        credentialsCount: 0
      });
    });
  });

  describe('getStoreInfo', () => {
    beforeEach(() => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
    });

    it('returns store information', () => {
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      const result = store.getStoreInfo();
      
      expect(result).toEqual({
        credentialsPath: testFilePath,
        credentialsCount: 2,
        entries: [
          { status: 'active', hasMetadata: true, hasPlatformCredentials: true },
          { status: 'active', hasMetadata: true, hasPlatformCredentials: true }
        ]
      });
    });
  });

  describe('reload', () => {
    it('reloads credentials from file', async () => {
      writeFileSync(testFilePath, JSON.stringify(validSchema));
      const store = new FileApiKeyStore({ credentialsPath: testFilePath });
      
      // Modify file
      const newSchema = {
        ...validSchema,
        credentials: [...validSchema.credentials, {
          apiKeyHash: '89f348b37ec85e66af30d67d2136af6fc056d88da4d86671cedd1a54a967f310',
          status: 'active',
          createdAt: '2025-08-17T10:00:00.000Z',
          metadata: {
            platform: 'acme-inc',
            account: 'acme',
            retailer: 'store3'
          },
          platformCredentials: {
            clientId: 'client-345',
            clientSecret: 'secret-678'
          }
        }]
      };
      writeFileSync(testFilePath, JSON.stringify(newSchema));
      
      await store.reload();
      
      const info = store.getStoreInfo();
      expect(info.credentialsCount).toBe(3);
    });
  });

  describe('validation', () => {
    it('validates duplicate API keys', () => {
      const invalidSchema = {
        ...validSchema,
        credentials: [
          validSchema.credentials[0],
          validSchema.credentials[0] // Duplicate
        ]
      };
      writeFileSync(testFilePath, JSON.stringify(invalidSchema));
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('Invalid credentials file format');
    });

    it('validates required fields', () => {
      const invalidSchema = {
        ...validSchema,
        credentials: [{
          apiKeyHash: '62af8704764faf8ea82fc61ce9c4c3908b6cb97d463a634e9e587d7c885db0ef',
          // Missing status and createdAt
          metadata: {
            account: 'test',
            retailer: 'store'
          }
        }]
      };
      writeFileSync(testFilePath, JSON.stringify(invalidSchema));
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('status is required and must be');
    });

    it('validates createdAt is required', () => {
      const invalidSchema = {
        ...validSchema,
        credentials: [{
          apiKeyHash: '62af8704764faf8ea82fc61ce9c4c3908b6cb97d463a634e9e587d7c885db0ef',
          status: 'active',
          // Missing createdAt
          metadata: {
            account: 'test',
            retailer: 'store'
          }
        }]
      };
      writeFileSync(testFilePath, JSON.stringify(invalidSchema));
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('createdAt is required');
    });

    it('validates status values', () => {
      const invalidSchema = {
        ...validSchema,
        credentials: [{
          apiKeyHash: '62af8704764faf8ea82fc61ce9c4c3908b6cb97d463a634e9e587d7c885db0ef',
          status: 'invalid-status', // Invalid status
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            account: 'test',
            retailer: 'store'
          }
        }]
      };
      writeFileSync(testFilePath, JSON.stringify(invalidSchema));
      
      expect(() => {
        new FileApiKeyStore({ credentialsPath: testFilePath });
      }).toThrow('status is required and must be \'active\', \'inactive\', or \'expired\'');
    });
  });
});