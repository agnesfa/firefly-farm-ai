import type { ApiKeyStore, ExtendedAuthContext, PlatformCredentials } from '@fireflyagents/mcp-server-types';
import { JsonFileReader, createValidator, CommonValidations } from '@fireflyagents/mcp-shared-utils';
import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import { createHash } from 'crypto';
import { writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

const logger = baseLogger.child({ context: 'fa-mcp:core:file-api-key-store' });

export interface FileApiKeyStoreConfig {
  credentialsPath: string;
  watchForChanges?: boolean;
  validateOnLoad?: boolean;
}

export interface FileCredentialsEntry {
  apiKeyHash: string; // SHA256 hash of the API key
  status: 'active' | 'inactive' | 'expired';
  createdAt: string; // ISO date string
  lastUsedAt?: string; // ISO date string
  metadata?: Record<string, any>; // Platform-specific data (e.g., account, retailer, region)
  platformCredentials?: Record<string, any>; // Platform-specific auth config (OAuth, API keys, JWT, etc.)
}

export interface FileCredentialsSchema {
  version: '1.0';
  environment: string;
  credentials: FileCredentialsEntry[];
}

/**
 * File-based API Key Store for development and pilot deployments
 * Uses generic file utilities from shared-utils to implement MCP-specific authentication
 * 
 * @example
 * ```typescript
 * const store = new FileApiKeyStore({
 *   credentialsPath: './secrets/credentials.json',
 *   watchForChanges: true
 * });
 * 
 * const authContext = await store.validateApiKey('acme-store1-dev-abc123');
 * ```
 */
export class FileApiKeyStore implements ApiKeyStore {
  private fileReader: JsonFileReader<FileCredentialsSchema>;
  private credentials: Map<string, FileCredentialsEntry> = new Map(); // Maps apiKeyHash to entry

  constructor(private config: FileApiKeyStoreConfig) {
    this.fileReader = new JsonFileReader({
      filePath: config.credentialsPath,
      validateOnLoad: config.validateOnLoad ?? true
    });
    
    this.loadCredentials();
    
    if (config.watchForChanges) {
      this.setupFileWatcher();
    }
  }

  async validateApiKey(apiKey: string): Promise<ExtendedAuthContext> {
    // Hash the provided API key to compare with stored hashes
    const apiKeyHash = createHash('sha256').update(apiKey).digest('hex');
    const entry = this.credentials.get(apiKeyHash);
    
    if (!entry) {
      const availableHashCount = this.credentials.size;
      
      throw new Error(
        `Invalid API key. Check your credentials file at ${this.config.credentialsPath}\n` +
        `Available credential entries: ${availableHashCount}`
      );
    }

    // Check if credential is active
    if (entry.status !== 'active') {
      throw new Error(`API key is ${entry.status}. Only active keys are accepted.`);
    }

    // Update last used timestamp (in-memory only, not persisted back to file)
    entry.lastUsedAt = new Date().toISOString();

    // Simple pass-through of file data - no interpretation by framework
    const metadata = entry.metadata || {};
    
    logger.debug('API key validated from file', { 
      apiKeyHashPrefix: apiKeyHash.substring(0, 16) + '***',
      status: entry.status,
      createdAt: entry.createdAt,
      hasMetadata: Object.keys(metadata).length > 0,
      hasPlatformCredentials: !!entry.platformCredentials
    });

    return {
      apiKey,
      tenantId: apiKeyHash.substring(0, 8), // Simple hash-based ID
      clientType: 'file-based',
      clientMetadata: {
        status: entry.status,
        createdAt: entry.createdAt,
        lastUsedAt: entry.lastUsedAt,
        ...metadata // Raw metadata from file
      },
      platformCredentials: entry.platformCredentials ? {
        credentials: entry.platformCredentials // Raw credentials from file - no platform field needed
      } : undefined
    };
  }

  async getCredentials(apiKey: string): Promise<PlatformCredentials | null> {
    // Hash the provided API key to look up the entry
    const apiKeyHash = createHash('sha256').update(apiKey).digest('hex');
    const entry = this.credentials.get(apiKeyHash);
    
    if (!entry || !entry.platformCredentials) {
      return null;
    }

    return {
      credentials: entry.platformCredentials // No platform field - just raw credentials
    };
  }

  async refreshToken(_apiKey: string): Promise<string> {
    throw new Error('Token refresh not supported by FileApiKeyStore. Use platform-based store for production token management.');
  }

  async storeCredentials(_apiKey: string, _credentials: PlatformCredentials): Promise<void> {
    throw new Error('Storing credentials not supported by FileApiKeyStore. Credentials are loaded from file only.');
  }

  async healthCheck(): Promise<{ healthy: boolean; details?: unknown }> {
    try {
      const metadata = this.fileReader.getMetadata();

      return {
        healthy: metadata.exists,  // File exists is enough - empty credentials OK for admin API bootstrap
        details: {
          type: 'file-api-key-store',
          credentialsPath: this.config.credentialsPath,
          fileExists: metadata.exists,
          credentialsCount: this.credentials.size,
          lastLoaded: metadata.lastLoaded,
          watchingForChanges: this.config.watchForChanges
        }
      };
    } catch (error) {
      return {
        healthy: false,
        details: {
          type: 'file-api-key-store',
          credentialsPath: this.config.credentialsPath,
          error: error instanceof Error ? error.message : 'Unknown error'
        }
      };
    }
  }

  /**
   * Reload credentials from file (useful after manual file changes)
   */
  async reload(): Promise<void> {
    this.fileReader.clearCache();
    this.loadCredentials();
  }

  /**
   * Get store metadata and statistics
   */
  getStoreInfo(): {
    credentialsPath: string;
    credentialsCount: number;
    entries: { status: string; hasMetadata: boolean; hasPlatformCredentials: boolean }[];
  } {
    const entries = Array.from(this.credentials.values()).map(entry => ({
      status: entry.status,
      hasMetadata: !!(entry.metadata && Object.keys(entry.metadata).length > 0),
      hasPlatformCredentials: !!entry.platformCredentials
    }));

    return {
      credentialsPath: this.config.credentialsPath,
      credentialsCount: this.credentials.size,
      entries
    };
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    this.fileReader.destroy();
    this.credentials.clear();
  }

  private loadCredentials(): void {
    try {
      if (!this.fileReader.exists()) {
        // Create empty credentials file for admin API bootstrap
        this.createEmptyCredentialsFile();
        // Reload after creating
        this.fileReader.clearCache();
      }

      const schema = this.fileReader.load();
      this.validateCredentialsSchema(schema);
      this.updateCredentialsMap(schema);

      logger.info('Credentials loaded from file', { 
        path: this.config.credentialsPath,
        count: schema.credentials.length,
        environment: schema.environment,
        entriesWithMetadata: schema.credentials.filter(c => c.metadata && Object.keys(c.metadata).length > 0).length,
        entriesWithPlatformCredentials: schema.credentials.filter(c => !!c.platformCredentials).length
      });

    } catch (error) {
      logger.error('Failed to load credentials', { 
        path: this.config.credentialsPath,
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  private validateCredentialsSchema(schema: FileCredentialsSchema): void {
    const validator = createValidator<FileCredentialsSchema>()
      .requireVersion('1.0')
      .requireField('environment', 'string')
      .requireArray('credentials', 0)  // Allow empty credentials for admin API bootstrap
      .preventDuplicates<string>('credentials', 'apiKeyHash');

    const result = validator.validate(schema);
    
    if (!result.valid) {
      throw new Error(`Invalid credentials file format:\n${result.errors.join('\n')}`);
    }

    // Validate individual credential entries
    for (const [index, entry] of schema.credentials.entries()) {
      const entryPath = `credentials[${index}]`;
      
      // Required fields
      if (!CommonValidations.nonEmptyString(entry.apiKeyHash)) {
        throw new Error(`${entryPath}: apiKeyHash is required and must be a non-empty string`);
      }
      
      // Validate SHA256 hash format (64 hex characters)
      if (!/^[a-f0-9]{64}$/i.test(entry.apiKeyHash)) {
        throw new Error(`${entryPath}: apiKeyHash must be a valid SHA256 hash (64 hex characters)`);
      }
      
      if (!entry.status || !['active', 'inactive', 'expired'].includes(entry.status)) {
        throw new Error(`${entryPath}: status is required and must be 'active', 'inactive', or 'expired'`);
      }
      
      if (!entry.createdAt || !CommonValidations.nonEmptyString(entry.createdAt)) {
        throw new Error(`${entryPath}: createdAt is required and must be a non-empty string (ISO date)`);
      }
      
      // Validate ISO date format
      try {
        new Date(entry.createdAt);
      } catch {
        throw new Error(`${entryPath}: createdAt must be a valid ISO date string`);
      }
      
      // Validate lastUsedAt if provided
      if (entry.lastUsedAt) {
        try {
          new Date(entry.lastUsedAt);
        } catch {
          throw new Error(`${entryPath}: lastUsedAt must be a valid ISO date string`);
        }
      }
      
      // Optional validation for metadata and platformCredentials
      if (entry.metadata && typeof entry.metadata !== 'object') {
        throw new Error(`${entryPath}: metadata must be an object`);
      }
      
      if (entry.platformCredentials && typeof entry.platformCredentials !== 'object') {
        throw new Error(`${entryPath}: platformCredentials must be an object`);
      }
    }

    if (result.warnings.length > 0) {
      logger.warn('Credentials file validation warnings', { 
        warnings: result.warnings
      });
    }
  }

  private updateCredentialsMap(schema: FileCredentialsSchema): void {
    this.credentials.clear();
    
    for (const entry of schema.credentials) {
      this.credentials.set(entry.apiKeyHash, entry);
    }
  }

  private createEmptyCredentialsFile(): void {
    const emptySchema: FileCredentialsSchema = {
      version: '1.0',
      environment: process.env.NODE_ENV || 'development',
      credentials: []
    };

    // Ensure directory exists
    const dir = dirname(this.config.credentialsPath);
    mkdirSync(dir, { recursive: true });

    // Write empty credentials file
    writeFileSync(
      this.config.credentialsPath,
      JSON.stringify(emptySchema, null, 2),
      'utf-8'
    );

    logger.info('Created empty credentials file for admin API bootstrap', {
      path: this.config.credentialsPath
    });
  }

  private setupFileWatcher(): void {
    this.fileReader.watch((newSchema, error) => {
      if (error) {
        logger.error('File watch error', { 
          path: this.config.credentialsPath,
          error: error.message 
        });
        return;
      }

      try {
        this.validateCredentialsSchema(newSchema);
        this.updateCredentialsMap(newSchema);
        
        logger.info('Credentials reloaded from file change', { 
          path: this.config.credentialsPath,
          count: newSchema.credentials.length 
        });
      } catch (error) {
        logger.error('Failed to reload credentials after file change', { 
          path: this.config.credentialsPath,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
  }
}