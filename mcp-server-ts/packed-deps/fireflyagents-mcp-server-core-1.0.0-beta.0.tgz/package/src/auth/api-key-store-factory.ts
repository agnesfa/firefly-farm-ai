import type { ApiKeyStore } from '@fireflyagents/mcp-server-types';
import { FileApiKeyStore, type FileApiKeyStoreConfig } from './file-api-key-store.js';

export type ApiKeyStoreType = 'file' | 'platform' | 'vault' | 'env';

export interface CreateApiKeyStoreOptions {
  type: ApiKeyStoreType;
  fileConfig?: FileApiKeyStoreConfig;
  platformConfig?: PlatformApiKeyStoreConfig;
  vaultConfig?: VaultApiKeyStoreConfig;
  envConfig?: EnvApiKeyStoreConfig;
}

// Future configuration interfaces
export interface PlatformApiKeyStoreConfig {
  apiBaseUrl: string;
  authEndpoint?: string;
  timeout?: number;
}

export interface VaultApiKeyStoreConfig {
  vaultUrl: string;
  vaultToken: string;
  secretPath: string;
}

export interface EnvApiKeyStoreConfig {
  apiKeyVariable: string;
  credentialsPrefix?: string;
}

/**
 * Factory for creating API Key Store instances
 * Provides consistent interface across different storage backends
 * 
 * @example
 * ```typescript
 * // File-based store for development
 * const store = createApiKeyStore({
 *   type: 'file',
 *   fileConfig: {
 *     credentialsPath: './config/credentials.json'
 *   }
 * });
 * 
 * // Platform store for production (future)
 * const store = createApiKeyStore({
 *   type: 'platform',
 *   platformConfig: {
 *     apiBaseUrl: 'https://platform.api.com'
 *   }
 * });
 * ```
 */
export function createApiKeyStore(options: CreateApiKeyStoreOptions): ApiKeyStore {
  switch (options.type) {
    case 'file':
      if (!options.fileConfig) {
        throw new Error('fileConfig is required when type is "file"');
      }
      return new FileApiKeyStore(options.fileConfig);
      
    case 'platform':
      if (!options.platformConfig) {
        throw new Error('platformConfig is required when type is "platform"');
      }
      // TODO: Implement PlatformApiKeyStore
      throw new Error('Platform API key store not yet implemented. Use "file" type for development.');
      
    case 'vault':
      if (!options.vaultConfig) {
        throw new Error('vaultConfig is required when type is "vault"');
      }
      // TODO: Implement VaultApiKeyStore  
      throw new Error('Vault API key store not yet implemented. Use "file" type for development.');
      
    case 'env':
      if (!options.envConfig) {
        throw new Error('envConfig is required when type is "env"');
      }
      // TODO: Implement EnvApiKeyStore
      throw new Error('Environment API key store not yet implemented. Use "file" type for development.');
      
    default:
      throw new Error(`Unsupported API key store type: ${options.type}. Supported types: file, platform, vault, env`);
  }
}

/**
 * Get recommended API key store type based on environment
 */
export function getRecommendedStoreType(environment: string): ApiKeyStoreType {
  switch (environment?.toLowerCase()) {
    case 'development':
    case 'dev':
    case 'local':
      return 'file';
      
    case 'staging':
    case 'test':
      return 'platform'; // or 'vault' depending on setup
      
    case 'production':
    case 'prod':
      return 'platform'; // or 'vault' for maximum security
      
    default:
      return 'file'; // Safe default for unknown environments
  }
}

/**
 * Create API key store with environment-based defaults
 */
export function createApiKeyStoreForEnvironment(
  environment: string,
  overrides: Partial<CreateApiKeyStoreOptions> = {}
): ApiKeyStore {
  const recommendedType = getRecommendedStoreType(environment);
  
  const defaultOptions: CreateApiKeyStoreOptions = {
    type: recommendedType,
    fileConfig: recommendedType === 'file' ? {
      credentialsPath: process.env.CREDENTIALS_PATH || './config/credentials.json',
      watchForChanges: environment === 'development',
      validateOnLoad: true
    } : undefined
  };

  const finalOptions: CreateApiKeyStoreOptions = {
    ...defaultOptions,
    ...overrides,
    // Merge nested configs properly
    fileConfig: overrides.fileConfig ? { ...defaultOptions.fileConfig, ...overrides.fileConfig } : defaultOptions.fileConfig,
    platformConfig: overrides.platformConfig ? { ...defaultOptions.platformConfig, ...overrides.platformConfig } : defaultOptions.platformConfig
  };

  return createApiKeyStore(finalOptions);
}

/**
 * Validate API key store configuration
 */
export function validateApiKeyStoreConfig(options: CreateApiKeyStoreOptions): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!options.type) {
    errors.push('type is required');
  }

  switch (options.type) {
    case 'file':
      if (!options.fileConfig) {
        errors.push('fileConfig is required for file-based store');
      } else {
        if (!options.fileConfig.credentialsPath) {
          errors.push('fileConfig.credentialsPath is required');
        }
      }
      break;

    case 'platform':
      if (!options.platformConfig) {
        errors.push('platformConfig is required for platform-based store');
      } else {
        if (!options.platformConfig.apiBaseUrl) {
          errors.push('platformConfig.apiBaseUrl is required');
        }
      }
      break;

    case 'vault':
      if (!options.vaultConfig) {
        errors.push('vaultConfig is required for vault-based store');
      } else {
        if (!options.vaultConfig.vaultUrl || !options.vaultConfig.vaultToken) {
          errors.push('vaultConfig.vaultUrl and vaultToken are required');
        }
      }
      break;

    case 'env':
      if (!options.envConfig) {
        errors.push('envConfig is required for environment-based store');
      } else {
        if (!options.envConfig.apiKeyVariable) {
          errors.push('envConfig.apiKeyVariable is required');
        }
      }
      break;

    default:
      errors.push(`Unsupported store type: ${options.type}`);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}