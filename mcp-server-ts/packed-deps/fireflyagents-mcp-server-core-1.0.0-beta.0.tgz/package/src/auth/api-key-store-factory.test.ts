import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { resolve } from 'path';
import {
  createApiKeyStore,
  getRecommendedStoreType,
  createApiKeyStoreForEnvironment,
  validateApiKeyStoreConfig,
  type CreateApiKeyStoreOptions,
  type ApiKeyStoreType
} from './api-key-store-factory.js';
import { FileApiKeyStore } from './file-api-key-store.js';

// Mock logger from shared-utils
vi.mock('@fireflyagents/mcp-shared-utils', async () => {
  const actual = await vi.importActual('@fireflyagents/mcp-shared-utils');
  return {
    ...actual,
    logger: {
      child: vi.fn(() => ({
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn()
      })),
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn()
    }
  };
});

describe('createApiKeyStore', () => {
  const testFilePath = resolve('./test-factory-credentials.json');
  const validCredentials = {
    version: '1.0',
    environment: 'development',
    credentials: [{
      apiKeyHash: '625faa3fbbc3d2bd9d6ee7678d04cc5339cb33dc68d9b58451853d60046e226a',
      status: 'active',
      createdAt: '2025-01-01T00:00:00.000Z',
      metadata: {
        platform: 'test-platform',
        account: 'test-account',
        retailer: 'test-retailer'
      },
      platformCredentials: {
        clientId: 'test-client-id',
        clientSecret: 'test-client-secret'
      }
    }]
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    if (existsSync(testFilePath)) {
      unlinkSync(testFilePath);
    }
  });

  describe('file store creation', () => {
    it('creates FileApiKeyStore successfully', () => {
      writeFileSync(testFilePath, JSON.stringify(validCredentials));

      const store = createApiKeyStore({
        type: 'file',
        fileConfig: {
          credentialsPath: testFilePath
        }
      });

      expect(store).toBeInstanceOf(FileApiKeyStore);
    });

    it('throws error when fileConfig is missing', () => {
      expect(() => {
        createApiKeyStore({
          type: 'file'
        });
      }).toThrow('fileConfig is required when type is "file"');
    });

    it('passes through file configuration options', () => {
      writeFileSync(testFilePath, JSON.stringify(validCredentials));

      const store = createApiKeyStore({
        type: 'file',
        fileConfig: {
          credentialsPath: testFilePath,
          watchForChanges: true,
          validateOnLoad: false
        }
      });

      expect(store).toBeInstanceOf(FileApiKeyStore);
    });
  });

  describe('platform store creation', () => {
    it('throws error for platform store (not implemented)', () => {
      expect(() => {
        createApiKeyStore({
          type: 'platform',
          platformConfig: {
            apiBaseUrl: 'https://platform.api.com'
          }
        });
      }).toThrow('Platform API key store not yet implemented. Use "file" type for development.');
    });

    it('throws error when platformConfig is missing', () => {
      expect(() => {
        createApiKeyStore({
          type: 'platform'
        });
      }).toThrow('platformConfig is required when type is "platform"');
    });
  });

  describe('vault store creation', () => {
    it('throws error for vault store (not implemented)', () => {
      expect(() => {
        createApiKeyStore({
          type: 'vault',
          vaultConfig: {
            vaultUrl: 'https://vault.example.com',
            vaultToken: 'vault-token-123',
            secretPath: 'secret/api-keys'
          }
        });
      }).toThrow('Vault API key store not yet implemented. Use "file" type for development.');
    });

    it('throws error when vaultConfig is missing', () => {
      expect(() => {
        createApiKeyStore({
          type: 'vault'
        });
      }).toThrow('vaultConfig is required when type is "vault"');
    });
  });

  describe('environment store creation', () => {
    it('throws error for env store (not implemented)', () => {
      expect(() => {
        createApiKeyStore({
          type: 'env',
          envConfig: {
            apiKeyVariable: 'API_KEY',
            credentialsPrefix: 'CRED_'
          }
        });
      }).toThrow('Environment API key store not yet implemented. Use "file" type for development.');
    });

    it('throws error when envConfig is missing', () => {
      expect(() => {
        createApiKeyStore({
          type: 'env'
        });
      }).toThrow('envConfig is required when type is "env"');
    });
  });

  describe('invalid store type', () => {
    it('throws error for unsupported store type', () => {
      expect(() => {
        createApiKeyStore({
          type: 'invalid-type' as ApiKeyStoreType
        });
      }).toThrow('Unsupported API key store type: invalid-type. Supported types: file, platform, vault, env');
    });
  });
});

describe('getRecommendedStoreType', () => {
  it('recommends file for development environments', () => {
    expect(getRecommendedStoreType('development')).toBe('file');
    expect(getRecommendedStoreType('dev')).toBe('file');
    expect(getRecommendedStoreType('local')).toBe('file');
    expect(getRecommendedStoreType('DEVELOPMENT')).toBe('file'); // Case insensitive
  });

  it('recommends platform for staging environments', () => {
    expect(getRecommendedStoreType('staging')).toBe('platform');
    expect(getRecommendedStoreType('test')).toBe('platform');
    expect(getRecommendedStoreType('STAGING')).toBe('platform'); // Case insensitive
  });

  it('recommends platform for production environments', () => {
    expect(getRecommendedStoreType('production')).toBe('platform');
    expect(getRecommendedStoreType('prod')).toBe('platform');
    expect(getRecommendedStoreType('PRODUCTION')).toBe('platform'); // Case insensitive
  });

  it('defaults to file for unknown environments', () => {
    expect(getRecommendedStoreType('unknown')).toBe('file');
    expect(getRecommendedStoreType('')).toBe('file');
    expect(getRecommendedStoreType('custom-env')).toBe('file');
  });

  it('handles undefined environment', () => {
    expect(getRecommendedStoreType(undefined as any)).toBe('file');
  });

  it('handles null environment', () => {
    expect(getRecommendedStoreType(null as any)).toBe('file');
  });
});

describe('createApiKeyStoreForEnvironment', () => {
  const testFilePath = resolve('./test-env-factory-credentials.json');
  
  beforeEach(() => {
    vi.clearAllMocks();
    // Clear environment variables
    delete process.env.CREDENTIALS_PATH;
  });

  afterEach(() => {
    if (existsSync(testFilePath)) {
      unlinkSync(testFilePath);
    }
    delete process.env.CREDENTIALS_PATH;
  });

  describe('development environment defaults', () => {
    it('creates file store with development defaults', () => {
      const configPath = './config/credentials.json';
      
      // Create directory if it doesn't exist
      const fs = require('fs');
      if (!fs.existsSync('./config')) {
        fs.mkdirSync('./config', { recursive: true });
      }
      
      writeFileSync(configPath, JSON.stringify({
        version: '1.0',
        environment: 'development',
        credentials: [{
          apiKeyHash: '0f11c9ecaecabe613512ae472855ae9cb7d9639bc8c3fe85e0357efbf4739cd4',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'dev-platform',
            account: 'dev-account',
            retailer: 'dev-retailer'
          },
          platformCredentials: {
            clientId: 'dev-client-id',
            clientSecret: 'dev-client-secret'
          }
        }]
      }));

      try {
        const store = createApiKeyStoreForEnvironment('development');
        expect(store).toBeInstanceOf(FileApiKeyStore);
      } finally {
        if (existsSync(configPath)) {
          unlinkSync(configPath);
        }
        if (fs.existsSync('./config')) {
          fs.rmSync('./config', { recursive: true, force: true });
        }
      }
    });

    it('uses CREDENTIALS_PATH environment variable when set', () => {
      process.env.CREDENTIALS_PATH = testFilePath;
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'development',
        credentials: [{
          apiKeyHash: '21faea14ff4fc5e691092b9577b94dac5ce0a150e36c9d4a1f669dcc0f7a8274',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'env-platform',
            account: 'env-account',
            retailer: 'env-retailer'
          },
          platformCredentials: {
            clientId: 'env-client-id',
            clientSecret: 'env-client-secret'
          }
        }]
      }));

      const store = createApiKeyStoreForEnvironment('development');
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });

    it('enables file watching for development environment', () => {
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'development',
        credentials: [{
          apiKeyHash: '3e078f9f7305e658835368f2d287beeadd6c4c8ddedd15bdf4df20862e50e16d',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'watch-platform',
            account: 'watch-account',
            retailer: 'watch-retailer'
          },
          platformCredentials: {
            clientId: 'watch-client-id',
            clientSecret: 'watch-client-secret'
          }
        }]
      }));

      // We can't directly test the internal config, but we can verify it creates successfully
      const store = createApiKeyStoreForEnvironment('development', {
        fileConfig: { credentialsPath: testFilePath }
      });
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });
  });

  describe('production environment defaults', () => {
    it('attempts platform store for production (should fail - config required)', () => {
      expect(() => {
        createApiKeyStoreForEnvironment('production');
      }).toThrow('platformConfig is required when type is "platform"');
    });

    it('can override to use file store for production', () => {
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'production',
        credentials: [{
          apiKeyHash: '02912e69cdf597e4ccde73ed2dfcc4203444c4fb8b4feed88cc8332335de2f7f',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'prod-platform',
            account: 'prod-account',
            retailer: 'prod-retailer'
          },
          platformCredentials: {
            clientId: 'prod-client-id',
            clientSecret: 'prod-client-secret'
          }
        }]
      }));

      const store = createApiKeyStoreForEnvironment('production', {
        type: 'file',
        fileConfig: { credentialsPath: testFilePath }
      });
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });
  });

  describe('configuration overrides', () => {
    it('merges file configuration overrides', () => {
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'development',
        credentials: [{
          apiKeyHash: '45ced5967288318d059271e623af4f5388535001ab03fc63ad1d76dbba7ee8d7',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'merge-platform',
            account: 'merge-account',
            retailer: 'merge-retailer'
          },
          platformCredentials: {
            clientId: 'merge-client-id',
            clientSecret: 'merge-client-secret'
          }
        }]
      }));

      const store = createApiKeyStoreForEnvironment('development', {
        fileConfig: {
          credentialsPath: testFilePath,
          watchForChanges: false // Override default
        }
      });

      expect(store).toBeInstanceOf(FileApiKeyStore);
    });

    it('allows complete type override', () => {
      expect(() => {
        createApiKeyStoreForEnvironment('development', {
          type: 'platform',
          platformConfig: {
            apiBaseUrl: 'https://override.com'
          }
        });
      }).toThrow('Platform API key store not yet implemented');
    });

    it('handles partial configuration merging', () => {
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'development', 
        credentials: [{
          apiKeyHash: '95ec4d86a3a655abda64c30f1dc620122872d2048b273c35112e65c872a92cd4',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'partial-platform',
            account: 'partial-account',
            retailer: 'partial-retailer'
          },
          platformCredentials: {
            clientId: 'partial-client-id',
            clientSecret: 'partial-client-secret'
          }
        }]
      }));

      // Should merge with defaults properly
      const store = createApiKeyStoreForEnvironment('development', {
        fileConfig: { credentialsPath: testFilePath }
      });
      
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });
  });

  describe('environment variations', () => {
    it('handles case-insensitive environments', () => {
      expect(() => {
        createApiKeyStoreForEnvironment('DEVELOPMENT', {
          type: 'platform',
          platformConfig: { apiBaseUrl: 'test' }
        });
      }).toThrow('Platform API key store not yet implemented'); // Would use platform recommendation
    });

    it('handles unknown environments with file fallback', () => {
      writeFileSync(testFilePath, JSON.stringify({
        version: '1.0',
        environment: 'custom',
        credentials: [{
          apiKeyHash: '81c7bf6efc18d290bac44b5f30e82e97540c7b58977aa80234a44ee26cf65a4a',
          status: 'active',
          createdAt: '2025-01-01T00:00:00.000Z',
          metadata: {
            platform: 'custom-platform',
            account: 'custom-account',
            retailer: 'custom-retailer'
          },
          platformCredentials: {
            clientId: 'custom-client-id',
            clientSecret: 'custom-client-secret'
          }
        }]
      }));

      const store = createApiKeyStoreForEnvironment('custom-environment', {
        fileConfig: { credentialsPath: testFilePath }
      });
      
      expect(store).toBeInstanceOf(FileApiKeyStore);
    });
  });
});

describe('validateApiKeyStoreConfig', () => {
  describe('basic validation', () => {
    it('validates successful file configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file',
        fileConfig: {
          credentialsPath: './test-path.json'
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('fails when type is missing', () => {
      const result = validateApiKeyStoreConfig({} as CreateApiKeyStoreOptions);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('type is required');
    });

    it('fails for unsupported store type', () => {
      const result = validateApiKeyStoreConfig({
        type: 'invalid-type' as ApiKeyStoreType
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Unsupported store type: invalid-type');
    });
  });

  describe('file store validation', () => {
    it('fails when fileConfig is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('fileConfig is required for file-based store');
    });

    it('fails when credentialsPath is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file',
        fileConfig: {} as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('fileConfig.credentialsPath is required');
    });

    it('validates complete file configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file',
        fileConfig: {
          credentialsPath: './credentials.json',
          watchForChanges: true,
          validateOnLoad: false
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe('platform store validation', () => {
    it('fails when platformConfig is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'platform'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('platformConfig is required for platform-based store');
    });

    it('fails when apiBaseUrl is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'platform',
        platformConfig: {} as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('platformConfig.apiBaseUrl is required');
    });

    it('validates complete platform configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'platform',
        platformConfig: {
          apiBaseUrl: 'https://api.platform.com',
          authEndpoint: '/auth',
          timeout: 5000
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe('vault store validation', () => {
    it('fails when vaultConfig is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'vault'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('vaultConfig is required for vault-based store');
    });

    it('fails when vault credentials are incomplete', () => {
      const resultMissingUrl = validateApiKeyStoreConfig({
        type: 'vault',
        vaultConfig: {
          vaultToken: 'token-123',
          secretPath: 'secret/path'
        } as any
      });

      expect(resultMissingUrl.valid).toBe(false);
      expect(resultMissingUrl.errors).toContain('vaultConfig.vaultUrl and vaultToken are required');

      const resultMissingToken = validateApiKeyStoreConfig({
        type: 'vault',
        vaultConfig: {
          vaultUrl: 'https://vault.example.com',
          secretPath: 'secret/path'
        } as any
      });

      expect(resultMissingToken.valid).toBe(false);
      expect(resultMissingToken.errors).toContain('vaultConfig.vaultUrl and vaultToken are required');
    });

    it('validates complete vault configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'vault',
        vaultConfig: {
          vaultUrl: 'https://vault.example.com',
          vaultToken: 'vault-token-123',
          secretPath: 'secret/api-keys'
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe('environment store validation', () => {
    it('fails when envConfig is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'env'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('envConfig is required for environment-based store');
    });

    it('fails when apiKeyVariable is missing', () => {
      const result = validateApiKeyStoreConfig({
        type: 'env',
        envConfig: {} as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('envConfig.apiKeyVariable is required');
    });

    it('validates complete environment configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'env',
        envConfig: {
          apiKeyVariable: 'API_KEY',
          credentialsPrefix: 'CRED_'
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('validates minimal environment configuration', () => {
      const result = validateApiKeyStoreConfig({
        type: 'env',
        envConfig: {
          apiKeyVariable: 'MY_API_KEY'
        }
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe('multiple validation errors', () => {
    it('accumulates multiple errors', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file',
        fileConfig: {} as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('fileConfig.credentialsPath is required');
    });

    it('provides detailed error information', () => {
      const result = validateApiKeyStoreConfig({
        type: 'vault',
        vaultConfig: {
          secretPath: 'secret/path'
        } as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]).toContain('vaultUrl and vaultToken are required');
    });
  });

  describe('edge cases', () => {
    it('handles null configurations gracefully', () => {
      const result = validateApiKeyStoreConfig({
        type: 'file',
        fileConfig: null as any
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('fileConfig is required for file-based store');
    });

    it('handles undefined configurations gracefully', () => {
      const result = validateApiKeyStoreConfig({
        type: 'platform',
        platformConfig: undefined
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('platformConfig is required for platform-based store');
    });
  });
});