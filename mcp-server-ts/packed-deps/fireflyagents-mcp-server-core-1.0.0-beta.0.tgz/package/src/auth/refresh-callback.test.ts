import { describe, it, expect, vi, beforeEach } from 'vitest';
import type * as SharedUtils from '@fireflyagents/mcp-shared-utils';

const mockLogger = {
  info: vi.fn(),
  debug: vi.fn(),
  error: vi.fn(),
  warn: vi.fn()
};

vi.mock('@fireflyagents/mcp-shared-utils', async (importOriginal) => {
  const actual = (await importOriginal()) as typeof SharedUtils;
  return {
    ...actual,
    logger: {
      ...actual.logger,
      child: vi.fn().mockReturnValue(mockLogger)
    }
  };
});

const mockRefreshSessionToken = vi.fn();

vi.mock('../services/platform-auth-service.js', () => ({
  PlatformAuthService: {
    refreshSessionToken: mockRefreshSessionToken
  }
}));

const { createAuthRefreshCallback } = await import('./refresh-callback.js');

describe('createAuthRefreshCallback', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns null when extra has no sessionId', async () => {
    const extra = { authInfo: { token: 'stale' } };
    const callback = createAuthRefreshCallback(extra);

    const result = await callback();

    expect(result).toBeNull();
    expect(mockRefreshSessionToken).not.toHaveBeenCalled();
  });

  it('returns null when PlatformAuthService.refreshSessionToken returns null', async () => {
    mockRefreshSessionToken.mockResolvedValueOnce(null);
    const extra = { sessionId: 'sess-1', authInfo: { token: 'stale' } };
    const callback = createAuthRefreshCallback(extra);

    const result = await callback();

    expect(mockRefreshSessionToken).toHaveBeenCalledWith('sess-1', 'default');
    expect(result).toBeNull();
  });

  it('returns fresh Authorization header on successful refresh', async () => {
    mockRefreshSessionToken.mockResolvedValueOnce('brand-new-token');
    const extra = { sessionId: 'sess-1', authInfo: { token: 'stale' } };
    const callback = createAuthRefreshCallback(extra);

    const result = await callback();

    expect(result).toEqual({ headers: { Authorization: 'Bearer brand-new-token' } });
  });

  it('mutates extra.authInfo.token so in-flight handlers see the fresh token', async () => {
    mockRefreshSessionToken.mockResolvedValueOnce('brand-new-token');
    const extra: { sessionId: string; authInfo: { token: string } } = {
      sessionId: 'sess-1',
      authInfo: { token: 'stale' }
    };
    const callback = createAuthRefreshCallback(extra);

    await callback();

    expect(extra.authInfo.token).toBe('brand-new-token');
  });

  it('passes the platform argument through to the service', async () => {
    mockRefreshSessionToken.mockResolvedValueOnce('tok');
    const extra = { sessionId: 'sess-1', authInfo: { token: 'stale' } };
    const callback = createAuthRefreshCallback(extra, 'fluent-commerce');

    await callback();

    expect(mockRefreshSessionToken).toHaveBeenCalledWith('sess-1', 'fluent-commerce');
  });

  it('does not throw when extra has no authInfo to mutate', async () => {
    mockRefreshSessionToken.mockResolvedValueOnce('tok');
    const extra = { sessionId: 'sess-1' };
    const callback = createAuthRefreshCallback(extra);

    await expect(callback()).resolves.toEqual({
      headers: { Authorization: 'Bearer tok' }
    });
  });
});
