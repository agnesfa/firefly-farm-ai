import { describe, it, expect, vi } from 'vitest';
import { helloWorldPrompt } from './hello-world-prompt.js';

describe('registerHelloWorldPrompt', () => {
  it('should handle prompt execution with topic parameter', async () => {
    const result = await helloWorldPrompt.handler({topic: 'testing'}, null);

    expect(result).toEqual({
      description: 'Hello world prompt about testing',
      messages: [
        {
          role: 'user',
          content: {
            type: 'text',
            text: 'Please help me with testing. Start with a friendly greeting and provide helpful assistance.'
          }
        }
      ]
    });
  });

  it('should handle prompt execution without topic parameter', async () => {
    const result = await helloWorldPrompt.handler({}, null);

    expect(result).toEqual({
      description: 'Hello world prompt about general topics',
      messages: [
        {
          role: 'user',
          content: {
            type: 'text',
            text: 'Please help me with whatever I need. Start with a friendly greeting and provide helpful assistance.'
          }
        }
      ]
    });
  });

  it('should handle errors gracefully during prompt execution', async () => {
    // Mock logger to throw an error
    const spy = vi.spyOn(Date, 'now').mockImplementation(() => {
      throw new Error('Date.now error');
    });

    // Should throw the error
    await expect(helloWorldPrompt.handler({ topic: 'test' }, null)).rejects.toThrow('Date.now error');

    spy.mockRestore();
  });

  it('should handle different topic values', async () => {
    const result1 = await helloWorldPrompt.handler({topic: ''}, null);
    expect(result1.description).toBe('Hello world prompt about general topics');
    const content1 = result1.messages[0].content as { type: 'text'; text: string };
    expect(content1.text).toBe('Please help me with whatever I need. Start with a friendly greeting and provide helpful assistance.');

    // Test with specific topic
    const result2 = await helloWorldPrompt.handler({topic: 'programming'}, null);
    expect(result2.description).toBe('Hello world prompt about programming');
    const content2 = result2.messages[0].content as { type: 'text'; text: string };
    expect(content2.text).toBe('Please help me with programming. Start with a friendly greeting and provide helpful assistance.');
  });
});