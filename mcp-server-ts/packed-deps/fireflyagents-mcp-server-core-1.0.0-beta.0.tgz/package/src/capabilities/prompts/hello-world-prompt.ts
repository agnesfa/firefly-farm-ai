import { z, type Prompt } from "@fireflyagents/mcp-server-types";
import { logger as baseLogger } from "@fireflyagents/mcp-shared-utils";

const logger = baseLogger.child({ context: 'fa-mcp:core:hello-world-prompt' });

const argsSchema = z.object({
  topic: z.string().describe("Topic to create prompt for").optional(),
});

/**
 * Hello World prompt - Framework demonstration prompt
 * Shows basic prompt structure and logging patterns
 */
export const helloWorldPrompt: Prompt = {
  namespace: 'fa',
  name: 'hello_prompt',
  title: 'Framework Hello World Prompt',
  description: 'Generate a hello world prompt',
  paramsSchema: argsSchema.shape,
  handler: async ({ topic }) => {
    const startTime = Date.now();
    logger.info('Prompt execution started', {
      prompt: 'fa/hello_prompt',
      parameters: { topic }
    });

    try {
      const result = {
        description: `Hello world prompt about ${topic || 'general topics'}`,
        messages: [
          {
            role: "user" as const,
            content: {
              type: "text" as const,
              text: `Please help me with ${topic || 'whatever I need'}. Start with a friendly greeting and provide helpful assistance.`
            }
          }
        ]
      };

      logger.info('Prompt execution completed', {
        prompt: 'fa/hello_prompt',
        duration: Date.now() - startTime,
        success: true
      });

      return result;
    } catch (error) {
      logger.error('Prompt execution failed', {
        prompt: 'fa/hello_prompt',
        error: error instanceof Error ? error.message : 'Unknown error',
        duration: Date.now() - startTime
      });
      throw error;
    }
  },
};
