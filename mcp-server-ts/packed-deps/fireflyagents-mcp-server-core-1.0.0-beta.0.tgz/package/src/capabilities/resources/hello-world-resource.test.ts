import { describe, it, expect, vi } from 'vitest';
import { helloWorldResource } from './hello-world-resource.js';

describe('registerHelloWorldResource', () => {
  it('should handle resource read successfully', async () => {
    const mockUri = new URL('fa://hello-world');
    const result = await helloWorldResource.handler(mockUri, null);

    expect(result).toEqual({
      contents: [
        {
          uri: 'fa://hello-world',
          mimeType: 'text/plain',
          text: expect.stringContaining('Hello World MCP Server Resource')
        }
      ]
    });

    const textContent = result.contents[0] as { uri: string; text: string; mimeType?: string };
    expect(textContent.text).toContain('Hello World MCP Server Resource');
    expect(textContent.text).toContain('This is a demonstration resource');
    expect(textContent.text).toContain('URI: fa://hello-world');
    expect(textContent.text).toContain('Server: Firefly Agents MCP Server Framework');
    expect(textContent.text).toContain('Static resource registration');
    expect(textContent.text).toContain('Text content delivery');
    expect(textContent.text).toContain('Proper logging and error handling');
    expect(textContent.text).toContain('Framework integration patterns');
  });

  it('should include current timestamp in resource content', async () => {
    const mockUri = new URL('fa://hello-world');
    // const utcTimestampRegex = /^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2]\d|3[0-1])T(?:[0-1]\d|2[0-3]):[0-5]\d:[0-5]\dZ$/

    const result = await helloWorldResource.handler(mockUri, null);
    const textContent = result.contents[0] as { uri: string; text: string; mimeType?: string };
    expect(textContent.text).toContain('Timestamp: ');
  });

  it('should handle errors during resource reading', async () => {
    // Mock Date to throw an error
    const spy = vi.spyOn(global, 'Date').mockImplementation(() => {
      throw new Error('Date construction failed');
    });

    const mockUri = new URL('fa://hello-world');
    // Should throw the error
    await expect(helloWorldResource.handler(mockUri, null)).rejects.toThrow('Date construction failed');

    spy.mockRestore();
  });

  it('should include comprehensive resource information', async () => {
    const mockUri = new URL('fa://hello-world');

    const result = await helloWorldResource.handler(mockUri, null);
    const textContent = result.contents[0] as { uri: string; text: string; mimeType?: string };

    // Check that all expected sections are present
    expect(textContent.text).toContain('This resource demonstrates:');
    expect(textContent.text).toContain('You can use this resource to:');
    expect(textContent.text).toContain('Understand MCP resource capabilities');
    expect(textContent.text).toContain('Test resource reading functionality');
    expect(textContent.text).toContain('Learn about the framework architecture');
    expect(textContent.text).toContain('Build your own application-specific resources');
  });

  it('should return proper content structure', async () => {
    const mockUri = new URL('fa://hello-world');

    const result = await helloWorldResource.handler(mockUri, null);

    // Verify the structure matches expected format
    expect(result).toHaveProperty('contents');
    expect(Array.isArray(result.contents)).toBe(true);
    expect(result.contents).toHaveLength(1);

    const textContent = result.contents[0] as { uri: string; text: string; mimeType?: string };
    expect(textContent).toHaveProperty('uri');
    expect(textContent).toHaveProperty('mimeType', 'text/plain');
    expect(textContent).toHaveProperty('text');
    expect(typeof textContent.text).toBe('string');
    expect(textContent.text.length).toBeGreaterThan(100); // Should be substantial content
  });
});