import { type Resource } from "@fireflyagents/mcp-server-types";
import { logger as baseLogger } from "@fireflyagents/mcp-shared-utils";

const logger = baseLogger.child({ context: 'fa-mcp:core:hello-world-resource' });

/**
 * Hello World resource - Framework demonstration resource
 * Shows basic resource structure and logging patterns
 */
export const helloWorldResource: Resource = {
  namespace: 'fa',
  name: 'hello_world_info',
  title: 'Framework Hello World Resource',
  description: 'Basic information about this demo MCP server',
  uriTemplate: 'demo://hello-world',
  options: {
    mimeType: 'text/plain'
  },
  handler: async (uri) => {
    const startTime = Date.now();
    logger.info('Resource read started', {
      resource: 'fa/hello_world_info',
      uri: uri.toString()
    });

    try {
      const content = `Hello World MCP Server Resource

This is a demonstration resource provided by the MCP server framework.

URI: ${uri.toString()}
Timestamp: ${new Date().toISOString()}
Server: Firefly Agents MCP Server Framework

This resource demonstrates:
- Static resource registration
- Text content delivery
- Proper logging and error handling
- Framework integration patterns

You can use this resource to:
- Understand MCP resource capabilities
- Test resource reading functionality
- Learn about the framework architecture
- Build your own application-specific resources`;

      const result = {
        contents: [
          {
            uri: uri.toString(),
            mimeType: 'text/plain',
            text: content
          }
        ]
      };

      logger.info('Resource read completed', {
        resource: 'fa/hello_world_info',
        duration: Date.now() - startTime,
        success: true
      });

      return result;
    } catch (error) {
      logger.error('Resource read failed', {
        resource: 'fa/hello_world_info',
        error: error instanceof Error ? error.message : 'Unknown error',
        duration: Date.now() - startTime
      });
      throw error;
    }
  },
};
