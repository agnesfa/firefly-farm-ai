import { z, type Tool } from "@fireflyagents/mcp-server-types";
import { logger as baseLogger } from "@fireflyagents/mcp-shared-utils";

const logger = baseLogger.child({ context: 'fa-mcp:core:hello-world-tool' });

export const inputSchema = z.object({
  name: z.string().describe("Name to greet").optional(),
});

/**
 * Hello World tool - Framework demonstration tool
 * Shows basic tool structure and logging patterns
 */
export const helloWorldTool: Tool = {
  namespace: 'fa',
  name: 'hello_world',
  title: 'Framework Hello World Tool',
  description: 'Logs a hello message and returns a greeting.',
  paramsSchema: inputSchema.shape,
  options: {
    readOnlyHint: true,
  },
  handler: async ({ name }) => {
    const startTime = Date.now();
    logger.info('Tool execution started', { tool: 'fa/hello_world', parameters: { name } });

    try {
      const result = {
        content: [
          {
            type: "text" as const,
            text: `👋 Hello, ${name ?? "world"}! Timestamp: ${new Date().toISOString()}`
          }
        ]
      };

      logger.info('Tool execution completed', {
        tool: 'fa/hello_world',
        duration: Date.now() - startTime,
        success: true
      });

      return result;
    } catch (error) {
      logger.error('Tool execution failed', {
        tool: 'fa/hello_world',
        error: error instanceof Error ? error.message : 'Unknown error',
        duration: Date.now() - startTime
      });
      throw error;
    }
  },
};
