import { describe, it, expect, vi, beforeEach } from 'vitest';
import { helloWorldTool } from './hello-world.js';

describe('Hello World Tool', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('registerHelloWorldTool', () => {

    it('should handle tool execution with name parameter', async () => {

      const result = await helloWorldTool.handler({ name: 'Alice' }, null);

      expect(result).toEqual({
        content: [
          {
            type: 'text',
            text: expect.stringContaining('👋 Hello, Alice!')
          }
        ]
      });
      const textContent = result.content[0] as { type: 'text'; text: string };
      expect(textContent.text).toMatch(/Timestamp: \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z/);
    });

    it('should handle tool execution without name parameter', async () => {
      const result = await helloWorldTool.handler({}, null);

      expect(result).toEqual({
        content: [
          {
            type: 'text',
            text: expect.stringContaining('👋 Hello, world!')
          }
        ]
      });
      const textContent = result.content[0] as { type: 'text'; text: string };
      expect(textContent.text).toMatch(/Timestamp: \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z/);
    });

    it('should handle tool execution with undefined name', async () => {
      const result = await helloWorldTool.handler({ name: undefined }, null);

      expect(result).toEqual({
        content: [
          {
            type: 'text',
            text: expect.stringContaining('👋 Hello, world!')
          }
        ]
      });
    });

    it('should handle tool execution with null name', async () => {
      const result = await helloWorldTool.handler({ name: null }, null);

      expect(result).toEqual({
        content: [
          {
            type: 'text',
            text: expect.stringContaining('👋 Hello, world!')
          }
        ]
      });
    });

    it('should handle errors in tool execution and log them properly', async () => {
      // Mock Date.now to throw an error for testing error path
      const originalNow = Date.now;
      Date.now = vi.fn().mockImplementationOnce(() => 1000).mockImplementationOnce(() => {
        throw new Error('Date.now failed');
      });

      await expect(helloWorldTool.handler({ name: 'Test' }, null)).rejects.toThrow('Date.now failed');

      // Restore Date.now
      Date.now = originalNow;
    });
  });
});