/**
 * Handles Legacy SSE GET requests
 */
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import type {ExtendedAuthContext, McpServerConfig} from "@fireflyagents/mcp-server-types";
import {SSEServerTransport} from "@modelcontextprotocol/sdk/server/sse.js";
import {getUnifiedSessionStore} from "../services/unified-session-store.js";
import type {Request, Response} from "express";
import {PlatformAuthService} from "../services/platform-auth-service.js";
import {RequestContext} from "@fireflyagents/mcp-server-types";

const logger = baseLogger.child({ context: 'fa-mcp:core:sse-get-handler'})

export function handleLegacySseGet(mcpServerConfig: McpServerConfig) {

    return async (requestContext: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext): Promise<void> => {
        let sessionId: string | null = null;

        logger.debug('Legacy SSE GET request received', { reqHeaders: req.headers, reqBody: req.body });

        const unifiedStore = getUnifiedSessionStore();

        try {
            const tenantId = authContext.tenantId || 'default';

            // Create a new SSE transport for the client
            // The endpoint for POST messages is '/messages'
            const transport = new SSEServerTransport('mcp/messages', res);

            // Set up onclose handler to clean up transport when closed
            transport.onclose = async () => {
                if (sessionId) {
                    logger.http(`SSE transport closed for session ${sessionId}`);
                    await unifiedStore.removeSession(sessionId);
                }
            };

            // Use the transport's generated session ID
            sessionId = transport.sessionId;

            const sessionLogger = requestContext.requestLogger.child({ sessionId });

            sessionLogger.debug('Creating new Legacy SSE session', {
                newSession: true,
                transportType: 'SSE'
            });

            // Create session with server instance - all in one place
            const server = await unifiedStore.createSession(
                sessionId,
                transport,
                authContext
            );

            // Connect the transport to the MCP server
            await server.connect(transport);

            // Perform OAuth authentication if platform credentials exist
            await PlatformAuthService.authenticateOnSessionCreation(sessionId, authContext, mcpServerConfig);

            // Log connection established
            sessionLogger.http('SSE connection established', {
                tenantId,
                sessionId,
                setupDuration: Date.now() - requestContext.startTime
            });

            req.on('close', async () => {
                if (sessionId) {
                    sessionLogger.http('SSE client disconnected', {
                        reason: 'client-close',
                        duration: Date.now() - requestContext.startTime
                    });
                    await unifiedStore.removeSession(sessionId);
                }
            });

            // Also handle response finish event as backup
            res.on('finish', async () => {
                if (sessionId) {
                    sessionLogger.http('SSE response finished', {
                        reason: 'response-finish',
                        duration: Date.now() - requestContext.startTime
                    });
                    await unifiedStore.removeSession(sessionId);
                }
            });

        } catch (error) {
            // Clean up session if created
            if (sessionId) {
                await unifiedStore.removeSession(sessionId);
            }

            // Let the error bubble up to the global error handler:
            throw error;
        }
    }

}
