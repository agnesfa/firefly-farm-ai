import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import {handleStreamableGet} from './streamable-get-handler.js';
import type {Request, Response} from 'express';
import type {ExtendedAuthContext} from '@fireflyagents/mcp-server-types';
import type {RequestContext} from '@fireflyagents/mcp-server-types';

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});

vi.mock('../services/unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn()
}));

vi.mock('@modelcontextprotocol/sdk/server/streamableHttp.js', () => {
    const mockConstructor = vi.fn().mockImplementation(() => {
        return {
            sessionId: 'mock-session-id',
            handleRequest: vi.fn().mockResolvedValue(undefined),
        } as any;
    });

    return {
        StreamableHTTPServerTransport: mockConstructor,
    };
});

vi.mock('../utils/request-helpers.js', () => ({
    injectAuthContext: vi.fn(),
}));

describe('handleStreamableGet', () => {
    let mockStore: any;
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockRequestContext: RequestContext;
    let mockAuthContext: ExtendedAuthContext;

    beforeEach(async () => {
        vi.clearAllMocks();

        // Initialize mockStore
        mockStore = {
            isValidSession: vi.fn().mockReturnValue(true),
            hasSession: vi.fn().mockResolvedValue(true),
            getTransport: vi.fn().mockResolvedValue({
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'test-session-id',
            }),
            createSession: vi.fn().mockResolvedValue({ connect: vi.fn() }),
            removeSession: vi.fn().mockResolvedValue(true),
            getSession: vi.fn().mockResolvedValue({
                tenantId: 'test-tenant',
                authContext: {
                    clientMetadata: {
                        accountId: 'test-account',
                        retailerId: 'test-retailer',
                    },
                },
            }),
        };
        const {getUnifiedSessionStore} = await import('../services/unified-session-store.js');
        (getUnifiedSessionStore as any).mockReturnValue(mockStore);

        // Mock request context
        mockRequestContext = {
            requestId: 'test-request-id',
            startTime: Date.now() - 100,
            sessionId: 'test-session-id',
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
                child: vi.fn().mockReturnValue({
                    debug: vi.fn(),
                    info: vi.fn(),
                    warn: vi.fn(),
                    error: vi.fn(),
                    http: vi.fn(),
                }),
            },
        };

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Mock request
        mockReq = {
            headers: {
                'content-type': 'application/json',
                'content-length': '100',
                accept: 'application/json',
                origin: 'test-origin',
                'mcp-session-id': 'existing-session-id',
            },
            body: {
                jsonrpc: '2.0',
                method: 'tools/list',
                id: 1,
            },
            ip: '127.0.0.1',
        };

        // Mock response
        mockRes = {
            status: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
        };
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('Valid session handling', () => {
        it('should handle valid session requests successfully', async () => {
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session validation
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');
            expect(mockStore.getTransport).toHaveBeenCalledWith('existing-session-id');

            // Verify auth context injection
            expect(injectAuthContext).toHaveBeenCalledWith(
                'existing-session-id',
                mockReq,
                mockAuthContext,
                expect.any(Object)
            );

            // Verify request handled by transport
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes);

            // Verify logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                {
                    contentType: 'application/json',
                    contentLength: '100',
                    accept: 'application/json',
                    clientIp: '127.0.0.1',
                    origin: 'test-origin',
                    sessionIdHeader: 'existing-session-id',
                    mcpMethod: 'tools/list',
                }
            );
        });

        it('should create session logger with session ID', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session logger creation
            expect(mockRequestContext.requestLogger.child).toHaveBeenCalledWith({
                sessionId: 'existing-session-id',
            });
        });

        it('should log auth context injection success', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            const mockSessionLogger = {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            };

            mockRequestContext.requestLogger.child = vi.fn().mockReturnValue(mockSessionLogger);
            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify auth context injection logging
            expect(mockSessionLogger.debug).toHaveBeenCalledWith(
                'Auth context injected into request',
                { reqAuth: (mockReq as any).auth }
            );
        });

        it('should handle default tenant ID when not provided', async () => {

            const authContextWithoutTenant = {
                ...mockAuthContext,
                tenantId: undefined,
            };

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, authContextWithoutTenant);

            // Should use 'default' as tenant ID
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'default');
        });
    });

    describe('Invalid session handling', () => {
        it('should reject requests with missing session ID', async () => {
            mockReq.headers!['mcp-session-id'] = undefined;

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify error response
            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32000,
                    message: 'Bad Request: Missing session ID',
                },
            });

            // Verify error logging
            expect(mockRequestContext.requestLogger.error).toHaveBeenCalledWith(
                'Missing session ID',
                { sessionId: undefined }
            );
        });

        it('should reject requests with empty session ID', async () => {
            mockReq.headers!['mcp-session-id'] = '';

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify error response
            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32000,
                    message: 'Bad Request: Missing session ID',
                },
            });

            // Verify error logging
            expect(mockRequestContext.requestLogger.error).toHaveBeenCalledWith(
                'Missing session ID',
                { sessionId: '' }
            );
        });

        it('should reject requests with invalid session ID', async () => {

            mockStore.isValidSession.mockReturnValue(false);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session validation was attempted
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');

            // Verify error response
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32001,
                    message: 'Not Found: Invalid session ID',
                },
            });

            // Verify error logging
            expect(mockRequestContext.requestLogger.error).toHaveBeenCalledWith(
                'Invalid session ID',
                { sessionId: 'existing-session-id' }
            );
        });

        it('should reject requests when transport does not exist', async () => {

            mockStore.isValidSession.mockReturnValue(false);
            mockStore.hasSession.mockResolvedValue(false);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify validation was attempted
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');

            // Verify error response
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32001,
                    message: 'Not Found: Invalid session ID',
                },
            });

            // Verify error logging
            expect(mockRequestContext.requestLogger.error).toHaveBeenCalledWith(
                'Invalid session ID',
                { sessionId: 'existing-session-id' }
            );
        });

        it('should reject requests when all validation conditions fail', async () => {

            // All validation conditions fail
            mockStore.isValidSession.mockReturnValue(false);
            mockStore.hasSession.mockResolvedValue(false);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should only check session validity (short-circuit evaluation)
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');
            // transportStore.hasAsync might not be called due to short-circuit evaluation

            // Verify error response
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32001,
                    message: 'Not Found: Invalid session ID',
                },
            });
        });
    });

    describe('Error handling', () => {
        it('should handle transport store errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => { throw new Error('Transport store error'); }); // (new Error('Transport store error'));

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport store error');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Transport store error',
                    sessionId: null,
                }
            );
        });

        it('should handle session manager errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => {
                throw new Error('Session manager error');
            });

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Session manager error');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Session manager error',
                    sessionId: null,
                }
            );
        });

        it('should handle transport getAsync errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockRejectedValue(new Error('Transport get error'));

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport get error');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Transport get error',
                    sessionId: null,
                }
            );
        });

        it('should handle transport handleRequest errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            const mockTransport = {
                handleRequest: vi.fn().mockRejectedValue(new Error('Transport handling failed')),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport handling failed');

            // Verify transport was called
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes);

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Transport handling failed',
                    sessionId: null,
                }
            );
        });

        it('should handle non-Error objects in catch block', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => {
                throw 'String error'; // Non-Error object
            });

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('String error');

            // Verify error logging with unknown error message
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Unknown error',
                    sessionId: null,
                }
            );
        });

        it('should handle auth context injection errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);
            vi.mocked(injectAuthContext).mockImplementation(() => {
                throw new Error('Auth injection failed');
            });

            const handler = handleStreamableGet();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Auth injection failed');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable GET request',
                {
                    error: 'Auth injection failed',
                    sessionId: null,
                }
            );
        });
    });

    describe('Logging and context', () => {
        it('should log comprehensive request details', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify comprehensive request logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                {
                    contentType: 'application/json',
                    contentLength: '100',
                    accept: 'application/json',
                    clientIp: '127.0.0.1',
                    origin: 'test-origin',
                    sessionIdHeader: 'existing-session-id',
                    mcpMethod: 'tools/list',
                }
            );
        });

        it('should log request details with missing body method', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            // Request without body method
            mockReq.body = undefined;

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify logging handles undefined body gracefully
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                expect.objectContaining({
                    mcpMethod: undefined,
                })
            );
        });

        it('should log request details with partial headers', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            // Request with minimal headers
            mockReq = {
                ...mockReq,
                headers: {
                    'mcp-session-id': 'existing-session-id',
                },
                ip: undefined, // Set IP to undefined to test minimal scenario
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify logging handles minimal headers gracefully
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                {
                    contentType: undefined,
                    contentLength: undefined,
                    accept: undefined,
                    clientIp: undefined,
                    origin: undefined,
                    sessionIdHeader: 'existing-session-id',
                    mcpMethod: 'tools/list',
                }
            );
        });
    });

    describe('Auth context handling', () => {
        it('should inject auth context with correct parameters', async () => {
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify auth context injection with correct parameters
            expect(injectAuthContext).toHaveBeenCalledWith(
                'existing-session-id',
                mockReq,
                mockAuthContext,
                expect.any(Object) // session logger
            );

            // Verify the session logger object structure
            const sessionLoggerCall = vi.mocked(injectAuthContext).mock.calls[0][3];
            expect(sessionLoggerCall).toHaveProperty('info');
        });

        it('should handle auth context injection with custom session logger', async () => {
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            const customSessionLogger = {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            };

            mockRequestContext.requestLogger.child = vi.fn().mockReturnValue(customSessionLogger);

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify auth context injection uses the custom session logger
            expect(injectAuthContext).toHaveBeenCalledWith(
                'existing-session-id',
                mockReq,
                mockAuthContext,
                customSessionLogger
            );

            // Verify the custom session logger was used for debug logging
            expect(customSessionLogger.debug).toHaveBeenCalledWith(
                'Auth context injected into request',
                { reqAuth: (mockReq as any).auth }
            );
        });
    });

    describe('Transport integration', () => {
        it('should cast transport to StreamableHTTPServerTransport correctly', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify transport retrieval and casting
            expect(mockStore.getTransport).toHaveBeenCalledWith('existing-session-id');
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes);
        });

        it('should handle transport handleRequest with only req and res parameters', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamableGet();
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify transport handleRequest is called with exactly 2 parameters (req, res)
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes);
            expect(mockTransport.handleRequest).toHaveBeenCalledTimes(1);
        });
    });

    describe('Handler factory', () => {
        it('should return a function when called', () => {
            const handler = handleStreamableGet();
            expect(typeof handler).toBe('function');
        });

        it('should create independent handler instances', () => {
            const handler1 = handleStreamableGet();
            const handler2 = handleStreamableGet();

            // Handlers should be different function instances
            expect(handler1).not.toBe(handler2);
            expect(typeof handler1).toBe('function');
            expect(typeof handler2).toBe('function');
        });

        it('should handle multiple concurrent requests with same handler instance', async () => {

            const mockTransport1 = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'session-1',
            };

            const mockTransport2 = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'session-2',
            };

            // Setup different session scenarios
            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport
                .mockResolvedValueOnce(mockTransport1 as any)
                .mockResolvedValueOnce(mockTransport2 as any);

            // Create two different request contexts
            const req1 = { ...mockReq, headers: { ...mockReq.headers, 'mcp-session-id': 'session-1' } };
            const req2 = { ...mockReq, headers: { ...mockReq.headers, 'mcp-session-id': 'session-2' } };

            const handler = handleStreamableGet();

            // Execute requests concurrently
            await Promise.all([
                handler(mockRequestContext, req1 as Request, mockRes as Response, mockAuthContext),
                handler(mockRequestContext, req2 as Request, mockRes as Response, mockAuthContext),
            ]);

            // Verify both requests were processed
            expect(mockTransport1.handleRequest).toHaveBeenCalledWith(req1, mockRes);
            expect(mockTransport2.handleRequest).toHaveBeenCalledWith(req2, mockRes);
            expect(mockStore.isValidSession).toHaveBeenCalledTimes(2);
            expect(mockStore.getTransport).toHaveBeenCalledTimes(2);
        });
    });
});