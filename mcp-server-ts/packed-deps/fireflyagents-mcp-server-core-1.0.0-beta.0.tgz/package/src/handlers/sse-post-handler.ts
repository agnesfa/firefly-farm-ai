/**
 * Handles Legacy SSE POST requests
 */
import type {ExtendedAuthContext} from "@fireflyagents/mcp-server-types";
import type {Request, Response} from "express";
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import {getUnifiedSessionStore} from "../services/unified-session-store.js";
import {SSEServerTransport} from "@modelcontextprotocol/sdk/server/sse.js";
import {RequestContext} from "@fireflyagents/mcp-server-types";
import {injectAuthContext} from "../utils/request-helpers.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:sse-post-handler'})

export function handleLegacySsePost() {

    return async (context: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext): Promise<void> => {
        let sessionId: string | null = null;

        context.requestLogger.debug('Legacy SSE POST request received', {
            contentType: req.headers['content-type'],
            contentLength: req.headers['content-length'],
            accept: req.headers.accept,
            clientIp: req.ip,
            origin: req.headers.origin,
            sessionIdHeader: req.headers['mcp-session-id'],
            mcpMethod: req.body.method,
            mcpBody: req.body,
        });

        try {
            const unifiedStore = getUnifiedSessionStore();
            const tenantId = authContext.tenantId || 'default';
            context.requestLogger.debug('Authentication context validated', { tenantId: tenantId })

            // Extract session ID from URL query parameter
            // In the SSE protocol, this is added by the client based on the endpoint event
            sessionId = req.query.sessionId as string | null;

            const sessionLogger = context.requestLogger.child({ sessionId: sessionId });

            if (!sessionId) {
                sessionLogger.error('No session ID provided in request URL');
                res.status(400).send('Missing sessionId parameter');
                return;
            }


            if (!await unifiedStore.hasSession(sessionId)) {
                sessionLogger.error(`No active transport found for session ID: ${sessionId}`);
                res.status(404).send('Session not found');
                return;
            }

            const transport = await unifiedStore.getTransport(sessionId);

            // Check what error should be returned here per Spec
            if (!(transport instanceof SSEServerTransport)) {
                sessionLogger.error(`Bad Request: Session exists but uses a different transport protocol`, {
                    sessionId: sessionId,
                    transportType: transport?.constructor.name
                });
                // Transport exists but is not a SSEServerTransport (could be StreamableHTTPServerTransport)
                res.status(400).json({
                    jsonrpc: '2.0',
                    error: {
                        code: -32000,
                        message: 'Bad Request: Session exists but uses a different transport protocol',
                    },
                    id: null,
                });
                return;
            }

            sessionLogger.debug('Using existing SSE transport', {
                reuseSession: true,
                acceptHeader: req.headers.accept,
                contentType: req.headers['content-type']
            });

            injectAuthContext(sessionId, req, authContext, sessionLogger);
            sessionLogger.debug('Auth context injected into request', { reqAuth: (req as any).auth });

            // Handle the POST message with the transport
            await transport.handlePostMessage(req, res, req.body);

            // sessionLogger.http('Request completed', {
            //     reuseSession: true,
            //     duration: Date.now() - context.startTime
            // });
            return;

        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            logger.error('Error handling Legacy SSE POST request', { error: errorMessage, sessionId });
            // Let the error bubble up to the global error handler:
            throw error;
        }
    }
}