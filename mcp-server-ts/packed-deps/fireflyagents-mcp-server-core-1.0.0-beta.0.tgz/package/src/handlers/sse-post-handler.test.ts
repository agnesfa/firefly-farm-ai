import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import { getUnifiedSessionStore } from '../services/unified-session-store.js';
import {handleLegacySsePost} from './sse-post-handler.js';
import type {Request, Response} from 'express';
import type {ExtendedAuthContext} from '@fireflyagents/mcp-server-types';
import type {RequestContext} from '@fireflyagents/mcp-server-types';
import {SSEServerTransport} from '@modelcontextprotocol/sdk/server/sse.js';

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});



vi.mock('../utils/request-helpers.js', () => ({
    injectAuthContext: vi.fn(),
}));

vi.mock('../services/unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn()
}));

vi.mock('@modelcontextprotocol/sdk/server/sse.js', () => {
    class MockSSEServerTransport {
        sessionId: string;
        handlePostMessage: any;

        constructor(_endpoint: string, _res: any) {
            this.sessionId = 'mock-session-id';
            this.handlePostMessage = vi.fn().mockResolvedValue(undefined);
        }
    }
    return {SSEServerTransport: MockSSEServerTransport};
});

describe('handleLegacySsePost', () => {
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockAuthContext: ExtendedAuthContext;
    let mockRequestContext: RequestContext;
    let mockSessionLogger: any;
    let mockTransport: any;
    let mockStore: any;

    beforeEach(async () => {
        vi.clearAllMocks();
        // Setup unified store mock
        const defaultMockTransport = {
            handleRequest: vi.fn().mockResolvedValue(undefined),
            sessionId: 'test-session-id',
        };

        mockStore = {
            isValidSession: vi.fn().mockReturnValue(true),
            hasSession: vi.fn().mockResolvedValue(true),
            getTransport: vi.fn().mockResolvedValue(defaultMockTransport),
            createSession: vi.fn().mockResolvedValue({ connect: vi.fn().mockResolvedValue(undefined) }),
            removeSession: vi.fn().mockResolvedValue(true),
            getSession: vi.fn().mockResolvedValue({
                tenantId: 'test-tenant',
                authContext: {
                    clientMetadata: {
                        accountId: 'test-account',
                        retailerId: 'test-retailer',
                    },
                },
                platformTokens: {
                    default: {
                        accessToken: 'test-access-token-12345',
                        expiresAt: new Date(Date.now() + 3600000),
                    }
                }
            }),
            getPlatformToken: vi.fn().mockReturnValue({
                accessToken: 'test-access-token-12345',
                expiresAt: new Date(Date.now() + 3600000),
            }),
        };

        (getUnifiedSessionStore as any).mockReturnValue(mockStore);


        // Mock session logger
        mockSessionLogger = {
            debug: vi.fn(),
            info: vi.fn(),
            warn: vi.fn(),
            error: vi.fn(),
            http: vi.fn(),
        };

        // Mock request
        mockReq = {
            headers: {
                'content-type': 'application/json',
                'content-length': '123',
                accept: 'application/json',
                origin: 'http://localhost:3000',
                'mcp-session-id': 'test-session-id',
            },
            body: {
                jsonrpc: '2.0',
                method: 'tools/list',
                params: {},
                id: 1,
            },
            ip: '127.0.0.1',
            query: {
                sessionId: 'test-session-id',
            },
        };

        // Mock response
        mockRes = {
            status: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
        };

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Mock request context
        mockRequestContext = {
            requestId: 'test-request-id',
            startTime: Date.now() - 100, // Set a past time for positive duration
            sessionId: 'test-session-id',
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
                child: vi.fn().mockReturnValue(mockSessionLogger),
            },
        };

        // Mock transport that passes instanceof check
        mockTransport = new SSEServerTransport('test-endpoint', {} as any);
        mockTransport.sessionId = 'test-session-id';
        mockTransport.handlePostMessage = vi.fn().mockResolvedValue(undefined);
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('Successful SSE POST handling', () => {
        it('should successfully handle POST request with existing SSE session', async () => {

            const {injectAuthContext} = await import('../utils/request-helpers.js');

            // Mock transport store to return existing SSE transport
            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify logging of request
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE POST request received',
                expect.objectContaining({
                    contentType: 'application/json',
                    contentLength: '123',
                    accept: 'application/json',
                    clientIp: '127.0.0.1',
                    origin: 'http://localhost:3000',
                    sessionIdHeader: 'test-session-id',
                    mcpMethod: 'tools/list',
                    mcpBody: mockReq.body,
                })
            );

            // Verify authentication context validation
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Authentication context validated',
                {tenantId: 'test-tenant'}
            );

            // Verify transport store operations
            expect(mockStore.getTransport).toHaveBeenCalledWith('test-session-id');

            // Verify session logger was created
            expect(mockRequestContext.requestLogger.child).toHaveBeenCalledWith({sessionId: 'test-session-id'});

            // Verify auth context injection
            expect(injectAuthContext).toHaveBeenCalledWith('test-session-id', mockReq, mockAuthContext, mockSessionLogger);

            // Verify transport usage logging
            expect(mockSessionLogger.debug).toHaveBeenCalledWith(
                'Using existing SSE transport',
                {
                    reuseSession: true,
                    acceptHeader: 'application/json',
                    contentType: 'application/json',
                }
            );

            // Verify transport handlePostMessage was called
            expect(mockTransport.handlePostMessage).toHaveBeenCalledWith(mockReq, mockRes, mockReq.body);

            // Request completion logging is commented out in the handler
            // expect(mockSessionLogger.debug).toHaveBeenCalledWith(
            //     'Request completed',
            //     {
            //         reuseSession: true,
            //         duration: expect.any(Number),
            //     }
            // );
        });

        it('should use sessionId from query parameter when available', async () => {

            // Remove sessionId from headers, rely on query parameter
            delete mockReq.headers!['mcp-session-id'];

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should still work with query parameter sessionId
            expect(mockRequestContext.requestLogger.child).toHaveBeenCalledWith({sessionId: 'test-session-id'});
        });

        it('should use default tenant when tenantId is not provided', async () => {

            const authContextWithoutTenant = {
                ...mockAuthContext,
                tenantId: undefined,
            };

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, authContextWithoutTenant);

            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Authentication context validated',
                {tenantId: 'default'}
            );
        });
    });

    describe('Error handling - Missing session ID', () => {
        it('should return 400 when sessionId is missing from both query and headers', async () => {
            delete mockReq.query!.sessionId;
            delete mockReq.headers!['mcp-session-id'];

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify error logging
            expect(mockSessionLogger.error).toHaveBeenCalledWith('No session ID provided in request URL');

            // Verify 400 response
            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.send).toHaveBeenCalledWith('Missing sessionId parameter');
        });

        it('should return 400 when sessionId is null', async () => {
            (mockReq.query as any).sessionId = null;
            delete mockReq.headers!['mcp-session-id'];

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.send).toHaveBeenCalledWith('Missing sessionId parameter');
        });

        it('should return 400 when sessionId is empty string', async () => {
            mockReq.query!.sessionId = '';
            delete mockReq.headers!['mcp-session-id'];

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.send).toHaveBeenCalledWith('Missing sessionId parameter');
        });
    });

    describe('Error handling - Session not found', () => {
        it('should return 404 when session does not exist', async () => {

            // Mock hasSession to return false (session not found)
            vi.mocked(mockStore.hasSession).mockResolvedValue(false);
            vi.mocked(mockStore.getTransport).mockResolvedValue(null);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Handler checks hasSession first and returns 404
            expect(mockSessionLogger.error).toHaveBeenCalledWith(
                'No active transport found for session ID: test-session-id'
            );

            // Verify 404 response for session not found
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.send).toHaveBeenCalledWith('Session not found');
        });
    });

    describe('Error handling - Transport type mismatch', () => {
        it('should return 400 when transport exists but is not SSEServerTransport', async () => {

            // Mock a different transport type
            const mockStreamableTransport = {
                sessionId: 'test-session-id',
                constructor: {name: 'StreamableHTTPServerTransport'},
            };

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockStreamableTransport as any);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify error logging
            expect(mockSessionLogger.error).toHaveBeenCalledWith(
                'Bad Request: Session exists but uses a different transport protocol',
                {
                    sessionId: 'test-session-id',
                    transportType: 'StreamableHTTPServerTransport',
                }
            );

            // Verify 400 JSON-RPC error response
            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                error: {
                    code: -32000,
                    message: 'Bad Request: Session exists but uses a different transport protocol',
                },
                id: null,
            });
        });
    });

    describe('Error handling - Transport operations', () => {
        it('should handle transport store retrieval errors', async () => {

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockRejectedValue(new Error('Transport store error'));

            const handler = handleLegacySsePost();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport store error');
        });

        it('should handle transport handlePostMessage errors', async () => {

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            // Make handlePostMessage throw an error
            mockTransport.handlePostMessage.mockRejectedValue(new Error('Transport handling error'));

            const handler = handleLegacySsePost();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport handling error');
        });

        it('should handle injectAuthContext errors', async () => {

            const {injectAuthContext} = await import('../utils/request-helpers.js');

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            // Make injectAuthContext throw an error
            vi.mocked(injectAuthContext).mockImplementation(() => {
                throw new Error('Auth injection error');
            });

            const handler = handleLegacySsePost();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Auth injection error');
        });
    });

    describe('Logging behavior', () => {
        it('should log comprehensive request information', async () => {

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify detailed request logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE POST request received',
                {
                    contentType: 'application/json',
                    contentLength: '123',
                    accept: 'application/json',
                    clientIp: '127.0.0.1',
                    origin: 'http://localhost:3000',
                    sessionIdHeader: 'test-session-id',
                    mcpMethod: 'tools/list',
                    mcpBody: mockReq.body,
                }
            );
        });

        it('should log auth context injection confirmation', async () => {

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify auth injection logging
            expect(mockSessionLogger.debug).toHaveBeenCalledWith(
                'Auth context injected into request',
                {reqAuth: (mockReq as any).auth}
            );
        });

        it('should handle missing optional headers gracefully in logging', async () => {

            // Remove optional headers
            delete mockReq.headers!.origin;
            delete mockReq.headers!['content-length'];

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should still log with undefined values
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE POST request received',
                expect.objectContaining({
                    contentType: 'application/json',
                    contentLength: undefined,
                    origin: undefined,
                })
            );
        });
    });

    describe('Edge cases and boundary conditions', () => {
        it('should handle missing request body gracefully', async () => {

            // The handler tries to access req.body.method, so this will throw an error
            // Let's test that it handles this error properly
            mockReq.body = undefined;

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            // This should throw because the handler tries to access req.body.method
            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Cannot read properties of undefined (reading \'method\')');
        });

        it('should handle missing IP address gracefully', async () => {

            (mockReq as any).ip = undefined;

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE POST request received',
                expect.objectContaining({
                    clientIp: undefined,
                })
            );
        });

        it('should handle minimal auth context', async () => {

            const minimalAuthContext = {
                apiKey: 'test-key',
            } as ExtendedAuthContext;

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransport);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, minimalAuthContext);

            // Should work with minimal auth context
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Authentication context validated',
                {tenantId: 'default'}
            );
        });

        it('should handle transport with missing constructor name', async () => {

            // Mock transport without constructor name
            const mockTransportNoConstructor = {
                sessionId: 'test-session-id',
                constructor: {},
            };

            vi.mocked(mockStore.hasSession).mockResolvedValue(true);
            vi.mocked(mockStore.getTransport).mockResolvedValue(mockTransportNoConstructor as any);

            const handler = handleLegacySsePost();

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should log undefined for constructor name
            expect(mockSessionLogger.error).toHaveBeenCalledWith(
                'Bad Request: Session exists but uses a different transport protocol',
                {
                    sessionId: 'test-session-id',
                    transportType: undefined,
                }
            );
        });
    });

    describe('Error propagation', () => {
        it('should propagate errors with proper logging', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            const error = new Error('Test error');

            // Mock transport store to throw
            
            vi.mocked(mockStore.hasSession).mockImplementation(() => {
                throw error;
            });

            const handler = handleLegacySsePost();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Test error');

            // Verify error was logged with proper context
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Legacy SSE POST request',
                {
                    error: 'Test error',
                    sessionId: 'test-session-id',
                }
            );
        });

        it('should handle non-Error objects in catch block', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            // Mock transport store to throw a non-Error object
            
            vi.mocked(mockStore.hasSession).mockImplementation(() => {
                throw 'String error'; // Non-Error object
            });

            const handler = handleLegacySsePost();

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toBe('String error');

            // Verify error was logged with 'Unknown error' message
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Legacy SSE POST request',
                {
                    error: 'Unknown error',
                    sessionId: 'test-session-id',
                }
            );
        });

        it('should handle early errors before session extraction', async () => {
            // Remove sessionId to cause early error
            delete mockReq.query!.sessionId;
            delete mockReq.headers!['mcp-session-id'];

            // Make requestLogger.debug throw to test error before sessionId extraction
            mockRequestContext.requestLogger.debug = vi.fn().mockImplementation(() => {
                throw new Error('Logging error');
            });

            const handler = handleLegacySsePost();

            // Should propagate the error
            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Logging error');
        });
    });
});