import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import {handleLegacySse} from './legacy-sse-handler.js';
import type {Request, Response} from 'express';
import type {McpServerConfig, ExtendedAuthContext} from '@fireflyagents/mcp-server-types';
import type {RequestContext} from '@fireflyagents/mcp-server-types';

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});

vi.mock('./sse-get-handler.js', () => ({
    handleLegacySseGet: vi.fn().mockReturnValue(vi.fn().mockResolvedValue(undefined)),
}));

vi.mock('./sse-post-handler.js', () => ({
    handleLegacySsePost: vi.fn().mockReturnValue(vi.fn().mockResolvedValue(undefined)),
}));

vi.mock('../utils/request-helpers.js', () => ({
    createRequestContext: vi.fn().mockReturnValue({
        requestId: 'test-request-id',
        startTime: Date.now() - 100,
        sessionId: 'test-session-id',
        requestLogger: {
            debug: vi.fn(),
            info: vi.fn(),
            warn: vi.fn(),
            error: vi.fn(),
            http: vi.fn(),
            child: vi.fn(),
        },
    }),
    handleAuthenticationError: vi.fn().mockResolvedValue(undefined),
    isAuthenticationError: vi.fn().mockReturnValue(false),
}));

vi.mock('../auth/extract-auth.js', () => ({
    extractAuthContext: vi.fn().mockResolvedValue({
        apiKey: 'test-api-key',
        tenantId: 'test-tenant',
        clientType: 'test-client',
        clientMetadata: {
            accountId: 'test-account',
            retailerId: 'test-retailer',
        },
    }),
}));

describe('handleLegacySse', () => {
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockMcpServerConfig: McpServerConfig;
    let mockRequestContext: RequestContext;
    let mockAuthContext: ExtendedAuthContext;

    beforeEach(async () => {
        vi.clearAllMocks();

        // Mock request context
        mockRequestContext = {
            requestId: 'test-request-id',
            startTime: Date.now() - 100,
            sessionId: 'test-session-id',
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
                child: vi.fn(),
            },
        };

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Mock MCP server config
        mockMcpServerConfig = {
            name: 'test-server',
            version: '1.0.0',
            apiKeyStore: {
                validateApiKey: vi.fn().mockResolvedValue(true),
            } as any,
            authHandlers: [],
        };

        // Mock request
        mockReq = {
            method: 'GET',
            headers: {
                'x-api-key': 'test-api-key',
                'content-type': 'application/json',
                accept: 'text/event-stream',
            },
            body: {},
            query: {},
        };

        // Mock response
        mockRes = {
            status: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
            statusCode: 200,
            headersSent: false,
        };
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('Request routing', () => {
        it('should route GET requests to legacy SSE GET handler', async () => {
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'GET';

            const mockGetHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleLegacySseGet).mockReturnValue(mockGetHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify GET handler was created with config
            expect(handleLegacySseGet).toHaveBeenCalledWith(mockMcpServerConfig);

            // Verify GET handler was called with correct parameters
            expect(mockGetHandler).toHaveBeenCalledWith(
                mockRequestContext,
                mockReq,
                mockRes,
                mockAuthContext
            );

            // Verify request context creation
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));

            // Verify auth extraction
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
        });

        it('should route POST requests to legacy SSE POST handler', async () => {
            const {handleLegacySsePost} = await import('./sse-post-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'POST';

            const mockPostHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleLegacySsePost).mockReturnValue(mockPostHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify POST handler was created
            expect(handleLegacySsePost).toHaveBeenCalled();

            // Verify POST handler was called with correct parameters
            expect(mockPostHandler).toHaveBeenCalledWith(
                mockRequestContext,
                mockReq,
                mockRes,
                mockAuthContext
            );

            // Verify request context creation
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));

            // Verify auth extraction
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
        });

        it('should reject unsupported HTTP methods with 500 error', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'PUT';

            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Invalid HTTP method: PUT');

            // Verify 500 response
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });

        it('should handle DELETE method as unsupported', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'DELETE';

            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            expect(mockModuleLogger.error).toHaveBeenCalledWith('Invalid HTTP method: DELETE');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });

        it('should handle PATCH method as unsupported', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'PATCH';

            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            expect(mockModuleLogger.error).toHaveBeenCalledWith('Invalid HTTP method: PATCH');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });
    });

    describe('Authentication handling', () => {
        it('should handle authentication errors properly', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {isAuthenticationError, handleAuthenticationError, createRequestContext} = await import('../utils/request-helpers.js');

            // Mock authentication failure
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockRejectedValue(new Error('Invalid API key'));
            vi.mocked(isAuthenticationError).mockReturnValue(true);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify authentication error handling
            expect(isAuthenticationError).toHaveBeenCalledWith('Invalid API key');
            expect(handleAuthenticationError).toHaveBeenCalledWith(
                mockReq,
                mockRes,
                mockRequestContext,
                'Invalid API key'
            );
        });

        it('should extract authentication context before routing', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            const mockGetHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleLegacySseGet).mockReturnValue(mockGetHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify auth context extraction happens first
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
            expect(mockGetHandler).toHaveBeenCalledWith(
                expect.any(Object),
                mockReq,
                mockRes,
                mockAuthContext
            );
        });

        it('should handle missing headers gracefully in auth extraction', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            // Request with minimal headers
            mockReq.headers = {};

            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Should still attempt auth extraction
            expect(extractAuthContext).toHaveBeenCalledWith({}, mockMcpServerConfig);
        });
    });

    describe('Error handling and logging', () => {
        it('should handle GET handler errors properly', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const mockGetHandler = vi.fn().mockRejectedValue(new Error('GET handler error'));
            vi.mocked(handleLegacySseGet).mockReturnValue(mockGetHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling request:',
                expect.any(Error)
            );

            // Verify 500 response
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });

        it('should handle POST handler errors properly', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {handleLegacySsePost} = await import('./sse-post-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockReq.method = 'POST';

            const mockPostHandler = vi.fn().mockRejectedValue(new Error('POST handler error'));
            vi.mocked(handleLegacySsePost).mockReturnValue(mockPostHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling request:',
                expect.any(Error)
            );
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });

        it('should handle non-Error objects in catch block', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            // Mock to throw a non-Error object
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockImplementation(() => {
                throw 'String error'; // Non-Error object
            });

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Should log 'Unknown error' for non-Error objects
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Error handling request:', 'String error');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.send).toHaveBeenCalledWith('Error handling request');
        });

        it('should not send response if headers already sent', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            mockRes.headersSent = true;
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockRejectedValue(new Error('Test error'));

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Should not call status or send when headers already sent
            expect(mockRes.status).not.toHaveBeenCalled();
            expect(mockRes.send).not.toHaveBeenCalled();
        });

        it('should log completion in finally block with success status', async () => {
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            mockRes.statusCode = 200;

            const mockGetHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleLegacySseGet).mockReturnValue(mockGetHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify completion logging
            expect(mockRequestContext.requestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                {
                    statusCode: 200,
                    status: 'success',
                    duration: expect.any(Number),
                }
            );
        });

        it('should log completion in finally block with error status', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            (mockRes as any).errored = true;
            mockRes.statusCode = undefined as any; // Ensure statusCode defaults to 500
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockRejectedValue(new Error('Test error'));

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error status logging
            expect(mockRequestContext.requestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                {
                    statusCode: 500, // Default when no statusCode set
                    status: 'error',
                    duration: expect.any(Number),
                }
            );
        });

        it('should use default statusCode 500 when not set', async () => {
            const {extractAuthContext} = await import('../auth/extract-auth.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');

            mockRes.statusCode = undefined as any;
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockRejectedValue(new Error('Test error'));

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            expect(mockRequestContext.requestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                expect.objectContaining({
                    statusCode: 500,
                })
            );
        });
    });

    describe('Request context and logging', () => {
        it('should create request context with proper logger', async () => {
            // const utils = await import('@fireflyagents/mcp-shared-utils');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify request context creation with logger
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.objectContaining({
                debug: expect.any(Function),
                info: expect.any(Function),
                warn: expect.any(Function),
                error: expect.any(Function),
                http: expect.any(Function),
            }));
        });

        it('should propagate context creation errors without logging', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            // Make createRequestContext throw to test early error
            vi.mocked(createRequestContext).mockImplementation(() => {
                throw new Error('Context creation error');
            });

            const handler = handleLegacySse(mockMcpServerConfig);

            // This should throw the context creation error since it happens before try-catch
            await expect(handler(mockReq as Request, mockRes as Response)).rejects.toThrow('Context creation error');

            // Since the error happens before the try block, it's not logged by the handler
            expect(mockModuleLogger.error).not.toHaveBeenCalled();
            // Response methods should not be called either since error happens before try block
            expect(mockRes.status).not.toHaveBeenCalled();
            expect(mockRes.send).not.toHaveBeenCalled();
        });
    });

    describe('Handler initialization', () => {
        it('should create GET and POST handlers during initialization', async () => {
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {handleLegacySsePost} = await import('./sse-post-handler.js');

            // Clear previous calls
            vi.clearAllMocks();

            const handler = handleLegacySse(mockMcpServerConfig);

            // Verify handlers were created during initialization
            expect(handleLegacySseGet).toHaveBeenCalledWith(mockMcpServerConfig);
            expect(handleLegacySsePost).toHaveBeenCalled();

            // Handler should be a function
            expect(typeof handler).toBe('function');
        });

        it('should reuse handler instances across requests', async () => {
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {handleLegacySsePost} = await import('./sse-post-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const mockGetHandler = vi.fn().mockResolvedValue(undefined);
            const mockPostHandler = vi.fn().mockResolvedValue(undefined);

            vi.mocked(handleLegacySseGet).mockReturnValue(mockGetHandler);
            vi.mocked(handleLegacySsePost).mockReturnValue(mockPostHandler);
            vi.mocked(createRequestContext).mockReturnValue(mockRequestContext);
            vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

            const handler = handleLegacySse(mockMcpServerConfig);

            // Make multiple requests
            await handler(mockReq as Request, mockRes as Response);

            mockReq.method = 'POST';
            await handler(mockReq as Request, mockRes as Response);

            // Handlers should have been created only once during initialization
            expect(handleLegacySseGet).toHaveBeenCalledTimes(1);
            expect(handleLegacySsePost).toHaveBeenCalledTimes(1);

            // But the handler functions should be called for each request
            expect(mockGetHandler).toHaveBeenCalledTimes(1);
            expect(mockPostHandler).toHaveBeenCalledTimes(1);
        });
    });

    describe('Configuration handling', () => {
        it('should pass MCP server config to GET handler only', async () => {
            const {handleLegacySseGet} = await import('./sse-get-handler.js');
            const {handleLegacySsePost} = await import('./sse-post-handler.js');

            const customConfig: McpServerConfig = {
                ...mockMcpServerConfig,
                name: 'custom-test-server',
            };

            handleLegacySse(customConfig);

            // GET handler should receive config
            expect(handleLegacySseGet).toHaveBeenCalledWith(customConfig);

            // POST handler should not receive config
            expect(handleLegacySsePost).toHaveBeenCalledWith();
        });

        it('should work with minimal MCP server config', () => {
            const minimalConfig: McpServerConfig = {
                name: 'minimal-server',
                version: '1.0.0',
            };

            const handler = handleLegacySse(minimalConfig);
            expect(typeof handler).toBe('function');
        });
    });
});