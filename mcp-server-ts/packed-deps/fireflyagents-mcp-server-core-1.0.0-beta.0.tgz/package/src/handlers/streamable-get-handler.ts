/**
 * Handles StreamableHTTP GET requests
 */
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import type {ExtendedAuthContext} from "@fireflyagents/mcp-server-types";
import type {Request, Response} from "express";
import {getUnifiedSessionStore} from "../services/unified-session-store.js";
import {StreamableHTTPServerTransport} from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import {RequestContext} from "@fireflyagents/mcp-server-types";
import {injectAuthContext} from "../utils/request-helpers.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:streamable-get-handler' });

export function handleStreamableGet() {

    return async (context: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext) => {
        let sessionId: string | null = null;

        context.requestLogger.debug('StreamableHTTP request received', {
            contentType: req.headers['content-type'],
            contentLength: req.headers['content-length'],
            accept: req.headers.accept,
            clientIp: req.ip,
            origin: req.headers.origin,
            sessionIdHeader: req.headers['mcp-session-id'],
            mcpMethod: req.body?.method,
        });

        try {
            const unifiedStore = getUnifiedSessionStore();
            const tenantId = authContext.tenantId || 'default';

            // Check if there's an existing session ID in the request header
            const sessionId = req.headers['mcp-session-id'] as string;
            /**
             * Spec states:
             * Servers that require a session ID SHOULD respond to requests without an Mcp-Session-Id header (other than initialization) with HTTP 400 Bad Request. [https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#session-management]
             * The GET handler MUST NOT create a new session if no session ID is provided, since the client should POST an Initialization message to create a new session.
             */
            if (!sessionId) {
                context.requestLogger.error('Missing session ID', { sessionId });
                // res.status(400).send('Missing session ID');
                res.status(400).json({
                    jsonrpc: '2.0',
                    id: context.requestId,
                    error: {
                        code: -32000,
                        message: 'Bad Request: Missing session ID',
                    },
                });
                return;
            }

            // Session ID is provided, check if it's valid and exists
            /**
             * Spec states:
             * The server MAY terminate the session at any time, after which it MUST respond to requests containing that session ID with HTTP 404 Not Found. [https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#session-management]
             *
             */
            if (!unifiedStore.isValidSession(sessionId, tenantId)) {
                context.requestLogger.error('Invalid session ID', { sessionId });
                // res.status(404).send('Invalid session ID');
                res.status(404).json({
                    jsonrpc: '2.0',
                    id: context.requestId,
                    error: {
                        code: -32001,
                        message: 'Not Found: Invalid session ID',
                    },
                });
                return;
            }

            const sessionLogger = context.requestLogger.child({ sessionId: sessionId });

            // TODO: Future implement resumability as per spec: https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#resumability-and-redelivery

            injectAuthContext(sessionId, req, authContext, sessionLogger);
            sessionLogger.debug('Auth context injected into request', { reqAuth: (req as any).auth });

            const transport = await unifiedStore.getTransport(sessionId) as StreamableHTTPServerTransport;
            await transport.handleRequest(req, res);

        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            logger.error('Error handling Streamable GET request', { error: errorMessage, sessionId });
            // Let the error bubble up to the global error handler:
            throw error;
        }
    }
}
