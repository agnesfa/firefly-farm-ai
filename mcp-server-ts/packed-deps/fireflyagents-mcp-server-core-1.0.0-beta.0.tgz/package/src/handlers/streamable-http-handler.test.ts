import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import {handleStreamableHttp} from './streamable-http-handler.js';
import type {Request, Response} from 'express';
import type {McpServerConfig, ExtendedAuthContext} from '@fireflyagents/mcp-server-types';

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
        child: vi.fn().mockReturnThis(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});

vi.mock('../utils/request-helpers.js', () => ({
    createRequestContext: vi.fn().mockReturnValue({
        requestId: 'test-request-id',
        startTime: Date.now() - 100,
        sessionId: 'test-session-id',
        requestLogger: {
            debug: vi.fn(),
            info: vi.fn(),
            warn: vi.fn(),
            error: vi.fn(),
            http: vi.fn(),
        },
    }),
    handleAuthenticationError: vi.fn().mockResolvedValue(undefined),
    isAuthenticationError: vi.fn().mockReturnValue(false),
}));

vi.mock('./streamable-post-handler.js', () => ({
    handleStreamablePost: vi.fn().mockReturnValue(vi.fn().mockResolvedValue(undefined)),
}));

vi.mock('./streamable-get-handler.js', () => ({
    handleStreamableGet: vi.fn().mockReturnValue(vi.fn().mockResolvedValue(undefined)),
}));

vi.mock('./streamable-delete-handler.js', () => ({
    handleStreamableDelete: vi.fn().mockReturnValue(vi.fn().mockResolvedValue(undefined)),
}));

vi.mock('../auth/extract-auth.js', () => ({
    extractAuthContext: vi.fn().mockResolvedValue({
        apiKey: 'test-api-key',
        tenantId: 'test-tenant',
        clientType: 'test-client',
        clientMetadata: {
            accountId: 'test-account',
            retailerId: 'test-retailer',
        },
    }),
}));

describe('handleStreamableHttp', () => {
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockMcpServerConfig: McpServerConfig;
    let mockAuthContext: ExtendedAuthContext;

    beforeEach(async () => {
        // Clear all mocks but preserve the basic ones needed for functionality
        vi.clearAllMocks();

        // Mock MCP server config
        mockMcpServerConfig = {
            name: 'test-server',
            version: '1.0.0',
            apiKeyStore: {
                validateApiKey: vi.fn().mockResolvedValue(true),
            },
        } as any;

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Restore essential mocks that need to work across tests
        const {createRequestContext} = await import('../utils/request-helpers.js');
        const {extractAuthContext} = await import('../auth/extract-auth.js');

        vi.mocked(createRequestContext).mockReturnValue({
            requestId: 'test-request-id',
            startTime: Date.now() - 100,
            sessionId: 'test-session-id',
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            },
        });

        // Restore auth context mock - now mockAuthContext is defined
        vi.mocked(extractAuthContext).mockResolvedValue(mockAuthContext);

        // Mock request
        mockReq = {
            method: 'POST',
            url: '/mcp',
            headers: {
                'content-type': 'application/json',
                'x-api-key': 'test-api-key',
                'mcp-session-id': 'test-session-id',
            },
            body: {
                jsonrpc: '2.0',
                method: 'initialize',
                id: 1,
            },
        };

        // Mock response
        mockRes = {
            status: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
            statusCode: 200,
            headersSent: false,
        };
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('HTTP method routing', () => {
        it('should route POST requests to streamable POST handler', async () => {
            const {handleStreamablePost} = await import('./streamable-post-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const mockPostHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify POST handler creation and execution
            expect(handleStreamablePost).toHaveBeenCalledWith(mockMcpServerConfig);
            expect(mockPostHandler).toHaveBeenCalledWith(
                expect.any(Object), // context
                mockReq,
                mockRes,
                mockAuthContext
            );

            // Verify request context creation and auth extraction
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
        });

        it('should route GET requests to streamable GET handler', async () => {
            const {handleStreamableGet} = await import('./streamable-get-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const mockGetHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleStreamableGet).mockReturnValue(mockGetHandler);

            mockReq.method = 'GET';

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify GET handler creation and execution
            expect(handleStreamableGet).toHaveBeenCalledWith();
            expect(mockGetHandler).toHaveBeenCalledWith(
                expect.any(Object), // context
                mockReq,
                mockRes,
                mockAuthContext
            );

            // Verify request context creation and auth extraction
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
        });

        it('should route DELETE requests to streamable DELETE handler', async () => {
            const {handleStreamableDelete} = await import('./streamable-delete-handler.js');
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const mockDeleteHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleStreamableDelete).mockReturnValue(mockDeleteHandler);

            mockReq.method = 'DELETE';

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify DELETE handler creation and execution
            expect(handleStreamableDelete).toHaveBeenCalledWith();
            expect(mockDeleteHandler).toHaveBeenCalledWith(
                expect.any(Object), // context
                mockReq,
                mockRes,
                mockAuthContext
            );

            // Verify request context creation and auth extraction
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));
            expect(extractAuthContext).toHaveBeenCalledWith(mockReq.headers, mockMcpServerConfig);
        });

        it('should reject unsupported HTTP methods with error', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockReq.method = 'PUT';

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error logging and response
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Invalid HTTP method: PUT');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32603,
                    message: 'Internal Server Error: Error handling request',
                },
            });
        });

        it('should handle PATCH method as unsupported', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockReq.method = 'PATCH';

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error logging and response
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Invalid HTTP method: PATCH');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32603,
                    message: 'Internal Server Error: Error handling request',
                },
            });
        });
    });

    describe('Authentication handling', () => {
        it('should handle authentication errors with special handling', async () => {
            const {isAuthenticationError, handleAuthenticationError} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            vi.mocked(extractAuthContext).mockRejectedValue(new Error('Invalid API key'));
            vi.mocked(isAuthenticationError).mockReturnValue(true);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify authentication error handling
            expect(isAuthenticationError).toHaveBeenCalledWith('Invalid API key');
            expect(handleAuthenticationError).toHaveBeenCalledWith(
                mockReq,
                mockRes,
                expect.any(Object), // context
                'Invalid API key'
            );
        });

        it('should pass through valid authentication context', async () => {
            const {handleStreamablePost} = await import('./streamable-post-handler.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            const customAuthContext = {
                apiKey: 'custom-key',
                tenantId: 'custom-tenant',
                clientType: 'custom-client',
                clientMetadata: { accountId: 'custom-account' },
            };

            vi.mocked(extractAuthContext).mockResolvedValue(customAuthContext);

            const mockPostHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify custom auth context is passed through
            expect(mockPostHandler).toHaveBeenCalledWith(
                expect.any(Object), // context
                mockReq,
                mockRes,
                customAuthContext
            );
        });

        it('should handle authentication extraction failure', async () => {
            const {isAuthenticationError} = await import('../utils/request-helpers.js');
            const {extractAuthContext} = await import('../auth/extract-auth.js');

            vi.mocked(extractAuthContext).mockRejectedValue(new Error('API key is required'));
            vi.mocked(isAuthenticationError).mockReturnValue(true);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify authentication error is detected and handled
            expect(isAuthenticationError).toHaveBeenCalledWith('API key is required');
        });
    });

    describe('Error handling', () => {
        it('should handle general errors with 500 response', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockPostHandler = vi.fn().mockRejectedValue(new Error('Handler error'));
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify error logging and response
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Error handling request:', expect.any(Error));
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32603,
                    message: 'Internal Server Error: Error handling request',
                },
            });
        });

        it('should not send response if headers already sent', async () => {
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockPostHandler = vi.fn().mockRejectedValue(new Error('Handler error'));
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            mockRes.headersSent = true;

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify no response is sent when headers already sent
            expect(mockRes.status).not.toHaveBeenCalled();
            expect(mockRes.send).not.toHaveBeenCalled();
            expect(mockRes.json).not.toHaveBeenCalled();
        });

        it('should handle non-Error objects in catch block', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockPostHandler = vi.fn().mockRejectedValue('String error');
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify non-Error objects are handled gracefully
            expect(mockModuleLogger.error).toHaveBeenCalledWith('Error handling request:', 'String error');
            expect(mockRes.status).toHaveBeenCalledWith(500);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                id: 'test-request-id',
                error: {
                    code: -32603,
                    message: 'Internal Server Error: Error handling request',
                },
            });
        });

        it('should handle errors during context creation', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');

            vi.mocked(createRequestContext).mockImplementation(() => {
                throw new Error('Context creation failed');
            });

            const handler = handleStreamableHttp(mockMcpServerConfig);

            // The handler will throw because context creation fails and the finally block can't access context
            // This is expected behavior - the error will be uncaught since there's no context for cleanup
            await expect(handler(mockReq as Request, mockRes as Response)).rejects.toThrow('Context creation failed');
        });
    });

    describe('Request context and logging', () => {
        it('should create request context with proper logger', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify request context creation - the logger passed should be an object
            expect(createRequestContext).toHaveBeenCalledWith(mockReq, expect.any(Object));

            // Verify that the logger passed to createRequestContext has a child method (indicating it's a proper logger)
            const createRequestContextCalls = vi.mocked(createRequestContext).mock.calls;
            const loggerArg = createRequestContextCalls[0][1];
            expect(typeof loggerArg).toBe('object');
            expect(loggerArg).toBeDefined();
        });

        it('should log request completion with success status', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');

            const mockRequestLogger = {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            };

            const mockContext = {
                requestId: 'test-request-id',
                startTime: Date.now() - 1000, // 1 second ago
                sessionId: 'test-session-id',
                requestLogger: mockRequestLogger,
            };

            vi.mocked(createRequestContext).mockReturnValue(mockContext);
            mockRes.statusCode = 200;
            // errored property is read-only, so we don't set it - it will be falsy by default

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify request completion logging
            expect(mockRequestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                {
                    statusCode: 200,
                    status: 'success',
                    duration: expect.any(Number),
                }
            );
        });

        it('should log request completion with error status', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockRequestLogger = {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            };

            const mockContext = {
                requestId: 'test-request-id',
                startTime: Date.now() - 500, // 0.5 seconds ago
                sessionId: 'test-session-id',
                requestLogger: mockRequestLogger,
            };

            vi.mocked(createRequestContext).mockReturnValue(mockContext);

            const mockPostHandler = vi.fn().mockRejectedValue(new Error('Handler failed'));
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            mockRes.statusCode = 500;
            // Mock response with errored property for error status test
            mockRes = { ...mockRes, errored: new Error('Mock error') } as any;

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify request completion logging with error status
            expect(mockRequestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                {
                    statusCode: 500,
                    status: 'error',
                    duration: expect.any(Number),
                }
            );
        });

        it('should log request completion with default status code when missing', async () => {
            const {createRequestContext} = await import('../utils/request-helpers.js');
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockRequestLogger = {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
            };

            const mockContext = {
                requestId: 'test-request-id',
                startTime: Date.now() - 250, // 0.25 seconds ago
                sessionId: 'test-session-id',
                requestLogger: mockRequestLogger,
            };

            vi.mocked(createRequestContext).mockReturnValue(mockContext);

            const mockPostHandler = vi.fn().mockRejectedValue(new Error('Handler failed'));
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            delete mockRes.statusCode; // Remove statusCode to test default
            // errored property is undefined by default (falsy), so no need to set it

            const handler = handleStreamableHttp(mockMcpServerConfig);
            await handler(mockReq as Request, mockRes as Response);

            // Verify request completion logging with default status code
            // Since errored is falsy, it should show 'success' even though handler failed
            expect(mockRequestLogger.http).toHaveBeenCalledWith(
                'Request completed',
                {
                    statusCode: 500, // Default when missing
                    status: 'success', // errored is falsy so shows 'success'
                    duration: expect.any(Number),
                }
            );
        });
    });

    describe('Handler factory and initialization', () => {
        it('should create handler function with proper configuration', () => {
            const handler = handleStreamableHttp(mockMcpServerConfig);
            expect(typeof handler).toBe('function');
        });

        it('should initialize sub-handlers correctly', async () => {
            const {handleStreamablePost} = await import('./streamable-post-handler.js');
            const {handleStreamableGet} = await import('./streamable-get-handler.js');
            const {handleStreamableDelete} = await import('./streamable-delete-handler.js');

            // Clear mocks to check initialization calls
            vi.clearAllMocks();

            handleStreamableHttp(mockMcpServerConfig);

            // Verify sub-handlers are initialized during factory creation
            expect(handleStreamablePost).toHaveBeenCalledWith(mockMcpServerConfig);
            expect(handleStreamableGet).toHaveBeenCalledWith();
            expect(handleStreamableDelete).toHaveBeenCalledWith();
        });

        it('should create independent handler instances', () => {
            const handler1 = handleStreamableHttp(mockMcpServerConfig);
            const handler2 = handleStreamableHttp(mockMcpServerConfig);

            // Handlers should be different function instances
            expect(handler1).not.toBe(handler2);
            expect(typeof handler1).toBe('function');
            expect(typeof handler2).toBe('function');
        });

        it('should handle concurrent requests with same handler instance', async () => {
            const {handleStreamablePost} = await import('./streamable-post-handler.js');

            const mockPostHandler = vi.fn().mockResolvedValue(undefined);
            vi.mocked(handleStreamablePost).mockReturnValue(mockPostHandler);

            // Create two different requests
            const req1 = { ...mockReq, url: '/mcp/request1' };
            const req2 = { ...mockReq, url: '/mcp/request2' };

            const handler = handleStreamableHttp(mockMcpServerConfig);

            // Execute requests concurrently
            await Promise.all([
                handler(req1 as Request, mockRes as Response),
                handler(req2 as Request, mockRes as Response),
            ]);

            // Verify both requests were processed
            expect(mockPostHandler).toHaveBeenCalledTimes(2);
        });
    });
});