/**
 * This must ONLY deal with the StreamableHTTPTransport
 */
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import type {McpServerConfig} from "@fireflyagents/mcp-server-types";
import type {Request, Response} from "express";
import {createRequestContext, handleAuthenticationError, isAuthenticationError} from "../utils/index.js";
import {handleStreamablePost} from "./streamable-post-handler.js";
import {handleStreamableDelete} from "./streamable-delete-handler.js";
import {handleStreamableGet} from "./streamable-get-handler.js";
import {extractAuthContext} from "../auth/extract-auth.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:streamable-http-handler'})

// TODO: Handle Protocol Version per spec: https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#protocol-version-header

export function handleStreamableHttp(mcpServerConfig: McpServerConfig) {

    logger.debug('Initializing StreamableHTTP handler with config: ', {mcpServerConfig});

    const streamablePostHandler = handleStreamablePost(mcpServerConfig);
    const streamableGetHandler = handleStreamableGet();
    const streamableDeleteHandler = handleStreamableDelete();

    return async (req: Request, res: Response): Promise<void> => {
        // Step 1: Set up request context logger
        const context = createRequestContext(req, logger);
        try {
            // Step 2: Validate API Key Authentication
            const authContext = await extractAuthContext(req.headers, mcpServerConfig);

            // Step 3: Route GET vs POST vs DELETE
            const httpMethod = req.method;
            switch (httpMethod) {
                case 'POST':
                    return await streamablePostHandler(context, req, res, authContext);
                case 'GET':
                    return await streamableGetHandler(context, req, res, authContext);
                case 'DELETE':
                    return await streamableDeleteHandler(context, req, res, authContext);
                default:
                    // Invalid HTTP method for SSE Protocol, return 405 Method Not Allowed? (Check Old Spec)
                    logger.error(`Invalid HTTP method: ${httpMethod}`);
                    throw new Error(`Invalid HTTP method: ${httpMethod}`);
            }

        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';

            // Check if this is an authentication error
            if (isAuthenticationError(errorMessage)) {
                return handleAuthenticationError(req, res, context, errorMessage);
            }

            logger.error('Error handling request:', error);
            if (!res.headersSent) {
                res.status(500).json({
                    jsonrpc: '2.0',
                    id: context.requestId,
                    error: {
                        code: -32603,
                        message: 'Internal Server Error: Error handling request',
                    },
                });
            }

        } finally {
            context.requestLogger.http('Request completed', {
                statusCode: res.statusCode || 500,
                status: res.errored ? 'error' : 'success',
                duration: Date.now() - context.startTime
            });
        }
    }
}
