/**
 * Handles StreamableHTTP POST requests
 */
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import type {ExtendedAuthContext, McpServerConfig} from "@fireflyagents/mcp-server-types";
import type {Request, Response} from "express";
import {randomUUID} from "crypto";
import {getUnifiedSessionStore} from "../services/unified-session-store.js";
import {StreamableHTTPServerTransport} from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import {isInitializeRequest} from "../utils/mcp-helpers.js";
import {RequestContext} from "@fireflyagents/mcp-server-types";
import {injectAuthContext} from "../utils/request-helpers.js";
import {PlatformAuthService} from "../services/platform-auth-service.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:streamable-post-handler' });

export function handleStreamablePost(mcpServerConfig: McpServerConfig) {

    return async (context: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext) => {
        let sessionId: string | null = null;

        context.requestLogger.debug('StreamableHTTP request received', {
            contentType: req.headers['content-type'],
            contentLength: req.headers['content-length'],
            accept: req.headers.accept,
            clientIp: req.ip,
            origin: req.headers.origin,
            sessionIdHeader: req.headers['mcp-session-id'],
            mcpMethod: req.body?.method || '',
        });

        try {
            const unifiedStore = getUnifiedSessionStore();
            const tenantId = authContext.tenantId || 'default';

            // Check if there's an existing session ID in the request (header or query param)
            const sessionId = req.headers['mcp-session-id'] as string;

            if (sessionId && unifiedStore.isValidSession(sessionId, tenantId)) {
                // Existing session found, use it
                context.requestLogger.debug('Using existing transport', {
                    reuseSession: true,
                    acceptHeader: req.headers.accept,
                    contentType: req.headers['content-type']
                });
                return await handleWithExistingSession(sessionId, context, req, res, authContext);

            } else if (!sessionId && isInitializeRequest(req.body)) {
                // New Initialisation request
                context.requestLogger.debug('Creating new transport', {});
                return await handleInitialization(mcpServerConfig, context, req, res, authContext);

            } else {
              // Invalid request - no session ID or not initialization request
                /**
                 * Spec states:
                 * Servers that require a session ID SHOULD respond to requests without an Mcp-Session-Id header (other than initialization) with HTTP 400 Bad Request. [https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#session-management]
                 * The GET handler MUST NOT create a new session if no session ID is provided, since the client should POST an Initialization message to create a new session.
                 */
                if (!sessionId) {
                    context.requestLogger.error('Missing session ID', { sessionId });
                    // res.status(400).send('Missing session ID');
                    res.status(400).json({
                        jsonrpc: '2.0',
                        id: context.requestId,
                        error: {
                            code: -32000,
                            message: 'Bad Request: Missing session ID',
                        },
                    });
                    return;
                }

                // Session ID is provided, check if it's valid and exists
                /**
                 * Spec states:
                 * The server MAY terminate the session at any time, after which it MUST respond to requests containing that session ID with HTTP 404 Not Found. [https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#session-management]
                 *
                 */
                if (!unifiedStore.isValidSession(sessionId, tenantId)) {
                    context.requestLogger.error('Invalid session ID', { sessionId });
                    // res.status(404).send('Invalid session ID');
                    res.status(404).json({
                      jsonrpc: '2.0',
                      id: context.requestId,
                      error: {
                        code: -32001,
                        message: 'Not Found: Invalid session ID',
                      },
                    });
                    return;
                }

              //
              // context.requestLogger.error('No valid session ID provided or not an initialization request', { sessionId });
              // res.status(400).json({
              //   jsonrpc: '2.0',
              //   error: {
              //     code: -32000,
              //     message: 'Bad Request: No valid session ID provided or not an initialization request',
              //   },
              //   id: null,
              // });
              // return;
            }

        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            logger.error('Error handling Streamable POST request', { error: errorMessage, sessionId });
            // Let the error bubble up to the global error handler:
            throw error;
        }
    }
}

async function handleWithExistingSession(sessionId: string, context: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext) {
    const unifiedStore = getUnifiedSessionStore();
    const sessionLogger = context.requestLogger.child({ sessionId: sessionId });

    // Inject auth context for tool handlers
    injectAuthContext(sessionId, req, authContext, sessionLogger);
    sessionLogger.debug('Auth context injected into request', { reqAuth: (req as any).auth });

    // Get transport from unified store
    const transport = await unifiedStore.getTransport(sessionId) as StreamableHTTPServerTransport;
    await transport.handleRequest(req, res, req.body);
    return;
}

async function handleInitialization(mcpServerConfig: McpServerConfig, context: RequestContext, req: Request, res: Response, authContext: ExtendedAuthContext) {
    const unifiedStore = getUnifiedSessionStore();

    const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => randomUUID(),
        onsessioninitialized: async (sessionId) => {
            // Store the transport by session ID when session is initialized
            // This avoids race conditions where requests might come in before the session is stored
            context.requestLogger.debug(`Session initialized with ID: ${sessionId}`);

            // Create session with server instance - all in one place
            const server = await unifiedStore.createSession(
                sessionId,
                transport,
                authContext
            );

            // Connect transport to server
            await server.connect(transport);

            // Perform OAuth authentication if platform credentials exist
            await PlatformAuthService.authenticateOnSessionCreation(
                sessionId,
                authContext,
                mcpServerConfig
            );
        },
        onsessionclosed: async (sessionId) => {
            context.requestLogger.info(`StreamableHTTP session closed: ${sessionId}`);
            await unifiedStore.removeSession(sessionId);
        }
    })

    // Set up onclose handler to clean up transport when closed
    transport.onclose = async () => {
        const sid = transport.sessionId;
        if (sid && await unifiedStore.hasSession(sid)) {
            context.requestLogger.info(`Transport closed for session ${sid}, removing from sessions`);
            await unifiedStore.removeSession(sid);
        }
    };

    // Handle the initialization request immediately to initialise the session
    await transport.handleRequest(req, res, req.body);
    return;
}