import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import { getUnifiedSessionStore } from '../services/unified-session-store.js';
import {handleLegacySseGet} from './sse-get-handler.js';
import type {Request, Response} from 'express';
import type {ExtendedAuthContext, McpServerConfig} from '@fireflyagents/mcp-server-types';
import type {RequestContext} from '@fireflyagents/mcp-server-types';
import {SSEServerTransport} from '@modelcontextprotocol/sdk/server/sse.js';

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});

vi.mock('../services/transport-store.js', () => ({
    transportStore: {
        setAsync: vi.fn(),
        getAsync: vi.fn(),
        hasAsync: vi.fn(),
        removeAsync: vi.fn(),
    },
}));

vi.mock('../services/unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn()
}));

vi.mock('../services/platform-auth-service.js', () => ({
    PlatformAuthService: {
        authenticateOnSessionCreation: vi.fn().mockResolvedValue(undefined),
    },
}));

vi.mock('../factory/mcp-server-factory.js', () => ({
    createMcpServer: vi.fn(),
}));

vi.mock('@modelcontextprotocol/sdk/server/sse.js', () => {
    const MockSSEServerTransport = vi.fn().mockImplementation((_endpoint, _res) => ({
        sessionId: 'mock-session-id',
        onclose: undefined,
    }));
    return {SSEServerTransport: MockSSEServerTransport};
});

describe('handleLegacySseGet', () => {
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockAuthContext: ExtendedAuthContext;
    let mockRequestContext: RequestContext;
    let mockMcpServerConfig: McpServerConfig;
    let mockMcpServer: any;
    let mockSessionLogger: any;
    let mockStore: any;

    beforeEach(async () => {
        vi.clearAllMocks();
        // Setup unified store mock
        const mockTransport = {
            handleRequest: vi.fn().mockResolvedValue(undefined),
            sessionId: 'test-session-id',
        };

        mockStore = {
            isValidSession: vi.fn().mockReturnValue(true),
            hasSession: vi.fn().mockResolvedValue(true),
            getTransport: vi.fn().mockResolvedValue(mockTransport),
            createSession: vi.fn().mockResolvedValue({ connect: vi.fn().mockResolvedValue(undefined) }),
            removeSession: vi.fn().mockResolvedValue(true),
            getSession: vi.fn().mockResolvedValue({
                tenantId: 'test-tenant',
                authContext: {
                    clientMetadata: {
                        accountId: 'test-account',
                        retailerId: 'test-retailer',
                    },
                },
                platformTokens: {
                    default: {
                        accessToken: 'test-access-token-12345',
                        expiresAt: new Date(Date.now() + 3600000),
                    }
                }
            }),
            getPlatformToken: vi.fn().mockReturnValue({
                accessToken: 'test-access-token-12345',
                expiresAt: new Date(Date.now() + 3600000),
            }),
            getSessionCount: vi.fn().mockReturnValue(0)
        };

        (getUnifiedSessionStore as any).mockReturnValue(mockStore);


        // Mock session logger
        mockSessionLogger = {
            debug: vi.fn(),
            info: vi.fn(),
            warn: vi.fn(),
            error: vi.fn(),
            http: vi.fn(),
        };

        // Mock request
        mockReq = {
            headers: {
                accept: 'text/event-stream',
                'user-agent': 'test-client',
            },
            body: {},
            ip: '127.0.0.1',
            on: vi.fn(),
        };

        // Mock response
        mockRes = {
            on: vi.fn(),
            status: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
        };

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Mock request context
        mockRequestContext = {
            requestId: 'test-request-id',
            startTime: Date.now() - 100, // Set a past time for positive setupDuration
            sessionId: null,
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
                child: vi.fn().mockReturnValue(mockSessionLogger),
            },
        };

        // Mock MCP server config
        mockMcpServerConfig = {
            name: 'test-server',
            version: '1.0.0',
            authHandlers: [],
        };

        // Mock MCP server
        mockMcpServer = {
            connect: vi.fn().mockResolvedValue(undefined),
        };

        // Import mocked modules after mocks are set up
        const {createMcpServer} = await import('../factory/mcp-server-factory.js');
        vi.mocked(createMcpServer).mockResolvedValue(mockMcpServer);
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('Successful SSE connection creation', () => {
        it('should successfully create an SSE connection and store transport', async () => {

            const {PlatformAuthService} = await import('../services/platform-auth-service.js');
            // const {createMcpServer} = await import('../factory/mcp-server-factory.js');

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify SSE transport was created
            expect(SSEServerTransport).toHaveBeenCalledWith('mcp/messages', mockRes);

            // Verify session was created with transport and authContext
            expect(mockStore.createSession).toHaveBeenCalledWith('mock-session-id', expect.any(Object), mockAuthContext);

            // Verify OAuth authentication was attempted
            expect(PlatformAuthService.authenticateOnSessionCreation).toHaveBeenCalledWith(
                'mock-session-id',
                mockAuthContext,
                mockMcpServerConfig
            );

            // Server creation happens inside createSession (mocked), so we verify session was created
            expect(mockStore.createSession).toHaveBeenCalled();
        });

        it('should setup transport onclose handler for cleanup', async () => {

            let mockTransport: any;

            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify onclose handler was set
            expect(mockTransport.onclose).toBeDefined();
            expect(typeof mockTransport.onclose).toBe('function');

            // Test onclose handler functionality
            await mockTransport.onclose();
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should setup request and response event handlers', async () => {
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify request close event listener was set
            expect(mockReq.on).toHaveBeenCalledWith('close', expect.any(Function));

            // Verify response finish event listener was set
            expect(mockRes.on).toHaveBeenCalledWith('finish', expect.any(Function));
        });

        it('should use default tenant when tenantId is not provided', async () => {

            const authContextWithoutTenant = {
                ...mockAuthContext,
                tenantId: undefined,
            };

            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, authContextWithoutTenant);

            expect(mockStore.createSession).toHaveBeenCalledWith('mock-session-id', expect.any(Object), authContextWithoutTenant);
        });

        it('should log request information and session creation', async () => {
            vi.mocked(mockStore.getSessionCount).mockReturnValue(1);
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Get the mocked logger from the utils module
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            // Verify initial logging of request using the shared mock logger
            expect(mockModuleLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE GET request received',
                {
                    reqHeaders: mockReq.headers,
                    reqBody: mockReq.body,
                }
            );

            // Verify session logger was created
            expect(mockRequestContext.requestLogger.child).toHaveBeenCalledWith({sessionId: 'mock-session-id'});

            // Verify session creation logging
            expect(mockSessionLogger.debug).toHaveBeenCalledWith(
                'Creating new Legacy SSE session',
                {
                    newSession: true,
                    transportType: 'SSE',
                }
            );

            // Verify connection establishment logging
            expect(mockSessionLogger.http).toHaveBeenCalledWith(
                'SSE connection established',
                expect.objectContaining({
                    tenantId: 'test-tenant',
                    setupDuration: expect.any(Number),
                })
            );
        });
    });

    describe('Error handling', () => {
        it('should cleanup session when transport creation fails', async () => {

            const error = new Error('Transport creation failed');
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                throw error;
            });

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport creation failed');

            // Session should not be created since transport creation failed before session creation
            expect(mockStore.createSession).not.toHaveBeenCalled();
        });

        it('should cleanup session when createSession fails', async () => {
            const error = new Error('Session creation failed');
            vi.mocked(mockStore.createSession).mockRejectedValue(error);
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Session creation failed');

            // Verify session was cleaned up
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should cleanup session when transport store fails', async () => {

            const error = new Error('Transport store failed');
            vi.mocked(mockStore.createSession).mockRejectedValue(error);
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport store failed');

            // Verify session was cleaned up
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should handle OAuth authentication failure gracefully', async () => {

            const {PlatformAuthService} = await import('../services/platform-auth-service.js');

            const error = new Error('OAuth failed');
            vi.mocked(PlatformAuthService.authenticateOnSessionCreation).mockRejectedValue(error);
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('OAuth failed');

            // Verify session was cleaned up
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });
    });

    describe('Transport onclose cleanup', () => {
        it('should handle transport onclose cleanup with sessionId', async () => {

            let mockTransport: any;

            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Test onclose handler with sessionId
            await mockTransport.onclose();
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should handle transport onclose cleanup without sessionId', async () => {

            let mockTransport: any;

            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: null,
                    onclose: undefined,
                };
                return mockTransport;
            });

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Test onclose handler without sessionId
            await mockTransport.onclose();
            expect(mockStore.removeSession).not.toHaveBeenCalled();
        });
    });

    describe('Edge cases and boundary conditions', () => {
        it('should handle missing authContext gracefully', async () => {

            const minimalAuthContext = {} as ExtendedAuthContext;
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, minimalAuthContext);

            // Should still work with minimal auth context
            expect(mockStore.createSession).toHaveBeenCalledWith('mock-session-id', expect.any(Object), minimalAuthContext);
        });

        it('should handle missing request headers gracefully', async () => {
            mockReq.headers = {};

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should still work with empty headers
            expect(SSEServerTransport).toHaveBeenCalledWith('mcp/messages', mockRes);
        });

        it('should handle missing request body gracefully', async () => {
            delete mockReq.body;
            let mockTransport: any;
            vi.mocked(SSEServerTransport).mockImplementation(() => {
                mockTransport = {
                    sessionId: 'mock-session-id',
                    onclose: undefined,
                };
                return mockTransport;
            });
            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Get the mocked logger from the utils module
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            // Should still work with missing body using the shared mock logger
            expect(mockModuleLogger.debug).toHaveBeenCalledWith(
                'Legacy SSE GET request received',
                {
                    reqHeaders: mockReq.headers,
                    reqBody: undefined,
                }
            );
        });

        it('should use transport sessionId when available', async () => {

            const customSessionId = 'custom-session-123';

            vi.mocked(SSEServerTransport).mockImplementation(() => ({
                sessionId: customSessionId,
                onclose: undefined,
            } as any));

            const handler = handleLegacySseGet(mockMcpServerConfig);

            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            expect(mockStore.createSession).toHaveBeenCalledWith(customSessionId, expect.any(Object), mockAuthContext);
        });
    });
});