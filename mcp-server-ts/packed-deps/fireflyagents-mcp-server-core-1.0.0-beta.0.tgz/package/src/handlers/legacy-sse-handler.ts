/**
 * This must ONLY deal with the SSETransport
 * The deprecated HTTP+SSE transport (protocol version 2024-11-05)
 * - /sse: The deprecated SSE endpoint for older clients (GET to establish stream)
 * - /messages: The deprecated POST endpoint for older clients (POST to send messages)
 *
 * It does not need to check the Accept header.
 */
import {logger as baseLogger} from "@fireflyagents/mcp-shared-utils";
import type {McpServerConfig} from "@fireflyagents/mcp-server-types";
import type {Request, Response} from "express";
import {handleLegacySseGet} from "./sse-get-handler.js";
import {handleLegacySsePost} from "./sse-post-handler.js";
import {createRequestContext, handleAuthenticationError, isAuthenticationError} from "../utils/request-helpers.js";
import {extractAuthContext} from "../auth/extract-auth.js";

const logger = baseLogger.child({ context: 'fa-mcp:core:legacy-sse-handler'})

// TODO: Handle Protocol Version per spec: https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#protocol-version-header

export function handleLegacySse(mcpServerConfig: McpServerConfig) {

    const legacySSEGetHandler = handleLegacySseGet(mcpServerConfig);
    const legacySSEPostHandler = handleLegacySsePost();

    return async (req: Request, res: Response): Promise<void> => {
        // Step 1: Set up request context logger
        const context = createRequestContext(req, logger);

        try {
            // Step 2: Validate API Key Authentication
            // // Extract authentication context from request headers using configured ApiKeyStore
            const authContext = await extractAuthContext(req.headers, mcpServerConfig);
            // const tenantId = authContext.tenantId || 'default';


            // Step 3: Route GET vs POST
            const httpMethod = req.method;
            switch (httpMethod) {
                case 'GET':
                    // GET Request to /sse endpoint establishes new SSE session
                    return await legacySSEGetHandler(context, req, res, authContext);
                case 'POST':
                    // POST Request to /messages endpoint sends messages to existing SSE session
                    return await legacySSEPostHandler(context, req, res, authContext);
                default:
                    // Invalid HTTP method for SSE Protocol, return 405 Method Not Allowed? (Check Old Spec)
                    logger.error(`Invalid HTTP method: ${httpMethod}`);
                    throw new Error(`Invalid HTTP method: ${httpMethod}`);
            }
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';

            // Check if this is an authentication error
            if (isAuthenticationError(errorMessage)) {
                return handleAuthenticationError(req, res, context, errorMessage);
            }

            logger.error('Error handling request:', error);
            if (!res.headersSent) {
                res.status(500).send('Error handling request');
            }

        } finally {
            context.requestLogger.http('Request completed', {
                statusCode: res.statusCode || 500,
                status: res.errored ? 'error' : 'success',
                duration: Date.now() - context.startTime
            });
        }
    }
}