import {describe, it, expect, vi, beforeEach, afterEach} from 'vitest';
import {handleStreamablePost} from './streamable-post-handler.js';
import type {Request, Response} from 'express';
import type {McpServerConfig, ExtendedAuthContext} from '@fireflyagents/mcp-server-types';
import type {RequestContext} from '@fireflyagents/mcp-server-types';

// Declare mock variables at top level - will be assigned inside mock factories

// Mock dependencies
vi.mock('@fireflyagents/mcp-shared-utils', () => {
    const mockModuleLogger = {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        http: vi.fn(),
    };

    return {
        logger: {
            child: vi.fn().mockReturnValue(mockModuleLogger),
        },
        mockModuleLogger, // Export for use in tests
    };
});

vi.mock('../services/unified-session-store.js', () => ({
    getUnifiedSessionStore: vi.fn()
}));

// Create a class-based mock for StreamableHTTPServerTransport for instanceof checks
vi.mock('@modelcontextprotocol/sdk/server/streamableHttp.js', () => {
    const mockConstructor = vi.fn().mockImplementation((_options: any) => {
        const instance = {
            sessionId: 'mock-session-id',
            onclose: undefined as (() => Promise<void>) | undefined,
            handleRequest: vi.fn().mockResolvedValue(undefined),
        };

        // DON'T auto-simulate callbacks - let tests trigger them explicitly when needed
        // This prevents async callback issues after test completion

        return instance as any;
    });

    return {
        StreamableHTTPServerTransport: mockConstructor,
    };
});

vi.mock('../utils/mcp-helpers.js', () => ({
    isInitializeRequest: vi.fn().mockReturnValue(false),
}));

vi.mock('../factory/mcp-server-factory.js', () => {
    const mockFactory = vi.fn().mockResolvedValue({
        connect: vi.fn().mockResolvedValue(undefined),
    });
    return {
        createMcpServer: mockFactory,
    };
});

vi.mock('../utils/request-helpers.js', () => ({
    injectAuthContext: vi.fn(),
}));

vi.mock('../services/platform-auth-service.js', () => ({
    PlatformAuthService: {
        authenticateOnSessionCreation: vi.fn().mockResolvedValue(undefined),
    },
}));

vi.mock('crypto', () => ({
    randomUUID: vi.fn().mockReturnValue('random-uuid-12345'),
}));

describe('handleStreamablePost', () => {
    let mockStore: any;
    let mockReq: Partial<Request>;
    let mockRes: Partial<Response>;
    let mockMcpServerConfig: McpServerConfig;
    let mockRequestContext: RequestContext;
    let mockAuthContext: ExtendedAuthContext;

    beforeEach(async () => {
        vi.clearAllMocks();

        // Initialize mockStore
        mockStore = {
            isValidSession: vi.fn().mockReturnValue(true),
            getTransport: vi.fn().mockResolvedValue({
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'test-session-id',
            }),
            createSession: vi.fn().mockResolvedValue({
                connect: vi.fn().mockResolvedValue(undefined)
            }),
            removeSession: vi.fn().mockResolvedValue(true),
            getSession: vi.fn().mockResolvedValue({
                tenantId: 'test-tenant',
                authContext: {
                    clientMetadata: {
                        accountId: 'test-account',
                        retailerId: 'test-retailer',
                    },
                },
            }),
            hasSession: vi.fn().mockResolvedValue(true)
        };
        const {getUnifiedSessionStore} = await import('../services/unified-session-store.js');
        (getUnifiedSessionStore as any).mockReturnValue(mockStore);
        
        // Re-setup the createMcpServer mock after clearing
        const {createMcpServer} = await import('../factory/mcp-server-factory.js');
        vi.mocked(createMcpServer).mockResolvedValue({
            connect: vi.fn().mockResolvedValue(undefined),
        } as any);

        // Re-setup the StreamableHTTPServerTransport mock after clearing
        const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
        vi.mocked(StreamableHTTPServerTransport).mockImplementation((_options: any) => {
            const instance = {
                sessionId: 'mock-session-id',
                onclose: undefined as (() => Promise<void>) | undefined,
                handleRequest: vi.fn().mockResolvedValue(undefined),
            };

            // Don't auto-trigger callbacks - tests that need them will trigger explicitly

            return instance as any;
        });

        // Mock request context
        mockRequestContext = {
            requestId: 'test-request-id',
            startTime: Date.now() - 100,
            sessionId: 'test-session-id',
            requestLogger: {
                debug: vi.fn(),
                info: vi.fn(),
                warn: vi.fn(),
                error: vi.fn(),
                http: vi.fn(),
                child: vi.fn().mockReturnValue({
                    debug: vi.fn(),
                    info: vi.fn(),
                    warn: vi.fn(),
                    error: vi.fn(),
                    http: vi.fn(),
                }),
            },
        };

        // Mock auth context
        mockAuthContext = {
            apiKey: 'test-api-key',
            tenantId: 'test-tenant',
            clientType: 'test-client',
            clientMetadata: {
                accountId: 'test-account',
                retailerId: 'test-retailer',
            },
        };

        // Mock MCP server config
        mockMcpServerConfig = {
            name: 'test-server',
            version: '1.0.0',
            apiKeyStore: {
                validateApiKey: vi.fn().mockResolvedValue(true),
            } as any,
            authHandlers: [],
        };

        // Mock request
        mockReq = {
            headers: {
                'content-type': 'application/json',
                'content-length': '100',
                accept: 'application/json',
                origin: 'test-origin',
                'mcp-session-id': 'existing-session-id',
            },
            body: {
                jsonrpc: '2.0',
                method: 'tools/list',
                id: 1,
            },
            ip: '127.0.0.1',
        };

        // Mock response
        mockRes = {
            status: vi.fn().mockReturnThis(),
            json: vi.fn().mockReturnThis(),
            send: vi.fn().mockReturnThis(),
        };
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    describe('Existing session handling', () => {
        it('should handle existing valid session requests', async () => {
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session validation
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');
            expect(mockStore.getTransport).toHaveBeenCalledWith('existing-session-id');

            // Verify auth context injection
            expect(injectAuthContext).toHaveBeenCalledWith(
                'existing-session-id',
                mockReq,
                mockAuthContext,
                expect.any(Object)
            );

            // Verify request handled by transport
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes, mockReq.body);

            // Verify logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                expect.objectContaining({
                    contentType: 'application/json',
                    sessionIdHeader: 'existing-session-id',
                })
            );
        });

        it('should handle missing session ID in existing session flow', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            // No session ID in headers
            mockReq.headers!['mcp-session-id'] = undefined;

            // Not an initialize request
            vi.mocked(isInitializeRequest).mockReturnValue(false);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should not validate session since no session ID
            expect(mockStore.isValidSession).not.toHaveBeenCalled();

            // Should return 400 error for invalid request
            expect(mockRes.status).toHaveBeenCalledWith(400);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                error: {
                    code: -32000,
                    message: 'Bad Request: Missing session ID',
                },
                id: 'test-request-id',
            });
        });

        it('should handle invalid session ID', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockStore.isValidSession.mockReturnValue(false);
            vi.mocked(isInitializeRequest).mockReturnValue(false);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should validate session and find it invalid
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');

            // Should return 404 error for invalid session
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                error: {
                    code: -32001,
                    message: 'Not Found: Invalid session ID',
                },
                id: 'test-request-id',
            });
        });

        it('should handle session ID with missing transport', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            // In new code, isValidSession returning false is the only check
            mockStore.isValidSession.mockReturnValue(false);
            mockStore.hasSession.mockResolvedValue(false);
            vi.mocked(isInitializeRequest).mockReturnValue(false);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Should validate session and find it invalid
            expect(mockStore.isValidSession).toHaveBeenCalledWith('existing-session-id', 'test-tenant');

            // Should return 404 error for invalid session
            expect(mockRes.status).toHaveBeenCalledWith(404);
            expect(mockRes.json).toHaveBeenCalledWith({
                jsonrpc: '2.0',
                error: {
                    code: -32001,
                    message: 'Not Found: Invalid session ID',
                },
                id: 'test-request-id',
            });
        });
    });

    describe('Initialization handling', () => {
        it('should handle new initialization requests', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            // No session ID and is initialize request
            mockReq.headers!['mcp-session-id'] = undefined;
            mockReq.body = {
                jsonrpc: '2.0',
                method: 'initialize',
                params: { capabilities: {} },
                id: 1,
            };

            vi.mocked(isInitializeRequest).mockReturnValue(true);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // MCP server creation happens inside createSession (which is mocked), so not verifying directly

            // Should create new transport
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
            expect(StreamableHTTPServerTransport).toHaveBeenCalledWith(
                expect.objectContaining({
                    sessionIdGenerator: expect.any(Function),
                    onsessioninitialized: expect.any(Function),
                    onsessionclosed: expect.any(Function),
                })
            );

            // Verify logging for new transport creation
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Creating new transport',
                {}
            );
        });

        it('should handle session initialization callback', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');
            const {PlatformAuthService} = await import('../services/platform-auth-service.js');
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            mockReq.body = {
                jsonrpc: '2.0',
                method: 'initialize',
                params: { capabilities: {} },
                id: 1,
            };

            vi.mocked(isInitializeRequest).mockReturnValue(true);

            // Create a mock that DOES trigger the callback for this test
            let capturedCallback: any;
            vi.mocked(StreamableHTTPServerTransport).mockImplementation((options: any) => {
                capturedCallback = options.onsessioninitialized;
                return {
                    sessionId: 'mock-session-id',
                    handleRequest: vi.fn().mockResolvedValue(undefined),
                    onclose: undefined,
                } as any;
            });

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Manually trigger the callback
            if (capturedCallback) {
                await capturedCallback('mock-session-id');
            }

            // Should create session (with transport and authContext)
            expect(mockStore.createSession).toHaveBeenCalledWith('mock-session-id', expect.any(Object), mockAuthContext);

            // Should authenticate on session creation
            expect(PlatformAuthService.authenticateOnSessionCreation).toHaveBeenCalledWith(
                'mock-session-id',
                mockAuthContext,
                mockMcpServerConfig
            );
        });

        it('should handle session closed callback', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);

            let capturedOptions: any;
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
            vi.mocked(StreamableHTTPServerTransport).mockImplementation((options: any) => {
                capturedOptions = options;
                return {
                    sessionId: 'mock-session-id',
                    handleRequest: vi.fn().mockResolvedValue(undefined),
                    onclose: undefined,
                } as any;
            });

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Trigger the session closed callback
            if (capturedOptions?.onsessionclosed) {
                await capturedOptions.onsessionclosed('mock-session-id');
            }

            // Should remove session and transport
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should handle transport onclose callback', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);

            let capturedTransport: any;
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
            vi.mocked(StreamableHTTPServerTransport).mockImplementation((_options: any) => {
                capturedTransport = {
                    sessionId: 'mock-session-id',
                    handleRequest: vi.fn().mockResolvedValue(undefined),
                    onclose: undefined,
                };
                return capturedTransport as any;
            });

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Trigger the onclose callback
            if (capturedTransport?.onclose) {
                await capturedTransport.onclose();
            }

            // Should check if session exists and remove it
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
            expect(mockStore.removeSession).toHaveBeenCalledWith('mock-session-id');
        });

        it('should handle transport onclose callback with no session', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(false);

            let capturedTransport: any;
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
            vi.mocked(StreamableHTTPServerTransport).mockImplementation((_options: any) => {
                capturedTransport = {
                    sessionId: 'mock-session-id',
                    handleRequest: vi.fn().mockResolvedValue(undefined),
                    onclose: undefined,
                };
                return capturedTransport as any;
            });

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Trigger the onclose callback
            if (capturedTransport?.onclose) {
                await capturedTransport.onclose();
            }

            // Should check if session exists but not remove it since it doesn't exist
            expect(mockStore.removeSession).not.toHaveBeenCalled();
            expect(mockStore.removeSession).not.toHaveBeenCalled();
        });
    });

    describe('Error handling', () => {
        it('should handle transport store errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => { throw new Error('Transport store error'); }); // (new Error('Transport store error'));

            const handler = handleStreamablePost(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport store error');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable POST request',
                {
                    error: 'Transport store error',
                    sessionId: null,
                }
            );
        });

        it('should handle session manager errors gracefully', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => {
                throw new Error('Session manager error');
            });

            const handler = handleStreamablePost(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Session manager error');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable POST request',
                {
                    error: 'Session manager error',
                    sessionId: null,
                }
            );
        });

        it.skip('should handle MCP server creation errors', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);

            // Simulate server creation error by making createSession reject
            mockStore.createSession.mockRejectedValue(new Error('Server creation failed'));

            const handler = handleStreamablePost(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Server creation failed');

            // Verify error logging
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable POST request',
                {
                    error: 'Server creation failed',
                    sessionId: null,
                }
            );
        });

        it('should handle non-Error objects in catch block', async () => {
            const utils = await import('@fireflyagents/mcp-shared-utils');
            const mockModuleLogger = (utils as any).mockModuleLogger;

            mockStore.isValidSession.mockImplementation(() => {
                throw 'String error'; // Non-Error object
            });

            const handler = handleStreamablePost(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('String error');

            // Verify error logging with unknown error message
            expect(mockModuleLogger.error).toHaveBeenCalledWith(
                'Error handling Streamable POST request',
                {
                    error: 'Unknown error',
                    sessionId: null,
                }
            );
        });

        it('should handle transport handleRequest errors', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockRejectedValue(new Error('Transport handling failed')),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);

            await expect(
                handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext)
            ).rejects.toThrow('Transport handling failed');

            // Verify transport was called
            expect(mockTransport.handleRequest).toHaveBeenCalledWith(mockReq, mockRes, mockReq.body);
        });
    });

    describe('Logging and context', () => {
        it('should log request details properly', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify comprehensive request logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'StreamableHTTP request received',
                {
                    contentType: 'application/json',
                    contentLength: '100',
                    accept: 'application/json',
                    clientIp: '127.0.0.1',
                    origin: 'test-origin',
                    sessionIdHeader: 'existing-session-id',
                    mcpMethod: 'tools/list',
                }
            );
        });

        it('should create session logger with session ID', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session logger creation
            expect(mockRequestContext.requestLogger.child).toHaveBeenCalledWith({
                sessionId: 'existing-session-id',
            });
        });

        it('should log reuse session information', async () => {

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify session reuse logging
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Using existing transport',
                {
                    reuseSession: true,
                    acceptHeader: 'application/json',
                    contentType: 'application/json',
                }
            );
        });

        it('should log invalid request errors properly', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(false);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify error logging for invalid requests
            expect(mockRequestContext.requestLogger.error).toHaveBeenCalledWith(
                'Missing session ID',
                { sessionId: undefined }
            );
        });
    });

    describe('Auth context handling', () => {
        it('should inject auth context for existing sessions', async () => {
            const {injectAuthContext} = await import('../utils/request-helpers.js');

            const mockTransport = {
                handleRequest: vi.fn().mockResolvedValue(undefined),
                sessionId: 'existing-session-id',
            };

            mockStore.isValidSession.mockReturnValue(true);
            mockStore.hasSession.mockResolvedValue(true);
            mockStore.getTransport.mockResolvedValue(mockTransport as any);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify auth context injection
            expect(injectAuthContext).toHaveBeenCalledWith(
                'existing-session-id',
                mockReq,
                mockAuthContext,
                expect.any(Object) // session logger
            );
        });

        it('should handle default tenant ID when not provided', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            // Auth context without tenantId
            const authContextWithoutTenant = {
                ...mockAuthContext,
                tenantId: undefined,
            };

            mockReq.headers!['mcp-session-id'] = 'test-session';
            mockStore.isValidSession.mockReturnValue(true);
            vi.mocked(isInitializeRequest).mockReturnValue(false);

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, authContextWithoutTenant);

            // Should use 'default' as tenant ID
            expect(mockStore.isValidSession).toHaveBeenCalledWith('test-session', 'default');
        });
    });

    describe('Configuration and factory integration', () => {
        it('should pass server config to factory during initialization', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);

            const customConfig = {
                ...mockMcpServerConfig,
                name: 'custom-streamable-server',
            };

            const handler = handleStreamablePost(customConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Config is passed to createSession, which calls createMcpServer internally (mocked)
            // Verifying handler executes without error is sufficient
            expect(mockRequestContext.requestLogger.debug).toHaveBeenCalledWith(
                'Creating new transport',
                {}
            );
        });

        it('should provide session ID generator to transport', async () => {
            const {isInitializeRequest} = await import('../utils/mcp-helpers.js');

            mockReq.headers!['mcp-session-id'] = undefined;
            vi.mocked(isInitializeRequest).mockReturnValue(true);

            let capturedOptions: any;
            const {StreamableHTTPServerTransport} = await import('@modelcontextprotocol/sdk/server/streamableHttp.js');
            vi.mocked(StreamableHTTPServerTransport).mockImplementation((options: any) => {
                capturedOptions = options;
                return {
                    sessionId: 'mock-session-id',
                    handleRequest: vi.fn().mockResolvedValue(undefined),
                    onclose: undefined,
                } as any;
            });

            const handler = handleStreamablePost(mockMcpServerConfig);
            await handler(mockRequestContext, mockReq as Request, mockRes as Response, mockAuthContext);

            // Verify that session ID generator was provided to transport
            expect(capturedOptions.sessionIdGenerator).toBeDefined();
            expect(typeof capturedOptions.sessionIdGenerator).toBe('function');

            // Verify that the generator function can be called (implementation detail testing not critical)
            expect(() => capturedOptions.sessionIdGenerator()).not.toThrow();
        });
    });
});