import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { Resource, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:resource-filter' });

/**
 * Context provided to resource filters for decision making
 */
export interface ResourceFilterContext {
  tenantId: string;
  authContext: ExtendedAuthContext;
  availableResources: Resource[];
}

/**
 * Resource filter interface - implement to create custom filtering logic
 */
export interface ResourceFilter {
  name: string;
  filterResources(context: ResourceFilterContext): Resource[];
}

/**
 * Role-Based Resource Filter
 */
export class RoleBasedResourceFilter implements ResourceFilter {
  name = 'role-based-resources';

  filterResources(context: ResourceFilterContext): Resource[] {
    const userRoles = (context.authContext.clientMetadata?.roles as string[]) || [];

    logger.debug('Applying role-based resource filter', {
      tenantId: context.tenantId,
      userRoles,
      resourceCount: context.availableResources.length
    });

    const filteredResources = context.availableResources.filter(resource => {
      const requiredRoles = resource.options?.requiredRoles as string[] | undefined;
      if (!requiredRoles || requiredRoles.length === 0) return true;

      const hasAccess = requiredRoles.some(role => userRoles.includes(role));

      if (!hasAccess) {
        logger.debug('Resource filtered out by role', {
          resource: `${resource.namespace}__${resource.name}`,
          requiredRoles,
          userRoles
        });
      }

      return hasAccess;
    });

    logger.info('Role-based resource filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availableResources.length,
      filteredCount: filteredResources.length,
      removedCount: context.availableResources.length - filteredResources.length
    });

    return filteredResources;
  }
}

/**
 * Namespace Resource Filter
 */
export class NamespaceResourceFilter implements ResourceFilter {
  name = 'namespace-resources';

  constructor(private allowedNamespaces: string[]) {}

  filterResources(context: ResourceFilterContext): Resource[] {
    logger.debug('Applying namespace resource filter', {
      tenantId: context.tenantId,
      allowedNamespaces: this.allowedNamespaces,
      resourceCount: context.availableResources.length
    });

    const filteredResources = context.availableResources.filter(resource =>
      this.allowedNamespaces.includes(resource.namespace)
    );

    logger.info('Namespace resource filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availableResources.length,
      filteredCount: filteredResources.length
    });

    return filteredResources;
  }
}