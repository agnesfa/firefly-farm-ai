import { describe, it, expect } from 'vitest';
import {
  RoleBasedResourceFilter,
  NamespaceResourceFilter,
  type ResourceFilterContext
} from './resource-filter.js';
import type { Resource, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

describe('ResourceFilter', () => {
  const createMockResource = (namespace: string, name: string, options?: any): Resource => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    uriTemplate: `${namespace}://${name}`,
    handler: async () => ({ contents: [] }),
    options
  });

  const createMockContext = (roles: string[] = [], tenantId: string = 'tenant-1'): ResourceFilterContext => ({
    tenantId,
    authContext: {
      apiKey: 'test-key',
      tenantId,
      clientMetadata: { roles }
    } as ExtendedAuthContext,
    availableResources: []
  });

  describe('RoleBasedResourceFilter', () => {
    const filter = new RoleBasedResourceFilter();

    it('should allow resources with no role requirements', () => {
      const context = createMockContext(['user']);
      context.availableResources = [
        createMockResource('demo', 'public_resource')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_resource');
    });

    it('should filter out resources when user has no required roles', () => {
      const context = createMockContext(['user']);
      context.availableResources = [
        createMockResource('demo', 'admin_resource', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(0);
    });

    it('should allow resources when user has at least one required role', () => {
      const context = createMockContext(['manager', 'analyst']);
      context.availableResources = [
        createMockResource('demo', 'report_resource', { requiredRoles: ['admin', 'manager'] })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('report_resource');
    });

    it('should handle user with no roles', () => {
      const context = createMockContext([]);
      context.availableResources = [
        createMockResource('demo', 'public_resource'),
        createMockResource('demo', 'admin_resource', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_resource');
    });

    it('should allow resources when user has multiple matching roles', () => {
      const context = createMockContext(['admin', 'manager']);
      context.availableResources = [
        createMockResource('demo', 'admin_resource', { requiredRoles: ['admin'] }),
        createMockResource('demo', 'manager_resource', { requiredRoles: ['manager'] }),
        createMockResource('demo', 'user_resource', { requiredRoles: ['user'] })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(2);
      expect(result.map(r => r.name).sort()).toEqual(['admin_resource', 'manager_resource']);
    });

    it('should handle empty resource list', () => {
      const context = createMockContext(['admin']);
      context.availableResources = [];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(0);
    });

    it('should handle resources with empty requiredRoles array', () => {
      const context = createMockContext(['user']);
      context.availableResources = [
        createMockResource('demo', 'resource1', { requiredRoles: [] })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(1);
    });

    it('should handle resources with other options alongside requiredRoles', () => {
      const context = createMockContext(['admin']);
      context.availableResources = [
        createMockResource('demo', 'resource1', {
          requiredRoles: ['admin'],
          mimeType: 'application/json',
          experimental: true
        })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(1);
      expect(result[0].options?.mimeType).toBe('application/json');
      expect(result[0].options?.experimental).toBe(true);
    });
  });

  describe('NamespaceResourceFilter', () => {
    it('should only include resources from allowed namespaces', () => {
      const filter = new NamespaceResourceFilter(['demo', 'partner']);
      const context = createMockContext();
      context.availableResources = [
        createMockResource('demo', 'resource1'),
        createMockResource('partner', 'resource2'),
        createMockResource('admin', 'resource3')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(2);
      expect(result.map(r => r.namespace)).toEqual(['demo', 'partner']);
    });

    it('should return empty array when no resources match allowed namespaces', () => {
      const filter = new NamespaceResourceFilter(['allowed']);
      const context = createMockContext();
      context.availableResources = [
        createMockResource('demo', 'resource1'),
        createMockResource('partner', 'resource2')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(0);
    });

    it('should return all resources when all match allowed namespaces', () => {
      const filter = new NamespaceResourceFilter(['demo']);
      const context = createMockContext();
      context.availableResources = [
        createMockResource('demo', 'resource1'),
        createMockResource('demo', 'resource2')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(2);
    });

    it('should handle empty allowed namespaces gracefully', () => {
      const filter = new NamespaceResourceFilter([]);
      const context = createMockContext();
      context.availableResources = [
        createMockResource('demo', 'resource1')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(0);
    });

    it('should handle multiple namespaces with different resources', () => {
      const filter = new NamespaceResourceFilter(['config', 'docs']);
      const context = createMockContext();
      context.availableResources = [
        createMockResource('config', 'tsconfig'),
        createMockResource('config', 'package_json'),
        createMockResource('docs', 'readme'),
        createMockResource('api', 'swagger')
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(3);
      expect(result.map(r => r.name).sort()).toEqual(['package_json', 'readme', 'tsconfig']);
    });
  });

  describe('Combined Filtering Scenarios', () => {
    it('should work with role-based filter on resources with various metadata', () => {
      const filter = new RoleBasedResourceFilter();
      const context = createMockContext(['developer']);
      context.availableResources = [
        createMockResource('demo', 'public_docs'),
        createMockResource('demo', 'dev_config', {
          requiredRoles: ['developer', 'admin'],
          mimeType: 'application/json'
        }),
        createMockResource('demo', 'admin_secrets', {
          requiredRoles: ['admin'],
          mimeType: 'text/plain'
        })
      ];

      const result = filter.filterResources(context);
      expect(result).toHaveLength(2);
      expect(result.map(r => r.name).sort()).toEqual(['dev_config', 'public_docs']);
    });
  });
});