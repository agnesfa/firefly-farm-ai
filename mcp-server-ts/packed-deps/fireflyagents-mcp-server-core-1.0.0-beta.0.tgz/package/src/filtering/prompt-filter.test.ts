import { describe, it, expect } from 'vitest';
import {
  RoleBasedPromptFilter,
  NamespacePromptFilter,
  type PromptFilterContext
} from './prompt-filter.js';
import type { Prompt, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

describe('PromptFilter', () => {
  const createMockPrompt = (namespace: string, name: string, options?: any): Prompt => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    handler: async () => ({ messages: [] }),
    options
  });

  const createMockContext = (roles: string[] = [], tenantId: string = 'tenant-1'): PromptFilterContext => ({
    tenantId,
    authContext: {
      apiKey: 'test-key',
      tenantId,
      clientMetadata: { roles }
    } as ExtendedAuthContext,
    availablePrompts: []
  });

  describe('RoleBasedPromptFilter', () => {
    const filter = new RoleBasedPromptFilter();

    it('should allow prompts with no role requirements', () => {
      const context = createMockContext(['user']);
      context.availablePrompts = [
        createMockPrompt('demo', 'public_prompt')
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_prompt');
    });

    it('should filter out prompts when user has no required roles', () => {
      const context = createMockContext(['user']);
      context.availablePrompts = [
        createMockPrompt('demo', 'admin_prompt', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(0);
    });

    it('should allow prompts when user has at least one required role', () => {
      const context = createMockContext(['manager', 'analyst']);
      context.availablePrompts = [
        createMockPrompt('demo', 'report_prompt', { requiredRoles: ['admin', 'manager'] })
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('report_prompt');
    });

    it('should handle user with no roles', () => {
      const context = createMockContext([]);
      context.availablePrompts = [
        createMockPrompt('demo', 'public_prompt'),
        createMockPrompt('demo', 'admin_prompt', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_prompt');
    });

    it('should allow prompts when user has multiple matching roles', () => {
      const context = createMockContext(['admin', 'manager']);
      context.availablePrompts = [
        createMockPrompt('demo', 'admin_prompt', { requiredRoles: ['admin'] }),
        createMockPrompt('demo', 'manager_prompt', { requiredRoles: ['manager'] }),
        createMockPrompt('demo', 'user_prompt', { requiredRoles: ['user'] })
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(2);
      expect(result.map(p => p.name).sort()).toEqual(['admin_prompt', 'manager_prompt']);
    });

    it('should handle empty prompt list', () => {
      const context = createMockContext(['admin']);
      context.availablePrompts = [];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(0);
    });

    it('should handle prompts with empty requiredRoles array', () => {
      const context = createMockContext(['user']);
      context.availablePrompts = [
        createMockPrompt('demo', 'prompt1', { requiredRoles: [] })
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(1);
    });
  });

  describe('NamespacePromptFilter', () => {
    it('should only include prompts from allowed namespaces', () => {
      const filter = new NamespacePromptFilter(['demo', 'partner']);
      const context = createMockContext();
      context.availablePrompts = [
        createMockPrompt('demo', 'prompt1'),
        createMockPrompt('partner', 'prompt2'),
        createMockPrompt('admin', 'prompt3')
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(2);
      expect(result.map(p => p.namespace)).toEqual(['demo', 'partner']);
    });

    it('should return empty array when no prompts match allowed namespaces', () => {
      const filter = new NamespacePromptFilter(['allowed']);
      const context = createMockContext();
      context.availablePrompts = [
        createMockPrompt('demo', 'prompt1'),
        createMockPrompt('partner', 'prompt2')
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(0);
    });

    it('should return all prompts when all match allowed namespaces', () => {
      const filter = new NamespacePromptFilter(['demo']);
      const context = createMockContext();
      context.availablePrompts = [
        createMockPrompt('demo', 'prompt1'),
        createMockPrompt('demo', 'prompt2')
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(2);
    });

    it('should handle empty allowed namespaces gracefully', () => {
      const filter = new NamespacePromptFilter([]);
      const context = createMockContext();
      context.availablePrompts = [
        createMockPrompt('demo', 'prompt1')
      ];

      const result = filter.filterPrompts(context);
      expect(result).toHaveLength(0);
    });
  });
});