import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { Prompt, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:prompt-filter' });

/**
 * Context provided to prompt filters for decision making
 */
export interface PromptFilterContext {
  tenantId: string;
  authContext: ExtendedAuthContext;
  availablePrompts: Prompt[];
}

/**
 * Prompt filter interface - implement to create custom filtering logic
 */
export interface PromptFilter {
  name: string;
  filterPrompts(context: PromptFilterContext): Prompt[];
}

/**
 * Role-Based Prompt Filter
 */
export class RoleBasedPromptFilter implements PromptFilter {
  name = 'role-based-prompts';

  filterPrompts(context: PromptFilterContext): Prompt[] {
    const userRoles = (context.authContext.clientMetadata?.roles as string[]) || [];

    logger.debug('Applying role-based prompt filter', {
      tenantId: context.tenantId,
      userRoles,
      promptCount: context.availablePrompts.length
    });

    const filteredPrompts = context.availablePrompts.filter(prompt => {
      const requiredRoles = prompt.options?.requiredRoles as string[] | undefined;
      if (!requiredRoles || requiredRoles.length === 0) return true;

      const hasAccess = requiredRoles.some(role => userRoles.includes(role));

      if (!hasAccess) {
        logger.debug('Prompt filtered out by role', {
          prompt: `${prompt.namespace}__${prompt.name}`,
          requiredRoles,
          userRoles
        });
      }

      return hasAccess;
    });

    logger.info('Role-based prompt filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availablePrompts.length,
      filteredCount: filteredPrompts.length,
      removedCount: context.availablePrompts.length - filteredPrompts.length
    });

    return filteredPrompts;
  }
}

/**
 * Namespace Prompt Filter
 */
export class NamespacePromptFilter implements PromptFilter {
  name = 'namespace-prompts';

  constructor(private allowedNamespaces: string[]) {}

  filterPrompts(context: PromptFilterContext): Prompt[] {
    logger.debug('Applying namespace prompt filter', {
      tenantId: context.tenantId,
      allowedNamespaces: this.allowedNamespaces,
      promptCount: context.availablePrompts.length
    });

    const filteredPrompts = context.availablePrompts.filter(prompt =>
      this.allowedNamespaces.includes(prompt.namespace)
    );

    logger.info('Namespace prompt filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availablePrompts.length,
      filteredCount: filteredPrompts.length
    });

    return filteredPrompts;
  }
}