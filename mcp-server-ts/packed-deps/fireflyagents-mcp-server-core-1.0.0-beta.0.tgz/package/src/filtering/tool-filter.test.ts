import { describe, it, expect } from 'vitest';
import {
  RoleBasedToolFilter,
  NamespaceToolFilter,
  TenantWhitelistToolFilter,
  CompositeToolFilter,
  type ToolFilterContext
} from './tool-filter.js';
import type { Tool, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

describe('ToolFilter', () => {
  const createMockTool = (namespace: string, name: string, options?: any): Tool => ({
    namespace,
    name,
    title: `${namespace}/${name}`,
    paramsSchema: {},
    handler: async () => ({ content: [] }),
    options
  });

  const createMockContext = (roles: string[] = [], tenantId: string = 'tenant-1'): ToolFilterContext => ({
    tenantId,
    authContext: {
      apiKey: 'test-key',
      tenantId,
      clientMetadata: { roles }
    } as ExtendedAuthContext,
    availableTools: []
  });

  describe('RoleBasedToolFilter', () => {
    const filter = new RoleBasedToolFilter();

    it('should allow tools with no role requirements', () => {
      const context = createMockContext(['user']);
      context.availableTools = [
        createMockTool('demo', 'public_tool')
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_tool');
    });

    it('should filter out tools when user has no required roles', () => {
      const context = createMockContext(['user']);
      context.availableTools = [
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(0);
    });

    it('should allow tools when user has at least one required role', () => {
      const context = createMockContext(['manager', 'analyst']);
      context.availableTools = [
        createMockTool('demo', 'report_tool', { requiredRoles: ['admin', 'manager'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('report_tool');
    });

    it('should handle user with no roles', () => {
      const context = createMockContext([]);
      context.availableTools = [
        createMockTool('demo', 'public_tool'),
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('public_tool');
    });

    it('should allow tools when user has all required roles', () => {
      const context = createMockContext(['admin', 'manager']);
      context.availableTools = [
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
    });
  });

  describe('NamespaceToolFilter', () => {
    it('should only include tools from allowed namespaces', () => {
      const filter = new NamespaceToolFilter(['demo', 'partner']);
      const context = createMockContext();
      context.availableTools = [
        createMockTool('demo', 'tool1'),
        createMockTool('partner', 'tool2'),
        createMockTool('admin', 'tool3')
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(2);
      expect(result.map(t => t.namespace)).toEqual(['demo', 'partner']);
    });

    it('should return empty array when no tools match allowed namespaces', () => {
      const filter = new NamespaceToolFilter(['allowed']);
      const context = createMockContext();
      context.availableTools = [
        createMockTool('demo', 'tool1'),
        createMockTool('partner', 'tool2')
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(0);
    });

    it('should return all tools when all match allowed namespaces', () => {
      const filter = new NamespaceToolFilter(['demo']);
      const context = createMockContext();
      context.availableTools = [
        createMockTool('demo', 'tool1'),
        createMockTool('demo', 'tool2')
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(2);
    });
  });

  describe('TenantWhitelistToolFilter', () => {
    const filter = new TenantWhitelistToolFilter();

    it('should allow tools with no tenant whitelist', () => {
      const context = createMockContext([], 'tenant-1');
      context.availableTools = [
        createMockTool('demo', 'public_tool')
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
    });

    it('should filter out tools when tenant not in whitelist', () => {
      const context = createMockContext([], 'tenant-1');
      context.availableTools = [
        createMockTool('demo', 'exclusive_tool', { tenantWhitelist: ['tenant-2', 'tenant-3'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(0);
    });

    it('should allow tools when tenant is in whitelist', () => {
      const context = createMockContext([], 'tenant-1');
      context.availableTools = [
        createMockTool('demo', 'whitelisted_tool', { tenantWhitelist: ['tenant-1', 'tenant-2'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(1);
    });

    it('should handle mix of whitelisted and public tools', () => {
      const context = createMockContext([], 'tenant-1');
      context.availableTools = [
        createMockTool('demo', 'public_tool'),
        createMockTool('demo', 'tenant1_tool', { tenantWhitelist: ['tenant-1'] }),
        createMockTool('demo', 'tenant2_tool', { tenantWhitelist: ['tenant-2'] })
      ];

      const result = filter.filterTools(context);
      expect(result).toHaveLength(2);
      expect(result.map(t => t.name)).toEqual(['public_tool', 'tenant1_tool']);
    });
  });

  describe('CompositeToolFilter', () => {
    it('should apply multiple filters in sequence', () => {
      const roleFilter = new RoleBasedToolFilter();
      const namespaceFilter = new NamespaceToolFilter(['demo']);
      const composite = new CompositeToolFilter([roleFilter, namespaceFilter]);

      const context = createMockContext(['admin']);
      context.availableTools = [
        createMockTool('demo', 'admin_tool', { requiredRoles: ['admin'] }),
        createMockTool('demo', 'user_tool', { requiredRoles: ['user'] }),
        createMockTool('partner', 'partner_tool', { requiredRoles: ['admin'] })
      ];

      const result = composite.filterTools(context);
      // Should have admin_tool (has admin role AND demo namespace)
      // Should NOT have user_tool (doesn't have user role)
      // Should NOT have partner_tool (not in demo namespace)
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('admin_tool');
    });

    it('should return all tools when no filters provided', () => {
      const composite = new CompositeToolFilter([]);
      const context = createMockContext();
      context.availableTools = [
        createMockTool('demo', 'tool1'),
        createMockTool('partner', 'tool2')
      ];

      const result = composite.filterTools(context);
      expect(result).toHaveLength(2);
    });

    it('should apply filters sequentially with correct pipeline', () => {
      const namespaceFilter = new NamespaceToolFilter(['demo', 'partner']);
      const roleFilter = new RoleBasedToolFilter();
      const composite = new CompositeToolFilter([namespaceFilter, roleFilter]);

      const context = createMockContext(['manager']);
      context.availableTools = [
        createMockTool('demo', 'demo_tool', { requiredRoles: ['manager'] }),
        createMockTool('partner', 'partner_tool', { requiredRoles: ['manager'] }),
        createMockTool('admin', 'admin_tool', { requiredRoles: ['manager'] })
      ];

      const result = composite.filterTools(context);
      // First filter removes admin_tool (not in allowed namespaces)
      // Second filter keeps demo_tool and partner_tool (user has manager role)
      expect(result).toHaveLength(2);
      expect(result.map(t => t.namespace).sort()).toEqual(['demo', 'partner']);
    });
  });
});