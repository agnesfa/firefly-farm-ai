import { logger as baseLogger } from '@fireflyagents/mcp-shared-utils';
import type { Tool, ExtendedAuthContext } from '@fireflyagents/mcp-server-types';

const logger = baseLogger.child({ context: 'fa-mcp:core:tool-filter' });

/**
 * Context provided to tool filters for decision making
 */
export interface ToolFilterContext {
  tenantId: string;
  authContext: ExtendedAuthContext;
  availableTools: Tool[];
}

/**
 * Tool filter interface - implement to create custom filtering logic
 *
 * Filters are applied sequentially, each receiving the output of the previous filter.
 */
export interface ToolFilter {
  name: string;

  /**
   * Filter tools based on context
   *
   * @param context - Filter context with tenant, auth, and available tools
   * @returns Filtered array of tools (subset of availableTools)
   */
  filterTools(context: ToolFilterContext): Tool[];
}

/**
 * Role-Based Access Control (RBAC) Tool Filter
 *
 * Filters tools based on required roles defined in tool.options.requiredRoles.
 * User roles are read from authContext.clientMetadata.roles.
 *
 * If a tool has no requiredRoles, it's visible to everyone.
 * If a tool has requiredRoles, user must have at least ONE of those roles.
 *
 * Example:
 *   Tool: requiredRoles: ['admin', 'manager']
 *   User: roles: ['manager', 'analyst']
 *   Result: ALLOWED (user has 'manager')
 */
export class RoleBasedToolFilter implements ToolFilter {
  name = 'role-based';

  filterTools(context: ToolFilterContext): Tool[] {
    // Extract user roles from auth context
    const userRoles = (context.authContext.clientMetadata?.roles as string[]) || [];

    logger.debug('Applying role-based filter', {
      tenantId: context.tenantId,
      userRoles,
      toolCount: context.availableTools.length
    });

    const filteredTools = context.availableTools.filter(tool => {
      const requiredRoles = tool.options?.requiredRoles as string[] | undefined;

      // No role requirement = everyone can see it
      if (!requiredRoles || requiredRoles.length === 0) {
        return true;
      }

      // Check if user has ANY of the required roles
      const hasAccess = requiredRoles.some(role => userRoles.includes(role));

      if (!hasAccess) {
        logger.debug('Tool filtered out by role', {
          tool: `${tool.namespace}__${tool.name}`,
          requiredRoles,
          userRoles
        });
      }

      return hasAccess;
    });

    logger.info('Role-based filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availableTools.length,
      filteredCount: filteredTools.length,
      removedCount: context.availableTools.length - filteredTools.length
    });

    return filteredTools;
  }
}

/**
 * Namespace Tool Filter
 *
 * Filters tools to only include specified namespaces.
 * Useful for limiting tool visibility to specific feature sets.
 *
 * Example:
 *   Allowed: ['demo', 'partner']
 *   Result: Only tools with namespace 'demo' or 'partner' are visible
 */
export class NamespaceToolFilter implements ToolFilter {
  name = 'namespace';

  constructor(private allowedNamespaces: string[]) {}

  filterTools(context: ToolFilterContext): Tool[] {
    logger.debug('Applying namespace filter', {
      tenantId: context.tenantId,
      allowedNamespaces: this.allowedNamespaces,
      toolCount: context.availableTools.length
    });

    const filteredTools = context.availableTools.filter(tool =>
      this.allowedNamespaces.includes(tool.namespace)
    );

    logger.info('Namespace filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availableTools.length,
      filteredCount: filteredTools.length
    });

    return filteredTools;
  }
}

/**
 * Tenant Whitelist Tool Filter
 *
 * Filters tools based on tenant whitelist defined in tool.options.tenantWhitelist.
 * If a tool has no whitelist, it's visible to all tenants.
 * If a tool has a whitelist, only those tenants can see it.
 */
export class TenantWhitelistToolFilter implements ToolFilter {
  name = 'tenant-whitelist';

  filterTools(context: ToolFilterContext): Tool[] {
    logger.debug('Applying tenant whitelist filter', {
      tenantId: context.tenantId,
      toolCount: context.availableTools.length
    });

    const filteredTools = context.availableTools.filter(tool => {
      const whitelist = tool.options?.tenantWhitelist as string[] | undefined;

      // No whitelist = visible to all tenants
      if (!whitelist || whitelist.length === 0) {
        return true;
      }

      // Check if current tenant is in whitelist
      return whitelist.includes(context.tenantId);
    });

    logger.info('Tenant whitelist filtering complete', {
      tenantId: context.tenantId,
      originalCount: context.availableTools.length,
      filteredCount: filteredTools.length
    });

    return filteredTools;
  }
}

/**
 * Composite Tool Filter
 *
 * Applies multiple filters in sequence.
 * Each filter receives the output of the previous filter.
 */
export class CompositeToolFilter implements ToolFilter {
  name = 'composite';

  constructor(private filters: ToolFilter[]) {}

  filterTools(context: ToolFilterContext): Tool[] {
    logger.debug('Applying composite filter', {
      filterCount: this.filters.length,
      filterNames: this.filters.map(f => f.name)
    });

    let tools = context.availableTools;

    for (const filter of this.filters) {
      tools = filter.filterTools({
        ...context,
        availableTools: tools
      });
    }

    return tools;
  }
}