/**
 * Smart app configuration builder with auto-detection and sensible defaults
 */

import { readNameAndVersionFromPackageJson, type Env } from '@fireflyagents/mcp-shared-utils';
import type {
  AppConfig,
  ApiKeyStore,
  SessionStore,
  Tool,
  Prompt,
  Resource,
  PlatformAuthHandler,
  ServerPlugin,
  RouteRegistrar
} from '@fireflyagents/mcp-server-types';
import { helloWorldTool } from "../capabilities/tools/hello-world.js";
import { helloWorldPrompt } from "../capabilities/prompts/hello-world-prompt.js";
import { helloWorldResource } from "../capabilities/resources/hello-world-resource.js";
import type { ToolFilter } from '../filtering/tool-filter.js';
import type { PromptFilter } from '../filtering/prompt-filter.js';
import type { ResourceFilter } from '../filtering/resource-filter.js';

/**
 * Extensions interface for customizing app capabilities and stores
 */
export interface AppExtensions {
  // Capability configuration (NEW: Direct arrays)
  capabilities?: {
    tools?: Tool[];
    prompts?: Prompt[];
    resources?: Resource[];
    authHandlers?: PlatformAuthHandler[];
    plugins?: ServerPlugin[];
    routes?: RouteRegistrar[];
  };

  // Store overrides
  stores?: {
    apiKey?: ApiKeyStore;
    session?: SessionStore;
  };

  // Phase 2: Capability filters
  toolFilters?: ToolFilter[];
  promptFilters?: PromptFilter[];
  resourceFilters?: ResourceFilter[];

  // Framework behavior
  includeDefaults?: boolean; // Default: true (includes fa demo tools)
}

/**
 * Build application configuration with smart defaults and optional extensions
 *
 * @param env - Environment configuration object from shared utils
 * @param extensions - Optional capabilities and store overrides
 * @param packageJsonPath - Optional path to package.json (auto-detected if not provided)
 * @returns Complete AppConfig with smart defaults and extensions applied
 */
export async function buildAppConfig(
  env: Env,
  extensions?: AppExtensions,
  packageJsonPath?: string
): Promise<AppConfig> {
  // Auto-detect package.json information
  const { pkgName, pkgVersion } = await readNameAndVersionFromPackageJson(packageJsonPath);

  const authType = determineAuthType(env, extensions);

  // Framework defaults (included unless explicitly disabled)
  const defaultCapabilities = extensions?.includeDefaults !== false ? {
    tools: [helloWorldTool],
    prompts: [helloWorldPrompt],
    resources: [helloWorldResource]
  } : {};

  // Merge user capabilities with defaults
  const mergedCapabilities = mergeCapabilities(defaultCapabilities, extensions?.capabilities);

  // Build complete configuration
  const config: AppConfig = {
    environment: env.NODE_ENV === 'test' ? 'development' : env.NODE_ENV,
    server: {
      name: pkgName,
      version: pkgVersion,
      port: env.PORT,
      host: env.HOST
    },
    auth: {
      type: authType,
      credentialsPath: env.CREDENTIALS_PATH,
      apiKeyStore: extensions?.stores?.apiKey
    },
    // Add capabilities to config (NEW: Direct arrays)
    tools: mergedCapabilities?.tools || [],
    prompts: mergedCapabilities?.prompts || [],
    resources: mergedCapabilities?.resources || [],
    authHandlers: mergedCapabilities?.authHandlers || [],
    plugins: mergedCapabilities?.plugins || [],
    routeRegistrars: mergedCapabilities?.routes || [],

    // Phase 2: Capability filters
    toolFilters: extensions?.toolFilters || [],
    promptFilters: extensions?.promptFilters || [],
    resourceFilters: extensions?.resourceFilters || [],

    // Session store override
    sessionStore: extensions?.stores?.session
  };

  return config;
}

/**
 * Merge default capabilities with user-provided capabilities
 */
function mergeCapabilities(
  defaults: any = {},
  userCapabilities?: AppExtensions['capabilities']
): any {
  return {
    // NEW: Direct arrays
    tools: [...(defaults?.tools || []), ...(userCapabilities?.tools || [])],
    prompts: [...(defaults?.prompts || []), ...(userCapabilities?.prompts || [])],
    resources: [...(defaults?.resources || []), ...(userCapabilities?.resources || [])],
    authHandlers: [...(defaults?.authHandlers || []), ...(userCapabilities?.authHandlers || [])],
    plugins: [...(defaults?.plugins || []), ...(userCapabilities?.plugins || [])],
    routes: [...(defaults?.routes || []), ...(userCapabilities?.routes || [])],
  };
}

/**
 * Determine appropriate authentication type based on environment
 */
function determineAuthType(env: Env, extensions?: AppExtensions): 'dev' | 'file' | 'custom' {
    if (extensions?.stores?.apiKey) {
        return 'custom';
    }
    return (env.NODE_ENV === 'development' && !env.CREDENTIALS_PATH) ? 'dev' : 'file';
}