import baseConfig from '../../../vitest.base.config'
import { defineConfig, mergeConfig } from 'vitest/config'
import * as path from "node:path";

// Resolve relative to monorepo root
export default mergeConfig(
    baseConfig,
    defineConfig({
        root: path.resolve(__dirname),
    })
)