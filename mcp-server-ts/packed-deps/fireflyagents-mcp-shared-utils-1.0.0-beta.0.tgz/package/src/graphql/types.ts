// GraphQL standard types based on GraphQL specification

export interface GraphQLError {
  message: string;
  locations?: Array<{ line: number; column: number }>;
  path?: Array<string | number>;
  extensions?: Record<string, unknown>;
}

export interface GraphQLResponse<TData = unknown> {
  data: TData;
  errors?: GraphQLError[];
}

export interface GraphQLRequestOptions {
  headers?: Record<string, string>;
}