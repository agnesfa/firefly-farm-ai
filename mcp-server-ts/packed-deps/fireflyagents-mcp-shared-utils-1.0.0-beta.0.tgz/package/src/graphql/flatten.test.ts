import { describe, expect, it } from 'vitest';
import { type Flatten, flattenConnections } from './flatten.js';

describe('GraphQL flatten utility', () => {
  describe('type safety', () => {
    it('should provide correct type inference for connections', () => {
      type TestConnection = {
        edges: Array<{
          node: {
            id: string;
            name: string;
          };
        }>;
      };

      type Expected = Array<{
        id: string;
        name: string;
      }>;

      // Type-only test - this should compile without errors
      const _typeTest: Flatten<TestConnection> = [] as Expected;
      expect(_typeTest).toBeDefined();
    });

    it('should provide correct type inference for nested connections', () => {
      type NestedConnection = {
        orders: {
          edges: Array<{
            node: {
              id: string;
              items: {
                edges: Array<{
                  node: {
                    productId: string;
                  };
                }>;
              };
            };
          }>;
        };
      };

      type Expected = {
        orders: Array<{
          id: string;
          items: Array<{
            productId: string;
          }>;
        }>;
      };

      // Type-only test - this should compile without errors
      const _typeTest: Flatten<NestedConnection> = {} as Expected;
      expect(_typeTest).toBeDefined();
    });
  });

  describe('flattenConnections', () => {
    describe('connection flattening', () => {
      it('should flatten simple connections', () => {
        const connection = {
          edges: [
            { node: { id: '1', name: 'Item 1' } },
            { node: { id: '2', name: 'Item 2' } },
            { node: { id: '3', name: 'Item 3' } },
          ],
        };

        const result = flattenConnections(connection);

        expect(result).toEqual([
          { id: '1', name: 'Item 1' },
          { id: '2', name: 'Item 2' },
          { id: '3', name: 'Item 3' },
        ]);
      });

      it('should handle empty connections', () => {
        const connection = { edges: [] };
        const result = flattenConnections(connection);
        expect(result).toEqual([]);
      });

      it('should handle null edges', () => {
        const connection = { edges: null };
        const result = flattenConnections(connection);
        // Objects with null edges are treated as regular objects, not connections
        expect(result).toEqual({ edges: null });
      });

      it('should handle missing edges property', () => {
        const connection = {};
        const result = flattenConnections(connection);
        // Objects without edges property are treated as regular objects
        expect(result).toEqual({});
      });

      it('should filter out null edge nodes', () => {
        const connection = {
          edges: [
            { node: { id: '1', name: 'Item 1' } },
            null,
            { node: { id: '2', name: 'Item 2' } },
            { node: null },
            { node: { id: '3', name: 'Item 3' } },
          ],
        };

        const result = flattenConnections(connection);

        expect(result).toEqual([
          { id: '1', name: 'Item 1' },
          { id: '2', name: 'Item 2' },
          { id: '3', name: 'Item 3' },
        ]);
      });

      it('should handle edges without node property', () => {
        const connection = {
          edges: [
            { node: { id: '1', name: 'Item 1' } },
            { cursor: 'abc123' }, // Edge without node
            { node: { id: '2', name: 'Item 2' } },
          ],
        };

        const result = flattenConnections(connection);

        expect(result).toEqual([
          { id: '1', name: 'Item 1' },
          { id: '2', name: 'Item 2' },
        ]);
      });
    });

    describe('nested connection flattening', () => {
      it('should flatten nested connections recursively', () => {
        const data = {
          user: {
            orders: {
              edges: [
                {
                  node: {
                    id: 'order-1',
                    items: {
                      edges: [
                        { node: { id: 'item-1', productId: 'prod-1' } },
                        { node: { id: 'item-2', productId: 'prod-2' } },
                      ],
                    },
                  },
                },
                {
                  node: {
                    id: 'order-2',
                    items: {
                      edges: [{ node: { id: 'item-3', productId: 'prod-3' } }],
                    },
                  },
                },
              ],
            },
          },
        };

        const result = flattenConnections(data);

        expect(result).toEqual({
          user: {
            orders: [
              {
                id: 'order-1',
                items: [
                  { id: 'item-1', productId: 'prod-1' },
                  { id: 'item-2', productId: 'prod-2' },
                ],
              },
              {
                id: 'order-2',
                items: [{ id: 'item-3', productId: 'prod-3' }],
              },
            ],
          },
        });
      });

      it('should handle mixed connections and regular objects', () => {
        const data = {
          metadata: {
            count: 10,
            hasMore: true,
          },
          results: {
            edges: [
              {
                node: {
                  id: '1',
                  details: {
                    name: 'Test Item',
                    category: 'electronics',
                  },
                },
              },
            ],
          },
        };

        const result = flattenConnections(data);

        expect(result).toEqual({
          metadata: {
            count: 10,
            hasMore: true,
          },
          results: [
            {
              id: '1',
              details: {
                name: 'Test Item',
                category: 'electronics',
              },
            },
          ],
        });
      });
    });

    describe('array handling', () => {
      it('should flatten arrays recursively', () => {
        const data = [
          {
            connection: {
              edges: [{ node: { id: '1', name: 'Item 1' } }, { node: { id: '2', name: 'Item 2' } }],
            },
          },
          {
            connection: {
              edges: [{ node: { id: '3', name: 'Item 3' } }],
            },
          },
        ];

        const result = flattenConnections(data);

        expect(result).toEqual([
          {
            connection: [
              { id: '1', name: 'Item 1' },
              { id: '2', name: 'Item 2' },
            ],
          },
          {
            connection: [{ id: '3', name: 'Item 3' }],
          },
        ]);
      });

      it('should handle primitive arrays', () => {
        const data = {
          tags: ['electronics', 'mobile', 'android'],
          scores: [4.5, 3.2, 5.0],
        };

        const result = flattenConnections(data);
        expect(result).toEqual(data);
      });
    });

    describe('__typename handling', () => {
      it('should drop __typename by default', () => {
        const connection = {
          __typename: 'OrderConnection',
          edges: [
            {
              node: {
                __typename: 'Order',
                id: '1',
                name: 'Order 1',
              },
            },
          ],
        };

        const result = flattenConnections(connection);

        expect(result).toEqual([{ id: '1', name: 'Order 1' }]);
      });

      it('should preserve __typename when dropTypename is false', () => {
        const connection = {
          __typename: 'OrderConnection',
          edges: [
            {
              node: {
                __typename: 'Order',
                id: '1',
                name: 'Order 1',
              },
            },
          ],
        };

        const result = flattenConnections(connection, { dropTypename: false });

        expect(result).toEqual([{ __typename: 'Order', id: '1', name: 'Order 1' }]);
      });

      it('should handle __typename in nested objects', () => {
        const data = {
          __typename: 'Query',
          user: {
            __typename: 'User',
            id: 'user-1',
            profile: {
              __typename: 'UserProfile',
              displayName: 'John Doe',
            },
          },
        };

        const result = flattenConnections(data);

        expect(result).toEqual({
          user: {
            id: 'user-1',
            profile: {
              displayName: 'John Doe',
            },
          },
        });
      });
    });

    describe('null and undefined handling', () => {
      it('should preserve null values by default', () => {
        const data = {
          name: 'Test',
          description: null,
          category: undefined,
        };

        const result = flattenConnections(data);

        expect(result).toEqual({
          name: 'Test',
          description: null,
          category: undefined,
        });
      });

      it('should convert nulls to undefined when nullAsUndefined is true', () => {
        const data = {
          name: 'Test',
          description: null,
          category: undefined,
        };

        const result = flattenConnections(data, { nullAsUndefined: true });

        expect(result).toEqual({
          name: 'Test',
          description: undefined,
          category: undefined,
        });
      });

      it('should handle null values in nested structures', () => {
        const data = {
          user: {
            id: '1',
            profile: null,
            settings: {
              theme: null,
              notifications: true,
            },
          },
        };

        const result = flattenConnections(data, { nullAsUndefined: true });

        expect(result).toEqual({
          user: {
            id: '1',
            profile: undefined,
            settings: {
              theme: undefined,
              notifications: true,
            },
          },
        });
      });
    });

    describe('primitive values', () => {
      it('should pass through string values', () => {
        const result = flattenConnections('hello world');
        expect(result).toBe('hello world');
      });

      it('should pass through number values', () => {
        const result = flattenConnections(42);
        expect(result).toBe(42);
      });

      it('should pass through boolean values', () => {
        expect(flattenConnections(true)).toBe(true);
        expect(flattenConnections(false)).toBe(false);
      });

      it('should pass through null and undefined', () => {
        expect(flattenConnections(null)).toBe(null);
        expect(flattenConnections(undefined)).toBe(undefined);
      });
    });

    describe('complex GraphQL response scenarios', () => {
      it('should handle real-world Fluent Commerce order response', () => {
        const orderResponse = {
          __typename: 'Query',
          orders: {
            __typename: 'OrderConnection',
            edges: [
              {
                __typename: 'OrderEdge',
                cursor: 'cursor-1',
                node: {
                  __typename: 'Order',
                  id: 'order-1',
                  ref: 'ORD-001',
                  status: 'CONFIRMED',
                  customer: {
                    __typename: 'Customer',
                    id: 'cust-1',
                    firstName: 'John',
                    lastName: 'Doe',
                  },
                  items: {
                    __typename: 'OrderItemConnection',
                    edges: [
                      {
                        __typename: 'OrderItemEdge',
                        node: {
                          __typename: 'OrderItem',
                          id: 'item-1',
                          quantity: 2,
                          product: {
                            __typename: 'Product',
                            id: 'prod-1',
                            name: 'iPhone 15',
                            sku: 'IPHONE-15-128GB',
                          },
                        },
                      },
                      {
                        __typename: 'OrderItemEdge',
                        node: {
                          __typename: 'OrderItem',
                          id: 'item-2',
                          quantity: 1,
                          product: {
                            __typename: 'Product',
                            id: 'prod-2',
                            name: 'AirPods Pro',
                            sku: 'AIRPODS-PRO-2',
                          },
                        },
                      },
                    ],
                  },
                },
              },
            ],
          },
        };

        const result = flattenConnections(orderResponse);

        expect(result).toEqual({
          orders: [
            {
              id: 'order-1',
              ref: 'ORD-001',
              status: 'CONFIRMED',
              customer: {
                id: 'cust-1',
                firstName: 'John',
                lastName: 'Doe',
              },
              items: [
                {
                  id: 'item-1',
                  quantity: 2,
                  product: {
                    id: 'prod-1',
                    name: 'iPhone 15',
                    sku: 'IPHONE-15-128GB',
                  },
                },
                {
                  id: 'item-2',
                  quantity: 1,
                  product: {
                    id: 'prod-2',
                    name: 'AirPods Pro',
                    sku: 'AIRPODS-PRO-2',
                  },
                },
              ],
            },
          ],
        });
      });

      it('should handle pagination metadata alongside connections', () => {
        const paginatedResponse = {
          orders: {
            totalCount: 150,
            pageInfo: {
              hasNextPage: true,
              hasPreviousPage: false,
              startCursor: 'cursor-start',
              endCursor: 'cursor-end',
            },
            edges: [
              {
                cursor: 'cursor-1',
                node: {
                  id: 'order-1',
                  ref: 'ORD-001',
                  total: 299.99,
                },
              },
              {
                cursor: 'cursor-2',
                node: {
                  id: 'order-2',
                  ref: 'ORD-002',
                  total: 149.99,
                },
              },
            ],
          },
        };

        const result = flattenConnections(paginatedResponse);

        expect(result).toEqual({
          orders: [
            {
              id: 'order-1',
              ref: 'ORD-001',
              total: 299.99,
            },
            {
              id: 'order-2',
              ref: 'ORD-002',
              total: 149.99,
            },
          ],
        });
      });

      it('should handle empty connections in real responses', () => {
        const emptyResponse = {
          orders: {
            totalCount: 0,
            pageInfo: {
              hasNextPage: false,
              hasPreviousPage: false,
              startCursor: null,
              endCursor: null,
            },
            edges: [],
          },
          user: {
            id: 'user-1',
            name: 'Test User',
          },
        };

        const result = flattenConnections(emptyResponse);

        expect(result).toEqual({
          orders: [],
          user: {
            id: 'user-1',
            name: 'Test User',
          },
        });
      });
    });

    describe('edge cases and error conditions', () => {
      it('should handle deeply nested connections', () => {
        const deeplyNested = {
          level1: {
            edges: [
              {
                node: {
                  level2: {
                    edges: [
                      {
                        node: {
                          level3: {
                            edges: [
                              {
                                node: {
                                  id: 'deep-item',
                                  value: 'deeply nested',
                                },
                              },
                            ],
                          },
                        },
                      },
                    ],
                  },
                },
              },
            ],
          },
        };

        const result = flattenConnections(deeplyNested);

        expect(result).toEqual({
          level1: [
            {
              level2: [
                {
                  level3: [
                    {
                      id: 'deep-item',
                      value: 'deeply nested',
                    },
                  ],
                },
              ],
            },
          ],
        });
      });

      it('should handle circular-like structures (non-circular but repeated)', () => {
        const sharedObject = { id: 'shared', name: 'Shared Item' };
        const data = {
          connection1: {
            edges: [{ node: sharedObject }],
          },
          connection2: {
            edges: [{ node: sharedObject }],
          },
        };

        const result = flattenConnections(data);

        expect(result).toEqual({
          connection1: [{ id: 'shared', name: 'Shared Item' }],
          connection2: [{ id: 'shared', name: 'Shared Item' }],
        });
      });

      it('should handle objects with edge-like properties that are not connections', () => {
        const notAConnection = {
          edges: 'not-an-array',
          data: {
            id: '1',
            name: 'Test',
          },
        };

        const result = flattenConnections(notAConnection);

        expect(result).toEqual({
          edges: 'not-an-array',
          data: {
            id: '1',
            name: 'Test',
          },
        });
      });

      it('should handle mixed option combinations', () => {
        const data = {
          __typename: 'Root',
          connection: {
            __typename: 'Connection',
            edges: [
              {
                node: {
                  __typename: 'Node',
                  id: '1',
                  name: null,
                  description: 'Test item',
                },
              },
            ],
          },
          metadata: null,
        };

        const result = flattenConnections(data, {
          dropTypename: false,
          nullAsUndefined: true,
        });

        expect(result).toEqual({
          __typename: 'Root',
          connection: [
            {
              __typename: 'Node',
              id: '1',
              name: undefined,
              description: 'Test item',
            },
          ],
          metadata: undefined,
        });
      });
    });
  });
});
