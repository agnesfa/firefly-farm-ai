import type { DocumentNode } from 'graphql';
import { print } from 'graphql';
import type { HttpClient } from '../http/types.js';
import type { GraphQLResponse, GraphQLRequestOptions } from './types.js';
import { logger as baseLogger } from '../logger/logger.js';

const logger = baseLogger.child({ context: 'fa:shared-utils:graphql-client' });

export interface GraphQLClientConfig {
  httpClient: HttpClient;
  endpoint?: string;
}

/**
 * Base GraphQL client that leverages the framework's HTTP client infrastructure.
 * Provides standard GraphQL protocol handling while being completely generic and platform-agnostic.
 *
 * Domain-specific clients should extend this class and provide their own configuration.
 *
 * @example
 * ```typescript
 * class MyGraphQLClient extends GraphQLClient {
 *   constructor(config: MyConfig) {
 *     const httpClient = createHttpClient({
 *       baseURL: config.apiUrl,
 *       headers: { Authorization: `Bearer ${config.token}` }
 *     });
 *     super({ httpClient });
 *   }
 * }
 * ```
 */
export abstract class GraphQLClient {
  protected httpClient: HttpClient;
  protected endpoint: string;

  constructor(config: GraphQLClientConfig) {
    this.httpClient = config.httpClient;
    this.endpoint = config.endpoint || '/graphql';

    logger.debug('GraphQL client initialized', {
      endpoint: this.endpoint,
      hasHttpClient: !!this.httpClient
    });
  }

  /**
   * Execute a GraphQL query, mutation, or subscription.
   *
   * @param query - GraphQL query string or DocumentNode
   * @param variables - Variables for the GraphQL operation
   * @param options - Request options (headers, etc.)
   * @returns Promise resolving to GraphQL response
   */
  async query<TData = unknown, TVariables = Record<string, unknown>>(
    query: DocumentNode | string,
    variables?: TVariables,
    options?: GraphQLRequestOptions
  ): Promise<GraphQLResponse<TData>> {
    const queryString = typeof query === 'string' ? query : print(query);
    const operationType = this.extractOperationType(queryString);

    logger.debug('GraphQL operation initiated', {
      operationType,
      queryLength: queryString.length,
      hasVariables: !!variables,
      endpoint: this.endpoint
    });

    try {
      const response = await this.httpClient.graphql<GraphQLResponse<TData>>(
        queryString,
        variables,
        {
          headers: options?.headers
        }
      );

      // Check for GraphQL errors in successful HTTP response
      const result = response.data;
      if (result && typeof result === 'object' && 'errors' in result && result.errors) {
        logger.warn('GraphQL response contains errors', {
          operationType,
          errorCount: result.errors.length,
          errors: result.errors.map(error => ({
            message: error.message,
            path: error.path,
            locations: error.locations
          }))
        });
      } else {
        logger.debug('GraphQL operation completed successfully', {
          operationType,
          hasData: !!(result && 'data' in result && result.data)
        });
      }

      return result;
    } catch (error) {
      logger.error('GraphQL operation failed', {
        operationType,
        queryLength: queryString.length,
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  /**
   * Extract the operation type from a GraphQL query string.
   * Used for logging and debugging purposes.
   */
  private extractOperationType(query: string): string {
    const trimmed = query.trim();
    if (trimmed.startsWith('query')) return 'query';
    if (trimmed.startsWith('mutation')) return 'mutation';
    if (trimmed.startsWith('subscription')) return 'subscription';
    return 'query'; // default assumption
  }
}