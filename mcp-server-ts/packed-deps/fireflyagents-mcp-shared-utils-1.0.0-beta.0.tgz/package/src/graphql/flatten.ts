/** ---- Type helpers (generic, schema-agnostic) ---- */

type IsEdge<E> = E extends { node?: unknown } ? true : false;
type EdgeNode<E> = E extends { node?: infer N | null } ? N : never;

type IsConnection<T> = T extends { edges?: Array<infer E> | null }
  ? IsEdge<E> extends true
    ? true
    : false
  : false;

type ConnectionNodes<T> = T extends { edges?: Array<infer E> | null } ? EdgeNode<E>[] : never;

/**
 * Flatten<T>:
 * - Connections become arrays of flattened nodes
 * - Arrays are recursively flattened
 * - Objects are recursively flattened
 * - Leaves (string/number/boolean/etc.) pass through
 * - Null/undefined are preserved where they appear inside objects;
 *   for connections the runtime flattener returns [] when edges are missing.
 *
 *   @example Type definitions:
 *   ```typescript
 *   import type { GetLocationsByRefsQuery } from './queries/locations.generated.js';
 *
 *   export type FlatGetLocationsByRefs = Flatten<GetLocationsByRefsQuery>;
 *   ```
 *   @example Usage:
 *   ```typescript
 *   export const getLocations = async (
 *     loc_refs: string[],
 *     extra: ExtraContext
 *   ): Promise<FlatGetLocationsByRefs['locations']> => {
 *     const client = new FluentGraphQLClient({
 *       accountId: extra.authInfo.metadata.accountId,
 *       oauthToken: extra.authInfo.token,
 *     });
 *     logger.info('Getting Locations via GraphQL with MCP auth context', {
 *       sessionId: extra.sessionId,
 *       hasAuthToken: !!extra.authInfo.token,
 *     });
 *
 *     const graphqlResult = await client.query<GetLocationsByRefsQuery>(GET_LOCATIONS_BY_REFS, {
 *       refs: loc_refs,
 *     });
 *
 *     if (graphqlResult.errors) {
 *       logger.error('GraphQL errors in locations query', { errors: graphqlResult.errors });
 *       throw new Error('GraphQL errors in locations query', { cause: graphqlResult.errors });
 *     }
 *
 *     const flattenedData = flattenConnections(graphqlResult.data) as FlatGetLocationsByRefs;
 *     return flattenedData.locations;
 *   };
 *   ```
 */
export type Flatten<T> =
  // arrays
  T extends (infer A)[]
    ? Flatten<A>[]
    : // connections => array of nodes
      IsConnection<T> extends true
      ? Flatten<ConnectionNodes<T>>
      : // objects
        T extends object
        ? { [K in keyof T]: Flatten<T[K]> }
        : T;

/** ---- Runtime flattener (mirrors the type above) ---- */

export interface FlattenOptions {
  /** remove __typename keys (default: true) */
  dropTypename?: boolean;
  /** convert nulls in arrays/objects to undefined (default: false) */
  nullAsUndefined?: boolean;
}

const isObject = (v: unknown): v is Record<string, unknown> => v !== null && typeof v === 'object';

const isConnectionLike = (v: unknown): v is { edges?: Array<{ node?: unknown } | null> | null } =>
  isObject(v) && 'edges' in v && Array.isArray((v as Record<string, unknown>).edges);

function maybeCleanKey(key: string, opts: FlattenOptions | undefined): boolean {
  return !(opts?.dropTypename !== false && key === '__typename');
}

/**
 * Flatten any GraphQL response:
 * - `{ edges: [{ node }] }` -> `[node]` (recursively)
 * - drops `__typename` by default
 * - returns [] for missing/empty connections
 */
export function flattenConnections<T>(value: T, opts?: FlattenOptions): Flatten<T> {
  // Connections -> array of nodes
  if (isConnectionLike(value)) {
    const edges = (value.edges ?? []) as Array<{ node?: unknown } | null>;
    const arr = edges
      .map((e) => (e && 'node' in e ? e.node : undefined))
      .filter((n): n is unknown => n != null)
      .map((n) => flattenConnections(n, opts));
    return arr as Flatten<T>;
  }

  // Arrays
  if (Array.isArray(value)) {
    return value.map((v) => flattenConnections(v, opts)) as Flatten<T>;
  }

  // Objects
  if (isObject(value)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      if (!maybeCleanKey(k, opts)) continue;
      const flat =
        v == null
          ? opts?.nullAsUndefined
            ? undefined
            : v
          : flattenConnections(v as unknown, opts);
      out[k] = flat as unknown;
    }
    return out as Flatten<T>;
  }

  // Primitives (string/number/boolean/etc.)
  return value as Flatten<T>;
}
