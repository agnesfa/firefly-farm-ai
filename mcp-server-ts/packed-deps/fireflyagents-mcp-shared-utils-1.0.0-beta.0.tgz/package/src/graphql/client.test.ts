import { describe, it, expect, vi, beforeEach, afterEach, type MockedFunction } from 'vitest';
import { gql } from 'graphql-tag';
import { GraphQLClient, type GraphQLClientConfig } from './client.js';
import type { HttpClient, HttpResponse } from '../http/types.js';
import type { GraphQLResponse } from './types.js';

// Create a concrete test implementation of the abstract GraphQLClient
class TestGraphQLClient extends GraphQLClient {
  constructor(config: GraphQLClientConfig) {
    super(config);
  }
}

describe('GraphQLClient', () => {
  let client: TestGraphQLClient;
  let mockHttpClient: {
    get: MockedFunction<any>;
    post: MockedFunction<any>;
    put: MockedFunction<any>;
    delete: MockedFunction<any>;
    graphql: MockedFunction<any>;
  };

  beforeEach(() => {
    // Create mock HTTP client
    mockHttpClient = {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      delete: vi.fn(),
      graphql: vi.fn(),
    };

    client = new TestGraphQLClient({
      httpClient: mockHttpClient as unknown as HttpClient,
      endpoint: '/graphql'
    });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with default endpoint', () => {
      const defaultClient = new TestGraphQLClient({
        httpClient: mockHttpClient as unknown as HttpClient
      });

      expect(defaultClient).toBeDefined();
      // Access protected property for testing
      expect((defaultClient as any).endpoint).toBe('/graphql');
    });

    it('should initialize with custom endpoint', () => {
      const customClient = new TestGraphQLClient({
        httpClient: mockHttpClient as unknown as HttpClient,
        endpoint: '/api/graphql'
      });

      expect((customClient as any).endpoint).toBe('/api/graphql');
    });

    it('should store HTTP client reference', () => {
      expect((client as any).httpClient).toBe(mockHttpClient);
    });
  });

  describe('query method', () => {
    const mockGraphQLResponse: GraphQLResponse<any> = {
      data: {
        users: [
          { id: '1', name: 'John Doe' },
          { id: '2', name: 'Jane Smith' }
        ]
      }
    };

    const mockHttpResponse: HttpResponse<GraphQLResponse<any>> = {
      data: mockGraphQLResponse,
      status: 200,
      statusText: 'OK',
      headers: { 'content-type': 'application/json' }
    };

    beforeEach(() => {
      mockHttpClient.graphql.mockResolvedValue(mockHttpResponse);
    });

    describe('with string queries', () => {
      it('should execute GraphQL query with string', async () => {
        const query = `
          query GetUsers($limit: Int) {
            users(limit: $limit) {
              id
              name
            }
          }
        `;
        const variables = { limit: 10 };

        const result = await client.query(query, variables);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          query,
          variables,
          { headers: undefined }
        );
        expect(result).toEqual(mockGraphQLResponse);
      });

      it('should handle query without variables', async () => {
        const query = 'query { users { id name } }';

        const result = await client.query(query);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          query,
          undefined,
          { headers: undefined }
        );
        expect(result).toEqual(mockGraphQLResponse);
      });

      it('should pass custom headers', async () => {
        const query = 'query { users { id } }';
        const headers = { 'X-Request-ID': 'test-123' };

        await client.query(query, undefined, { headers });

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          query,
          undefined,
          { headers }
        );
      });
    });

    describe('with DocumentNode queries', () => {
      it('should execute GraphQL query with DocumentNode', async () => {
        const query = gql`
          query GetUsers($limit: Int) {
            users(limit: $limit) {
              id
              name
              email
            }
          }
        `;
        const variables = { limit: 5 };

        const result = await client.query(query, variables);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          expect.stringContaining('query GetUsers'),
          variables,
          { headers: undefined }
        );
        expect(result).toEqual(mockGraphQLResponse);
      });

      it('should handle DocumentNode without variables', async () => {
        const query = gql`
          query GetCurrentUser {
            me {
              id
              username
            }
          }
        `;

        const result = await client.query(query);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          expect.stringContaining('query GetCurrentUser'),
          undefined,
          { headers: undefined }
        );
        expect(result).toEqual(mockGraphQLResponse);
      });

      it('should handle complex DocumentNode with fragments', async () => {
        const query = gql`
          fragment UserInfo on User {
            id
            name
            email
          }

          query GetUsersWithInfo($first: Int) {
            users(first: $first) {
              ...UserInfo
              profile {
                avatar
              }
            }
          }
        `;

        await client.query(query, { first: 3 });

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          expect.stringContaining('fragment UserInfo'),
          { first: 3 },
          { headers: undefined }
        );
      });
    });

    describe('with mutations', () => {
      it('should execute GraphQL mutation', async () => {
        const mutationResponse: GraphQLResponse<any> = {
          data: {
            updateUser: {
              id: '1',
              name: 'Updated Name',
              success: true
            }
          }
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: mutationResponse
        });

        const mutation = gql`
          mutation UpdateUser($id: ID!, $input: UpdateUserInput!) {
            updateUser(id: $id, input: $input) {
              id
              name
              success
            }
          }
        `;

        const variables = {
          id: '1',
          input: { name: 'Updated Name' }
        };

        const result = await client.query(mutation, variables);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          expect.stringContaining('mutation UpdateUser'),
          variables,
          { headers: undefined }
        );
        expect(result).toEqual(mutationResponse);
      });
    });

    describe('type safety', () => {
      it('should provide type-safe responses', async () => {
        interface UsersResponse {
          users: Array<{
            id: string;
            name: string;
            email: string;
          }>;
        }

        interface UsersVariables {
          limit: number;
          status?: string;
        }

        const typedResponse: GraphQLResponse<UsersResponse> = {
          data: {
            users: [
              { id: '1', name: 'John', email: 'john@example.com' },
              { id: '2', name: 'Jane', email: 'jane@example.com' }
            ]
          }
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: typedResponse
        });

        const query = 'query GetUsers($limit: Int!, $status: String) { users(limit: $limit, status: $status) { id name email } }';
        const variables: UsersVariables = { limit: 10, status: 'active' };

        const result = await client.query<UsersResponse, UsersVariables>(query, variables);

        // TypeScript should infer correct types
        expect((result.data as UsersResponse).users[0].id).toBe('1');
        expect((result.data as UsersResponse).users[0].name).toBe('John');
        expect((result.data as UsersResponse).users[0].email).toBe('john@example.com');
      });
    });

    describe('GraphQL error handling', () => {
      it('should handle GraphQL errors in successful HTTP response', async () => {
        const errorResponse: GraphQLResponse<any> = {
          data: null,
          errors: [
            {
              message: 'User not found',
              locations: [{ line: 2, column: 3 }],
              path: ['user'],
              extensions: { code: 'NOT_FOUND' }
            }
          ]
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: errorResponse
        });

        const query = 'query { user(id: "nonexistent") { id name } }';

        const result = await client.query(query);

        expect(result).toEqual(errorResponse);
        expect(result.errors).toHaveLength(1);
        expect(result.errors![0].message).toBe('User not found');
        expect(result.errors![0].extensions?.code).toBe('NOT_FOUND');
      });

      it('should handle multiple GraphQL errors', async () => {
        const errorResponse: GraphQLResponse<any> = {
          data: {
            user: null,
            posts: null
          },
          errors: [
            {
              message: 'Insufficient permissions for user',
              path: ['user']
            },
            {
              message: 'Insufficient permissions for posts',
              path: ['posts']
            }
          ]
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: errorResponse
        });

        const query = 'query { user { id } posts { title } }';

        const result = await client.query(query);

        expect(result.errors).toHaveLength(2);
        expect(result.errors![0].message).toBe('Insufficient permissions for user');
        expect(result.errors![1].message).toBe('Insufficient permissions for posts');
      });

      it('should not throw on GraphQL errors (let consumer handle)', async () => {
        const errorResponse: GraphQLResponse<any> = {
          data: null,
          errors: [{ message: 'Some GraphQL error' }]
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: errorResponse
        });

        const query = 'query { problematicField }';

        // Should not throw, should return the error response
        const result = await client.query(query);
        expect(result.errors).toHaveLength(1);
      });
    });

    describe('HTTP error handling', () => {
      it('should propagate HTTP client errors', async () => {
        const httpError = new Error('Network error: 500 Internal Server Error');
        mockHttpClient.graphql.mockRejectedValue(httpError);

        const query = 'query { users { id } }';

        await expect(client.query(query)).rejects.toThrow(
          'Network error: 500 Internal Server Error'
        );
      });

      it('should propagate authentication errors', async () => {
        const authError = new Error('Unauthorized: Invalid token');
        mockHttpClient.graphql.mockRejectedValue(authError);

        const query = 'query { protectedData { value } }';

        await expect(client.query(query)).rejects.toThrow('Unauthorized: Invalid token');
      });

      it('should propagate timeout errors', async () => {
        const timeoutError = new Error('Request timeout');
        mockHttpClient.graphql.mockRejectedValue(timeoutError);

        const query = 'query { slowOperation { result } }';

        await expect(client.query(query)).rejects.toThrow('Request timeout');
      });
    });

    describe('operation type detection', () => {
      it('should detect query operations', async () => {
        const query = 'query GetUsers { users { id } }';
        await client.query(query);

        // Just verify the call was made - operation type is used for logging
        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          query,
          undefined,
          { headers: undefined }
        );
      });

      it('should detect mutation operations', async () => {
        const mutation = 'mutation CreateUser($input: UserInput!) { createUser(input: $input) { id } }';
        await client.query(mutation, { input: { name: 'Test' } });

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          mutation,
          { input: { name: 'Test' } },
          { headers: undefined }
        );
      });

      it('should detect subscription operations', async () => {
        const subscription = 'subscription OnUserUpdate { userUpdated { id name } }';
        await client.query(subscription);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          subscription,
          undefined,
          { headers: undefined }
        );
      });

      it('should default to query for unrecognized operations', async () => {
        const unknownOperation = 'fragment UserFragment on User { id name }';
        await client.query(unknownOperation);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          unknownOperation,
          undefined,
          { headers: undefined }
        );
      });
    });

    describe('complex scenarios', () => {
      it('should handle large queries with many variables', async () => {
        const largeQuery = `
          query GetComplexData(
            $userId: ID!,
            $limit: Int,
            $offset: Int,
            $filters: DataFilters,
            $sortBy: SortOptions
          ) {
            user(id: $userId) {
              id
              profile { name email avatar }
              posts(limit: $limit, offset: $offset, filters: $filters, sortBy: $sortBy) {
                edges {
                  node {
                    id
                    title
                    content
                    author { id name }
                    comments { id text author { name } }
                  }
                }
              }
            }
          }
        `;

        const complexVariables = {
          userId: 'user-123',
          limit: 50,
          offset: 0,
          filters: { status: 'published', category: 'tech' },
          sortBy: { field: 'createdAt', direction: 'DESC' }
        };

        await client.query(largeQuery, complexVariables);

        expect(mockHttpClient.graphql).toHaveBeenCalledWith(
          largeQuery,
          complexVariables,
          { headers: undefined }
        );
      });

      it('should handle deeply nested responses', async () => {
        const nestedResponse: GraphQLResponse<any> = {
          data: {
            organization: {
              id: 'org-1',
              teams: [
                {
                  id: 'team-1',
                  members: [
                    {
                      id: 'user-1',
                      profile: {
                        personal: {
                          name: 'John',
                          contacts: {
                            emails: ['john@example.com'],
                            phones: ['+1234567890']
                          }
                        }
                      }
                    }
                  ]
                }
              ]
            }
          }
        };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: nestedResponse
        });

        const query = `
          query GetOrgDetails {
            organization {
              teams {
                members {
                  profile {
                    personal {
                      name
                      contacts {
                        emails
                        phones
                      }
                    }
                  }
                }
              }
            }
          }
        `;

        const result = await client.query(query);

        expect((result.data as any).organization.teams[0].members[0].profile.personal.name).toBe('John');
      });

      it('should handle empty responses', async () => {
        const emptyResponse: GraphQLResponse<any> = { data: {} };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: emptyResponse
        });

        const query = 'query { emptyField }';

        const result = await client.query(query);
        expect(result.data).toEqual({});
      });

      it('should handle null data with no errors', async () => {
        const nullResponse: GraphQLResponse<any> = { data: null };

        mockHttpClient.graphql.mockResolvedValue({
          ...mockHttpResponse,
          data: nullResponse
        });

        const query = 'query { nullField }';

        const result = await client.query(query);
        expect(result.data).toBeNull();
        expect(result.errors).toBeUndefined();
      });
    });
  });
});