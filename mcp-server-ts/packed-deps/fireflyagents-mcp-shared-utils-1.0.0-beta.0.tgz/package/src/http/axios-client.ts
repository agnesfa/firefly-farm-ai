import axios, { AxiosInstance, AxiosResponse, AxiosError } from 'axios';
import { logger as baseLogger } from '../logger/logger.js';
import type { HttpClient, HttpClientConfig, RequestConfig, HttpResponse } from './types.js';
import { HttpClientError } from './types.js';

const logger = baseLogger.child({ context: 'fa:shared-utils:http-client' });

export class AxiosHttpClient implements HttpClient {
  private axiosInstance: AxiosInstance;

  constructor(config: HttpClientConfig = {}) {
    this.axiosInstance = axios.create({
      baseURL: config.baseURL,
      timeout: config.timeout || 30000,
      headers: {
        'Content-Type': 'application/json',
        ...config.headers
      }
    });

    // Request interceptor for logging
    this.axiosInstance.interceptors.request.use(
      (request) => {
        logger.http('HTTP request initiated', {
          method: request.method?.toUpperCase(),
          url: request.url,
          baseURL: request.baseURL,
          timeout: request.timeout
        });
        return request;
      },
      (error) => {
        logger.error('HTTP request setup failed', { error: error.message });
        return Promise.reject(error);
      }
    );

    // Response interceptor for logging and error handling
    this.axiosInstance.interceptors.response.use(
      (response) => {
        logger.http('HTTP request completed', {
          method: response.config.method?.toUpperCase(),
          url: response.config.url,
          status: response.status,
          statusText: response.statusText
        });
        return response;
      },
      (error: AxiosError) => {
        const status = error.response?.status;
        const statusText = error.response?.statusText;
        
        logger.error('HTTP request failed', {
          method: error.config?.method?.toUpperCase(),
          url: error.config?.url,
          status,
          statusText,
          error: error.message
        });

        // Convert AxiosError to HttpClientError
        const httpError = new HttpClientError(
          error.message,
          status,
          error.response?.data
        );
        
        return Promise.reject(httpError);
      }
    );
  }

  private normalizeResponse<T>(axiosResponse: AxiosResponse<T>): HttpResponse<T> {
    return {
      data: axiosResponse.data,
      status: axiosResponse.status,
      statusText: axiosResponse.statusText,
      headers: axiosResponse.headers as Record<string, string>
    };
  }

  private mergeConfig(config?: RequestConfig): any {
    if (!config) return {};

    return {
      headers: config.headers,
      timeout: config.timeout,
      baseURL: config.baseURL
    };
  }

  async get<T = any>(url: string, config?: RequestConfig): Promise<HttpResponse<T>> {
    const startTime = Date.now();
    
    try {
      const response = await this.axiosInstance.get<T>(url, this.mergeConfig(config));
      
      logger.debug('GET request completed', {
        url,
        status: response.status,
        duration: Date.now() - startTime
      });
      
      return this.normalizeResponse(response);
    } catch (error) {
      logger.error('GET request failed', {
        url,
        duration: Date.now() - startTime,
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  async post<T = any>(url: string, data?: any, config?: RequestConfig): Promise<HttpResponse<T>> {
    const startTime = Date.now();
    
    try {
      const response = await this.axiosInstance.post<T>(url, data, this.mergeConfig(config));
      
      logger.debug('POST request completed', {
        url,
        status: response.status,
        duration: Date.now() - startTime
      });
      
      return this.normalizeResponse(response);
    } catch (error) {
      logger.error('POST request failed', {
        url,
        duration: Date.now() - startTime,
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  async put<T = any>(url: string, data?: any, _config?: RequestConfig): Promise<HttpResponse<T>> {
    // TODO: Implement PUT method
    throw new Error(`PUT method not yet implemented for ${url}${data ? ' with data' : ''}`);
  }

  async delete<T = any>(url: string, _config?: RequestConfig): Promise<HttpResponse<T>> {
    // TODO: Implement DELETE method  
    throw new Error(`DELETE method not yet implemented for ${url}`);
  }

  async graphql<T = any>(query: string, variables?: any, config?: RequestConfig): Promise<HttpResponse<T>> {
    const startTime = Date.now();
    
    const requestBody = {
      query,
      ...(variables && { variables })
    };

    // Create GraphQL-specific config with content type
    const graphqlConfig = {
      ...config,
      headers: {
        'Content-Type': 'application/json',
        ...config?.headers
      }
    };

    try {
      logger.debug('GraphQL request initiated', {
        queryLength: query.length,
        hasVariables: !!variables,
        operationType: this.extractOperationType(query)
      });

      const response = await this.post<T>('/graphql', requestBody, graphqlConfig);
      
      // Check for GraphQL errors in successful HTTP response
      if (response.data && typeof response.data === 'object' && 'errors' in response.data) {
        const errors = (response.data as any).errors;
        logger.warn('GraphQL response contains errors', { errors });
        // Note: Don't throw - let consumer handle GraphQL errors
      }

      logger.debug('GraphQL request completed', {
        queryLength: query.length,
        status: response.status,
        duration: Date.now() - startTime
      });

      return response;
    } catch (error) {
      logger.error('GraphQL request failed', {
        queryLength: query.length,
        duration: Date.now() - startTime,
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  private extractOperationType(query: string): string {
    const trimmed = query.trim();
    if (trimmed.startsWith('query')) return 'query';
    if (trimmed.startsWith('mutation')) return 'mutation';  
    if (trimmed.startsWith('subscription')) return 'subscription';
    return 'query'; // default assumption
  }
}

export function createHttpClient(config?: HttpClientConfig): HttpClient {
  return new AxiosHttpClient(config);
}