import { vi } from 'vitest';

// Mock logger before other imports
export const mockLogger = {
  child: vi.fn(() => mockLogger),
  http: vi.fn(),
  info: vi.fn(),
  error: vi.fn(),
  debug: vi.fn(),
  warn: vi.fn()
};

vi.mock('../logger/logger.js', () => ({
  logger: mockLogger
}));