import './test-setup.js';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import axios from 'axios';
import { AxiosHttpClient, createHttpClient } from './axios-client.js';
import type { HttpClientConfig } from './types.js';
import { mockLogger } from './test-setup.js';

// Mock axios
vi.mock('axios', () => ({
  default: {
    create: vi.fn()
  }
}));

// Remove unused mockedAxios since we use vi.mocked(axios.create) directly

describe('AxiosHttpClient', () => {
  let client: AxiosHttpClient;
  const mockAxiosInstance: any = {
    create: vi.fn(),
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    patch: vi.fn(),
    delete: vi.fn(),
    request: vi.fn(),
    defaults: { headers: { common: {} } },
    interceptors: {
      request: { use: vi.fn() },
      response: { use: vi.fn() }
    }
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(axios.create).mockReturnValue(mockAxiosInstance as any);
    client = new AxiosHttpClient();
  });

  describe('constructor', () => {
    it('creates axios instance with default config', () => {
      expect(axios.create).toHaveBeenCalledWith({
        baseURL: undefined,
        timeout: 30000,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    });

    it('creates axios instance with custom config', () => {
      const config: HttpClientConfig = {
        baseURL: 'https://api.example.com',
        timeout: 5000,
        headers: { 'Authorization': 'Bearer token' }
      };
      
      new AxiosHttpClient(config);
      
      expect(axios.create).toHaveBeenCalledWith({
        baseURL: 'https://api.example.com',
        timeout: 5000,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer token'
        }
      });
    });

    it('sets up request and response interceptors', () => {
      expect(mockAxiosInstance.interceptors.request.use).toHaveBeenCalled();
      expect(mockAxiosInstance.interceptors.response.use).toHaveBeenCalled();
    });
  });

  describe('get method', () => {
    it('makes successful GET request', async () => {
      const mockResponse = {
        data: { id: 1, name: 'test' },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.get.mockResolvedValue(mockResponse);
      
      const result = await client.get('/test');
      
      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/test', {});
      expect(result).toEqual({
        data: { id: 1, name: 'test' },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GET request completed', expect.any(Object));
    });

    it('makes GET request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.get.mockResolvedValue(mockResponse);
      
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      };
      
      await client.get('/test', config);
      
      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/test', {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      });
    });

    it('handles GET request error', async () => {
      const error = new Error('Network error');
      mockAxiosInstance.get.mockRejectedValue(error);
      
      await expect(client.get('/test')).rejects.toThrow('Network error');
      expect(mockLogger.error).toHaveBeenCalledWith('GET request failed', expect.any(Object));
    });
  });

  describe('post method', () => {
    it('makes successful POST request', async () => {
      const mockResponse = {
        data: { id: 1, created: true },
        status: 201,
        statusText: 'Created',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const data = { name: 'test', value: 123 };
      const result = await client.post('/test', data);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/test', data, {});
      expect(result).toEqual({
        data: { id: 1, created: true },
        status: 201,
        statusText: 'Created',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('POST request completed', expect.any(Object));
    });

    it('makes POST request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 201,
        statusText: 'Created',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const data = { test: 'data' };
      const config = {
        headers: { 'Content-Type': 'application/xml' },
        timeout: 5000
      };
      
      await client.post('/test', data, config);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/test', data, {
        headers: { 'Content-Type': 'application/xml' },
        timeout: 5000
      });
    });

    it('handles POST request error', async () => {
      const error = new Error('Server error');
      mockAxiosInstance.post.mockRejectedValue(error);
      
      await expect(client.post('/test', {})).rejects.toThrow('Server error');
      expect(mockLogger.error).toHaveBeenCalledWith('POST request failed', expect.any(Object));
    });
  });

  describe('graphql method', () => {
    it('makes successful GraphQL query request', async () => {
      const mockResponse = {
        data: { data: { user: { id: 1, name: 'test' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { user(id: 1) { id name } }';
      const result = await client.graphql(query);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, 
        { 
          headers: { 'Content-Type': 'application/json' } 
        }
      );
      expect(result).toEqual({
        data: { data: { user: { id: 1, name: 'test' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated', expect.objectContaining({
        queryLength: query.length,
        hasVariables: false,
        operationType: 'query'
      }));
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request completed', expect.any(Object));
    });

    it('makes successful GraphQL mutation request with variables', async () => {
      const mockResponse = {
        data: { data: { createUser: { id: 2, name: 'new user' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'mutation CreateUser($input: UserInput!) { createUser(input: $input) { id name } }';
      const variables = { input: { name: 'new user', email: 'test@example.com' } };
      const result = await client.graphql(query, variables);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query, variables }, 
        { 
          headers: { 'Content-Type': 'application/json' } 
        }
      );
      expect(result.data).toEqual({ data: { createUser: { id: 2, name: 'new user' } } });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated', expect.objectContaining({
        queryLength: query.length,
        hasVariables: true,
        operationType: 'mutation'
      }));
    });

    it('makes GraphQL request with custom config', async () => {
      const mockResponse = {
        data: { data: { products: [] } },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = '{ products { id name } }';
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      };
      
      await client.graphql(query, null, config);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, 
        {
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Bearer token'
          },
          timeout: 10000
        }
      );
    });

    it('handles GraphQL response with errors but does not throw', async () => {
      const mockResponse = {
        data: { 
          data: null,
          errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
        },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { user(id: 999) { id name } }';
      const result = await client.graphql(query);
      
      expect(result.data).toEqual({
        data: null,
        errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
      });
      expect(mockLogger.warn).toHaveBeenCalledWith('GraphQL response contains errors', {
        errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request completed', expect.any(Object));
    });

    it('handles network/HTTP errors', async () => {
      const error = new Error('Network error');
      mockAxiosInstance.post.mockRejectedValue(error);
      
      const query = 'query { test }';
      await expect(client.graphql(query)).rejects.toThrow('Network error');
      expect(mockLogger.error).toHaveBeenCalledWith('GraphQL request failed', expect.objectContaining({
        queryLength: query.length,
        error: 'Network error'
      }));
    });

    it('detects operation types correctly', async () => {
      const mockResponse = {
        data: { data: {} },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      // Test query detection
      await client.graphql('query GetUser { user { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'query' }));
      
      // Test mutation detection
      await client.graphql('mutation CreateUser { createUser { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'mutation' }));
      
      // Test subscription detection  
      await client.graphql('subscription UserUpdated { userUpdated { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'subscription' }));
      
      // Test default (no operation type specified)
      await client.graphql('{ user { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'query' }));
    });

    it('handles variables omitted when undefined', async () => {
      const mockResponse = {
        data: { data: {} },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { test }';
      await client.graphql(query, undefined);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, // variables should not be included
        expect.any(Object)
      );
    });
  });

  describe('put method', () => {
    it('makes successful PUT request', async () => {
      const mockResponse = {
        data: { id: 1, updated: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };

      mockAxiosInstance.put.mockResolvedValue(mockResponse);

      const data = { name: 'updated', value: 456 };
      const result = await client.put('/test/1', data);

      expect(mockAxiosInstance.put).toHaveBeenCalledWith('/test/1', data, {});
      expect(result).toEqual({
        data: { id: 1, updated: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('PUT request completed', expect.any(Object));
    });

    it('makes PUT request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 200,
        statusText: 'OK',
        headers: {}
      };

      mockAxiosInstance.put.mockResolvedValue(mockResponse);

      const data = { test: 'data' };
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      };

      await client.put('/test/1', data, config);

      expect(mockAxiosInstance.put).toHaveBeenCalledWith('/test/1', data, {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      });
    });

    it('handles PUT request error', async () => {
      const error = new Error('Server error');
      mockAxiosInstance.put.mockRejectedValue(error);

      await expect(client.put('/test/1', {})).rejects.toThrow('Server error');
      expect(mockLogger.error).toHaveBeenCalledWith('PUT request failed', expect.any(Object));
    });
  });

  describe('patch method', () => {
    it('makes successful PATCH request', async () => {
      const mockResponse = {
        data: { id: 1, patched: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };

      mockAxiosInstance.patch.mockResolvedValue(mockResponse);

      const data = { value: 789 };
      const result = await client.patch('/test/1', data);

      expect(mockAxiosInstance.patch).toHaveBeenCalledWith('/test/1', data, {});
      expect(result).toEqual({
        data: { id: 1, patched: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('PATCH request completed', expect.any(Object));
    });

    it('makes PATCH request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 200,
        statusText: 'OK',
        headers: {}
      };

      mockAxiosInstance.patch.mockResolvedValue(mockResponse);

      const data = { partial: 'update' };
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      };

      await client.patch('/test/1', data, config);

      expect(mockAxiosInstance.patch).toHaveBeenCalledWith('/test/1', data, {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      });
    });

    it('handles PATCH request error', async () => {
      const error = new Error('Server error');
      mockAxiosInstance.patch.mockRejectedValue(error);

      await expect(client.patch('/test/1', {})).rejects.toThrow('Server error');
      expect(mockLogger.error).toHaveBeenCalledWith('PATCH request failed', expect.any(Object));
    });
  });

  describe('delete method', () => {
    it('makes successful DELETE request', async () => {
      const mockResponse = {
        data: { deleted: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };

      mockAxiosInstance.delete.mockResolvedValue(mockResponse);

      const result = await client.delete('/test/1');

      expect(mockAxiosInstance.delete).toHaveBeenCalledWith('/test/1', {});
      expect(result).toEqual({
        data: { deleted: true },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('DELETE request completed', expect.any(Object));
    });

    it('makes DELETE request with config', async () => {
      const mockResponse = {
        data: null,
        status: 204,
        statusText: 'No Content',
        headers: {}
      };

      mockAxiosInstance.delete.mockResolvedValue(mockResponse);

      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      };

      await client.delete('/test/1', config);

      expect(mockAxiosInstance.delete).toHaveBeenCalledWith('/test/1', {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 5000
      });
    });

    it('handles DELETE request error', async () => {
      const error = new Error('Server error');
      mockAxiosInstance.delete.mockRejectedValue(error);

      await expect(client.delete('/test/1')).rejects.toThrow('Server error');
      expect(mockLogger.error).toHaveBeenCalledWith('DELETE request failed', expect.any(Object));
    });
  });

  describe('onUnauthorized retry-on-401', () => {
    /**
     * The error interceptor is registered via
     * `axiosInstance.interceptors.response.use(success, error)`. We capture
     * the error handler by reading back the mock's calls, then invoke it
     * directly with a synthetic 401 AxiosError to assert retry behaviour.
     */
    const captureErrorInterceptor = () => {
      const useCalls = mockAxiosInstance.interceptors.response.use.mock.calls;
      const lastCall = useCalls[useCalls.length - 1];
      return lastCall?.[1] as (error: any) => Promise<any>;
    };

    const buildAxiosError = (status: number) => ({
      response: { status, statusText: status === 401 ? 'Unauthorized' : 'Error', data: null },
      config: { method: 'get', url: '/test', headers: { Authorization: 'Bearer old' } },
      message: `Request failed with status code ${status}`
    });

    it('invokes onUnauthorized and retries once with merged headers on 401', async () => {
      const onUnauthorized = vi.fn().mockResolvedValue({
        headers: { Authorization: 'Bearer fresh' }
      });
      mockAxiosInstance.defaults = { headers: { common: {} } };
      mockAxiosInstance.request = vi.fn().mockResolvedValue({
        data: { ok: true },
        status: 200,
        statusText: 'OK',
        headers: {}
      });

      new AxiosHttpClient({ onUnauthorized });
      const errorHandler = captureErrorInterceptor();

      const result = await errorHandler(buildAxiosError(401));

      expect(onUnauthorized).toHaveBeenCalledTimes(1);
      expect(mockAxiosInstance.request).toHaveBeenCalledTimes(1);
      const retryConfig = mockAxiosInstance.request.mock.calls[0][0];
      expect(retryConfig.headers.Authorization).toBe('Bearer fresh');
      expect(retryConfig.__fa_auth_retry__).toBe(true);
      expect(mockAxiosInstance.defaults.headers.common.Authorization).toBe('Bearer fresh');
      expect(result.data).toEqual({ ok: true });
    });

    it('does not retry on non-401 statuses', async () => {
      const onUnauthorized = vi.fn();
      mockAxiosInstance.request = vi.fn();

      new AxiosHttpClient({ onUnauthorized });
      const errorHandler = captureErrorInterceptor();

      await expect(errorHandler(buildAxiosError(500))).rejects.toBeDefined();
      expect(onUnauthorized).not.toHaveBeenCalled();
      expect(mockAxiosInstance.request).not.toHaveBeenCalled();
    });

    it('propagates 401 when no onUnauthorized is configured', async () => {
      mockAxiosInstance.request = vi.fn();

      new AxiosHttpClient(); // no callback
      const errorHandler = captureErrorInterceptor();

      await expect(errorHandler(buildAxiosError(401))).rejects.toMatchObject({
        status: 401
      });
      expect(mockAxiosInstance.request).not.toHaveBeenCalled();
    });

    it('propagates 401 when onUnauthorized returns null (refuses to refresh)', async () => {
      const onUnauthorized = vi.fn().mockResolvedValue(null);
      mockAxiosInstance.request = vi.fn();

      new AxiosHttpClient({ onUnauthorized });
      const errorHandler = captureErrorInterceptor();

      await expect(errorHandler(buildAxiosError(401))).rejects.toMatchObject({
        status: 401
      });
      expect(onUnauthorized).toHaveBeenCalledTimes(1);
      expect(mockAxiosInstance.request).not.toHaveBeenCalled();
    });

    it('propagates 401 and logs when onUnauthorized throws', async () => {
      const onUnauthorized = vi.fn().mockRejectedValue(new Error('refresh kaboom'));
      mockAxiosInstance.request = vi.fn();

      new AxiosHttpClient({ onUnauthorized });
      const errorHandler = captureErrorInterceptor();

      await expect(errorHandler(buildAxiosError(401))).rejects.toMatchObject({
        status: 401
      });
      expect(mockLogger.warn).toHaveBeenCalledWith(
        'onUnauthorized callback threw; propagating original 401',
        expect.any(Object)
      );
      expect(mockAxiosInstance.request).not.toHaveBeenCalled();
    });

    it('does not retry a second time — second 401 on the same request propagates', async () => {
      const onUnauthorized = vi.fn().mockResolvedValue({
        headers: { Authorization: 'Bearer fresh' }
      });
      mockAxiosInstance.request = vi.fn();

      new AxiosHttpClient({ onUnauthorized });
      const errorHandler = captureErrorInterceptor();

      // Synthesize a 401 error whose config already carries the retry marker,
      // mimicking what the interceptor would see if the first retry also 401'd.
      const retriedError = buildAxiosError(401) as any;
      retriedError.config.__fa_auth_retry__ = true;

      await expect(errorHandler(retriedError)).rejects.toMatchObject({ status: 401 });
      expect(onUnauthorized).not.toHaveBeenCalled();
      expect(mockAxiosInstance.request).not.toHaveBeenCalled();
    });
  });
});

describe('createHttpClient', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(axios.create).mockReturnValue({
      interceptors: {
        request: { use: vi.fn() },
        response: { use: vi.fn() }
      }
    } as any);
  });

  it('creates AxiosHttpClient instance with default config', () => {
    const client = createHttpClient();
    expect(client).toBeInstanceOf(AxiosHttpClient);
  });

  it('creates AxiosHttpClient instance with custom config', () => {
    const config: HttpClientConfig = {
      baseURL: 'https://api.example.com',
      timeout: 5000
    };
    
    const client = createHttpClient(config);
    expect(client).toBeInstanceOf(AxiosHttpClient);
  });
});