import './test-setup.js';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import axios from 'axios';
import { AxiosHttpClient, createHttpClient } from './axios-client.js';
import type { HttpClientConfig } from './types.js';
import { mockLogger } from './test-setup.js';

// Mock axios
vi.mock('axios', () => ({
  default: {
    create: vi.fn()
  }
}));

// Remove unused mockedAxios since we use vi.mocked(axios.create) directly

describe('AxiosHttpClient', () => {
  let client: AxiosHttpClient;
  const mockAxiosInstance = {
    create: vi.fn(),
    get: vi.fn(),
    post: vi.fn(),
    interceptors: {
      request: { use: vi.fn() },
      response: { use: vi.fn() }
    }
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(axios.create).mockReturnValue(mockAxiosInstance as any);
    client = new AxiosHttpClient();
  });

  describe('constructor', () => {
    it('creates axios instance with default config', () => {
      expect(axios.create).toHaveBeenCalledWith({
        baseURL: undefined,
        timeout: 30000,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    });

    it('creates axios instance with custom config', () => {
      const config: HttpClientConfig = {
        baseURL: 'https://api.example.com',
        timeout: 5000,
        headers: { 'Authorization': 'Bearer token' }
      };
      
      new AxiosHttpClient(config);
      
      expect(axios.create).toHaveBeenCalledWith({
        baseURL: 'https://api.example.com',
        timeout: 5000,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer token'
        }
      });
    });

    it('sets up request and response interceptors', () => {
      expect(mockAxiosInstance.interceptors.request.use).toHaveBeenCalled();
      expect(mockAxiosInstance.interceptors.response.use).toHaveBeenCalled();
    });
  });

  describe('get method', () => {
    it('makes successful GET request', async () => {
      const mockResponse = {
        data: { id: 1, name: 'test' },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.get.mockResolvedValue(mockResponse);
      
      const result = await client.get('/test');
      
      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/test', {});
      expect(result).toEqual({
        data: { id: 1, name: 'test' },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GET request completed', expect.any(Object));
    });

    it('makes GET request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.get.mockResolvedValue(mockResponse);
      
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      };
      
      await client.get('/test', config);
      
      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/test', {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      });
    });

    it('handles GET request error', async () => {
      const error = new Error('Network error');
      mockAxiosInstance.get.mockRejectedValue(error);
      
      await expect(client.get('/test')).rejects.toThrow('Network error');
      expect(mockLogger.error).toHaveBeenCalledWith('GET request failed', expect.any(Object));
    });
  });

  describe('post method', () => {
    it('makes successful POST request', async () => {
      const mockResponse = {
        data: { id: 1, created: true },
        status: 201,
        statusText: 'Created',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const data = { name: 'test', value: 123 };
      const result = await client.post('/test', data);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/test', data, {});
      expect(result).toEqual({
        data: { id: 1, created: true },
        status: 201,
        statusText: 'Created',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('POST request completed', expect.any(Object));
    });

    it('makes POST request with config', async () => {
      const mockResponse = {
        data: { success: true },
        status: 201,
        statusText: 'Created',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const data = { test: 'data' };
      const config = {
        headers: { 'Content-Type': 'application/xml' },
        timeout: 5000
      };
      
      await client.post('/test', data, config);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/test', data, {
        headers: { 'Content-Type': 'application/xml' },
        timeout: 5000
      });
    });

    it('handles POST request error', async () => {
      const error = new Error('Server error');
      mockAxiosInstance.post.mockRejectedValue(error);
      
      await expect(client.post('/test', {})).rejects.toThrow('Server error');
      expect(mockLogger.error).toHaveBeenCalledWith('POST request failed', expect.any(Object));
    });
  });

  describe('graphql method', () => {
    it('makes successful GraphQL query request', async () => {
      const mockResponse = {
        data: { data: { user: { id: 1, name: 'test' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { user(id: 1) { id name } }';
      const result = await client.graphql(query);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, 
        { 
          headers: { 'Content-Type': 'application/json' } 
        }
      );
      expect(result).toEqual({
        data: { data: { user: { id: 1, name: 'test' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated', expect.objectContaining({
        queryLength: query.length,
        hasVariables: false,
        operationType: 'query'
      }));
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request completed', expect.any(Object));
    });

    it('makes successful GraphQL mutation request with variables', async () => {
      const mockResponse = {
        data: { data: { createUser: { id: 2, name: 'new user' } } },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'mutation CreateUser($input: UserInput!) { createUser(input: $input) { id name } }';
      const variables = { input: { name: 'new user', email: 'test@example.com' } };
      const result = await client.graphql(query, variables);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query, variables }, 
        { 
          headers: { 'Content-Type': 'application/json' } 
        }
      );
      expect(result.data).toEqual({ data: { createUser: { id: 2, name: 'new user' } } });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated', expect.objectContaining({
        queryLength: query.length,
        hasVariables: true,
        operationType: 'mutation'
      }));
    });

    it('makes GraphQL request with custom config', async () => {
      const mockResponse = {
        data: { data: { products: [] } },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = '{ products { id name } }';
      const config = {
        headers: { 'Authorization': 'Bearer token' },
        timeout: 10000
      };
      
      await client.graphql(query, null, config);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, 
        {
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Bearer token'
          },
          timeout: 10000
        }
      );
    });

    it('handles GraphQL response with errors but does not throw', async () => {
      const mockResponse = {
        data: { 
          data: null,
          errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
        },
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' }
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { user(id: 999) { id name } }';
      const result = await client.graphql(query);
      
      expect(result.data).toEqual({
        data: null,
        errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
      });
      expect(mockLogger.warn).toHaveBeenCalledWith('GraphQL response contains errors', {
        errors: [{ message: 'User not found', extensions: { code: 'NOT_FOUND' } }]
      });
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request completed', expect.any(Object));
    });

    it('handles network/HTTP errors', async () => {
      const error = new Error('Network error');
      mockAxiosInstance.post.mockRejectedValue(error);
      
      const query = 'query { test }';
      await expect(client.graphql(query)).rejects.toThrow('Network error');
      expect(mockLogger.error).toHaveBeenCalledWith('GraphQL request failed', expect.objectContaining({
        queryLength: query.length,
        error: 'Network error'
      }));
    });

    it('detects operation types correctly', async () => {
      const mockResponse = {
        data: { data: {} },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      // Test query detection
      await client.graphql('query GetUser { user { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'query' }));
      
      // Test mutation detection
      await client.graphql('mutation CreateUser { createUser { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'mutation' }));
      
      // Test subscription detection  
      await client.graphql('subscription UserUpdated { userUpdated { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'subscription' }));
      
      // Test default (no operation type specified)
      await client.graphql('{ user { id } }');
      expect(mockLogger.debug).toHaveBeenCalledWith('GraphQL request initiated',
        expect.objectContaining({ operationType: 'query' }));
    });

    it('handles variables omitted when undefined', async () => {
      const mockResponse = {
        data: { data: {} },
        status: 200,
        statusText: 'OK',
        headers: {}
      };
      
      mockAxiosInstance.post.mockResolvedValue(mockResponse);
      
      const query = 'query { test }';
      await client.graphql(query, undefined);
      
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/graphql', 
        { query }, // variables should not be included
        expect.any(Object)
      );
    });
  });

  describe('stub methods', () => {
    it('PUT method throws not implemented error', async () => {
      await expect(client.put('/test', {})).rejects.toThrow('PUT method not yet implemented');
    });

    it('DELETE method throws not implemented error', async () => {
      await expect(client.delete('/test')).rejects.toThrow('DELETE method not yet implemented');
    });
  });
});

describe('createHttpClient', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(axios.create).mockReturnValue({
      interceptors: {
        request: { use: vi.fn() },
        response: { use: vi.fn() }
      }
    } as any);
  });

  it('creates AxiosHttpClient instance with default config', () => {
    const client = createHttpClient();
    expect(client).toBeInstanceOf(AxiosHttpClient);
  });

  it('creates AxiosHttpClient instance with custom config', () => {
    const config: HttpClientConfig = {
      baseURL: 'https://api.example.com',
      timeout: 5000
    };
    
    const client = createHttpClient(config);
    expect(client).toBeInstanceOf(AxiosHttpClient);
  });
});