export interface RequestConfig {
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
  baseURL?: string;
}

export interface HttpClientConfig {
  baseURL?: string;
  timeout?: number;
  retries?: number;
  headers?: Record<string, string>;
}

export interface HttpResponse<T = any> {
  data: T;
  status: number;
  statusText: string;
  headers: Record<string, string>;
}

export interface HttpClient {
  get<T = any>(url: string, config?: RequestConfig): Promise<HttpResponse<T>>;
  post<T = any>(url: string, data?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
  put<T = any>(url: string, data?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
  delete<T = any>(url: string, config?: RequestConfig): Promise<HttpResponse<T>>;
  graphql<T = any>(query: string, variables?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
}

export class HttpClientError extends Error {
  constructor(
    message: string,
    public status?: number,
    public response?: any
  ) {
    super(message);
    this.name = 'HttpClientError';
  }
}