export interface RequestConfig {
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
  baseURL?: string;
}

/**
 * Result returned by the `onUnauthorized` callback. Returning `null` tells the
 * client to propagate the 401; returning an object causes the request to be
 * retried exactly once with the given headers merged over the original request.
 */
export interface UnauthorizedRetryResult {
  headers?: Record<string, string>;
}

export interface HttpClientConfig {
  baseURL?: string;
  timeout?: number;
  retries?: number;
  headers?: Record<string, string>;
  /**
   * Called when a request receives HTTP 401. If it returns retry headers
   * (e.g. a fresh `Authorization`), the request is retried once with those
   * headers merged in; if it returns `null`/`undefined` or throws, the 401 is
   * propagated. Strictly one-shot — a second 401 is always propagated.
   */
  onUnauthorized?: () => Promise<UnauthorizedRetryResult | null | undefined>;
}

export interface HttpResponse<T = any> {
  data: T;
  status: number;
  statusText: string;
  headers: Record<string, string>;
}

export interface HttpClient {
  get<T = any>(url: string, config?: RequestConfig): Promise<HttpResponse<T>>;
  post<T = any>(url: string, data?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
  put<T = any>(url: string, data?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
  delete<T = any>(url: string, config?: RequestConfig): Promise<HttpResponse<T>>;
  graphql<T = any>(query: string, variables?: any, config?: RequestConfig): Promise<HttpResponse<T>>;
}

export class HttpClientError extends Error {
  constructor(
    message: string,
    public status?: number,
    public response?: any
  ) {
    super(message);
    this.name = 'HttpClientError';
  }
}