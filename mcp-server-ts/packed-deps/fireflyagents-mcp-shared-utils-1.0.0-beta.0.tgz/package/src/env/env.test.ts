import { describe, it, expect, vi, beforeEach } from 'vitest';
import { loadAndValidateEnv, loadDotenv } from './env.js';
import { config } from 'dotenv';

// Mock the config function from dotenv
vi.mock('dotenv', () => ({
  config: vi.fn(),
}));

describe('Environment Configuration', () => {
  beforeEach(() => {
    // Clear mocks before each test
    vi.mocked(config).mockClear();
  });

  describe('loadDotenv', () => {
    it('should attempt to load .env.local in non-production', () => {
      loadDotenv('development', '/test/cwd');
      expect(config).toHaveBeenCalledWith({ path: '/test/cwd/.env.local' });
    });

    it('should attempt to load .env in production', () => {
      loadDotenv('production', '/test/cwd');
      expect(config).toHaveBeenCalledWith({ path: '/test/cwd/.env' });
    });

    it('should log an error if dotenv.config fails with an unexpected error', () => {
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const error = new Error('Test dotenv error');
      vi.mocked(config).mockReturnValue({ error });

      loadDotenv('development', '/test/cwd');

      expect(consoleErrorSpy).toHaveBeenCalledWith(
        'Error loading environment file:',
        error
      );
      consoleErrorSpy.mockRestore();
    });

    it('should not log an error if the file is simply not found (ENOENT)', () => {
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const error = new Error('File not found');
      (error as any).code = 'ENOENT';
      vi.mocked(config).mockReturnValue({ error });

      loadDotenv('development', '/test/cwd');

      expect(consoleErrorSpy).not.toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('loadAndValidateEnv', () => {
    it('should load default environment variables when none are set', () => {
      const env = loadAndValidateEnv({});
      expect(env.NODE_ENV).toBe('development');
      expect(env.PORT).toBe(3000);
      expect(env.HOST).toBe('localhost');
      expect(env.LOG_LEVEL).toBe('http');
      expect(env.MCP_SERVER_PORT).toBe('8080');
      expect(env.MCP_SERVER_HOST).toBe('localhost');
    });

    it('should use environment variables when they are set', () => {
      const mockEnv = {
        NODE_ENV: 'production',
        PORT: '8888',
        HOST: 'testhost',
        LOG_LEVEL: 'debug',
        MCP_SERVER_PORT: '9999',
        MCP_SERVER_HOST: 'mcp.test',
      };
      const env = loadAndValidateEnv(mockEnv);
      expect(env.NODE_ENV).toBe('production');
      expect(env.PORT).toBe(8888);
      expect(env.HOST).toBe('testhost');
      expect(env.LOG_LEVEL).toBe('debug');
      expect(env.MCP_SERVER_PORT).toBe('9999');
      expect(env.MCP_SERVER_HOST).toBe('mcp.test');
    });

    it('should include arbitrary environment variables from additionalVars but not from processEnv', () => {
      const mockEnv = {
        NODE_ENV: 'development',
        SYSTEM_VAR: 'system_value', // This should NOT be included
      };
      const additionalVars = {
        TEST_VAR: 'test_value',
        CUSTOM_SETTING: 'custom_value',
      };
      const env = loadAndValidateEnv(mockEnv, additionalVars);
      expect(env.NODE_ENV).toBe('development');
      expect(env.TEST_VAR).toBe('test_value');
      expect(env.CUSTOM_SETTING).toBe('custom_value');
      expect(env.PORT).toBe(3000); // Should still get default from schema
      expect(env.SYSTEM_VAR).toBeUndefined(); // Should NOT be included
    });

    it('should exit the process for invalid data', () => {
      const mockExit = vi.spyOn(process, 'exit').mockImplementation(() => undefined as never);
      const mockConsoleError = vi.spyOn(console, 'error').mockImplementation(() => {});

      const invalidEnv = { LOG_LEVEL: 'invalid-level' };
      loadAndValidateEnv(invalidEnv);

      expect(mockConsoleError).toHaveBeenCalled();
      expect(mockExit).toHaveBeenCalledWith(1);

      mockExit.mockRestore();
      mockConsoleError.mockRestore();
    });
  });
});
