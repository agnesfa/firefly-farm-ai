import { config } from 'dotenv';
import { resolve } from 'path';
import { z } from 'zod'; // must import from zod to avoid circular dependency on shared types

/**
 * Loads environment variables from a file.
 * This function is exported for testing purposes.
 * @param nodeEnv The current node environment.
 * @param cwd The current working directory.
 * @returns The parsed environment variables from the file, or empty object if no file found
 */
export function loadDotenv(nodeEnv: string | undefined, cwd: string): Record<string, string> {
  const envFile = (nodeEnv === 'production' || nodeEnv === 'staging') ? '.env' : '.env.local';
  const result = config({ path: resolve(cwd, envFile) });

  if (result && result.error && (result.error as any).code !== 'ENOENT') {
    // This is difficult to test without deeper mocks, but we cover the logic.
    console.error('Error loading environment file:', result.error);
    return {};
  }

  return result && result.parsed ? result.parsed : {};
}

// Load dotenv variables (but don't apply them to process.env yet)
let dotenvVars: Record<string, string> = {};
if (process.env.NODE_ENV !== 'test') {
  dotenvVars = loadDotenv(process.env.NODE_ENV, process.cwd());
}

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
  PORT: z.coerce.number().default(3000),
  HOST: z.string().default('localhost'),
  LOG_LEVEL: z
    .enum(['trace', 'debug', 'http', 'info', 'warn', 'error', 'fatal', 'silent'])
    .default('http'),
  // Add MCP-specific environment variables here
  MCP_SERVER_PORT: z.string().default('8080'),
  MCP_SERVER_HOST: z.string().default('localhost'),
  CREDENTIALS_PATH: z.string().optional(),
});

type ValidatedEnv = z.infer<typeof envSchema>;

// Extended env type that includes all validated variables plus any additional environment variables
export type Env = ValidatedEnv & Record<string, any>;

export function loadAndValidateEnv(processEnv: NodeJS.ProcessEnv, additionalVars: Record<string, string> = {}): Env {
  try {
    // First validate the known schema (using process.env for system vars + schema defaults)
    const validatedEnv = envSchema.parse(processEnv);

    // Then add only the additional variables from dotenv that aren't in the schema
    const schemaKeys = Object.keys(envSchema.shape);
    const additionalEnvVars: Record<string, any> = {};

    Object.entries(additionalVars).forEach(([key, value]) => {
      if (!schemaKeys.includes(key)) {
        additionalEnvVars[key] = value;
      }
    });

    // Combine validated schema vars with additional dotenv vars
    const allEnv = { ...validatedEnv, ...additionalEnvVars };

    return allEnv as Env;
  } catch (error) {
    console.error('Failed to parse environment variables:', error);
    // It's critical that environment variables are correct for the app to run
    process.exit(1);
  }
}

const env = loadAndValidateEnv(process.env, dotenvVars);

// Export the validated and parsed environment variables
export { env };
