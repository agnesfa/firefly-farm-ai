// shared/utils/package.ts
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

/**
 * Read the package name and version from a given package.json.
 * Defaults to package.json in the current working directory.
 */
export async function readNameAndVersionFromPackageJson(
  packageJsonPath?: string | URL
): Promise<{ pkgName: string; pkgVersion: string }> {
  if (!packageJsonPath) {
    // Default to current working directory's package.json
    packageJsonPath = resolve(process.cwd(), "package.json");
  }

  const content = await readFile(packageJsonPath, "utf8");
  const pkg = JSON.parse(content);

  return {
    pkgName: pkg.name ?? "unnamed-mcp-server",
    pkgVersion: pkg.version ?? "0.0.0",
  };
}