import { describe, it, expect, vi, beforeEach } from 'vitest';
import { readNameAndVersionFromPackageJson } from './package.js';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

// Mock node:fs/promises
vi.mock('node:fs/promises', () => ({
  readFile: vi.fn(),
}));

// Mock node:url
vi.mock('node:url', () => ({
  fileURLToPath: vi.fn(),
}));

// Mock node:path
vi.mock('node:path', () => ({
  dirname: vi.fn(),
  resolve: vi.fn(),
}));

describe('readNameAndVersionFromPackageJson', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('with provided package.json path', () => {
    it('should read name and version from provided path', async () => {
      const mockPackageJson = {
        name: 'test-package',
        version: '1.2.3',
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      expect(readFile).toHaveBeenCalledWith('/path/to/package.json', 'utf8');
      expect(result).toEqual({
        pkgName: 'test-package',
        pkgVersion: '1.2.3',
      });
    });

    it('should handle URL object as path', async () => {
      const mockPackageJson = {
        name: 'url-package',
        version: '2.0.0',
      };

      const urlPath = new URL('file:///path/to/package.json');
      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson(urlPath);

      expect(readFile).toHaveBeenCalledWith(urlPath, 'utf8');
      expect(result).toEqual({
        pkgName: 'url-package',
        pkgVersion: '2.0.0',
      });
    });

    it('should use default values when name/version are missing', async () => {
      const mockPackageJson = {
        description: 'A package without name/version',
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      expect(result).toEqual({
        pkgName: 'unnamed-mcp-server',
        pkgVersion: '0.0.0',
      });
    });

    it('should handle null name/version', async () => {
      const mockPackageJson = {
        name: null,
        version: null,
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      expect(result).toEqual({
        pkgName: 'unnamed-mcp-server',
        pkgVersion: '0.0.0',
      });
    });

    it('should handle empty string name/version', async () => {
      const mockPackageJson = {
        name: '',
        version: '',
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      // Empty strings are truthy, so they don't trigger the fallback
      expect(result).toEqual({
        pkgName: '',
        pkgVersion: '',
      });
    });
  });

  describe('without provided package.json path', () => {
    it('should resolve to current working directory package.json', async () => {
      const mockPackageJson = {
        name: 'auto-resolved-package',
        version: '3.1.4',
      };

      // Mock process.cwd and resolve
      const originalCwd = process.cwd;
      process.cwd = vi.fn().mockReturnValue('/current/working/directory');
      vi.mocked(resolve).mockReturnValue('/current/working/directory/package.json');
      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson();

      expect(process.cwd).toHaveBeenCalled();
      expect(resolve).toHaveBeenCalledWith('/current/working/directory', 'package.json');
      expect(readFile).toHaveBeenCalledWith('/current/working/directory/package.json', 'utf8');
      expect(result).toEqual({
        pkgName: 'auto-resolved-package',
        pkgVersion: '3.1.4',
      });

      // Restore original process.cwd
      process.cwd = originalCwd;
    });

  });

  describe('error handling', () => {
    it('should throw error when file cannot be read', async () => {
      const readError = new Error('File not found');
      vi.mocked(readFile).mockRejectedValue(readError);

      await expect(readNameAndVersionFromPackageJson('/nonexistent/package.json'))
        .rejects.toThrow('File not found');
    });

    it('should throw error when JSON is invalid', async () => {
      vi.mocked(readFile).mockResolvedValue('invalid json content');

      await expect(readNameAndVersionFromPackageJson('/path/to/package.json'))
        .rejects.toThrow();
    });

    it('should handle empty file content', async () => {
      vi.mocked(readFile).mockResolvedValue('');

      await expect(readNameAndVersionFromPackageJson('/path/to/package.json'))
        .rejects.toThrow();
    });

    it('should handle non-object JSON', async () => {
      vi.mocked(readFile).mockResolvedValue('"just a string"');

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');
      
      // Non-object JSON parsed as string gets default fallback values
      expect(result).toEqual({
        pkgName: 'unnamed-mcp-server',
        pkgVersion: '0.0.0',
      });
    });
  });

  describe('complex package.json structures', () => {
    it('should handle package.json with extra fields', async () => {
      const mockPackageJson = {
        name: 'complex-package',
        version: '1.0.0',
        description: 'A complex package',
        main: 'index.js',
        scripts: {
          test: 'vitest',
          build: 'tsc',
        },
        dependencies: {
          express: '^4.18.0',
        },
        devDependencies: {
          vitest: '^1.0.0',
        },
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      expect(result).toEqual({
        pkgName: 'complex-package',
        pkgVersion: '1.0.0',
      });
    });

    it('should handle scoped package names', async () => {
      const mockPackageJson = {
        name: '@company/scoped-package',
        version: '2.1.0-beta.1',
      };

      vi.mocked(readFile).mockResolvedValue(JSON.stringify(mockPackageJson));

      const result = await readNameAndVersionFromPackageJson('/path/to/package.json');

      expect(result).toEqual({
        pkgName: '@company/scoped-package',
        pkgVersion: '2.1.0-beta.1',
      });
    });
  });
});