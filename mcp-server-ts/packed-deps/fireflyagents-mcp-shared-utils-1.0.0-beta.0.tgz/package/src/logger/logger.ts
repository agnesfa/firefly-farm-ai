import {env, type Env} from '../env/env.js';
import type {TransformableInfo} from 'logform';
import winston from 'winston';

// ------- Levels -------
export const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    http: 3,
    debug: 4,
    trace: 5,
} as const;
export type LogLevel = keyof typeof logLevels;

// Extend Winston's Logger type to include our custom levels
declare module 'winston' {
    interface Logger {
        trace: winston.LeveledLogMethod;
    }
}

winston.addColors({
    error: 'red',
    warn: 'yellow',
    info: 'green',
    http: 'magenta',
    debug: 'blue',
    trace: 'gray',
});

// ------- Redaction helpers -------
const SENSITIVE_KEYS = new Set([
    'authorization',
    'proxy-authorization',
    'x-api-key',
    'apiKey',
    'apiKeyPrefix',
    'token',
    'access_token',
    'id_token',
    'refresh_token',
    'client_secret',
    'password',
    'username',
    'scope',
    'grant_type',
    'tokenPreview',
]);

const URL_SECRET_PARAMS = new Set([
    'client_secret',
    'password',
    'username',
    'scope',
    'grant_type',
    'token',
    'access_token',
    'id_token',
    'refresh_token',
    'client_id',
    'tokenPreview',
]);

function maskStr(v: string, visibleStart = 3, visibleEnd = 2): string {
    if (!v) return v;
    if (v.length <= visibleStart + visibleEnd) return '***';
    return `${v.slice(0, visibleStart)}***${v.slice(-visibleEnd)}`;
}

function redactUrl(url?: string): string | undefined {
    if (!url) return url;
    try {
        const u = new URL(url);
        u.searchParams.forEach((_, key) => {
            if (URL_SECRET_PARAMS.has(key)) u.searchParams.set(key, '***');
        });
        return u.toString();
    } catch {
        // Not a valid URL; best-effort mask query fragments
        return url.replace(
            /([?&])(client_secret|password|username|scope|grant_type|token|access_token|id_token|refresh_token|client_id)=([^&#]+)/gi,
            (_m, sep, k) => `${sep}${k}=***`
        );
    }
}

function redactAny(value: unknown, keyHint?: string): unknown {
    if (value == null) return value;
    if (typeof value === 'string') {
        // redact bearer-like strings only if key hint says so
        if (keyHint && SENSITIVE_KEYS.has(keyHint)) return maskStr(value);
        // redact URLs inline
        return redactUrl(value) ?? value;
    }
    if (Array.isArray(value)) return value.map((v) => redactAny(v));
    if (typeof value === 'object') {
        const out: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
            if (SENSITIVE_KEYS.has(k)) {
                // keep shape, mask value
                if (typeof v === 'string') out[k] = maskStr(v);
                else out[k] = v ? '***' : v;
            } else if (k.toLowerCase().includes('url')) {
                out[k] = typeof v === 'string' ? redactUrl(v) : redactAny(v, k);
            } else if (k.toLowerCase().includes('tokenpreview')) {
                out[k] = undefined; // drop token previews entirely
            } else {
                out[k] = redactAny(v, k);
            }
        }
        return out;
    }
    return value;
}

// Redaction helper that can be called directly
function redactLogInfo(info: Record<string, any>): Record<string, any> {
    const redacted = { ...info };

    if (redacted.url) redacted.url = redactUrl(redacted.url);
    if (redacted.request?.url) redacted.request.url = redactUrl(redacted.request.url);

    for (const [k, v] of Object.entries(redacted)) {
        redacted[k] = redactAny(v, k);
    }

    return redacted;
}

// ------- Level routing / sampling -------

// Messages we’ll demote from info->debug when healthy:
const DOWNGRADE_RULES: Array<{
    context?: RegExp;
    messageContains?: RegExp;
    event?: RegExp;
}> = [
    // // Per-request auth success noise
    // {context: /auth-extractor/i, messageContains: /validation successful/i},
    // {context: /legacy-sse-handler/i, messageContains: /Authentication context validated/i},
    // {context: /legacy-sse-handler/i, messageContains: /Auth context injection attempt/i},
    // {context: /legacy-sse-handler/i, messageContains: /Auth context added/i},
    // {context: /legacy-sse-handler/i, messageContains: /Auth context injected/i},
    // {context: /legacy-sse-handler/i, messageContains: /Using existing SSE transport/i},
    // // Session wiring noise
    // {context: /platform-auth-service/i, messageContains: /Platform credentials found/i},
    // {context: /platform-auth-service/i, messageContains: /Checking for platform auth handlers/i},
    // {context: /platform-auth-service/i, messageContains: /Performing OAuth authentication/i},
    // // Duplicate-ish transport lines
    // {context: /legacy-sse-handler/i, messageContains: /transport created/i},
];

// Optional sampling for very chatty routes
const SAMPLED_METHODS = new Map<string, number>([
    // method -> sample rate (log 1 out of N successes at info)
    // ['notifications/initialized', Number(env.LOG_SAMPLE_NOTIFICATIONS ?? 50)],
    ['notifications/initialized', Number(50)],
]);

function shouldSample(info: Record<string, any>): boolean {
    const mcpMethod: string | undefined =
        info.mcpMethod ?? info.request?.mcpMethod ?? info.meta?.mcpMethod;

    const statusCode: number | undefined = Number(
        info.statusCode ?? info.request?.statusCode ?? info.meta?.statusCode
    ) || undefined;

    if (!mcpMethod) return false;

    const n = SAMPLED_METHODS.get(mcpMethod);
    if (!n) return false;

    // Only sample successful, high-chatter paths
    if (statusCode && statusCode >= 400) return false;

    const rid: string =
        (info.requestId ?? info.request?.requestId ?? info.meta?.requestId ?? '').toString();

    // deterministic tiny hash
    let hash = 0;
    for (let i = 0; i < rid.length; i++) hash = (hash * 31 + rid.charCodeAt(i)) >>> 0;

    return hash % n !== 0;
}

const levelRouterFormat = winston.format((info: TransformableInfo) => {
    const asAny = info as Record<string, any>;
    let level = asAny.level as LogLevel;

    if ((level === 'http' || level === 'info') && shouldSample(asAny)) {
        asAny.level = 'debug';
        return info; // ✅
    }

    if (level === 'info') {
        const contextStr = (asAny.context ?? '').toString();
        const messageStr = (asAny.message ?? '').toString();
        const eventStr = (asAny.event ?? '').toString();

        for (const rule of DOWNGRADE_RULES) {
            const contextOk = rule.context ? rule.context.test(contextStr) : true;
            const messageOk = rule.messageContains ? rule.messageContains.test(messageStr) : true;
            const eventOk = rule.event ? rule.event.test(eventStr) : true;
            if (contextOk && messageOk && eventOk) {
                asAny.level = 'debug';
                break;
            }
        }
    }

    return info; // ✅
});

// ------- Canonical printf -------
const loggerFormat = (_appEnv: Env) =>
    winston.format.combine(
        winston.format.timestamp(),
        levelRouterFormat(),
        winston.format.colorize({all: true}),
        winston.format.splat(),
        winston.format.printf((raw) => {
            // Apply redaction right at the final format step
            const info = redactLogInfo(raw as Record<string, any>);
            const {timestamp, level, message, context, ...meta} = info;
            const contextStr = context ? `[${context}] ` : '';

            const pick = (o: any, keys: string[]) =>
                keys.reduce((acc, k) => (o?.[k] == null ? acc : {...acc, [k]: o[k]}), {});

            const surface = pick(meta, [
                'requestId', 'sessionId', 'tenantId', 'mcpMethod', 'method', 'path', 'statusCode', 'duration',
            ]);

            for (const k of Object.keys(surface)) delete (meta as any)[k];

            // Also redact surface and meta before stringifying
            const redactedSurface = redactLogInfo(surface);
            const redactedMeta = redactLogInfo(meta);

            const metaStr = [
                Object.keys(redactedSurface).length ? JSON.stringify(redactedSurface) : '',
                Object.keys(redactedMeta).length ? JSON.stringify(redactedMeta) : '',
            ].filter(Boolean).join(' ');

            return `${timestamp} ${level}: ${contextStr}${message}${metaStr ? ' ' + metaStr : ''}`;
        })
    );

// ------- Factory -------
export function createLogger(appEnv: Env) {
    return winston.createLogger({
        level: appEnv.LOG_LEVEL,
        levels: logLevels,
        format: loggerFormat(appEnv),
        transports: [new winston.transports.Console()],
    });
}

export const logger = createLogger(env);