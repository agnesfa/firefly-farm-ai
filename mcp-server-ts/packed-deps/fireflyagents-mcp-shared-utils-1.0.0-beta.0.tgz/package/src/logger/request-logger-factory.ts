import {Logger} from "winston";
import {Request} from "express";
import {UUID} from "node:crypto";


export const requestLoggerFactory = (parentLogger: Logger, req: Request, requestId: UUID, sessionId: string) => {

    // // Enhanced request context logger
    return parentLogger.child({
        request: {
            requestId: requestId,
            sessionId: sessionId,
            userAgent: req.headers['user-agent'],
            method: req.method,
            path: req.path,
            url: req.url,
            headers: req.headers,
            body: req.body,
        },
    });

};