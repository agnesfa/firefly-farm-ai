import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createLogger, logLevels, LogLevel } from './logger.js';
import { loadAndValidateEnv } from '../env/env.js';
import winston from 'winston';

describe('Logger', () => {
  it('should have all required log levels', () => {
    const expectedLevels = ['error', 'warn', 'info', 'http', 'debug', 'trace'];
    expect(Object.keys(logLevels)).toEqual(expectedLevels);
  });

  it('should have correct level values', () => {
    expect(logLevels.error).toBe(0);
    expect(logLevels.warn).toBe(1);
    expect(logLevels.info).toBe(2);
    expect(logLevels.http).toBe(3);
    expect(logLevels.debug).toBe(4);
    expect(logLevels.trace).toBe(5);
  });

  it('should have LogLevel type matching logLevels keys', () => {
    const level: LogLevel = 'info';
    expect(Object.keys(logLevels)).toContain(level);
  });

  it('should create a logger instance with the correct level from the environment', () => {
    const testEnv = loadAndValidateEnv({ LOG_LEVEL: 'debug' });
    const logger = createLogger(testEnv);

    expect(logger).toBeDefined();
    expect(logger.level).toBe('debug');
  });

  it('should default to http level if LOG_LEVEL is not specified', () => {
    const testEnv = loadAndValidateEnv({});
    const logger = createLogger(testEnv);

    expect(logger.level).toBe('http');
  });

  describe('Redaction and Masking', () => {
    // Test the redaction logic directly using functions similar to those in the main logger
    const maskStr = (v: string, visibleStart = 3, visibleEnd = 2): string => {
      if (!v) return v;
      if (v.length <= visibleStart + visibleEnd) return '***';
      return `${v.slice(0, visibleStart)}***${v.slice(-visibleEnd)}`;
    };

    const redactUrl = (url?: string): string | undefined => {
      if (!url) return url;
      try {
        const u = new URL(url);
        const sensitiveParams = ['client_secret', 'password', 'username', 'scope', 'grant_type', 'token', 'access_token', 'id_token', 'refresh_token'];
        u.searchParams.forEach((val, key) => {
          if (sensitiveParams.includes(key)) u.searchParams.set(key, '***');
        });
        return u.toString();
      } catch {
        // Not a valid URL; best-effort mask query fragments
        return url.replace(
          /([?&])(client_secret|password|username|scope|grant_type|token|access_token|id_token|refresh_token)=([^&#]+)/gi,
          (_m, sep, k) => `${sep}${k}=***`
        );
      }
    };

    const redactAny = (value: unknown, keyHint?: string): unknown => {
      const sensitiveKeys = ['authorization', 'proxy-authorization', 'x-api-key', 'apiKey', 'apiKeyPrefix', 'token', 'access_token', 'id_token', 'refresh_token', 'client_secret', 'password', 'username', 'scope', 'grant_type'];

      if (value == null) return value;
      if (typeof value === 'string') {
        // redact bearer-like strings only if key hint says so
        if (keyHint && sensitiveKeys.includes(keyHint)) return maskStr(value);
        // redact URLs inline
        return redactUrl(value) ?? value;
      }
      if (Array.isArray(value)) return value.map((v) => redactAny(v));
      if (typeof value === 'object') {
        const out: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
          if (sensitiveKeys.includes(k)) {
            // keep shape, mask value
            if (typeof v === 'string') out[k] = maskStr(v);
            else out[k] = v ? '***' : v;
          } else if (k.toLowerCase().includes('url')) {
            out[k] = typeof v === 'string' ? redactUrl(v) : redactAny(v, k);
          } else if (k.toLowerCase().includes('tokenpreview')) {
            out[k] = undefined; // drop token previews entirely
          } else {
            out[k] = redactAny(v, k);
          }
        }
        return out;
      }
      return value;
    };

    describe('String Masking', () => {
      it('should mask string values correctly', () => {
        expect(maskStr('Bearer abc123def456ghi789')).toBe('Bea***89');
        expect(maskStr('key_test123456789')).toBe('key***89');
        expect(maskStr('short')).toBe('***');
        expect(maskStr('')).toBe('');
      });

      it('should mask API keys and tokens', () => {
        const result = redactAny({
          apiKey: 'sk-1234567890abcdef',
          token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9',
          access_token: 'ya29.A0ARrdaM-example',
          refresh_token: '1//04-refresh-token-example'
        });

        const logEntry = result as Record<string, any>;
        expect(logEntry.apiKey).toBe('sk-***ef');
        expect(logEntry.token).toBe('eyJ***J9');
        expect(logEntry.access_token).toBe('ya2***le');
        expect(logEntry.refresh_token).toBe('1//***le');
      });

      it('should mask password and username fields', () => {
        const result = redactAny({
          password: 'mySecretPass123',
          username: 'testuser@example.com',
          client_secret: 'super_secret_client_value'
        });

        const logEntry = result as Record<string, any>;
        expect(logEntry.password).toBe('myS***23');
        expect(logEntry.username).toBe('tes***om');
        expect(logEntry.client_secret).toBe('sup***ue');
      });

      it('should handle short sensitive values', () => {
        const result = redactAny({
          token: 'abc',
          apiKey: '12',
          password: 'x'
        });

        const logEntry = result as Record<string, any>;
        expect(logEntry.token).toBe('***');
        expect(logEntry.apiKey).toBe('***');
        expect(logEntry.password).toBe('***');
      });

      it('should handle null and undefined sensitive values', () => {
        const result = redactAny({
          token: null,
          apiKey: undefined,
          password: ''
        });

        const logEntry = result as Record<string, any>;
        expect(logEntry.token).toBe(null);
        expect(logEntry.apiKey).toBe(undefined);
        expect(logEntry.password).toBe('');
      });
    });

    describe('URL Redaction', () => {
      it('should redact sensitive parameters in URLs', () => {
        const url = 'https://oauth.example.com/token?grant_type=authorization_code&client_secret=mysecret&username=testuser&password=mypass';
        const redactedUrl = redactUrl(url);

        expect(redactedUrl).toContain('grant_type=***');
        expect(redactedUrl).toContain('client_secret=***');
        expect(redactedUrl).toContain('username=***');
        expect(redactedUrl).toContain('password=***');
        expect(redactedUrl).toContain('https://oauth.example.com/token');
      });

      it('should redact token parameters in URLs', () => {
        const endpoint = 'https://api.example.com/data?access_token=ya29.example&id_token=eyJhbGci&refresh_token=1//04example';
        const redactedEndpoint = redactUrl(endpoint);

        expect(redactedEndpoint).toContain('access_token=***');
        expect(redactedEndpoint).toContain('id_token=***');
        expect(redactedEndpoint).toContain('refresh_token=***');
      });

      it('should handle malformed URLs gracefully', () => {
        const badUrl = 'not-a-valid-url?client_secret=secret&password=pass';
        const redactedBadUrl = redactUrl(badUrl);

        expect(redactedBadUrl).toContain('client_secret=***');
        expect(redactedBadUrl).toContain('password=***');
      });

      it('should preserve URLs without sensitive parameters', () => {
        const cleanUrl = 'https://api.example.com/users?page=1&limit=10';
        const redactedUrl = redactUrl(cleanUrl);

        expect(redactedUrl).toBe(cleanUrl);
      });
    });

    describe('Nested Object Redaction', () => {
      it('should redact sensitive data in nested objects', () => {
        const result = redactAny({
          request: {
            headers: {
              authorization: 'Bearer token123456789',
              'content-type': 'application/json'
            },
            body: {
              client_secret: 'secret123456789',
              username: 'testuser',
              password: 'password123'
            }
          }
        });

        const logEntry = result as any;
        expect(logEntry.request.headers.authorization).toBe('Bea***89');
        expect(logEntry.request.headers['content-type']).toBe('application/json');
        expect(logEntry.request.body.client_secret).toBe('sec***89');
        expect(logEntry.request.body.username).toBe('tes***er');
        expect(logEntry.request.body.password).toBe('pas***23');
      });

      it('should redact sensitive data in arrays', () => {
        const result = redactAny({
          credentials: [
            { apiKey: 'key123456789', name: 'service1' },
            { token: 'token123456789', name: 'service2' }
          ]
        });

        const logEntry = result as any;
        expect(logEntry.credentials[0].apiKey).toBe('key***89');
        expect(logEntry.credentials[0].name).toBe('service1');
        expect(logEntry.credentials[1].token).toBe('tok***89');
        expect(logEntry.credentials[1].name).toBe('service2');
      });
    });

    describe('Special Cases', () => {
      it('should drop tokenpreview fields entirely', () => {
        const result = redactAny({
          tokenPreview: 'eyJhbGciOiJIUzI1NiI',
          accessTokenPreview: 'ya29.A0ARrdaM',
          normalField: 'keep this'
        });

        const logEntry = result as any;
        expect(logEntry.tokenPreview).toBe(undefined);
        expect(logEntry.accessTokenPreview).toBe(undefined);
        expect(logEntry.normalField).toBe('keep this');
      });

      it('should preserve non-sensitive data unchanged', () => {
        const testData = {
          userId: 123,
          email: 'user@example.com',
          preferences: {
            theme: 'dark',
            language: 'en'
          },
          tags: ['important', 'user-data']
        };

        const result = redactAny(testData);
        const logEntry = result as any;
        expect(logEntry.userId).toBe(123);
        expect(logEntry.email).toBe('user@example.com');
        expect(logEntry.preferences).toEqual({ theme: 'dark', language: 'en' });
        expect(logEntry.tags).toEqual(['important', 'user-data']);
      });

      it('should handle mixed sensitive and non-sensitive data', () => {
        const result = redactAny({
          publicData: 'this is safe',
          apiKey: 'sk-1234567890',
          userInfo: {
            name: 'John Doe',
            password: 'secretpass123'
          },
          safeArray: ['item1', 'item2'],
          sensitiveArray: [
            { token: 'token123456789' },
            { normalField: 'safe' }
          ]
        });

        const logEntry = result as any;
        expect(logEntry.publicData).toBe('this is safe');
        expect(logEntry.apiKey).toBe('sk-***90');
        expect(logEntry.userInfo.name).toBe('John Doe');
        expect(logEntry.userInfo.password).toBe('sec***23');
        expect(logEntry.safeArray).toEqual(['item1', 'item2']);
        expect(logEntry.sensitiveArray[0].token).toBe('tok***89');
        expect(logEntry.sensitiveArray[1].normalField).toBe('safe');
      });
    });
  });

  describe('Winston Format Integration Tests', () => {
    let logOutput: any[];
    let logger: winston.Logger;
    let mockTransport: winston.transport;

    beforeEach(() => {
      logOutput = [];

      // Create a custom test transport by extending winston's base transport
      class TestTransport extends winston.transports.Console {
        log(info: any, callback: () => void) {
          logOutput.push(info);
          callback();
        }
      }

      mockTransport = new TestTransport();

      // Use actual createLogger to test the real winston format pipeline
      const testEnv = loadAndValidateEnv({ LOG_LEVEL: 'trace' });
      logger = createLogger(testEnv);

      // Clear and add our test transport instead of console
      logger.clear();
      logger.add(mockTransport);
    });

    afterEach(() => {
      logger?.close();
      logOutput = [];
    });

    describe('redactFormat Integration', () => {
      it.skip('should redact sensitive data in actual winston logs', () => {
        logger.info('API request', {
          apiKey: 'sk-1234567890abcdef',
          url: 'https://api.example.com/token?client_secret=mysecret&access_token=abc123',
          request: {
            url: 'https://oauth.example.com/auth?password=secret123'
          },
          headers: {
            authorization: 'Bearer token123456789'
          }
        });

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];
        expect(logEntry.apiKey).toBe('sk-***ef');
        expect(logEntry.url).toContain('client_secret=***');
        expect(logEntry.url).toContain('access_token=***');
        expect(logEntry.request.url).toContain('password=***');
        expect(logEntry.headers.authorization).toBe('Bea***89');
      });

      it.skip('should handle nested objects and arrays in winston logs', () => {
        logger.info('Complex data structure', {
          config: {
            auth: {
              client_secret: 'super_secret_value',
              username: 'testuser@example.com'
            },
            endpoints: [
              { url: 'https://api1.example.com?token=abc123' },
              { url: 'https://api2.example.com' }
            ]
          }
        });

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];
        expect(logEntry.config.auth.client_secret).toBe('sup***ue');
        expect(logEntry.config.auth.username).toBe('tes***om');
        expect(logEntry.config.endpoints[0].url).toContain('token=***');
        expect(logEntry.config.endpoints[1].url).toBe('https://api2.example.com');
      });
    });

    describe('shouldSample Function Coverage', () => {
      it.skip('should return false when no mcpMethod is present', () => {
        logger.info('Request without MCP method', {
          requestId: 'req-123',
          statusCode: 200
        });

        expect(logOutput).toHaveLength(1);
        expect(logOutput[0].level).toBe('info'); // Not sampled
      });

      it.skip('should return false for non-sampled methods', () => {
        logger.info('Non-sampled method', {
          mcpMethod: 'tools/list',
          requestId: 'req-123',
          statusCode: 200
        });

        expect(logOutput).toHaveLength(1);
        expect(logOutput[0].level).toBe('info'); // Not sampled
      });

      it('should handle different mcpMethod locations', () => {
        // Method in request object
        logger.http('HTTP request', {
          request: {
            mcpMethod: 'notifications/initialized',
            requestId: 'req-456'
          },
          statusCode: 200
        });

        // Method in meta object
        logger.http('HTTP request with meta', {
          meta: {
            mcpMethod: 'notifications/initialized',
            requestId: 'req-789'
          }
        });

        expect(logOutput).toHaveLength(2);
        // Both may be sampled depending on hash
      });

      it('should handle different requestId locations for hash calculation', () => {
        logger.info('Request with nested requestId', {
          mcpMethod: 'notifications/initialized',
          request: {
            requestId: 'nested-req-123'
          },
          statusCode: 200
        });

        logger.info('Request with meta requestId', {
          mcpMethod: 'notifications/initialized',
          meta: {
            requestId: 'meta-req-456'
          },
          statusCode: 200
        });

        expect(logOutput).toHaveLength(2);
        // Each should be processed with their respective request IDs
      });
    });

    describe('loggerFormat printf Integration', () => {
      beforeEach(() => {
        // Use a simple mock transport to capture the final formatted string
        logOutput = [];

        class StringTestTransport extends winston.transports.Console {
          log(info: any, callback: () => void) {
            // Capture the formatted string that would be output
            logOutput.push({
              ...info,
              formattedMessage: info[Symbol.for('message')] || info.message
            });
            callback();
          }
        }

        const stringTransport = new StringTestTransport();

        logger.clear();
        logger.add(stringTransport);
      });

      it('should format log messages with context and metadata', () => {
        logger.info('Test message', {
          context: 'test-component',
          requestId: 'req-123',
          sessionId: 'session-456',
          customField: 'custom-value'
        });

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];
        expect(logEntry.context).toBe('test-component');
        expect(logEntry.requestId).toBe('req-123');
        expect(logEntry.sessionId).toBe('session-456');
        expect(logEntry.customField).toBe('custom-value');
      });

      it('should surface priority metadata fields correctly', () => {
        logger.info('API call', {
          requestId: 'req-789',
          sessionId: 'session-abc',
          tenantId: 'tenant-def',
          mcpMethod: 'tools/call',
          method: 'POST',
          path: '/api/test',
          statusCode: 200,
          duration: 150,
          extraField: 'should-be-in-meta'
        });

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];

        // Priority fields should be present
        expect(logEntry.requestId).toBe('req-789');
        expect(logEntry.sessionId).toBe('session-abc');
        expect(logEntry.tenantId).toBe('tenant-def');
        expect(logEntry.mcpMethod).toBe('tools/call');
        expect(logEntry.method).toBe('POST');
        expect(logEntry.path).toBe('/api/test');
        expect(logEntry.statusCode).toBe(200);
        expect(logEntry.duration).toBe(150);

        // Extra field should also be present
        expect(logEntry.extraField).toBe('should-be-in-meta');
      });

      it.skip('should handle messages without context', () => {
        logger.error('Error without context', {
          errorCode: 'E001',
          stack: 'Error stack trace'
        });

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];
        expect(logEntry.message).toBe('Error without context');
        expect(logEntry.errorCode).toBe('E001');
        expect(logEntry.stack).toBe('Error stack trace');
      });

      it.skip('should handle empty metadata', () => {
        logger.warn('Simple warning');

        expect(logOutput).toHaveLength(1);
        const logEntry = logOutput[0];
        expect(logEntry.message).toBe('Simple warning');
        expect(logEntry.level).toBe('warn');
      });
    });
  });
}); 