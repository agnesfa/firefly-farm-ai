import { describe, it, expect } from 'vitest';

describe('shared/utils index exports', () => {
  it('should export env utilities', async () => {
    const module = await import('./index.js');
    
    // Verify env exports are available
    expect(module.loadAndValidateEnv).toBeDefined();
    expect(typeof module.loadAndValidateEnv).toBe('function');
  });

  it('should export logger utilities', async () => {
    const module = await import('./index.js');
    
    // Verify logger exports are available
    expect(module.createLogger).toBeDefined();
    expect(module.logger).toBeDefined();
    expect(module.logLevels).toBeDefined();
    
    expect(typeof module.createLogger).toBe('function');
    expect(typeof module.logger).toBe('object');
    expect(typeof module.logLevels).toBe('object');
  });

  it('should export package utilities', async () => {
    const module = await import('./index.js');
    
    // Verify package exports are available
    expect(module.readNameAndVersionFromPackageJson).toBeDefined();
    expect(typeof module.readNameAndVersionFromPackageJson).toBe('function');
  });

  it('should have all expected exports', async () => {
    const module = await import('./index.js');
    
    // Check that module has the expected structure
    expect(module).toBeDefined();
    expect(typeof module).toBe('object');
    
    // Verify we have exports from all sub-modules
    const exportKeys = Object.keys(module);
    expect(exportKeys.length).toBeGreaterThan(0);
  });
});