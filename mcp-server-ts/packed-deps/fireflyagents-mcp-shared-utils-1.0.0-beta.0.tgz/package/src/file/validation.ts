/**
 * Generic validation utilities for JSON data
 * Provides type-safe validation patterns for loaded data
 */

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export type Validator<T> = (data: any) => data is T;

export interface ValidationRule<T> {
  name: string;
  validate: (data: T) => ValidationResult;
}

/**
 * Schema validator for JSON data with comprehensive error reporting
 */
export class JsonValidator<T> {
  private rules: ValidationRule<T>[] = [];

  /**
   * Add a validation rule
   */
  addRule(rule: ValidationRule<T>): this {
    this.rules.push(rule);
    return this;
  }

  /**
   * Add a required field validation
   */
  requireField(fieldPath: string, type?: string): this {
    return this.addRule({
      name: `required-field-${fieldPath}`,
      validate: (data: T) => {
        const value = this.getNestedValue(data, fieldPath);
        const exists = value !== undefined && value !== null;
        const typeMatches = !type || typeof value === type;

        return {
          valid: exists && typeMatches,
          errors: [
            ...(exists ? [] : [`Required field missing: ${fieldPath}`]),
            ...(exists && !typeMatches ? [`Field ${fieldPath} must be of type ${type}, got ${typeof value}`] : [])
          ],
          warnings: []
        };
      }
    });
  }

  /**
   * Add array validation
   */
  requireArray(fieldPath: string, minLength?: number): this {
    return this.addRule({
      name: `array-field-${fieldPath}`,
      validate: (data: T) => {
        const value = this.getNestedValue(data, fieldPath);
        const isArray = Array.isArray(value);
        const meetsMinLength = !minLength || (isArray && value.length >= minLength);

        return {
          valid: isArray && meetsMinLength,
          errors: [
            ...(isArray ? [] : [`Field ${fieldPath} must be an array`]),
            ...(isArray && !meetsMinLength ? [`Array ${fieldPath} must have at least ${minLength} items`] : [])
          ],
          warnings: []
        };
      }
    });
  }

  /**
   * Add version validation
   */
  requireVersion(expectedVersion: string, versionField: string = 'version'): this {
    return this.addRule({
      name: 'version-check',
      validate: (data: T) => {
        const version = this.getNestedValue(data, versionField);
        const matches = version === expectedVersion;

        return {
          valid: matches,
          errors: matches ? [] : [`Unsupported version: ${version}. Expected: ${expectedVersion}`],
          warnings: []
        };
      }
    });
  }

  /**
   * Add duplicate detection for arrays
   */
  preventDuplicates<K>(arrayPath: string, keyPath: string): this {
    return this.addRule({
      name: `no-duplicates-${arrayPath}-${keyPath}`,
      validate: (data: T) => {
        const array = this.getNestedValue(data, arrayPath);
        
        if (!Array.isArray(array)) {
          return { valid: true, errors: [], warnings: [] };
        }

        const seen = new Set<K>();
        const duplicates: K[] = [];

        for (const item of array) {
          const key = this.getNestedValue(item, keyPath) as K;
          if (seen.has(key)) {
            duplicates.push(key);
          }
          seen.add(key);
        }

        return {
          valid: duplicates.length === 0,
          errors: duplicates.length > 0 ? [`Duplicate values found in ${arrayPath}.${keyPath}: ${duplicates.join(', ')}`] : [],
          warnings: []
        };
      }
    });
  }

  /**
   * Validate data against all rules
   */
  validate(data: T): ValidationResult {
    const allResults = this.rules.map(rule => rule.validate(data));
    
    return {
      valid: allResults.every(result => result.valid),
      errors: allResults.flatMap(result => result.errors),
      warnings: allResults.flatMap(result => result.warnings)
    };
  }

  /**
   * Get nested value from object using dot notation
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }
}

/**
 * Create a validator for a specific schema type
 */
export function createValidator<T>(): JsonValidator<T> {
  return new JsonValidator<T>();
}

/**
 * Common validation patterns
 */
export const CommonValidations = {
  /**
   * Validate email format
   */
  email: (value: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  },

  /**
   * Validate URL format
   */
  url: (value: string): boolean => {
    try {
      new URL(value);
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Validate non-empty string
   */
  nonEmptyString: (value: any): value is string => {
    return typeof value === 'string' && value.trim().length > 0;
  },

  /**
   * Validate positive number
   */
  positiveNumber: (value: any): value is number => {
    return typeof value === 'number' && value > 0;
  }
};