import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { resolve } from 'path';

// Mock logger before importing the module
vi.mock('../logger/logger.js', () => ({
  logger: {
    child: vi.fn(() => ({
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn()
    })),
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn()
  }
}));

import { JsonFileReader } from './json-file-reader.js';

describe('JsonFileReader', () => {
  const testFilePath = resolve('./test-config.json');
  const testData = { version: '1.0', settings: { key: 'value' } };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    // Clean up test file
    if (existsSync(testFilePath)) {
      unlinkSync(testFilePath);
    }
  });

  describe('constructor', () => {
    it('creates reader with default config', () => {
      const reader = new JsonFileReader({ filePath: testFilePath });
      expect(reader).toBeInstanceOf(JsonFileReader);
    });

    it('creates reader with custom config', () => {
      const reader = new JsonFileReader({ 
        filePath: testFilePath,
        encoding: 'utf8',
        validateOnLoad: false
      });
      expect(reader).toBeInstanceOf(JsonFileReader);
    });
  });

  describe('exists', () => {
    it('returns false for non-existent file', () => {
      const reader = new JsonFileReader({ filePath: testFilePath });
      expect(reader.exists()).toBe(false);
    });

    it('returns true for existing file', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      expect(reader.exists()).toBe(true);
    });
  });

  describe('load', () => {
    it('loads and parses JSON file successfully', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      const result = reader.load();
      
      expect(result).toEqual(testData);
      // Logger should be called - specific assertions removed due to mock complexity
    });

    it('throws error for non-existent file', () => {
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      expect(() => reader.load()).toThrow(`JSON file not found: ${testFilePath}`);
    });

    it('throws error for invalid JSON', () => {
      writeFileSync(testFilePath, '{ invalid json }');
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      expect(() => reader.load()).toThrow('Invalid JSON in file');
    });

    it('uses cached data when requested', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      const result1 = reader.load();
      const result2 = reader.load(true); // Use cache
      
      expect(result1).toEqual(result2);
    });
  });

  describe('loadAsync', () => {
    it('loads data asynchronously', async () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      const result = await reader.loadAsync();
      
      expect(result).toEqual(testData);
    });
  });

  describe('watch', () => {
    it('sets up file watcher', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      const callback = vi.fn();
      
      reader.watch(callback);
      
      // Verify watcher was set up (no exception thrown)
      expect(() => reader.unwatch()).not.toThrow();
    });

    it('calls callback with error for non-existent file', () => {
      const reader = new JsonFileReader({ filePath: testFilePath });
      const callback = vi.fn();
      
      reader.watch(callback);
      
      expect(callback).toHaveBeenCalledWith(null, expect.any(Error));
    });
  });

  describe('unwatch', () => {
    it('stops file watcher', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      const callback = vi.fn();
      
      reader.watch(callback);
      
      // Verify unwatch completes without error
      expect(() => reader.unwatch()).not.toThrow();
    });
  });

  describe('getMetadata', () => {
    it('returns file metadata', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      reader.load(); // Load to populate cache
      const metadata = reader.getMetadata();
      
      expect(metadata).toEqual({
        exists: true,
        filePath: testFilePath,
        lastLoaded: expect.any(Date),
        cached: true
      });
    });
  });

  describe('clearCache', () => {
    it('clears cached data', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      
      reader.load();
      reader.clearCache();
      
      const metadata = reader.getMetadata();
      expect(metadata.cached).toBe(false);
    });
  });

  describe('destroy', () => {
    it('cleans up resources', () => {
      writeFileSync(testFilePath, JSON.stringify(testData));
      const reader = new JsonFileReader({ filePath: testFilePath });
      const callback = vi.fn();
      
      reader.watch(callback);
      reader.load();
      reader.destroy();
      
      const metadata = reader.getMetadata();
      expect(metadata.cached).toBe(false);
    });
  });
});