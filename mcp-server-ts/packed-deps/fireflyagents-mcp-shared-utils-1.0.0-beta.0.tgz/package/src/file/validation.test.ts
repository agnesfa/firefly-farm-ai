import { describe, it, expect, beforeEach } from 'vitest';
import { 
  JsonValidator, 
  createValidator, 
  CommonValidations,
  type ValidationRule
} from './validation.js';

describe('JsonValidator', () => {
  interface TestConfig {
    version: string;
    name: string;
    settings: {
      enabled: boolean;
      count: number;
    };
    items: Array<{ id: string; name: string }>;
    optionalField?: string;
  }

  let validator: JsonValidator<TestConfig>;
  let validData: TestConfig;

  beforeEach(() => {
    validator = new JsonValidator<TestConfig>();
    validData = {
      version: '1.0',
      name: 'test-config',
      settings: {
        enabled: true,
        count: 5
      },
      items: [
        { id: 'item1', name: 'First Item' },
        { id: 'item2', name: 'Second Item' }
      ]
    };
  });

  describe('constructor and basic setup', () => {
    it('creates validator instance', () => {
      expect(validator).toBeInstanceOf(JsonValidator);
    });

    it('starts with empty rules', () => {
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(result.warnings).toHaveLength(0);
    });
  });

  describe('requireField validation', () => {
    it('validates required fields exist', () => {
      validator.requireField('version').requireField('name');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('fails when required field is missing', () => {
      validator.requireField('missingField');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Required field missing: missingField');
    });

    it('validates nested field paths', () => {
      validator.requireField('settings.enabled').requireField('settings.count');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails when nested field is missing', () => {
      validator.requireField('settings.missing');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Required field missing: settings.missing');
    });

    it('validates field types', () => {
      validator
        .requireField('version', 'string')
        .requireField('settings.count', 'number')
        .requireField('settings.enabled', 'boolean');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails when field type is incorrect', () => {
      validator.requireField('version', 'number');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Field version must be of type number, got string');
    });

    it('handles null and undefined values', () => {
      validator.requireField('optionalField');
      
      const dataWithNull = { ...validData, optionalField: null as any };
      const dataWithUndefined = { ...validData, optionalField: undefined };
      
      expect(validator.validate(dataWithNull).valid).toBe(false);
      expect(validator.validate(dataWithUndefined).valid).toBe(false);
    });
  });

  describe('requireArray validation', () => {
    it('validates array fields', () => {
      validator.requireArray('items');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails when field is not an array', () => {
      validator.requireArray('version'); // version is a string, not array
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Field version must be an array');
    });

    it('validates minimum array length', () => {
      validator.requireArray('items', 2);
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true); // has 2 items
    });

    it('fails when array is too short', () => {
      validator.requireArray('items', 5);
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Array items must have at least 5 items');
    });

    it('handles empty arrays', () => {
      const dataWithEmptyArray = { ...validData, items: [] };
      validator.requireArray('items', 1);
      
      const result = validator.validate(dataWithEmptyArray);
      expect(result.valid).toBe(false);
    });

    it('validates nested array paths', () => {
      const nestedData = {
        ...validData,
        nested: {
          list: [1, 2, 3]
        }
      };
      validator.requireArray('nested.list', 2);
      
      const result = validator.validate(nestedData);
      expect(result.valid).toBe(true);
    });
  });

  describe('requireVersion validation', () => {
    it('validates correct version', () => {
      validator.requireVersion('1.0');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails on incorrect version', () => {
      validator.requireVersion('2.0');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Unsupported version: 1.0. Expected: 2.0');
    });

    it('validates custom version field', () => {
      const dataWithCustomVersion = { ...validData, schemaVersion: '3.0' };
      validator.requireVersion('3.0', 'schemaVersion');
      
      const result = validator.validate(dataWithCustomVersion);
      expect(result.valid).toBe(true);
    });

    it('handles missing version field', () => {
      const dataWithoutVersion = { ...validData };
      delete (dataWithoutVersion as any).version;
      validator.requireVersion('1.0');
      
      const result = validator.validate(dataWithoutVersion);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Unsupported version: undefined. Expected: 1.0');
    });
  });

  describe('preventDuplicates validation', () => {
    it('validates unique values', () => {
      validator.preventDuplicates('items', 'id');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails when duplicates exist', () => {
      const dataWithDuplicates = {
        ...validData,
        items: [
          { id: 'item1', name: 'First Item' },
          { id: 'item1', name: 'Duplicate Item' }, // Duplicate ID
          { id: 'item2', name: 'Second Item' }
        ]
      };
      validator.preventDuplicates('items', 'id');
      
      const result = validator.validate(dataWithDuplicates);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Duplicate values found in items.id: item1');
    });

    it('handles multiple duplicates', () => {
      const dataWithMultipleDuplicates = {
        ...validData,
        items: [
          { id: 'item1', name: 'First' },
          { id: 'item1', name: 'Duplicate 1' },
          { id: 'item2', name: 'Second' },
          { id: 'item2', name: 'Duplicate 2' }
        ]
      };
      validator.preventDuplicates('items', 'id');
      
      const result = validator.validate(dataWithMultipleDuplicates);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Duplicate values found in items.id: item1, item2');
    });

    it('handles nested duplicate key paths', () => {
      const dataWithNestedKeys = {
        ...validData,
        users: [
          { profile: { email: 'user1@test.com' } },
          { profile: { email: 'user2@test.com' } },
          { profile: { email: 'user1@test.com' } } // Duplicate
        ]
      };
      validator.preventDuplicates('users', 'profile.email');
      
      const result = validator.validate(dataWithNestedKeys);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Duplicate values found in users.profile.email: user1@test.com');
    });

    it('ignores non-array fields gracefully', () => {
      validator.preventDuplicates('version', 'someKey'); // version is not an array
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true); // Should not fail
    });

    it('handles empty arrays', () => {
      const dataWithEmptyArray = { ...validData, items: [] };
      validator.preventDuplicates('items', 'id');
      
      const result = validator.validate(dataWithEmptyArray);
      expect(result.valid).toBe(true);
    });
  });

  describe('complex validation scenarios', () => {
    it('combines multiple validation rules', () => {
      validator
        .requireField('version', 'string')
        .requireField('name', 'string')
        .requireArray('items', 1)
        .requireVersion('1.0')
        .preventDuplicates('items', 'id');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('accumulates multiple errors', () => {
      const invalidData: any = {
        // Missing version
        name: 123, // Wrong type
        items: 'not-an-array', // Not an array
        duplicates: [
          { key: 'dup' },
          { key: 'dup' }
        ]
      };

      validator
        .requireField('version')
        .requireField('name', 'string')
        .requireArray('items')
        .preventDuplicates('duplicates', 'key');
      
      const result = validator.validate(invalidData);
      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(4);
      expect(result.errors).toContain('Required field missing: version');
      expect(result.errors).toContain('Field name must be of type string, got number');
      expect(result.errors).toContain('Field items must be an array');
      expect(result.errors).toContain('Duplicate values found in duplicates.key: dup');
    });

    it('handles deeply nested validation', () => {
      const deepData: any = {
        level1: {
          level2: {
            level3: {
              value: 'deep',
              items: [
                { id: 1, name: 'item1' },
                { id: 2, name: 'item2' }
              ]
            }
          }
        }
      };

      validator
        .requireField('level1.level2.level3.value', 'string')
        .requireArray('level1.level2.level3.items', 2)
        .preventDuplicates('level1.level2.level3.items', 'id');
      
      const result = validator.validate(deepData);
      expect(result.valid).toBe(true);
    });
  });

  describe('addRule custom validation', () => {
    it('accepts custom validation rules', () => {
      const customRule: ValidationRule<TestConfig> = {
        name: 'custom-rule',
        validate: (data) => ({
          valid: data.name.startsWith('test-'),
          errors: data.name.startsWith('test-') ? [] : ['Name must start with test-'],
          warnings: []
        })
      };

      validator.addRule(customRule);
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('fails custom validation rules', () => {
      const customRule: ValidationRule<TestConfig> = {
        name: 'custom-rule',
        validate: (data) => ({
          valid: data.name === 'expected-name',
          errors: data.name === 'expected-name' ? [] : ['Name does not match expected value'],
          warnings: []
        })
      };

      validator.addRule(customRule);
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Name does not match expected value');
    });

    it('supports validation warnings', () => {
      const warningRule: ValidationRule<TestConfig> = {
        name: 'warning-rule',
        validate: (data) => ({
          valid: true,
          errors: [],
          warnings: data.settings.count > 10 ? ['Count is quite high'] : []
        })
      };

      validator.addRule(warningRule);
      
      const dataWithHighCount = { ...validData, settings: { ...validData.settings, count: 15 } };
      const result = validator.validate(dataWithHighCount);
      expect(result.valid).toBe(true);
      expect(result.warnings).toContain('Count is quite high');
    });
  });

  describe('getNestedValue edge cases', () => {
    it('handles undefined intermediate values', () => {
      validator.requireField('missing.deeply.nested.value');
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Required field missing: missing.deeply.nested.value');
    });

    it('handles null intermediate values', () => {
      const dataWithNull = { ...validData, nullField: null };
      validator.requireField('nullField.subfield');
      
      const result = validator.validate(dataWithNull);
      expect(result.valid).toBe(false);
    });

    it('handles array index access', () => {
      validator.requireField('items.0.id'); // Access first item's id
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(true);
    });

    it('handles empty path', () => {
      // Empty path returns undefined, so this should fail
      validator.requireField(''); 
      
      const result = validator.validate(validData);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Required field missing: ');
    });
  });
});

describe('createValidator factory', () => {
  it('creates new validator instance', () => {
    const validator = createValidator<{ test: string }>();
    expect(validator).toBeInstanceOf(JsonValidator);
  });

  it('creates independent instances', () => {
    const validator1 = createValidator<{ field1: string }>();
    const validator2 = createValidator<{ field2: number }>();
    
    validator1.requireField('field1');
    validator2.requireField('field2');
    
    // Validators should be independent
    const testData1 = { field1: 'test' };
    const testData2 = { field2: 42 };
    
    expect(validator1.validate(testData1).valid).toBe(true);
    expect(validator1.validate(testData2 as any).valid).toBe(false);
    expect(validator2.validate(testData1 as any).valid).toBe(false);
    expect(validator2.validate(testData2).valid).toBe(true);
  });
});

describe('CommonValidations', () => {
  describe('email validation', () => {
    it('validates correct email formats', () => {
      expect(CommonValidations.email('user@example.com')).toBe(true);
      expect(CommonValidations.email('test.email@domain.co.uk')).toBe(true);
      expect(CommonValidations.email('user+tag@example.org')).toBe(true);
    });

    it('rejects invalid email formats', () => {
      expect(CommonValidations.email('invalid-email')).toBe(false);
      expect(CommonValidations.email('@example.com')).toBe(false);
      expect(CommonValidations.email('user@')).toBe(false);
      expect(CommonValidations.email('user@.com')).toBe(false);
      expect(CommonValidations.email('')).toBe(false);
    });
  });

  describe('url validation', () => {
    it('validates correct URL formats', () => {
      expect(CommonValidations.url('https://example.com')).toBe(true);
      expect(CommonValidations.url('http://localhost:3000')).toBe(true);
      expect(CommonValidations.url('ftp://files.example.com')).toBe(true);
    });

    it('rejects invalid URL formats', () => {
      expect(CommonValidations.url('not-a-url')).toBe(false);
      expect(CommonValidations.url('http://')).toBe(false);
      expect(CommonValidations.url('')).toBe(false);
      expect(CommonValidations.url('://example.com')).toBe(false);
    });
  });

  describe('nonEmptyString validation', () => {
    it('validates non-empty strings', () => {
      expect(CommonValidations.nonEmptyString('hello')).toBe(true);
      expect(CommonValidations.nonEmptyString('  text  ')).toBe(true);
    });

    it('rejects empty and non-string values', () => {
      expect(CommonValidations.nonEmptyString('')).toBe(false);
      expect(CommonValidations.nonEmptyString('   ')).toBe(false);
      expect(CommonValidations.nonEmptyString(null)).toBe(false);
      expect(CommonValidations.nonEmptyString(undefined)).toBe(false);
      expect(CommonValidations.nonEmptyString(123)).toBe(false);
    });
  });

  describe('positiveNumber validation', () => {
    it('validates positive numbers', () => {
      expect(CommonValidations.positiveNumber(1)).toBe(true);
      expect(CommonValidations.positiveNumber(0.1)).toBe(true);
      expect(CommonValidations.positiveNumber(1000)).toBe(true);
    });

    it('rejects zero, negative, and non-number values', () => {
      expect(CommonValidations.positiveNumber(0)).toBe(false);
      expect(CommonValidations.positiveNumber(-1)).toBe(false);
      expect(CommonValidations.positiveNumber('1')).toBe(false);
      expect(CommonValidations.positiveNumber(null)).toBe(false);
      expect(CommonValidations.positiveNumber(undefined)).toBe(false);
      expect(CommonValidations.positiveNumber(NaN)).toBe(false);
    });
  });
});

describe('ValidationResult interface', () => {
  it('properly structures validation results', () => {
    const validator = createValidator<{ test: string }>();
    validator.requireField('test');
    
    const result = validator.validate({ test: 'value' });
    
    expect(result).toHaveProperty('valid');
    expect(result).toHaveProperty('errors');
    expect(result).toHaveProperty('warnings');
    expect(typeof result.valid).toBe('boolean');
    expect(Array.isArray(result.errors)).toBe(true);
    expect(Array.isArray(result.warnings)).toBe(true);
  });
});

describe('error handling and edge cases', () => {
  let validator: JsonValidator<any>;

  beforeEach(() => {
    validator = createValidator<any>();
  });

  it('handles circular references gracefully', () => {
    const circularData: any = { name: 'test' };
    circularData.self = circularData;
    
    validator.requireField('name');
    
    // Should not throw, even with circular reference
    const result = validator.validate(circularData);
    expect(result.valid).toBe(true);
  });

  it('handles very deep nesting', () => {
    let deepData: any = {};
    let current = deepData;
    
    // Create 100 levels of nesting
    for (let i = 0; i < 100; i++) {
      current.nested = {};
      current = current.nested;
    }
    current.value = 'deep';
    
    validator.requireField('nested'.repeat(100).replace(/nested/g, 'nested.') + 'value');
    
    const result = validator.validate(deepData);
    expect(result.valid).toBe(true);
  });

  it('handles special characters in field names', () => {
    const data = {
      'field-with-dashes': 'value1',
      'field_with_underscores': 'value2',
      'field.with.dots': 'value3'
    };
    
    validator.requireField('field-with-dashes');
    validator.requireField('field_with_underscores');
    
    const result = validator.validate(data);
    expect(result.valid).toBe(true);
  });

  it('handles numeric field names', () => {
    const data = {
      '123': 'numeric field',
      items: ['item1', 'item2', 'item3']
    };
    
    validator.requireField('123');
    validator.requireField('items.1'); // Second item in array
    
    const result = validator.validate(data);
    expect(result.valid).toBe(true);
  });

  it('handles mixed data types in arrays', () => {
    const data = {
      mixedArray: [
        { id: 'string-id', value: 1 },
        { id: 2, value: 'string-value' },
        { id: true, value: null }
      ]
    };
    
    validator.requireArray('mixedArray');
    validator.preventDuplicates('mixedArray', 'id');
    
    const result = validator.validate(data);
    expect(result.valid).toBe(true); // All IDs are different types
  });
});