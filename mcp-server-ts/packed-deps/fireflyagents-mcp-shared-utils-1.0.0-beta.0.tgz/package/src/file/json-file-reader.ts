import { readFileSync, existsSync, watchFile, unwatchFile } from 'fs';
import { resolve } from 'path';
import { logger as baseLogger } from '../logger/logger.js';

const logger = baseLogger.child({ context: 'fa:shared-utils:json-file-reader' });

export interface JsonFileReaderConfig {
  filePath: string;
  encoding?: BufferEncoding;
  validateOnLoad?: boolean;
}

export interface FileWatchOptions {
  interval?: number; // Polling interval in ms, default: 5007
}

/**
 * Generic JSON file reader with validation and watching capabilities
 * Provides type-safe JSON file loading with comprehensive error handling
 * 
 * @example
 * ```typescript
 * interface MyConfig {
 *   version: string;
 *   settings: Record<string, any>;
 * }
 * 
 * const reader = new JsonFileReader<MyConfig>({
 *   filePath: './config/settings.json'
 * });
 * 
 * const config = reader.load();
 * ```
 */
export class JsonFileReader<T = any> {
  private config: Required<JsonFileReaderConfig>;
  private cachedData: T | null = null;
  private lastLoadTime: number = 0;
  private watchCallback: ((data: T, error?: Error) => void) | null = null;

  constructor(config: JsonFileReaderConfig) {
    this.config = {
      encoding: 'utf-8',
      validateOnLoad: true,
      ...config
    };
  }

  /**
   * Check if the file exists
   */
  exists(): boolean {
    try {
      const resolvedPath = resolve(this.config.filePath);
      return existsSync(resolvedPath);
    } catch (error) {
      logger.warn('Error checking file existence', {
        filePath: this.config.filePath,
        error: error instanceof Error ? error.message : String(error)
      });
      return false;
    }
  }

  /**
   * Load and parse JSON file
   * @param useCache - Whether to use cached data if available
   * @returns Parsed JSON data
   * @throws Error if file doesn't exist, can't be read, or contains invalid JSON
   */
  load(useCache: boolean = false): T {
    const resolvedPath = resolve(this.config.filePath);
    
    // Use cache if requested and available
    if (useCache && this.cachedData && this.isDataFresh()) {
      logger.debug('Using cached JSON data', { filePath: this.config.filePath });
      return this.cachedData;
    }

    if (!this.exists()) {
      throw new Error(`JSON file not found: ${resolvedPath}`);
    }

    try {
      logger.debug('Loading JSON file', { filePath: resolvedPath });
      
      const fileContent = readFileSync(resolvedPath, this.config.encoding);
      const data: T = JSON.parse(fileContent);
      
      // Cache the loaded data
      this.cachedData = data;
      this.lastLoadTime = Date.now();
      
      logger.info('JSON file loaded successfully', {
        filePath: this.config.filePath,
        dataType: typeof data,
        isArray: Array.isArray(data)
      });
      
      return data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error('Failed to load JSON file', {
        filePath: resolvedPath,
        error: errorMessage
      });
      
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${this.config.filePath}: ${errorMessage}`);
      } else {
        throw new Error(`Failed to read file ${this.config.filePath}: ${errorMessage}`);
      }
    }
  }

  /**
   * Load JSON file asynchronously (useful for consistency with async APIs)
   */
  async loadAsync(useCache: boolean = false): Promise<T> {
    return this.load(useCache);
  }

  /**
   * Watch file for changes and call callback when file is modified
   * @param callback - Function to call when file changes
   * @param options - Watch options
   */
  watch(callback: (data: T, error?: Error) => void, options: FileWatchOptions = {}): void {
    if (this.watchCallback) {
      this.unwatch(); // Stop existing watcher
    }

    const resolvedPath = resolve(this.config.filePath);
    this.watchCallback = callback;

    if (!this.exists()) {
      logger.warn('Cannot watch non-existent file', { filePath: resolvedPath });
      callback(null as unknown as T, new Error(`File not found: ${resolvedPath}`));
      return;
    }

    logger.info('Starting file watcher', { 
      filePath: this.config.filePath,
      interval: options.interval || 5007
    });

    watchFile(resolvedPath, { interval: options.interval || 5007 }, (curr, prev) => {
      if (curr.mtime !== prev.mtime) {
        logger.debug('File change detected', { 
          filePath: this.config.filePath,
          lastModified: curr.mtime.toISOString()
        });
        
        try {
          const newData = this.load(false); // Force reload, don't use cache
          callback(newData);
        } catch (error) {
          logger.error('Error reloading file after change', {
            filePath: this.config.filePath,
            error: error instanceof Error ? error.message : String(error)
          });
          callback(null as unknown as T, error instanceof Error ? error : new Error(String(error)));
        }
      }
    });
  }

  /**
   * Stop watching the file
   */
  unwatch(): void {
    if (this.watchCallback) {
      const resolvedPath = resolve(this.config.filePath);
      unwatchFile(resolvedPath);
      this.watchCallback = null;
      
      logger.info('Stopped file watcher', { filePath: this.config.filePath });
    }
  }

  /**
   * Get file metadata
   */
  getMetadata(): { exists: boolean; filePath: string; lastLoaded?: Date; cached: boolean } {
    return {
      exists: this.exists(),
      filePath: this.config.filePath,
      lastLoaded: this.lastLoadTime ? new Date(this.lastLoadTime) : undefined,
      cached: this.cachedData !== null
    };
  }

  /**
   * Clear cached data
   */
  clearCache(): void {
    this.cachedData = null;
    this.lastLoadTime = 0;
    logger.debug('Cache cleared', { filePath: this.config.filePath });
  }

  /**
   * Validate that cached data is still fresh (within 5 minutes)
   */
  private isDataFresh(): boolean {
    const fiveMinutes = 5 * 60 * 1000;
    return Date.now() - this.lastLoadTime < fiveMinutes;
  }

  /**
   * Cleanup resources when done
   */
  destroy(): void {
    this.unwatch();
    this.clearCache();
  }
}