// shared/utils/schema/type-mapper.ts
import { z, type ZodTypeAny } from 'zod';
import type { TypeMapper } from './dynamic-union-builder.js';
import { jsonSchemaToZod, type JSONSchema7 } from './json-schema-to-zod.js';
import { logger as baseLogger } from '../logger/logger.js';

const logger = baseLogger.child({ context: 'shared-utils:type-mapper' });

/**
 * Configuration for basic type mappings
 */
export interface BasicTypeMapping {
  /** Zod schema for this type */
  schema: ZodTypeAny;
  /** Optional description */
  description?: string;
}

/**
 * Basic configurable type mapper implementation
 */
export class BasicTypeMapper implements TypeMapper {
  private typeMappings: Map<string, BasicTypeMapping>;

  constructor(mappings: Record<string, BasicTypeMapping> = {}) {
    this.typeMappings = new Map(Object.entries(mappings));
  }

  /**
   * Add or update a type mapping
   */
  addMapping(type: string, mapping: BasicTypeMapping): void {
    this.typeMappings.set(type, mapping);
  }

  /**
   * Remove a type mapping
   */
  removeMapping(type: string): boolean {
    return this.typeMappings.delete(type);
  }

  /**
   * Maps a type string to a Zod validator
   */
  mapType(type: string): ZodTypeAny {
    const mapping = this.typeMappings.get(type);
    if (!mapping) {
      throw new Error(`Unsupported type: ${type}. Supported types: ${this.getSupportedTypes().join(', ')}`);
    }
    return mapping.schema;
  }

  /**
   * Returns supported type names
   */
  getSupportedTypes(): string[] {
    return Array.from(this.typeMappings.keys()).sort();
  }

  /**
   * Checks if a type is supported
   */
  isSupported(type: string): boolean {
    return this.typeMappings.has(type);
  }

  /**
   * Get mapping info for a type
   */
  getMappingInfo(type: string): BasicTypeMapping | undefined {
    return this.typeMappings.get(type);
  }
}

/**
 * Creates a standard type mapper with common primitive types
 */
export function createStandardTypeMapper(): BasicTypeMapper {
  return new BasicTypeMapper({
    'string': {
      schema: z.string(),
      description: 'Text string value'
    },
    'number': {
      schema: z.number(),
      description: 'Numeric value'
    },
    'integer': {
      schema: z.number().int(),
      description: 'Integer numeric value'
    },
    'boolean': {
      schema: z.boolean(),
      description: 'True/false boolean value'
    },
    'date': {
      schema: z.string().datetime(),
      description: 'ISO datetime string'
    },
    'email': {
      schema: z.string().email(),
      description: 'Email address string'
    },
    'url': {
      schema: z.string().url(),
      description: 'URL string'
    },
    'uuid': {
      schema: z.string().uuid(),
      description: 'UUID string'
    },
  });
}

/**
 * Creates a minimal type mapper with just basic primitives
 */
export function createMinimalTypeMapper(): BasicTypeMapper {
  return new BasicTypeMapper({
    'string': {
      schema: z.string(),
      description: 'Text string value'
    },
    'number': {
      schema: z.number(),
      description: 'Numeric value'
    },
    'boolean': {
      schema: z.boolean(),
      description: 'True/false boolean value'
    },
  });
}

/**
 * Enhance a TypeMapper with JSON Schema definitions
 *
 * Generic utility for adding JSON Schema-based type mappings to any BasicTypeMapper.
 * Converts each JSON Schema to a Zod schema and adds it to the mapper.
 *
 * This is source-agnostic - schemas can come from settings, files, APIs, etc.
 *
 * @param mapper - The BasicTypeMapper to enhance
 * @param schemas - Map of type name → JSON Schema (Draft-07)
 * @returns The same mapper instance (modified in place)
 *
 * @example
 * ```typescript
 * const mapper = createStandardTypeMapper();
 * const customSchemas = new Map([
 *   ['ADDRESS', { type: 'object', properties: {...}, required: [...] }],
 *   ['CONTACT_INFO', { type: 'object', properties: {...} }]
 * ]);
 *
 * enhanceTypeMapperWithJsonSchemas(mapper, customSchemas);
 * // mapper now supports ADDRESS and CONTACT_INFO types
 * ```
 */
export function enhanceTypeMapperWithJsonSchemas(
  mapper: BasicTypeMapper,
  schemas: Map<string, JSONSchema7>
): BasicTypeMapper {
  let successCount = 0;
  let failCount = 0;

  for (const [typeName, jsonSchema] of schemas.entries()) {
    try {
      // Convert JSON Schema to Zod schema
      const zodSchema = jsonSchemaToZod(jsonSchema);

      // Add mapping to type mapper
      mapper.addMapping(typeName, { schema: zodSchema });

      successCount++;
      logger.debug('Added custom type mapping', {
        typeName,
        schemaType: jsonSchema.type,
        hasValidation: !!(jsonSchema.required || jsonSchema.pattern || jsonSchema.minLength),
      });
    } catch (error) {
      failCount++;
      logger.error('Failed to convert JSON schema to Zod', {
        typeName,
        error: (error as Error).message,
        schemaPreview: JSON.stringify(jsonSchema).substring(0, 200),
      });
    }
  }

  logger.info('Enhanced TypeMapper with JSON schemas', {
    totalSchemas: schemas.size,
    successfulMappings: successCount,
    failedMappings: failCount,
    supportedTypes: mapper.getSupportedTypes(),
  });

  return mapper;
}