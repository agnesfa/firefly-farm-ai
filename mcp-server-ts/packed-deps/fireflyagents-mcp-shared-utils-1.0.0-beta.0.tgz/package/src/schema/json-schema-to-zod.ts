import { z, type ZodTypeAny } from 'zod';
import { logger as baseLogger } from '../logger/logger.js';

const logger = baseLogger.child({ context: 'SharedUtils:JSONSchemaConverter' });

/**
 * JSON Schema Draft-07 interface (subset)
 *
 * Represents a subset of JSON Schema Draft-07 specification for conversion to Zod schemas.
 * Focuses on commonly used features for runtime validation.
 */
export interface JSONSchema7 {
  $schema?: string;
  $id?: string;
  title?: string;
  description?: string;
  type?: 'string' | 'number' | 'integer' | 'boolean' | 'object' | 'array' | 'null';

  // Object types
  properties?: Record<string, JSONSchema7>;
  required?: string[];
  additionalProperties?: boolean | JSONSchema7;

  // Array types
  items?: JSONSchema7;
  minItems?: number;
  maxItems?: number;

  // String validation
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  format?: string;

  // Number validation
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  exclusiveMaximum?: number;
  multipleOf?: number;

  // Enum
  enum?: any[];

  // Combinators (future support)
  allOf?: JSONSchema7[];
  anyOf?: JSONSchema7[];
  oneOf?: JSONSchema7[];
  not?: JSONSchema7;

  // Allow additional properties
  [key: string]: any;
}

/**
 * Convert JSON Schema to Zod schema
 *
 * @param schema - JSON Schema (Draft-07 subset) to convert
 * @returns Zod schema for runtime validation
 *
 * @example
 * ```typescript
 * const jsonSchema: JSONSchema7 = {
 *   type: 'object',
 *   properties: {
 *     name: { type: 'string', minLength: 3 },
 *     age: { type: 'integer', minimum: 0 }
 *   },
 *   required: ['name']
 * };
 *
 * const zodSchema = jsonSchemaToZod(jsonSchema);
 * zodSchema.parse({ name: 'John', age: 30 }); // Valid
 * zodSchema.parse({ age: 30 }); // Throws - name required
 * ```
 */
export function jsonSchemaToZod(schema: JSONSchema7): ZodTypeAny {
  if (!schema.type) {
    logger.debug('Schema has no type, falling back to z.any()', { schema });
    return z.any();
  }

  switch (schema.type) {
    case 'object':
      return buildObjectSchema(schema);
    case 'array':
      return buildArraySchema(schema);
    case 'string':
      return buildStringSchema(schema);
    case 'number':
    case 'integer':
      return buildNumberSchema(schema);
    case 'boolean':
      return z.boolean();
    case 'null':
      return z.null();
    default:
      logger.warn('Unsupported schema type, falling back to z.any()', { type: schema.type });
      return z.any();
  }
}

/**
 * Build Zod object schema from JSON Schema
 */
function buildObjectSchema(schema: JSONSchema7): ZodTypeAny {
  const shape: Record<string, ZodTypeAny> = {};

  for (const [key, propSchema] of Object.entries(schema.properties || {})) {
    let fieldSchema = jsonSchemaToZod(propSchema);

    // Make optional if not in required array
    if (!schema.required?.includes(key)) {
      fieldSchema = fieldSchema.optional();
    }

    // Add description if available
    if (propSchema.description) {
      fieldSchema = fieldSchema.describe(propSchema.description);
    }

    shape[key] = fieldSchema;
  }

  let objectSchema = z.object(shape);

  // Add description if available
  if (schema.description) {
    objectSchema = objectSchema.describe(schema.description) as any;
  }

  return objectSchema;
}

/**
 * Build Zod array schema from JSON Schema
 */
function buildArraySchema(schema: JSONSchema7): ZodTypeAny {
  let arraySchema: ZodTypeAny;

  if (schema.items) {
    arraySchema = z.array(jsonSchemaToZod(schema.items));
  } else {
    arraySchema = z.array(z.any());
  }

  // Apply array constraints
  if (schema.minItems !== undefined) {
    arraySchema = (arraySchema as any).min(schema.minItems);
  }
  if (schema.maxItems !== undefined) {
    arraySchema = (arraySchema as any).max(schema.maxItems);
  }

  // Add description if available
  if (schema.description) {
    arraySchema = arraySchema.describe(schema.description);
  }

  return arraySchema;
}

/**
 * Build Zod string schema from JSON Schema
 */
function buildStringSchema(schema: JSONSchema7): ZodTypeAny {
  let strSchema = z.string();

  // Length constraints
  if (schema.minLength !== undefined) {
    strSchema = strSchema.min(schema.minLength);
  }
  if (schema.maxLength !== undefined) {
    strSchema = strSchema.max(schema.maxLength);
  }

  // Pattern (regex)
  if (schema.pattern) {
    try {
      strSchema = strSchema.regex(new RegExp(schema.pattern));
    } catch (error) {
      logger.warn('Invalid regex pattern in schema, skipping pattern validation', {
        pattern: schema.pattern,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Enum
  if (schema.enum && schema.enum.length > 0) {
    try {
      return z.enum(schema.enum as [string, ...string[]]);
    } catch (error) {
      logger.warn('Invalid enum values, falling back to string schema', {
        enum: schema.enum,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Format hints (email, url, uuid validation)
  if (schema.format) {
    switch (schema.format) {
      case 'email':
        strSchema = strSchema.email();
        break;
      case 'url':
        strSchema = strSchema.url();
        break;
      case 'uuid':
        strSchema = strSchema.uuid();
        break;
      // Add more formats as needed
      default:
        logger.debug('Unsupported string format, ignoring', { format: schema.format });
    }
  }

  // Add description if available
  if (schema.description) {
    strSchema = strSchema.describe(schema.description);
  }

  return strSchema;
}

/**
 * Build Zod number schema from JSON Schema
 */
function buildNumberSchema(schema: JSONSchema7): ZodTypeAny {
  let numSchema = z.number();

  // Integer constraint
  if (schema.type === 'integer') {
    numSchema = numSchema.int();
  }

  // Range constraints
  if (schema.minimum !== undefined) {
    numSchema = numSchema.min(schema.minimum);
  }
  if (schema.maximum !== undefined) {
    numSchema = numSchema.max(schema.maximum);
  }
  if (schema.exclusiveMinimum !== undefined) {
    numSchema = numSchema.gt(schema.exclusiveMinimum);
  }
  if (schema.exclusiveMaximum !== undefined) {
    numSchema = numSchema.lt(schema.exclusiveMaximum);
  }

  // Multiple of
  if (schema.multipleOf !== undefined) {
    numSchema = numSchema.multipleOf(schema.multipleOf);
  }

  // Enum - use union of literals for numbers
  if (schema.enum && schema.enum.length > 0) {
    try {
      const literals = schema.enum.map(value => z.literal(value));
      if (literals.length === 1) {
        return literals[0];
      }
      return z.union(literals as [any, any, ...any[]]);
    } catch (error) {
      logger.warn('Invalid enum values for number, falling back to number schema', {
        enum: schema.enum,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Add description if available
  if (schema.description) {
    numSchema = numSchema.describe(schema.description);
  }

  return numSchema;
}

/**
 * Converter class for advanced usage
 *
 * Provides a stateful interface for JSON Schema to Zod conversion
 * with metadata about supported and unsupported features.
 */
export class JSONSchemaConverter {
  /**
   * Convert JSON Schema to Zod schema
   */
  convert(schema: JSONSchema7): ZodTypeAny {
    return jsonSchemaToZod(schema);
  }

  /**
   * Get list of supported JSON Schema features
   */
  getSupportedFeatures(): string[] {
    return [
      'object types with nested properties',
      'array types with item schemas',
      'string validation (pattern, length, format)',
      'number validation (min, max, integer, multipleOf)',
      'boolean types',
      'required vs optional fields',
      'enum types',
      'minItems/maxItems for arrays',
      'description annotations'
    ];
  }

  /**
   * Get list of unsupported features (for documentation)
   */
  getUnsupportedFeatures(): string[] {
    return [
      'allOf, anyOf, oneOf combinators',
      'not operator',
      'conditional schemas (if/then/else)',
      'patternProperties',
      'propertyNames validation',
      'const keyword',
      '$ref references'
    ];
  }

  /**
   * Validate that a schema only uses supported features
   *
   * @param schema - JSON Schema to validate
   * @returns Array of unsupported features found in the schema
   */
  validateSchema(schema: JSONSchema7): string[] {
    const unsupported: string[] = [];

    if (schema.allOf) unsupported.push('allOf');
    if (schema.anyOf) unsupported.push('anyOf');
    if (schema.oneOf) unsupported.push('oneOf');
    if (schema.not) unsupported.push('not');
    if (schema['if']) unsupported.push('conditional schemas (if/then/else)');
    if (schema['patternProperties']) unsupported.push('patternProperties');
    if (schema['propertyNames']) unsupported.push('propertyNames');
    if (schema['const']) unsupported.push('const');
    if (schema['$ref']) unsupported.push('$ref');

    return unsupported;
  }
}