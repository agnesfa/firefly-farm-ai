import * as AjvModule from 'ajv';
import * as FormatsModule from 'ajv-formats';
import type { ErrorObject, ValidateFunction } from 'ajv';

const Ajv = (AjvModule as any).default ?? AjvModule;
const addFormats = (FormatsModule as any).default ?? FormatsModule;

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

/**
 * Generic JSON Schema validator using AJV.
 * Validates data against JSON Schema with proper error handling and $ref resolution.
 *
 * @param schemaBundle - JSON Schema object, may contain $ref and $defs
 * @param data - Data to validate against the schema
 * @throws Error with detailed validation messages if validation fails
 */
export function validateJsonSchema(schemaBundle: unknown, data: unknown): void {
  let root: unknown = schemaBundle;

  // Handle schema bundles with $ref and $defs
  if (root && typeof root === 'object' && '$ref' in root) {
    const { $ref, $defs } = root as { $ref: string; $defs?: Record<string, unknown> };

    if ($defs) {
      for (const [key, definition] of Object.entries($defs)) {
        const id = (definition as { $id?: string }).$id ?? `urn:def:schema:${key}`;
        ajv.removeSchema(id);
        ajv.addSchema({ ...(definition as object), $id: id });
      }
    }

    root = { $ref };
  }

  const validate: ValidateFunction = ajv.compile(root);

  if (!validate(data)) {
    const errorMessage = (validate.errors ?? [])
      .map((error: ErrorObject) => `${error.instancePath || '/'} ${error.message}`)
      .join('; ');

    throw new Error(`JSON Schema validation failed: ${errorMessage || 'unknown error'}`);
  }
}
