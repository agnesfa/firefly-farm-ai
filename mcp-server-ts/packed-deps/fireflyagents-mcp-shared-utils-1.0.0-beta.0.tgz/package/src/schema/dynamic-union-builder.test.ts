// shared/utils/schema/dynamic-union-builder.test.ts
import { describe, it, expect } from 'vitest';
import { DynamicUnionBuilder, type ActionDefinition } from './dynamic-union-builder.js';
import { BasicTypeMapper } from './type-mapper.js';
import { z } from 'zod';

describe('DynamicUnionBuilder', () => {
  const typeMapper = new BasicTypeMapper({
    'STRING': { schema: z.string(), description: 'Text string' },
    'INTEGER': { schema: z.number().int(), description: 'Integer number' },
    'BOOLEAN': { schema: z.boolean(), description: 'Boolean value' },
  });

  it('should create a union schema from multiple actions', () => {
    const actions: ActionDefinition[] = [
      {
        name: 'CancelOrder',
        attributes: [
          {
            name: 'cancellationReason',
            label: 'Cancellation Reason',
            type: 'STRING',
            required: true,
          },
        ],
      },
      {
        name: 'UpdateQuantity',
        attributes: [
          {
            name: 'newQuantity',
            label: 'New Quantity',
            type: 'INTEGER',
            required: true,
          },
          {
            name: 'reason',
            label: 'Update Reason',
            type: 'STRING',
            required: false,
          },
        ],
      },
    ];

    const result = DynamicUnionBuilder.createUnion(actions, typeMapper);

    expect(result.includedActions).toEqual(['CancelOrder', 'UpdateQuantity']);
    expect(result.skippedActions).toHaveLength(0);
    expect(result.skippedAttributes).toHaveLength(0);

    // Test that the schema validates correctly
    const cancelOrderData = {
      name: 'CancelOrder',
      attributes: {
        cancellationReason: 'Customer requested',
      },
    };

    const updateQuantityData = {
      name: 'UpdateQuantity',
      attributes: {
        newQuantity: 5,
        reason: 'Stock adjustment',
      },
    };

    expect(() => result.schema.parse(cancelOrderData)).not.toThrow();
    expect(() => result.schema.parse(updateQuantityData)).not.toThrow();
  });

  it('should skip actions with unsupported attribute types', () => {
    const actions: ActionDefinition[] = [
      {
        name: 'ValidAction',
        attributes: [
          {
            name: 'validField',
            type: 'STRING',
            required: true,
          },
        ],
      },
      {
        name: 'ActionWithUnsupportedType',
        attributes: [
          {
            name: 'complexField',
            type: 'ADDRESS', // Unsupported type
            required: true,
          },
        ],
      },
    ];

    const result = DynamicUnionBuilder.createUnion(actions, typeMapper);

    expect(result.includedActions).toEqual(['ValidAction']);
    expect(result.skippedActions).toHaveLength(1);
    expect(result.skippedActions[0].name).toBe('ActionWithUnsupportedType');
    expect(result.skippedActions[0].reason).toBe('No supported attributes found');
    expect(result.skippedAttributes).toHaveLength(1);
    expect(result.skippedAttributes[0].type).toBe('ADDRESS');
  });

  it('should handle single action without creating union', () => {
    const actions: ActionDefinition[] = [
      {
        name: 'OnlyAction',
        attributes: [
          {
            name: 'field',
            type: 'STRING',
            required: true,
          },
        ],
      },
    ];

    const result = DynamicUnionBuilder.createUnion(actions, typeMapper);

    expect(result.includedActions).toEqual(['OnlyAction']);
    
    const testData = {
      name: 'OnlyAction',
      attributes: { field: 'test' },
    };

    expect(() => result.schema.parse(testData)).not.toThrow();
  });

  it('should create never schema when no valid actions', () => {
    const actions: ActionDefinition[] = [
      {
        name: 'UnsupportedAction',
        attributes: [
          {
            name: 'complexField',
            type: 'UNSUPPORTED_TYPE',
            required: true,
          },
        ],
      },
    ];

    const result = DynamicUnionBuilder.createUnion(actions, typeMapper);

    expect(result.includedActions).toHaveLength(0);
    expect(result.skippedActions).toHaveLength(1);
  });
});