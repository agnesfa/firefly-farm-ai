// shared/utils/schema/runtime-action-validator.ts
import { z } from 'zod';
import { DynamicUnionBuilder, type TypeMapper, type ActionDefinition } from './dynamic-union-builder.js';

/**
 * Runtime action input to validate
 */
export interface ActionInput {
  name: string;
  attributes: Record<string, unknown>;
}

/**
 * Runtime validation result
 */
export interface RuntimeValidationResult {
  success: boolean;
  validatedData?: ActionInput;
  error?: {
    code: 'INVALID_ACTION' | 'INVALID_ATTRIBUTES' | 'VALIDATION_ERROR';
    message: string;
    details?: unknown;
  };
}

/**
 * Runtime action validator using dynamic schemas
 */
export class RuntimeActionValidator {
  /**
   * Validates action input against available actions at runtime
   */
  static validate(
    input: unknown,
    availableActions: ActionDefinition[],
    typeMapper: TypeMapper
  ): RuntimeValidationResult {
    // Step 1: Basic structure validation
    if (!this.isValidActionInput(input)) {
      return {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Input must be an object with "name" and "attributes" properties',
          details: { received: typeof input, expected: 'ActionInput' }
        }
      };
    }

    const actionInput = input as ActionInput;

    // Step 2: Check if action name is available
    const actionDefinition = availableActions.find(a => a.name === actionInput.name);
    if (!actionDefinition) {
      const availableNames = availableActions.map(a => a.name);
      return {
        success: false,
        error: {
          code: 'INVALID_ACTION',
          message: `Action "${actionInput.name}" is not available`,
          details: { 
            providedAction: actionInput.name,
            availableActions: availableNames 
          }
        }
      };
    }

    // Step 3: Generate union schema and validate
    try {
      const unionResult = DynamicUnionBuilder.createUnion([actionDefinition], typeMapper);
      
      if (unionResult.includedActions.length === 0) {
        return {
          success: false,
          error: {
            code: 'INVALID_ACTION',
            message: `Action "${actionInput.name}" has no supported attributes`,
            details: { 
              skippedAttributes: unionResult.skippedAttributes,
              supportedTypes: typeMapper.getSupportedTypes()
            }
          }
        };
      }

      // Validate against the generated schema
      const validatedData = unionResult.schema.parse(actionInput);

      return {
        success: true,
        validatedData: validatedData as ActionInput
      };

    } catch (error) {
      return {
        success: false,
        error: {
          code: 'INVALID_ATTRIBUTES',
          message: this.formatValidationError(error),
          details: { 
            actionName: actionInput.name,
            providedAttributes: Object.keys(actionInput.attributes),
            expectedAttributes: actionDefinition.attributes.map(attr => ({
              name: attr.name,
              type: attr.type,
              required: attr.required,
              supported: typeMapper.isSupported(attr.type)
            }))
          }
        }
      };
    }
  }

  /**
   * Validates multiple action inputs (batch validation)
   */
  static validateBatch(
    inputs: unknown[],
    availableActions: ActionDefinition[],
    typeMapper: TypeMapper
  ): { results: RuntimeValidationResult[]; allValid: boolean } {
    const results = inputs.map(input => 
      this.validate(input, availableActions, typeMapper)
    );
    
    return {
      results,
      allValid: results.every(result => result.success)
    };
  }

  /**
   * Basic type guard for action input structure
   */
  private static isValidActionInput(input: unknown): input is ActionInput {
    return (
      typeof input === 'object' &&
      input !== null &&
      'name' in input &&
      'attributes' in input &&
      typeof (input as any).name === 'string' &&
      typeof (input as any).attributes === 'object' &&
      (input as any).attributes !== null
    );
  }

  /**
   * Formats validation errors into human-readable messages
   */
  private static formatValidationError(error: unknown): string {
    if (error instanceof z.ZodError) {
      const issues = error.issues.map(issue => {
        const path = issue.path.length > 0 ? ` at "${issue.path.join('.')}"` : '';
        return `${issue.message}${path}`;
      });
      return `Validation failed: ${issues.join(', ')}`;
    }

    if (error instanceof Error) {
      return error.message;
    }

    return 'Unknown validation error occurred';
  }

  /**
   * Gets action definition by name for detailed validation info
   */
  static getActionDefinition(
    actionName: string,
    availableActions: ActionDefinition[]
  ): ActionDefinition | undefined {
    return availableActions.find(action => action.name === actionName);
  }

  /**
   * Gets supported attributes for an action
   */
  static getSupportedAttributes(
    actionName: string,
    availableActions: ActionDefinition[],
    typeMapper: TypeMapper
  ): Array<{
    name: string;
    type: string;
    required: boolean;
    supported: boolean;
    description?: string;
  }> {
    const action = this.getActionDefinition(actionName, availableActions);
    if (!action) return [];

    return action.attributes.map(attr => ({
      name: attr.name,
      type: attr.type,
      required: attr.required,
      supported: typeMapper.isSupported(attr.type),
      description: attr.description
    }));
  }
}