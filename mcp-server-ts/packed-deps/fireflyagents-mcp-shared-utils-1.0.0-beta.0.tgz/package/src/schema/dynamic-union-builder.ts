// shared/utils/schema/dynamic-union-builder.ts
import { z, type ZodTypeAny } from 'zod';

/**
 * Generic action definition for building union schemas
 */
export interface ActionDefinition {
  /** Unique identifier for the action (used as discriminator) */
  name: string;
  /** Action attributes/parameters */
  attributes: AttributeDefinition[];
}

/**
 * Generic attribute definition
 */
export interface AttributeDefinition {
  /** Attribute name/key */
  name: string;
  /** Attribute label for documentation */
  label?: string;
  /** Type identifier (string representation) */
  type: string;
  /** Whether this attribute is required */
  required: boolean;
  /** Default value if any */
  defaultValue?: unknown;
  /** Additional description */
  description?: string;
}

/**
 * Type mapper interface - converts string type names to Zod validators
 */
export interface TypeMapper {
  /** Maps a type string to a Zod validator */
  mapType(type: string): ZodTypeAny;
  /** Returns supported type names */
  getSupportedTypes(): string[];
  /** Checks if a type is supported */
  isSupported(type: string): boolean;
}

/**
 * Result of building a union schema
 */
export interface UnionSchemaResult {
  /** The generated Zod union schema */
  schema: ZodTypeAny;
  /** Actions that were included in the schema */
  includedActions: string[];
  /** Actions that were skipped (e.g., no supported attributes) */
  skippedActions: Array<{ name: string; reason: string; }>;
  /** Attributes that were skipped due to unsupported types */
  skippedAttributes: Array<{ actionName: string; attributeName: string; type: string; }>;
}

/**
 * Generic dynamic union schema builder
 * Creates discriminated union schemas from action definitions
 */
export class DynamicUnionBuilder {
  /**
   * Creates a discriminated union schema from action definitions
   */
  static createUnion(
    actions: ActionDefinition[],
    typeMapper: TypeMapper,
    options: {
      /** Field name used for discrimination (default: 'name') */
      discriminatorField?: string;
      /** Whether to skip actions with no supported attributes (default: true) */
      skipActionsWithNoAttributes?: boolean;
      /** Whether to skip unsupported attribute types (default: true) */
      skipUnsupportedTypes?: boolean;
    } = {}
  ): UnionSchemaResult {
    const {
      discriminatorField = 'name',
      skipActionsWithNoAttributes = true,
      skipUnsupportedTypes = true,
    } = options;

    const includedActions: string[] = [];
    const skippedActions: Array<{ name: string; reason: string; }> = [];
    const skippedAttributes: Array<{ actionName: string; attributeName: string; type: string; }> = [];
    const unionMembers: ZodTypeAny[] = [];

    for (const action of actions) {
      const supportedAttributes: AttributeDefinition[] = [];
      
      // Filter attributes by type support
      for (const attr of action.attributes) {
        if (typeMapper.isSupported(attr.type)) {
          supportedAttributes.push(attr);
        } else if (skipUnsupportedTypes) {
          skippedAttributes.push({
            actionName: action.name,
            attributeName: attr.name,
            type: attr.type
          });
        }
      }

      // Skip actions with no supported attributes if configured
      if (supportedAttributes.length === 0 && skipActionsWithNoAttributes) {
        skippedActions.push({
          name: action.name,
          reason: 'No supported attributes found'
        });
        continue;
      }

      // Build attributes schema
      const attributesSchema = this.buildAttributesSchema(supportedAttributes, typeMapper);
      
      // Build action schema with discriminator
      const actionSchema = z.object({
        [discriminatorField]: z.literal(action.name),
        attributes: attributesSchema,
      });

      unionMembers.push(actionSchema);
      includedActions.push(action.name);
    }

    // Create union schema or fallback
    let schema: ZodTypeAny;
    if (unionMembers.length === 0) {
      // No valid actions - create a never schema or empty schema
      schema = z.never().describe('No valid actions available');
    } else if (unionMembers.length === 1) {
      // Single action - no need for union
      schema = unionMembers[0];
    } else {
      // Multiple actions - create union
      schema = z.union(unionMembers as [ZodTypeAny, ZodTypeAny, ...ZodTypeAny[]]);
    }

    return {
      schema,
      includedActions,
      skippedActions,
      skippedAttributes,
    };
  }

  /**
   * Builds a Zod object schema for action attributes
   */
  private static buildAttributesSchema(
    attributes: AttributeDefinition[],
    typeMapper: TypeMapper
  ): ZodTypeAny {
    if (attributes.length === 0) {
      return z.object({}).describe('No attributes required');
    }

    const schemaFields: Record<string, ZodTypeAny> = {};
    const requiredFields: string[] = [];

    for (const attr of attributes) {
      let fieldSchema = typeMapper.mapType(attr.type);
      
      // Add description if available
      if (attr.description || attr.label) {
        fieldSchema = fieldSchema.describe(attr.description || attr.label || '');
      }

      // Handle optional vs required
      if (attr.required) {
        requiredFields.push(attr.name);
      } else {
        fieldSchema = fieldSchema.optional();
      }

      schemaFields[attr.name] = fieldSchema;
    }

    return z.object(schemaFields);
  }
}