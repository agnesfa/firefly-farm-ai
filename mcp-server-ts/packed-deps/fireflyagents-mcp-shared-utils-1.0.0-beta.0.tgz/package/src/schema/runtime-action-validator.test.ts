import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  RuntimeActionValidator,
  type ActionInput,
} from './runtime-action-validator.js';
import type { ActionDefinition, TypeMapper } from './dynamic-union-builder.js';

describe('RuntimeActionValidator', () => {
  const mockTypeMapper: TypeMapper = {
    mapType: (type: string) => {
      switch (type) {
        case 'STRING':
          return z.string();
        case 'INTEGER':
          return z.number().int();
        case 'BOOLEAN':
          return z.boolean();
        default:
          throw new Error(`Unsupported type: ${type}`);
      }
    },
    isSupported: (type: string) => ['STRING', 'INTEGER', 'BOOLEAN'].includes(type),
    getSupportedTypes: () => ['STRING', 'INTEGER', 'BOOLEAN'],
  };

  const mockActionDefinitions: ActionDefinition[] = [
    {
      name: 'CANCEL_ORDER',
      attributes: [
        {
          name: 'reason',
          type: 'STRING',
          required: true,
          description: 'Cancellation reason',
        },
        {
          name: 'priority',
          type: 'INTEGER',
          required: false,
          description: 'Priority level',
        },
      ],
    },
    {
      name: 'UPDATE_STATUS',
      attributes: [
        {
          name: 'status',
          type: 'STRING',
          required: true,
          description: 'New status',
        },
        {
          name: 'notify',
          type: 'BOOLEAN',
          required: false,
          description: 'Send notification',
        },
      ],
    },
  ];

  describe('validate', () => {
    it('should validate correct action input successfully', () => {
      const input: ActionInput = {
        name: 'CANCEL_ORDER',
        attributes: {
          reason: 'Customer request',
          priority: 1,
        },
      };

      const result = RuntimeActionValidator.validate(input, mockActionDefinitions, mockTypeMapper);

      expect(result.success).toBe(true);
      expect(result.validatedData).toEqual(input);
      expect(result.error).toBeUndefined();
    });

    it('should validate action with only required attributes', () => {
      const input: ActionInput = {
        name: 'CANCEL_ORDER',
        attributes: {
          reason: 'Customer request',
          // priority is optional
        },
      };

      const result = RuntimeActionValidator.validate(input, mockActionDefinitions, mockTypeMapper);

      expect(result.success).toBe(true);
      expect(result.validatedData).toEqual(input);
    });

    it('should fail validation for invalid input structure', () => {
      const invalidInputs = [
        null,
        undefined,
        'string',
        123,
        [],
        { name: 'CANCEL_ORDER' }, // missing attributes
        { attributes: {} }, // missing name
        { name: 123, attributes: {} }, // name not string
        { name: 'CANCEL_ORDER', attributes: 'invalid' }, // attributes not object
      ];

      invalidInputs.forEach((invalidInput) => {
        const result = RuntimeActionValidator.validate(invalidInput, mockActionDefinitions, mockTypeMapper);

        expect(result.success).toBe(false);
        expect(result.error?.code).toBe('VALIDATION_ERROR');
        expect(result.error?.message).toBe(
          'Input must be an object with "name" and "attributes" properties'
        );
        expect(result.validatedData).toBeUndefined();
      });
    });

    it('should fail validation for unknown action name', () => {
      const input: ActionInput = {
        name: 'UNKNOWN_ACTION',
        attributes: {},
      };

      const result = RuntimeActionValidator.validate(input, mockActionDefinitions, mockTypeMapper);

      expect(result.success).toBe(false);
      expect(result.error?.code).toBe('INVALID_ACTION');
      expect(result.error?.message).toBe('Action "UNKNOWN_ACTION" is not available');
      expect(result.error?.details).toEqual({
        providedAction: 'UNKNOWN_ACTION',
        availableActions: ['CANCEL_ORDER', 'UPDATE_STATUS'],
      });
    });

    it('should fail validation when no supported attributes exist', () => {
      const unsupportedAction: ActionDefinition = {
        name: 'UNSUPPORTED_ACTION',
        attributes: [
          {
            name: 'complex_data',
            type: 'COMPLEX_OBJECT',
            required: true,
            description: 'Complex data',
          },
        ],
      };

      const input: ActionInput = {
        name: 'UNSUPPORTED_ACTION',
        attributes: {
          complex_data: { some: 'data' },
        },
      };

      const result = RuntimeActionValidator.validate(input, [unsupportedAction], mockTypeMapper);

      expect(result.success).toBe(false);
      expect(result.error?.code).toBe('INVALID_ACTION');
      expect(result.error?.message).toBe('Action "UNSUPPORTED_ACTION" has no supported attributes');
    });

    it('should fail validation for incorrect attribute types', () => {
      const input: ActionInput = {
        name: 'CANCEL_ORDER',
        attributes: {
          reason: 'Customer request', // correct
          priority: 'high', // should be integer
        },
      };

      const result = RuntimeActionValidator.validate(input, mockActionDefinitions, mockTypeMapper);

      expect(result.success).toBe(false);
      expect(result.error?.code).toBe('INVALID_ATTRIBUTES');
      expect(result.error?.message).toContain('Validation failed');
    });

    it('should fail validation for missing required attributes', () => {
      const input: ActionInput = {
        name: 'CANCEL_ORDER',
        attributes: {
          priority: 1, // missing required 'reason'
        },
      };

      const result = RuntimeActionValidator.validate(input, mockActionDefinitions, mockTypeMapper);

      expect(result.success).toBe(false);
      expect(result.error?.code).toBe('INVALID_ATTRIBUTES');
    });

    it('should handle empty available actions array', () => {
      const input: ActionInput = {
        name: 'ANY_ACTION',
        attributes: {},
      };

      const result = RuntimeActionValidator.validate(input, [], mockTypeMapper);

      expect(result.success).toBe(false);
      expect(result.error?.code).toBe('INVALID_ACTION');
      expect(result.error?.details).toEqual({
        providedAction: 'ANY_ACTION',
        availableActions: [],
      });
    });
  });

  describe('validateBatch', () => {
    it('should validate multiple inputs successfully', () => {
      const inputs = [
        { name: 'CANCEL_ORDER', attributes: { reason: 'Test' } },
        { name: 'UPDATE_STATUS', attributes: { status: 'COMPLETED' } },
      ];

      const result = RuntimeActionValidator.validateBatch(inputs, mockActionDefinitions, mockTypeMapper);

      expect(result.allValid).toBe(true);
      expect(result.results).toHaveLength(2);
      expect(result.results[0].success).toBe(true);
      expect(result.results[1].success).toBe(true);
    });

    it('should handle mixed valid and invalid inputs', () => {
      const inputs = [
        { name: 'CANCEL_ORDER', attributes: { reason: 'Test' } }, // valid
        { name: 'UNKNOWN_ACTION', attributes: {} }, // invalid action
        { name: 'UPDATE_STATUS', attributes: { status: 123 } }, // invalid type
      ];

      const result = RuntimeActionValidator.validateBatch(inputs, mockActionDefinitions, mockTypeMapper);

      expect(result.allValid).toBe(false);
      expect(result.results).toHaveLength(3);
      expect(result.results[0].success).toBe(true);
      expect(result.results[1].success).toBe(false);
      expect(result.results[2].success).toBe(false);
    });

    it('should handle empty inputs array', () => {
      const result = RuntimeActionValidator.validateBatch([], mockActionDefinitions, mockTypeMapper);

      expect(result.allValid).toBe(true);
      expect(result.results).toHaveLength(0);
    });
  });

  describe('getActionDefinition', () => {
    it('should return action definition for existing action', () => {
      const definition = RuntimeActionValidator.getActionDefinition(
        'CANCEL_ORDER',
        mockActionDefinitions
      );

      expect(definition).toEqual(mockActionDefinitions[0]);
    });

    it('should return undefined for non-existing action', () => {
      const definition = RuntimeActionValidator.getActionDefinition(
        'NON_EXISTING_ACTION',
        mockActionDefinitions
      );

      expect(definition).toBeUndefined();
    });
  });

  describe('getSupportedAttributes', () => {
    it('should return supported attributes for existing action', () => {
      const attributes = RuntimeActionValidator.getSupportedAttributes(
        'CANCEL_ORDER',
        mockActionDefinitions,
        mockTypeMapper
      );

      expect(attributes).toEqual([
        {
          name: 'reason',
          type: 'STRING',
          required: true,
          supported: true,
          description: 'Cancellation reason',
        },
        {
          name: 'priority',
          type: 'INTEGER',
          required: false,
          supported: true,
          description: 'Priority level',
        },
      ]);
    });

    it('should return empty array for non-existing action', () => {
      const attributes = RuntimeActionValidator.getSupportedAttributes(
        'NON_EXISTING_ACTION',
        mockActionDefinitions,
        mockTypeMapper
      );

      expect(attributes).toEqual([]);
    });

    it('should mark unsupported types correctly', () => {
      const actionWithUnsupportedType: ActionDefinition = {
        name: 'COMPLEX_ACTION',
        attributes: [
          {
            name: 'supported_attr',
            type: 'STRING',
            required: true,
            description: 'Supported attribute',
          },
          {
            name: 'unsupported_attr',
            type: 'COMPLEX_OBJECT',
            required: false,
            description: 'Unsupported attribute',
          },
        ],
      };

      const attributes = RuntimeActionValidator.getSupportedAttributes(
        'COMPLEX_ACTION',
        [actionWithUnsupportedType],
        mockTypeMapper
      );

      expect(attributes).toEqual([
        {
          name: 'supported_attr',
          type: 'STRING',
          required: true,
          supported: true,
          description: 'Supported attribute',
        },
        {
          name: 'unsupported_attr',
          type: 'COMPLEX_OBJECT',
          required: false,
          supported: false,
          description: 'Unsupported attribute',
        },
      ]);
    });
  });
});