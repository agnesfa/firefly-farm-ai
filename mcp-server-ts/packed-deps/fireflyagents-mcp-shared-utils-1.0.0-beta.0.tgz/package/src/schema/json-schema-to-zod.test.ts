import { describe, it, expect } from 'vitest';
import {
  jsonSchemaToZod,
  JSONSchemaConverter,
  type JSONSchema7
} from './json-schema-to-zod.js';

describe('jsonSchemaToZod', () => {
  describe('object schemas', () => {
    it('should convert simple object schema', () => {
      const schema: JSONSchema7 = {
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'integer' }
        },
        required: ['name']
      };

      const zodSchema = jsonSchemaToZod(schema);

      // Valid data
      expect(() => zodSchema.parse({ name: 'John', age: 30 })).not.toThrow();
      expect(() => zodSchema.parse({ name: 'Jane' })).not.toThrow(); // age optional

      // Invalid data
      expect(() => zodSchema.parse({ age: 30 })).toThrow(); // name required
      expect(() => zodSchema.parse({ name: 'John', age: 'thirty' })).toThrow(); // age must be number
    });

    it('should convert nested object schema (ADDRESS example)', () => {
      const schema: JSONSchema7 = {
        type: 'object',
        properties: {
          street: { type: 'string' },
          city: { type: 'string' },
          state: { type: 'string' },
          zipCode: {
            type: 'string',
            pattern: '^[0-9]{5}$'
          },
          country: { type: 'string' }
        },
        required: ['street', 'city', 'zipCode', 'country']
      };

      const zodSchema = jsonSchemaToZod(schema);

      const validAddress = {
        street: '123 Main St',
        city: 'Springfield',
        state: 'IL',
        zipCode: '62701',
        country: 'USA'
      };

      expect(() => zodSchema.parse(validAddress)).not.toThrow();

      // Invalid zipCode
      expect(() => zodSchema.parse({
        ...validAddress,
        zipCode: 'ABCDE'
      })).toThrow();
    });

    it('should handle empty properties object', () => {
      const schema: JSONSchema7 = {
        type: 'object',
        properties: {}
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse({})).not.toThrow();
    });

    it('should handle object with descriptions', () => {
      const schema: JSONSchema7 = {
        type: 'object',
        description: 'User object',
        properties: {
          name: { type: 'string', description: 'User name' },
          age: { type: 'integer', description: 'User age' }
        },
        required: ['name']
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse({ name: 'John', age: 30 })).not.toThrow();
    });
  });

  describe('array schemas', () => {
    it('should convert array of objects', () => {
      const schema: JSONSchema7 = {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            name: { type: 'string' }
          },
          required: ['id']
        }
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse([
        { id: 1, name: 'Item 1' },
        { id: 2 }
      ])).not.toThrow();

      // Invalid - missing id
      expect(() => zodSchema.parse([
        { name: 'Item 1' }
      ])).toThrow();
    });

    it('should apply array constraints', () => {
      const schema: JSONSchema7 = {
        type: 'array',
        items: { type: 'string' },
        minItems: 2,
        maxItems: 5
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(['a', 'b'])).not.toThrow();
      expect(() => zodSchema.parse(['a', 'b', 'c', 'd', 'e'])).not.toThrow();
      expect(() => zodSchema.parse(['a'])).toThrow(); // too few
      expect(() => zodSchema.parse(['a', 'b', 'c', 'd', 'e', 'f'])).toThrow(); // too many
    });

    it('should handle array without items schema', () => {
      const schema: JSONSchema7 = {
        type: 'array'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(['anything', 123, { obj: true }])).not.toThrow();
    });

    it('should handle array with description', () => {
      const schema: JSONSchema7 = {
        type: 'array',
        description: 'List of items',
        items: { type: 'string' }
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(['a', 'b'])).not.toThrow();
    });
  });

  describe('string schemas', () => {
    it('should apply length constraints', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        minLength: 3,
        maxLength: 10
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('hello')).not.toThrow();
      expect(() => zodSchema.parse('ab')).toThrow(); // too short
      expect(() => zodSchema.parse('hello world!')).toThrow(); // too long
    });

    it('should apply pattern constraint', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        pattern: '^[A-Z]{3}$'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('ABC')).not.toThrow();
      expect(() => zodSchema.parse('abc')).toThrow(); // lowercase
      expect(() => zodSchema.parse('ABCD')).toThrow(); // too long
    });

    it('should handle format: email', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        format: 'email'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('user@example.com')).not.toThrow();
      expect(() => zodSchema.parse('invalid-email')).toThrow();
    });

    it('should handle format: url', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        format: 'url'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('https://example.com')).not.toThrow();
      expect(() => zodSchema.parse('not-a-url')).toThrow();
    });

    it('should handle format: uuid', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        format: 'uuid'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('550e8400-e29b-41d4-a716-446655440000')).not.toThrow();
      expect(() => zodSchema.parse('not-a-uuid')).toThrow();
    });

    it('should handle enum', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        enum: ['red', 'green', 'blue']
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('red')).not.toThrow();
      expect(() => zodSchema.parse('yellow')).toThrow();
    });

    it('should handle string with description', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        description: 'User name',
        minLength: 3
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('John')).not.toThrow();
    });

    it('should handle invalid regex pattern gracefully', () => {
      const schema: JSONSchema7 = {
        type: 'string',
        pattern: '[invalid regex'
      };

      const zodSchema = jsonSchemaToZod(schema);

      // Should still create a schema (pattern validation skipped)
      expect(() => zodSchema.parse('anything')).not.toThrow();
    });
  });

  describe('number schemas', () => {
    it('should apply range constraints', () => {
      const schema: JSONSchema7 = {
        type: 'number',
        minimum: 0,
        maximum: 100
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(50)).not.toThrow();
      expect(() => zodSchema.parse(0)).not.toThrow();
      expect(() => zodSchema.parse(100)).not.toThrow();
      expect(() => zodSchema.parse(-1)).toThrow(); // too small
      expect(() => zodSchema.parse(101)).toThrow(); // too large
    });

    it('should enforce integer constraint', () => {
      const schema: JSONSchema7 = {
        type: 'integer'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(42)).not.toThrow();
      expect(() => zodSchema.parse(42.5)).toThrow(); // not integer
    });

    it('should apply multipleOf constraint', () => {
      const schema: JSONSchema7 = {
        type: 'number',
        multipleOf: 0.5
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(1.5)).not.toThrow();
      expect(() => zodSchema.parse(2.0)).not.toThrow();
      expect(() => zodSchema.parse(1.3)).toThrow(); // not multiple of 0.5
    });

    it('should apply exclusive range constraints', () => {
      const schema: JSONSchema7 = {
        type: 'number',
        exclusiveMinimum: 0,
        exclusiveMaximum: 10
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(5)).not.toThrow();
      expect(() => zodSchema.parse(0.1)).not.toThrow();
      expect(() => zodSchema.parse(9.9)).not.toThrow();
      expect(() => zodSchema.parse(0)).toThrow(); // not > 0
      expect(() => zodSchema.parse(10)).toThrow(); // not < 10
    });

    it('should handle number enum', () => {
      const schema: JSONSchema7 = {
        type: 'number',
        enum: [1, 2, 3]
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(1)).not.toThrow();
      expect(() => zodSchema.parse(4)).toThrow();
    });

    it('should handle number with description', () => {
      const schema: JSONSchema7 = {
        type: 'number',
        description: 'User age',
        minimum: 0
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(30)).not.toThrow();
    });
  });

  describe('boolean schema', () => {
    it('should convert boolean type', () => {
      const schema: JSONSchema7 = {
        type: 'boolean'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(true)).not.toThrow();
      expect(() => zodSchema.parse(false)).not.toThrow();
      expect(() => zodSchema.parse('true')).toThrow(); // string not allowed
      expect(() => zodSchema.parse(1)).toThrow(); // number not allowed
    });
  });

  describe('null schema', () => {
    it('should convert null type', () => {
      const schema: JSONSchema7 = {
        type: 'null'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse(null)).not.toThrow();
      expect(() => zodSchema.parse(undefined)).toThrow();
      expect(() => zodSchema.parse('')).toThrow();
    });
  });

  describe('edge cases', () => {
    it('should handle schema without type (fallback to any)', () => {
      const schema: JSONSchema7 = {
        description: 'No type specified'
      };

      const zodSchema = jsonSchemaToZod(schema);

      expect(() => zodSchema.parse('anything')).not.toThrow();
      expect(() => zodSchema.parse(123)).not.toThrow();
      expect(() => zodSchema.parse({ any: 'object' })).not.toThrow();
    });

    it('should handle complex nested structure', () => {
      const schema: JSONSchema7 = {
        type: 'object',
        properties: {
          user: {
            type: 'object',
            properties: {
              name: { type: 'string', minLength: 1 },
              email: { type: 'string', format: 'email' },
              addresses: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    street: { type: 'string' },
                    city: { type: 'string' },
                    zipCode: { type: 'string', pattern: '^[0-9]{5}$' }
                  },
                  required: ['street', 'city', 'zipCode']
                }
              }
            },
            required: ['name', 'email']
          }
        },
        required: ['user']
      };

      const zodSchema = jsonSchemaToZod(schema);

      const validData = {
        user: {
          name: 'John',
          email: 'john@example.com',
          addresses: [
            { street: '123 Main St', city: 'Springfield', zipCode: '62701' }
          ]
        }
      };

      expect(() => zodSchema.parse(validData)).not.toThrow();

      // Invalid - missing required email
      expect(() => zodSchema.parse({
        user: {
          name: 'John',
          addresses: []
        }
      })).toThrow();

      // Invalid - bad zipCode
      expect(() => zodSchema.parse({
        user: {
          name: 'John',
          email: 'john@example.com',
          addresses: [
            { street: '123 Main St', city: 'Springfield', zipCode: 'ABCDE' }
          ]
        }
      })).toThrow();
    });
  });
});

describe('JSONSchemaConverter', () => {
  it('should provide supported features list', () => {
    const converter = new JSONSchemaConverter();
    const features = converter.getSupportedFeatures();

    expect(features).toContain('object types with nested properties');
    expect(features).toContain('array types with item schemas');
    expect(features).toContain('string validation (pattern, length, format)');
    expect(features.length).toBeGreaterThan(5);
  });

  it('should provide unsupported features list', () => {
    const converter = new JSONSchemaConverter();
    const unsupported = converter.getUnsupportedFeatures();

    expect(unsupported).toContain('allOf, anyOf, oneOf combinators');
    expect(unsupported).toContain('$ref references');
  });

  it('should convert via class method', () => {
    const converter = new JSONSchemaConverter();
    const schema: JSONSchema7 = {
      type: 'string',
      minLength: 5
    };

    const zodSchema = converter.convert(schema);

    expect(() => zodSchema.parse('hello')).not.toThrow();
    expect(() => zodSchema.parse('hi')).toThrow();
  });

  it('should validate schema for unsupported features', () => {
    const converter = new JSONSchemaConverter();

    // Schema with supported features only
    const supportedSchema: JSONSchema7 = {
      type: 'object',
      properties: {
        name: { type: 'string' }
      }
    };

    expect(converter.validateSchema(supportedSchema)).toEqual([]);

    // Schema with unsupported features
    const unsupportedSchema: JSONSchema7 = {
      type: 'object',
      allOf: [{ type: 'object' }],
      '$ref': '#/definitions/User'
    };

    const unsupported = converter.validateSchema(unsupportedSchema);
    expect(unsupported).toContain('allOf');
    expect(unsupported).toContain('$ref');
  });
});

describe('real-world scenarios', () => {
  it('should handle Fluent ADDRESS custom type', () => {
    const addressSchema: JSONSchema7 = {
      $schema: 'http://json-schema.org/draft-07/schema#',
      type: 'object',
      properties: {
        street: {
          type: 'string',
          minLength: 1,
          maxLength: 200
        },
        city: {
          type: 'string',
          minLength: 1,
          maxLength: 100
        },
        state: {
          type: 'string',
          pattern: '^[A-Z]{2}$'
        },
        zipCode: {
          type: 'string',
          pattern: '^[0-9]{5}(-[0-9]{4})?$'
        },
        country: {
          type: 'string',
          enum: ['USA', 'CAN', 'MEX']
        }
      },
      required: ['street', 'city', 'zipCode', 'country']
    };

    const zodSchema = jsonSchemaToZod(addressSchema);

    // Valid US address
    expect(() => zodSchema.parse({
      street: '123 Main Street',
      city: 'Springfield',
      state: 'IL',
      zipCode: '62701',
      country: 'USA'
    })).not.toThrow();

    // Valid with extended zip
    expect(() => zodSchema.parse({
      street: '456 Oak Ave',
      city: 'Portland',
      state: 'OR',
      zipCode: '97201-1234',
      country: 'USA'
    })).not.toThrow();

    // Invalid - missing required field
    expect(() => zodSchema.parse({
      street: '123 Main Street',
      city: 'Springfield',
      country: 'USA'
    })).toThrow();

    // Invalid - bad state format
    expect(() => zodSchema.parse({
      street: '123 Main Street',
      city: 'Springfield',
      state: 'Illinois',
      zipCode: '62701',
      country: 'USA'
    })).toThrow();

    // Invalid - bad zip format
    expect(() => zodSchema.parse({
      street: '123 Main Street',
      city: 'Springfield',
      state: 'IL',
      zipCode: 'ABCDE',
      country: 'USA'
    })).toThrow();

    // Invalid - unsupported country
    expect(() => zodSchema.parse({
      street: '123 Main Street',
      city: 'Springfield',
      state: 'IL',
      zipCode: '62701',
      country: 'GBR'
    })).toThrow();
  });

  it('should handle CONTACT_INFO custom type', () => {
    const contactInfoSchema: JSONSchema7 = {
      type: 'object',
      properties: {
        email: { type: 'string', format: 'email' },
        phone: { type: 'string', pattern: '^\\+?[1-9]\\d{1,14}$' },
        preferredMethod: { type: 'string', enum: ['email', 'phone', 'sms'] }
      },
      required: ['email', 'preferredMethod']
    };

    const zodSchema = jsonSchemaToZod(contactInfoSchema);

    // Valid contact info
    expect(() => zodSchema.parse({
      email: 'customer@example.com',
      phone: '+12345678901',
      preferredMethod: 'email'
    })).not.toThrow();

    // Valid without optional phone
    expect(() => zodSchema.parse({
      email: 'customer@example.com',
      preferredMethod: 'sms'
    })).not.toThrow();

    // Invalid - bad email format
    expect(() => zodSchema.parse({
      email: 'not-an-email',
      preferredMethod: 'email'
    })).toThrow();

    // Invalid - bad phone format
    expect(() => zodSchema.parse({
      email: 'customer@example.com',
      phone: 'invalid-phone',
      preferredMethod: 'phone'
    })).toThrow();
  });
});