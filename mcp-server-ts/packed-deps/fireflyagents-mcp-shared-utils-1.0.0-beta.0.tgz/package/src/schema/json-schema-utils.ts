/**
 * Pure JSON Schema utilities (no Fluent dependency).
 */

/**
 * Extract a specific variant from a JSON Schema oneOf union by discriminator value.
 *
 * Walks the `oneOf` array and matches against the discriminator path
 * (default: `properties.name.const`). Returns the matching variant schema,
 * or null if not found.
 *
 * @param unionSchema - A JSON Schema with a `oneOf` array of variant objects
 * @param actionName - The discriminator value to match (e.g., "OrderCancel")
 * @param discriminatorPath - Dot-delimited path to the const field (default: "properties.name.const")
 * @returns The matching variant schema, or null if not found
 */
export function extractVariantSchema(
  unionSchema: Record<string, unknown>,
  actionName: string,
  discriminatorPath?: string,
): Record<string, unknown> | null {
  const path = discriminatorPath ?? "properties.name.const";
  const segments = path.split(".");

  const oneOf = unionSchema.oneOf;
  if (!Array.isArray(oneOf)) return null;

  for (const variant of oneOf) {
    if (typeof variant !== "object" || variant === null) continue;

    let current: unknown = variant;
    for (const segment of segments) {
      if (typeof current !== "object" || current === null) {
        current = undefined;
        break;
      }
      current = (current as Record<string, unknown>)[segment];
    }

    if (current === actionName) {
      return variant as Record<string, unknown>;
    }
  }

  return null;
}
