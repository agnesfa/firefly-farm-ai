import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  BasicTypeMapper,
  createStandardTypeMapper,
  createMinimalTypeMapper,
  type BasicTypeMapping,
} from './type-mapper.js';

describe('BasicTypeMapper', () => {
  describe('constructor', () => {
    it('should create empty mapper with no initial mappings', () => {
      const mapper = new BasicTypeMapper();

      expect(mapper.getSupportedTypes()).toEqual([]);
    });

    it('should create mapper with initial mappings', () => {
      const mappings = {
        STRING: { schema: z.string(), description: 'String type' },
        NUMBER: { schema: z.number(), description: 'Number type' },
      };

      const mapper = new BasicTypeMapper(mappings);

      expect(mapper.getSupportedTypes()).toEqual(['NUMBER', 'STRING']);
      expect(mapper.isSupported('STRING')).toBe(true);
      expect(mapper.isSupported('NUMBER')).toBe(true);
    });
  });

  describe('addMapping', () => {
    it('should add new type mapping', () => {
      const mapper = new BasicTypeMapper();
      const mapping: BasicTypeMapping = {
        schema: z.string(),
        description: 'Test string type',
      };

      mapper.addMapping('TEST_STRING', mapping);

      expect(mapper.isSupported('TEST_STRING')).toBe(true);
      expect(mapper.getSupportedTypes()).toEqual(['TEST_STRING']);
    });

    it('should update existing type mapping', () => {
      const mapper = new BasicTypeMapper({
        STRING: { schema: z.string(), description: 'Old description' },
      });

      const newMapping: BasicTypeMapping = {
        schema: z.string().min(5),
        description: 'New description with min length',
      };

      mapper.addMapping('STRING', newMapping);

      expect(mapper.getMappingInfo('STRING')).toEqual(newMapping);
    });
  });

  describe('removeMapping', () => {
    it('should remove existing type mapping', () => {
      const mapper = new BasicTypeMapper({
        STRING: { schema: z.string() },
        NUMBER: { schema: z.number() },
      });

      const removed = mapper.removeMapping('STRING');

      expect(removed).toBe(true);
      expect(mapper.isSupported('STRING')).toBe(false);
      expect(mapper.getSupportedTypes()).toEqual(['NUMBER']);
    });

    it('should return false for non-existing type mapping', () => {
      const mapper = new BasicTypeMapper();

      const removed = mapper.removeMapping('NON_EXISTING');

      expect(removed).toBe(false);
    });
  });

  describe('mapType', () => {
    it('should return correct Zod schema for supported type', () => {
      const stringSchema = z.string().min(1);
      const numberSchema = z.number().positive();

      const mapper = new BasicTypeMapper({
        STRING: { schema: stringSchema },
        NUMBER: { schema: numberSchema },
      });

      expect(mapper.mapType('STRING')).toBe(stringSchema);
      expect(mapper.mapType('NUMBER')).toBe(numberSchema);
    });

    it('should throw error for unsupported type', () => {
      const mapper = new BasicTypeMapper({
        STRING: { schema: z.string() },
      });

      expect(() => mapper.mapType('UNSUPPORTED_TYPE')).toThrow(
        'Unsupported type: UNSUPPORTED_TYPE. Supported types: STRING'
      );
    });

    it('should include all supported types in error message', () => {
      const mapper = new BasicTypeMapper({
        BOOLEAN: { schema: z.boolean() },
        NUMBER: { schema: z.number() },
        STRING: { schema: z.string() },
      });

      expect(() => mapper.mapType('INVALID')).toThrow(
        'Unsupported type: INVALID. Supported types: BOOLEAN, NUMBER, STRING'
      );
    });
  });

  describe('getSupportedTypes', () => {
    it('should return empty array for empty mapper', () => {
      const mapper = new BasicTypeMapper();

      expect(mapper.getSupportedTypes()).toEqual([]);
    });

    it('should return sorted list of supported types', () => {
      const mapper = new BasicTypeMapper({
        ZEBRA: { schema: z.string() },
        ALPHA: { schema: z.string() },
        BETA: { schema: z.number() },
      });

      expect(mapper.getSupportedTypes()).toEqual(['ALPHA', 'BETA', 'ZEBRA']);
    });
  });

  describe('isSupported', () => {
    it('should return true for supported types', () => {
      const mapper = new BasicTypeMapper({
        STRING: { schema: z.string() },
        NUMBER: { schema: z.number() },
      });

      expect(mapper.isSupported('STRING')).toBe(true);
      expect(mapper.isSupported('NUMBER')).toBe(true);
    });

    it('should return false for unsupported types', () => {
      const mapper = new BasicTypeMapper({
        STRING: { schema: z.string() },
      });

      expect(mapper.isSupported('NUMBER')).toBe(false);
      expect(mapper.isSupported('BOOLEAN')).toBe(false);
      expect(mapper.isSupported('')).toBe(false);
    });
  });

  describe('getMappingInfo', () => {
    it('should return mapping info for existing type', () => {
      const stringMapping: BasicTypeMapping = {
        schema: z.string().email(),
        description: 'Email address',
      };

      const mapper = new BasicTypeMapper({
        EMAIL: stringMapping,
      });

      expect(mapper.getMappingInfo('EMAIL')).toEqual(stringMapping);
    });

    it('should return undefined for non-existing type', () => {
      const mapper = new BasicTypeMapper();

      expect(mapper.getMappingInfo('NON_EXISTING')).toBeUndefined();
    });
  });
});

describe('createStandardTypeMapper', () => {
  it('should create mapper with standard types', () => {
    const mapper = createStandardTypeMapper();

    const expectedTypes = [
      'boolean',
      'date',
      'email',
      'integer',
      'number',
      'string',
      'url',
      'uuid',
    ];

    expect(mapper.getSupportedTypes()).toEqual(expectedTypes);
  });

  it('should validate standard type schemas correctly', () => {
    const mapper = createStandardTypeMapper();

    // Test string validation
    const stringSchema = mapper.mapType('string');
    expect(() => stringSchema.parse('hello')).not.toThrow();
    expect(() => stringSchema.parse(123)).toThrow();

    // Test number validation
    const numberSchema = mapper.mapType('number');
    expect(() => numberSchema.parse(123.45)).not.toThrow();
    expect(() => numberSchema.parse('123')).toThrow();

    // Test integer validation
    const integerSchema = mapper.mapType('integer');
    expect(() => integerSchema.parse(123)).not.toThrow();
    expect(() => integerSchema.parse(123.45)).toThrow();

    // Test boolean validation
    const booleanSchema = mapper.mapType('boolean');
    expect(() => booleanSchema.parse(true)).not.toThrow();
    expect(() => booleanSchema.parse('true')).toThrow();

    // Test email validation
    const emailSchema = mapper.mapType('email');
    expect(() => emailSchema.parse('test@example.com')).not.toThrow();
    expect(() => emailSchema.parse('invalid-email')).toThrow();

    // Test URL validation
    const urlSchema = mapper.mapType('url');
    expect(() => urlSchema.parse('https://example.com')).not.toThrow();
    expect(() => urlSchema.parse('invalid-url')).toThrow();

    // Test UUID validation
    const uuidSchema = mapper.mapType('uuid');
    expect(() => uuidSchema.parse('550e8400-e29b-41d4-a716-446655440000')).not.toThrow();
    expect(() => uuidSchema.parse('invalid-uuid')).toThrow();

    // Test datetime validation
    const dateSchema = mapper.mapType('date');
    expect(() => dateSchema.parse('2025-01-01T00:00:00.000Z')).not.toThrow();
    expect(() => dateSchema.parse('invalid-date')).toThrow();
  });

  it('should have descriptions for all standard types', () => {
    const mapper = createStandardTypeMapper();
    const types = mapper.getSupportedTypes();

    types.forEach((type) => {
      const info = mapper.getMappingInfo(type);
      expect(info?.description).toBeTruthy();
    });
  });
});

describe('createMinimalTypeMapper', () => {
  it('should create mapper with minimal types', () => {
    const mapper = createMinimalTypeMapper();

    expect(mapper.getSupportedTypes()).toEqual(['boolean', 'number', 'string']);
  });

  it('should validate minimal type schemas correctly', () => {
    const mapper = createMinimalTypeMapper();

    // Test string validation
    const stringSchema = mapper.mapType('string');
    expect(() => stringSchema.parse('hello')).not.toThrow();
    expect(() => stringSchema.parse(123)).toThrow();

    // Test number validation
    const numberSchema = mapper.mapType('number');
    expect(() => numberSchema.parse(123.45)).not.toThrow();
    expect(() => numberSchema.parse('123')).toThrow();

    // Test boolean validation
    const booleanSchema = mapper.mapType('boolean');
    expect(() => booleanSchema.parse(true)).not.toThrow();
    expect(() => booleanSchema.parse('true')).toThrow();
  });

  it('should not support extended types', () => {
    const mapper = createMinimalTypeMapper();

    expect(mapper.isSupported('email')).toBe(false);
    expect(mapper.isSupported('url')).toBe(false);
    expect(mapper.isSupported('uuid')).toBe(false);
    expect(mapper.isSupported('date')).toBe(false);
    expect(mapper.isSupported('integer')).toBe(false);
  });
});

describe('Type Mapper Integration', () => {
  it('should work with dynamic type registration', () => {
    const mapper = new BasicTypeMapper();

    // Start empty
    expect(mapper.getSupportedTypes()).toEqual([]);

    // Add types dynamically
    mapper.addMapping('CUSTOM_STRING', {
      schema: z.string().min(5).max(50),
      description: 'Custom string with length constraints',
    });

    mapper.addMapping('POSITIVE_INTEGER', {
      schema: z.number().int().positive(),
      description: 'Positive integer only',
    });

    // Test usage
    expect(mapper.getSupportedTypes()).toEqual(['CUSTOM_STRING', 'POSITIVE_INTEGER']);

    const customStringSchema = mapper.mapType('CUSTOM_STRING');
    expect(() => customStringSchema.parse('Hello World')).not.toThrow();
    expect(() => customStringSchema.parse('Hi')).toThrow(); // too short

    const positiveIntSchema = mapper.mapType('POSITIVE_INTEGER');
    expect(() => positiveIntSchema.parse(42)).not.toThrow();
    expect(() => positiveIntSchema.parse(-1)).toThrow(); // not positive
    expect(() => positiveIntSchema.parse(3.14)).toThrow(); // not integer
  });
});