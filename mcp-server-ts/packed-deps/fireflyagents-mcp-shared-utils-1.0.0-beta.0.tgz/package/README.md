# Shared Utilities - Firefly Agents MCP

This package provides shared utilities for the Firefly Agents MCP monorepo, including environment management, structured logging, and common helper functions.

## 🛠️ Features

### Environment Variables (`env.ts`)

Provides a robust, validated, and type-safe environment configuration for all packages with container-ready defaults.

**Usage:**
```typescript
import { env } from '@fireflyagents/mcp-shared-utils';

console.log(`Server running on ${env.HOST}:${env.PORT}`);
console.log(`Environment: ${env.NODE_ENV}`);
```

**Available Variables:**
- `NODE_ENV` - Environment mode (development, production, test)
- `PORT` - Server port (default: 3000)
- `HOST` - Server host binding (default: 0.0.0.0)
- `REDIS_URL` - Redis connection string (optional)

### Structured Logger (`logger.ts`)

Centralized, structured logging using Winston with JSON formatting for production and human-readable format for development.

**Basic Usage:**
```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';

logger.info('Application started');
logger.error('Something went wrong', { error: err });
```

**Child Loggers (Recommended):**
```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';

const moduleLogger = logger.child({ context: 'AuthService' });
moduleLogger.info('User authenticated', { userId: '123' });
```

**Log Levels:**
- `error` - Error conditions
- `warn` - Warning conditions  
- `info` - Informational messages
- `debug` - Debug-level messages

### Package Information (`package.ts`)

Utilities for accessing package metadata and version information.

```typescript
import { getPackageInfo } from '@fireflyagents/mcp-shared-utils';

const info = getPackageInfo();
console.log(`Version: ${info.version}`);
```

### Tool Helpers (`tool/tool-helpers.ts`)

Common utilities for MCP tool development and validation.

```typescript
import { validateToolInput } from '@fireflyagents/mcp-shared-utils';

const isValid = validateToolInput(schema, input);
```

## 🐳 Container Compatibility

This package is optimized for containerized deployments:

- **Environment Detection**: Automatically detects container environments
- **Logging Format**: JSON in production, human-readable in development
- **Configuration**: Container-friendly defaults for Railway, Docker, Kubernetes

## 📦 Installation

This package is automatically installed as part of the monorepo workspace.

```bash
# Install workspace dependencies
npm install
```

## 🔧 Development

### Building
```bash
npm run build
```

### Type Checking
```bash
npm run type-check
```

### Testing
```bash
npm run test
```

## 🏗️ Architecture

The shared utilities follow these patterns:

- **Environment-First**: All configuration via environment variables
- **Structured Logging**: JSON output for production monitoring
- **Type Safety**: Full TypeScript coverage with strict checks
- **Container Ready**: Optimized for Docker and cloud deployment

## 📚 API Reference

### Environment (`env`)
- Type-safe environment variable access
- Validation and defaults
- Container deployment compatibility

### Logger (`logger`)
- Winston-based structured logging
- Child logger support for context
- Environment-aware formatting

### Package (`getPackageInfo()`)
- Package metadata access
- Version information
- Build details

### Tool Helpers
- Input validation utilities
- Schema helpers
- Error handling patterns

## 🤝 Contributing

When adding new utilities:

1. Maintain TypeScript strict compliance
2. Add comprehensive JSDoc comments
3. Include unit tests
4. Ensure container compatibility
5. Update this README

---

Part of the [Firefly Agents MCP](../../README.md) monorepo.
