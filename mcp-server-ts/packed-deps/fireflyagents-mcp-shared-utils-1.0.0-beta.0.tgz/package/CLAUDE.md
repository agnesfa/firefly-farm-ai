# MCP Shared Utilities

Common utilities and helper functions used across the MCP server framework. Provides HTTP client, logging, schema validation, and environment handling.

## Package Purpose

**Location:** `packages/shared/utils/`
**Package:** `@fireflyagents/mcp-shared-utils`
**Role:** Foundation utilities layer

### What This Package Provides
- **HTTP Client** - Axios-based client with logging and error handling
- **GraphQL Client** - Full GraphQL over HTTP implementation
- **Logger** - Winston-based structured logging
- **Schema Utilities** - Dynamic schema building and validation
- **Environment Handling** - Dotenv integration and validation
- **File Utilities** - Safe file operations
- **Package Utilities** - Version and metadata reading

### Design Principles
- **Framework-Agnostic**: Utilities usable in any context
- **Production-Ready**: Comprehensive error handling and logging
- **Type-Safe**: Full TypeScript support
- **No Business Logic**: Pure utility functions only

## HTTP Client

**Location:** `src/http/`

Generic HTTP client with Axios backend, providing consistent patterns across framework:

### Features
- **Complete Methods**: GET, POST, GraphQL fully implemented
- **Stubbed Methods**: PUT, DELETE with meaningful error messages
- **Automatic Logging**: Request/response timing and details
- **Error Handling**: Axios errors converted to `HttpClientError`
- **TypeScript Support**: Full generic type inference
- **Configuration**: Base URLs, timeouts, headers, retries

### Usage Pattern

```typescript
import { createHttpClient } from '@fireflyagents/mcp-shared-utils';

// Create configured client
const client = createHttpClient({
  baseURL: 'https://api.example.com',
  timeout: 5000,
  headers: {
    'Authorization': 'Bearer token',
    'Content-Type': 'application/json'
  }
});

// REST API calls
const data = await client.get<MyResponse>('/users/123');
const result = await client.post<CreateResponse>('/users', { name: 'John' });

// GraphQL calls
const gqlResult = await client.graphql<QueryResponse>(`
  query GetUser($id: ID!) {
    user(id: $id) {
      id
      name
      email
    }
  }
`, { id: '123' });
```

### Configuration Options

```typescript
interface HttpClientConfig {
  baseURL?: string;           // Base URL for all requests
  timeout?: number;           // Request timeout in ms (default: 30000)
  headers?: Record<string, string>;  // Default headers
  validateStatus?: (status: number) => boolean;  // Custom status validation
  maxRedirects?: number;      // Max redirects to follow
  proxy?: ProxyConfig;        // Proxy configuration
}
```

### Error Handling

```typescript
import { HttpClientError } from '@fireflyagents/mcp-shared-utils';

try {
  const data = await client.get('/api/data');
} catch (error) {
  if (error instanceof HttpClientError) {
    console.error('HTTP Error:', error.status, error.message);
    console.error('Response:', error.response);
  }
}
```

### GraphQL Support

Full GraphQL implementation with operation type detection:

```typescript
// Query
const queryResult = await client.graphql(`
  query GetOrders($status: String) {
    orders(status: $status) { id total }
  }
`, { status: 'pending' });

// Mutation
const mutationResult = await client.graphql(`
  mutation CreateOrder($input: OrderInput!) {
    createOrder(input: $input) { id }
  }
`, { input: { items: [...] } });

// With authentication
const authClient = createHttpClient({
  headers: { 'Authorization': `Bearer ${token}` }
});
const result = await authClient.graphql(query, variables);
```

### Logging Integration

HTTP client automatically logs requests/responses using Winston logger:

```typescript
// Logs include:
// - HTTP method and URL
// - Request timing (duration)
// - Status codes
// - Error details
// - GraphQL operation types

// Log output example:
// http: GET /api/users/123 → 200 (142ms)
// http: POST /graphql (query GetUser) → 200 (89ms)
// error: GET /api/data → 404: Not Found
```

## GraphQL Client

**Location:** `src/graphql/`

Specialized GraphQL client building on HTTP client:

### Features
- **Operation Detection**: Automatic query/mutation/subscription detection
- **Type Safety**: Generic type support for responses
- **Error Handling**: GraphQL-specific error parsing
- **Fragment Support**: Reusable GraphQL fragments
- **Flatten Utility**: Deep GraphQL response flattening

### Usage

```typescript
import { FluentGraphQLClient } from '@fireflyagents/mcp-shared-utils';

const client = new FluentGraphQLClient({
  endpoint: 'https://api.example.com/graphql',
  headers: {
    'Authorization': 'Bearer token',
    'X-Account': 'account-id'
  }
});

const result = await client.graphql<OrdersResponse>(
  GET_ORDERS_QUERY,
  { customerToken: 'abc123' }
);
```

### Fragment Pattern

```typescript
// Define reusable fragments
const ORDER_FRAGMENT = `
  fragment OrderFields on Order {
    id
    ref
    totalPrice
    status
  }
`;

// Use in queries
const GET_ORDERS = `
  ${ORDER_FRAGMENT}
  query GetOrders($token: String!) {
    orders(customerToken: $token) {
      ...OrderFields
    }
  }
`;
```

### Flatten Utility

Deep flatten GraphQL responses to extract nested data:

```typescript
import { flattenGraphQLResponse } from '@fireflyagents/mcp-shared-utils';

const response = {
  data: {
    order: {
      edges: [
        { node: { id: '1', name: 'Order 1' } },
        { node: { id: '2', name: 'Order 2' } }
      ]
    }
  }
};

const flattened = flattenGraphQLResponse(response);
// Returns: [{ id: '1', name: 'Order 1' }, { id: '2', name: 'Order 2' }]
```

## Logger

**Location:** `src/logger/`

Winston-based structured logging with hierarchical context:

### Features
- **Structured Logging**: JSON-formatted with context metadata
- **Multiple Transports**: Console, file, external services
- **Log Levels**: error, warn, info, http, debug, trace
- **Child Loggers**: Hierarchical context naming
- **Production-Ready**: Configurable via environment

### Usage Pattern

```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';

// Create child logger with context
const componentLogger = logger.child({
  context: 'App:MyComponent'
});

// Log at different levels
componentLogger.info('Operation started', { userId: '123' });
componentLogger.debug('Processing data', { records: 42 });
componentLogger.error('Operation failed', { error: err.message });
componentLogger.http('GET /api/users → 200', { duration: 142 });
```

### Context Naming Convention

Hierarchical naming for operational visibility:

```typescript
// Framework components
'Core:SessionManager'
'Core:TransportStore'
'Core:Auth:ApiKeyStore'

// Application components
'App:Demo:ApiKeyStore'
'App:Minimal:Application'

// Plugin components
'Plugin:DemoPlugin:PartnerTools'

// Tool components
'Core:ToolName'
'App:AppName:ToolName'
'Plugin:PluginName:ToolName'
```

### Environment Configuration

```bash
# Log level (error, warn, info, http, debug, trace)
LOG_LEVEL=http         # Development (all requests)
LOG_LEVEL=info         # Production (essential events)
LOG_LEVEL=debug        # Debugging (detailed info)

# Log format
LOG_FORMAT=json        # Structured JSON
LOG_FORMAT=simple      # Human-readable
```

### Log Output Structure

```json
{
  "level": "info",
  "message": "Session created",
  "context": "Core:SessionManager",
  "sessionId": "sess-123",
  "tenantId": "tenant-1",
  "timestamp": "2025-10-02T14:30:00.000Z"
}
```

## Schema Utilities

**Location:** `src/schema/`

Dynamic schema building and validation for structured outputs:

### Dynamic Union Builder

Build Zod union schemas from runtime arrays:

```typescript
import { buildDynamicUnion } from '@fireflyagents/mcp-shared-utils';

const actionSchemas = [
  { type: 'send_email', schema: sendEmailSchema },
  { type: 'create_ticket', schema: createTicketSchema }
];

const unionSchema = buildDynamicUnion(actionSchemas);
```

### Type Mapper

Map platform attribute types (STRING, BOOLEAN, INTEGER, custom) to Zod schemas and JSON Schema:

```typescript
import { createStandardTypeMapper, enhanceTypeMapperWithJsonSchemas } from '@fireflyagents/mcp-shared-utils';

// Create mapper with standard types
const typeMapper = createStandardTypeMapper();
typeMapper.isSupported('STRING');  // true
typeMapper.isSupported('ADDRESS'); // false (custom, not yet registered)

// Enhance with custom JSON Schemas
const customSchemas = new Map([['ADDRESS', addressJsonSchema]]);
enhanceTypeMapperWithJsonSchemas(typeMapper, customSchemas);
typeMapper.isSupported('ADDRESS'); // true
```

### JSON Schema Utilities

Extract specific variants from JSON Schema unions:

```typescript
import { extractVariantSchema, validateJsonSchema } from '@fireflyagents/mcp-shared-utils';

// Extract a specific variant from a oneOf union by discriminator value
const variant = extractVariantSchema(unionSchema, 'OrderCancel');
// Returns the matching variant schema, or null if not found

// Validate data against a JSON Schema using AJV
validateJsonSchema(schema, data); // throws on validation failure
```

### Runtime Action Validator

Validate workflow actions at runtime:

```typescript
import { validateAction } from '@fireflyagents/mcp-shared-utils';

const result = validateAction(actionData, actionSchemas);
if (!result.valid) {
  throw new Error(`Invalid action: ${result.errors.join(', ')}`);
}
```

## Response Utilities

**Location:** `src/response/`

### StructuredResponseBuilder

Build MCP tool responses with optional schema validation:

```typescript
import { StructuredResponseBuilder } from '@fireflyagents/mcp-shared-utils';

// Success response with schema validation
return StructuredResponseBuilder.buildResponse(data, outputSchema);

// Error response (standardized error format)
return StructuredResponseBuilder.buildErrorResponse(error);
```

## Environment Utilities

**Location:** `src/env/`

Safe environment variable handling with dotenv integration:

### Usage

```typescript
import { loadEnv, getRequiredEnv, getOptionalEnv } from '@fireflyagents/mcp-shared-utils';

// Load .env file
loadEnv();

// Required variables (throws if missing)
const apiKey = getRequiredEnv('API_KEY');
const dbUrl = getRequiredEnv('DATABASE_URL');

// Optional variables with defaults
const port = getOptionalEnv('PORT', '3000');
const logLevel = getOptionalEnv('LOG_LEVEL', 'info');
```

### Validation

```typescript
import { validateEnv } from '@fireflyagents/mcp-shared-utils';

// Validate required environment variables
validateEnv(['API_KEY', 'DATABASE_URL', 'PORT']);
// Throws if any are missing
```

## File Utilities

**Location:** `src/file/`

Safe file operations with error handling:

### Usage

```typescript
import {
  readJsonFile,
  writeJsonFile,
  fileExists
} from '@fireflyagents/mcp-shared-utils';

// Read JSON file
const config = await readJsonFile<Config>('./config.json');

// Write JSON file
await writeJsonFile('./output.json', { data: 'value' });

// Check existence
if (await fileExists('./credentials.json')) {
  // File exists
}
```

## Package Utilities

**Location:** `src/package/`

Read package.json metadata at runtime:

### Usage

```typescript
import { getPackageInfo } from '@fireflyagents/mcp-shared-utils';

const info = await getPackageInfo();
console.log(`${info.name} v${info.version}`);

// Access package.json fields
console.log('Author:', info.author);
console.log('License:', info.license);
```

## Testing

Shared utils have comprehensive test coverage:

```bash
npm run test --workspace=@fireflyagents/mcp-shared-utils
```

**Test Coverage Areas:**
- HTTP client (20 tests): GET, POST, GraphQL, error handling
- Logger: Context naming, log levels, transports
- Schema utilities: Union building, type mapping, validation
- Environment: Variable loading, validation, defaults
- File operations: Read, write, existence checks

## Integration with Framework

**Used By:**
- `@fireflyagents/mcp-server-core` - HTTP client, logger, schema utils
- `@fireflyagents/mcp-server-plugin-sdk` - Logger, file utilities
- All applications and plugins - HTTP client for API calls

**Import Pattern:**
```typescript
// ✅ Direct imports from package
import {
  createHttpClient,
  logger,
  validateAgainstSchema
} from '@fireflyagents/mcp-shared-utils';
```

## Common Patterns

### HTTP Client in Tools

```typescript
import { createHttpClient } from '@fireflyagents/mcp-shared-utils';

const handler: ToolHandler = async ({ query }, extra) => {
  const client = createHttpClient({
    baseURL: process.env.API_BASE_URL,
    headers: {
      'Authorization': `Bearer ${extra.authInfo?.token}`
    }
  });

  const data = await client.get(`/search?q=${query}`);

  return {
    content: [{ type: "text", text: JSON.stringify(data) }]
  };
};
```

### Structured Logging in Components

```typescript
import { logger } from '@fireflyagents/mcp-shared-utils';

class MyComponent {
  private logger = logger.child({ context: 'App:MyComponent' });

  async processData(input: Data) {
    this.logger.info('Processing started', { recordCount: input.length });

    try {
      const result = await this.process(input);
      this.logger.info('Processing completed', { resultSize: result.length });
      return result;
    } catch (error) {
      this.logger.error('Processing failed', { error: error.message });
      throw error;
    }
  }
}
```

### GraphQL Tool Pattern

```typescript
import { FluentGraphQLClient } from '@fireflyagents/mcp-shared-utils';

const handler: ToolHandler = async ({ customerId }, extra) => {
  const client = new FluentGraphQLClient({
    endpoint: process.env.GRAPHQL_ENDPOINT,
    headers: {
      'Authorization': `Bearer ${extra.authInfo?.token}`
    }
  });

  const result = await client.graphql(GET_CUSTOMER_QUERY, { customerId });

  return {
    content: [{ type: "text", text: JSON.stringify(result.data) }]
  };
};
```

## Architecture Benefits

1. **Consistency**: All HTTP calls use same client, logging, error handling
2. **Distribution Friendly**: Works with push-based distribution model
3. **Framework Integration**: Leverages structured logging and patterns
4. **Plugin Support**: Plugins get standardized utilities automatically
5. **Maintainable**: Single implementation, consistent patterns throughout

---

**For framework usage, see `packages/server/core/CLAUDE.md`**
**For application usage, see `apps/demo-server/CLAUDE.md`**
