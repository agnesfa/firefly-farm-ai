# Shared Types - Firefly Agents MCP

Common TypeScript type definitions and interfaces used across the Firefly Agents MCP monorepo, providing type safety and consistency for MCP protocol implementation.

## 🛠️ Overview

This package provides comprehensive type definitions for:

- **MCP Protocol** - Server, transport, and tool interfaces
- **Authentication** - User and session management types
- **Server Configuration** - Environment and setup types
- **Context Management** - Request context and metadata
- **Tool System** - Tool registration and execution types

## 📦 Types Reference

### MCP Server (`mcp-server.ts`)

Core MCP server interface and configuration types:

```typescript
import { McpServerConfig, McpServerFactoryOptions } from '@fireflyagents/mcp-server-types';

interface McpServerConfig {
  name: string;
  version: string;
  registrars: ToolRegistrar[];
}
```

### Authentication (`auth.ts`)

User authentication and session management:

```typescript
import { User, AuthContext, SessionData } from '@fireflyagents/mcp-server-types';

interface User {
  id: string;
  email?: string;
  roles: string[];
}

interface SessionData {
  userId: string;
  createdAt: Date;
  expiresAt: Date;
}
```

### Server Configuration (`server.ts`)

Server setup and environment configuration:

```typescript
import { ServerConfig, HealthCheckConfig } from '@fireflyagents/mcp-server-types';

interface ServerConfig {
  port: number;
  host: string;
  environment: 'development' | 'production' | 'test';
  redis?: RedisConfig;
}
```

### Transport Layer (`transports.ts`)

MCP transport and communication types:

```typescript
import { TransportConfig, SessionTransport } from '@fireflyagents/mcp-server-types';

interface SessionTransport {
  sessionId: string;
  transport: Transport;
  createdAt: Date;
  lastUsed: Date;
}
```

### Tool System (`tool.ts`)

Tool registration and execution interfaces:

```typescript
import { ToolDefinition, ToolRegistrar, ToolExecutionContext } from '@fireflyagents/mcp-server-types';

interface ToolDefinition<T = any, R = any> {
  name: string;
  description: string;
  inputSchema: ZodSchema<T>;
  handler: (input: T, context: ToolExecutionContext) => Promise<R>;
}
```

### Context Management (`context.ts`)

Request context and metadata handling:

```typescript
import { RequestContext, ExecutionContext } from '@fireflyagents/mcp-server-types';

interface RequestContext {
  sessionId?: string;
  userId?: string;
  timestamp: Date;
  headers: Record<string, string>;
}
```

## 🐳 Container Compatibility

All types are designed for containerized deployments:

- **Environment-Aware**: Configuration types support container env vars
- **Redis-Ready**: Session and cache types support Redis backends
- **Health Monitoring**: Health check and monitoring type definitions
- **Scaling Support**: Types designed for horizontal scaling scenarios

## 🔧 Development Usage

### Importing Types

```typescript
// Import specific types
import { McpServerConfig, ToolDefinition } from '@fireflyagents/mcp-server-types';

// Import all types
import * as Types from '@fireflyagents/mcp-server-types';
```

### Type-Safe Tool Development

```typescript
import { ToolDefinition, ToolExecutionContext } from '@fireflyagents/mcp-server-types';
import { z } from 'zod';

const helloToolSchema = z.object({
  name: z.string().optional(),
});

const helloTool: ToolDefinition<z.infer<typeof helloToolSchema>, string> = {
  name: 'demo/hello',
  description: 'Greets a user',
  inputSchema: helloToolSchema,
  handler: async (input, context) => {
    return `Hello, ${input.name || 'World'}!`;
  }
};
```

### Server Configuration

```typescript
import { ServerConfig } from '@fireflyagents/mcp-server-types';

const config: ServerConfig = {
  port: 3000,
  host: '0.0.0.0',
  environment: 'production',
  redis: {
    url: process.env.REDIS_URL,
    keyPrefix: 'mcp:',
  }
};
```

## 🏗️ Architecture

### Type Organization

- **Core Types**: Fundamental MCP protocol types
- **Configuration**: Environment and setup types  
- **Authentication**: User and session management
- **Tools**: Tool system and execution types
- **Transport**: Communication layer types

### Design Principles

- **Type Safety**: Strict TypeScript compliance
- **Extensibilty**: Generic interfaces for customization
- **Container Ready**: Support for containerized deployments
- **Protocol Compliance**: Aligned with MCP specification

## 🧪 Testing

Types include comprehensive test coverage:

```bash
# Run type definition tests
npm run test

# Type checking
npm run type-check
```

## 📚 API Documentation

### Core Interfaces

| Interface | Purpose | Key Properties |
|-----------|---------|----------------|
| `McpServerConfig` | Server configuration | `name`, `version`, `registrars` |
| `ToolDefinition<T,R>` | Tool specification | `name`, `inputSchema`, `handler` |
| `SessionData` | Session information | `userId`, `createdAt`, `expiresAt` |
| `RequestContext` | Request metadata | `sessionId`, `headers`, `timestamp` |

### Generic Types

- `ToolRegistrar<T>` - Tool registration function type
- `HealthCheck<T>` - Health check definition type
- `ConfigValidator<T>` - Configuration validation type

## 🤝 Contributing

When adding new types:

1. **Follow naming conventions** - PascalCase for interfaces, camelCase for properties
2. **Add JSDoc comments** - Document all public interfaces
3. **Include tests** - Add unit tests for complex types
4. **Maintain compatibility** - Ensure backward compatibility
5. **Update documentation** - Keep README current

### Adding New Types

```typescript
// 1. Define the interface
export interface MyNewType {
  /** Description of the property */
  property: string;
  /** Optional configuration */
  config?: MyConfig;
}

// 2. Export from index.ts
export type { MyNewType } from './my-new-type.js';

// 3. Add tests
describe('MyNewType', () => {
  it('should satisfy type constraints', () => {
    // Test implementation
  });
});
```

## 🔗 Related Packages

- **[Server Core](../core/README.md)** - Uses these types for implementation
- **[Shared Utils](../../shared/utils/README.md)** - Provides utilities for these types
- **[Root Project](../../../README.md)** - Overall project documentation

---

Part of the [Firefly Agents MCP](../../../README.md) containerized monorepo providing type-safe MCP protocol implementation.